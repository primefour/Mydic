// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.adobe.adms.measurement;

import android.database.*;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import java.io.*;
import java.util.ArrayList;

// Referenced classes of package com.adobe.adms.measurement:
//            ADMS_Measurement, ADMS_RequestProperties, ADMS_RequestHandler

final class ADMS_Worker
{
    private static class CorruptDatabaseException extends Exception
    {

        CorruptDatabaseException(String s)
        {
            super(s);
        }
    }

    private static class WorkerThread extends Thread
    {

        public void run()
        {
_L9:
            if(cancelled) goto _L2; else goto _L1
_L1:
            String s;
            String s1;
            s = null;
            s1 = null;
            Object obj = ADMS_Worker.dbMutex;
            obj;
            JVM INSTR monitorenter ;
            Cursor cursor = null;
            cursor = ADMS_Worker._offlineDB.query("HITS", new String[] {
                "ID", "URL", "TIMESTAMP"
            }, null, null, null, null, "ID ASC", "1");
            String s2;
            s2 = null;
            s1 = null;
            s = null;
            if(cursor == null)
                break MISSING_BLOCK_LABEL_122;
            boolean flag1 = cursor.moveToFirst();
            s1 = null;
            s = null;
            s2 = null;
            if(!flag1)
                break MISSING_BLOCK_LABEL_122;
            String s3;
            s1 = cursor.getString(0);
            s = cursor.getString(1);
            s3 = cursor.getString(2);
            s2 = s3;
            if(cursor == null)
                break MISSING_BLOCK_LABEL_144;
            if(!cursor.isClosed())
                cursor.close();
_L5:
            obj;
            JVM INSTR monitorexit ;
            if(s != null) goto _L3; else goto _L2
_L2:
            cancelled = true;
            return;
            SQLException sqlexception;
            sqlexception;
            ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Unable to read from database(").append(sqlexception.getMessage()).append(").").toString());
            s2 = null;
            if(cursor == null) goto _L5; else goto _L4
_L4:
            boolean flag = cursor.isClosed();
            s2 = null;
            if(flag) goto _L5; else goto _L6
_L6:
            cursor.close();
            s2 = null;
              goto _L5
            Exception exception1;
            exception1;
            obj;
            JVM INSTR monitorexit ;
            throw exception1;
            Exception exception;
            exception;
            if(cursor == null)
                break MISSING_BLOCK_LABEL_261;
            if(!cursor.isClosed())
                cursor.close();
            throw exception;
_L3:
            if(worker.trackOffline || Long.parseLong(s2) >= System.currentTimeMillis() / 1000L - (long)ADMS_Worker.TIMESTAMP_DISABLED_WAIT_THRESHOLD.intValue()) goto _L8; else goto _L7
_L7:
            worker.deleteHit(s1);
_L10:
            Thread.sleep(delay);
            delay = 0L;
              goto _L9
_L8:
            ADMS_RequestProperties adms_requestproperties = new ADMS_RequestProperties(s);
            if(!ADMS_RequestHandler.sendRequest(adms_requestproperties.getUrl(), adms_requestproperties.getHeaders()))
                break MISSING_BLOCK_LABEL_372;
            worker.deleteHit(s1);
              goto _L10
            CorruptDatabaseException corruptdatabaseexception;
            corruptdatabaseexception;
            worker.resetDB(corruptdatabaseexception);
              goto _L2
label0:
            {
                if(!worker.trackOffline)
                    break label0;
                ADMS_Measurement.sharedInstance().debugLog("ADMS SDK Debug: Error Sending Hit(pausing 30 seconds before retry)");
                delay = 30000L;
            }
              goto _L10
            ADMS_Measurement.sharedInstance().debugLog("ADMS SDK Debug: Error Sending Hit(deleting hit)");
            worker.deleteHit(s1);
              goto _L10
            InterruptedException interruptedexception;
            interruptedexception;
            ADMS_Measurement.sharedInstance().debugLog("ADMS SDK Debug: Background thread interrupted");
            delay = 0L;
              goto _L9
            Exception exception2;
            exception2;
            delay = 0L;
            throw exception2;
        }

        public boolean cancelled;
        private long delay;
        private ADMS_Worker worker;

        public WorkerThread(ADMS_Worker adms_worker)
        {
            delay = 0L;
            worker = null;
            cancelled = false;
            worker = adms_worker;
        }
    }


    protected ADMS_Worker(String s)
    {
        trackOffline = false;
        offlineLimit = 1000;
        backgroundThread = null;
        offlineForced = false;
        cacheFilename = null;
        cacheFilename = s;
        createOrOpenDB();
    }

    private void killThread()
    {
        if(backgroundThread != null)
        {
            backgroundThread.cancelled = true;
            backgroundThread = null;
        }
    }

    private void resetDB(Exception exception)
    {
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Database corrupted(").append(exception.getMessage()).append(").").toString());
        Boolean boolean1 = Boolean.valueOf((new File(cacheFilename)).delete());
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Debug: Attempting to recover from database failure(delete result = ").append(boolean1).append(").").toString());
        createOrOpenDB();
    }

    protected void clearTrackingQueue()
    {
        Object obj = dbMutex;
        obj;
        JVM INSTR monitorenter ;
        long l = _offlineDB.delete("HITS", null, null);
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Debug: Tracking queue cleared(").append(l).append(" hits purged).").toString());
_L1:
        return;
        SQLException sqlexception;
        sqlexception;
        resetDB(sqlexception);
          goto _L1
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected void createOrOpenDB()
    {
        File file = new File(cacheFilename);
        Object obj = dbMutex;
        obj;
        JVM INSTR monitorenter ;
        _offlineDB = SQLiteDatabase.openOrCreateDatabase(file.getPath(), null);
        _offlineDB.execSQL("CREATE TABLE IF NOT EXISTS HITS (ID INTEGER PRIMARY KEY AUTOINCREMENT, URL TEXT, TIMESTAMP INTEGER)");
        _preparedInsertStatement = _offlineDB.compileStatement("INSERT INTO HITS (URL, TIMESTAMP) VALUES (?, ?)");
_L1:
        return;
        SQLException sqlexception;
        sqlexception;
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Unable to create database(").append(sqlexception.getLocalizedMessage()).append(").").toString());
          goto _L1
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void deleteHit(String s)
        throws CorruptDatabaseException
    {
        obj;
        JVM INSTR monitorenter ;
        int i;
        synchronized(dbMutex)
        {
            i = _offlineDB.delete("HITS", (new StringBuilder()).append("ID=").append(s).toString(), null);
        }
        SQLException sqlexception;
        if(i != 1)
            throw new CorruptDatabaseException((new StringBuilder()).append("Count mismatch when deleting hit(").append(i).append(") should have been 1.").toString());
        else
            return;
        sqlexception;
        throw new CorruptDatabaseException((new StringBuilder()).append("Exception when deleting hit(").append(sqlexception.getMessage()).append(").").toString());
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void deleteOldestHit()
    {
        Object obj = dbMutex;
        obj;
        JVM INSTR monitorenter ;
        Cursor cursor = null;
        cursor = _offlineDB.query("HITS", new String[] {
            "ID", "URL", "TIMESTAMP"
        }, null, null, null, null, "ID ASC", "1");
        if(cursor == null)
            break MISSING_BLOCK_LABEL_72;
        boolean flag = cursor.moveToFirst();
        if(!flag)
            break MISSING_BLOCK_LABEL_72;
        deleteHit(cursor.getString(0));
_L1:
        if(cursor == null)
            break MISSING_BLOCK_LABEL_91;
        if(!cursor.isClosed())
            cursor.close();
_L3:
        obj;
        JVM INSTR monitorexit ;
        return;
        CorruptDatabaseException corruptdatabaseexception;
        corruptdatabaseexception;
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Database corruption error(").append(corruptdatabaseexception.getMessage()).append(")").toString());
          goto _L1
        SQLException sqlexception;
        sqlexception;
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Unable to delete hit(").append(sqlexception.getMessage()).append(")").toString());
        if(cursor == null) goto _L3; else goto _L2
_L2:
        if(cursor.isClosed()) goto _L3; else goto _L4
_L4:
        cursor.close();
          goto _L3
        Exception exception1;
        exception1;
        obj;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception;
        exception;
        if(cursor == null)
            break MISSING_BLOCK_LABEL_218;
        if(!cursor.isClosed())
            cursor.close();
        throw exception;
          goto _L1
    }

    protected int getTrackingQueueSize()
    {
        Object obj = dbMutex;
        obj;
        JVM INSTR monitorenter ;
        long l = 0L;
        long l1 = DatabaseUtils.queryNumEntries(_offlineDB, "HITS");
        l = l1;
_L2:
        int i = (int)l;
        obj;
        JVM INSTR monitorexit ;
        return i;
        SQLException sqlexception;
        sqlexception;
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Cannot query database count (").append(sqlexception.getLocalizedMessage()).append(")").toString());
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void queue(String s)
    {
        if(trackOffline || !offlineForced) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if(getTrackingQueueSize() >= offlineLimit)
            deleteOldestHit();
        Object obj = dbMutex;
        obj;
        JVM INSTR monitorenter ;
        _preparedInsertStatement.bindString(1, s);
        _preparedInsertStatement.bindLong(2, System.currentTimeMillis() / 1000L);
        _preparedInsertStatement.execute();
_L3:
        _preparedInsertStatement.clearBindings();
        if(!offlineForced)
        {
            setOnline(true);
            return;
        }
        continue; /* Loop/switch isn't completed */
        SQLException sqlexception;
        sqlexception;
        ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS Error: Unable to insert hit(").append(s).append("), exception(").append(sqlexception.getLocalizedMessage()).append(").").toString());
        resetDB(sqlexception);
          goto _L3
        Exception exception;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
        if(true) goto _L1; else goto _L4
_L4:
    }

    protected void setOnline(boolean flag)
    {
label0:
        {
            if(!flag)
                break MISSING_BLOCK_LABEL_91;
            synchronized(backgroundMutex)
            {
                if(backgroundThread == null || backgroundThread.cancelled)
                    break label0;
            }
            return;
        }
        if(backgroundThread == null || backgroundThread.cancelled)
        {
            killThread();
            backgroundThread = new WorkerThread(this);
            backgroundThread.start();
        }
        offlineForced = false;
        obj1;
        JVM INSTR monitorexit ;
        return;
        exception1;
        obj1;
        JVM INSTR monitorexit ;
        throw exception1;
        synchronized(backgroundMutex)
        {
            if(backgroundThread != null && !backgroundThread.cancelled)
                killThread();
        }
        offlineForced = true;
        return;
        exception;
        obj;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected void upgradeQueueToSQL(String s)
    {
        if(s != null) goto _L2; else goto _L1
_L1:
        File file;
        return;
_L2:
        if((file = new File(s)) == null || !file.exists()) goto _L1; else goto _L3
_L3:
        ADMS_Measurement.sharedInstance().debugLog("ADMS SDK Debug: Upgrading offline storage to SQLite");
        BufferedReader bufferedreader;
        ArrayList arraylist;
        bufferedreader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));
        arraylist = new ArrayList();
_L4:
        String s1 = bufferedreader.readLine();
label0:
        {
            if(s1 == null)
                break label0;
            try
            {
                arraylist.add(s1);
            }
            catch(IOException ioexception)
            {
                ADMS_Measurement.sharedInstance().debugLog((new StringBuilder()).append("ADMS SDK Error: Cannot Read Requests From Disk(").append(ioexception.getMessage()).append(").").toString());
                return;
            }
        }
          goto _L4
        int i;
        try
        {
            file.delete();
        }
        catch(Exception exception) { }
        if(file.exists()) goto _L6; else goto _L5
_L5:
        i = 0;
_L7:
        if(i >= arraylist.size())
            break; /* Loop/switch isn't completed */
        queue((String)arraylist.get(i));
        i++;
        if(true) goto _L7; else goto _L6
_L6:
        bufferedreader.close();
        return;
    }

    private static Integer TIMESTAMP_DISABLED_WAIT_THRESHOLD = Integer.valueOf(5);
    private static SQLiteDatabase _offlineDB;
    public static final Object dbMutex = new Object();
    private SQLiteStatement _preparedInsertStatement;
    private final Object backgroundMutex = new Object();
    private WorkerThread backgroundThread;
    public String cacheFilename;
    private boolean offlineForced;
    protected int offlineLimit;
    protected boolean trackOffline;




}
