// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.adobe.adms.testandtarget;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import java.io.*;
import java.net.URLEncoder;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import org.apache.http.*;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;

// Referenced classes of package com.adobe.adms.testandtarget:
//            Mbox

public final class MboxFactory
{
    private class RecordEventTask
        implements Runnable
    {

        public void run()
        {
            DefaultHttpClient defaulthttpclient = new DefaultHttpClient();
            HttpGet httpget = new HttpGet(url);
            httpget.setHeader("User-Agent", "Apache-HttpClient (Test&Target Android SDK)");
            if(cookies != null)
                httpget.setHeader("Cookie", cookies);
            try
            {
                defaulthttpclient.execute(httpget);
                saveCookies(defaulthttpclient.getCookieStore());
                return;
            }
            catch(ClientProtocolException clientprotocolexception)
            {
                Log.e("MboxFactory", (new StringBuilder()).append("EXCEPTION: ").append(clientprotocolexception.toString()).toString());
                return;
            }
            catch(IOException ioexception)
            {
                Log.e("MboxFactory", (new StringBuilder()).append("EXCEPTION: ").append(ioexception.toString()).toString());
            }
        }

        final MboxFactory this$0;
        public String url;

        public RecordEventTask(String s)
        {
            this$0 = MboxFactory.this;
            super();
            url = s;
        }
    }

    private class TargetBackgroundTask
        implements Runnable
    {

        public void run()
        {
            DefaultHttpClient defaulthttpclient;
            HttpGet httpget;
            InputStream inputstream;
            ByteArrayOutputStream bytearrayoutputstream;
            defaulthttpclient = new DefaultHttpClient();
            httpget = new HttpGet(url);
            httpget.setHeader("User-Agent", "Apache-HttpClient (Test&Target Android SDK)");
            if(cookies != null)
                httpget.setHeader("Cookie", cookies);
            inputstream = null;
            bytearrayoutputstream = null;
            HttpResponse httpresponse;
            int i;
            String s;
            httpresponse = defaulthttpclient.execute(httpget);
            i = httpresponse.getStatusLine().getStatusCode();
            s = httpresponse.getFirstHeader("Content-Type").getValue();
            saveCookies(defaulthttpclient.getCookieStore());
            if(i != 200) goto _L2; else goto _L1
_L1:
            if(!s.equals("image/gif")) goto _L3; else goto _L2
_L2:
            callback.call("/images/log.gif");
_L7:
            IOException ioexception;
            Exception exception;
            ByteArrayOutputStream bytearrayoutputstream1;
            byte abyte0[];
            int j;
            try
            {
                inputstream.close();
                bytearrayoutputstream.close();
                return;
            }
            catch(Exception exception3)
            {
                return;
            }
_L3:
            inputstream = httpresponse.getEntity().getContent();
            bytearrayoutputstream1 = new ByteArrayOutputStream();
            abyte0 = new byte[512];
_L6:
            j = inputstream.read(abyte0);
            if(j == -1) goto _L5; else goto _L4
_L4:
            bytearrayoutputstream1.write(abyte0, 0, j);
              goto _L6
            ioexception;
            bytearrayoutputstream = bytearrayoutputstream1;
_L10:
            Log.e("MboxFactory", (new StringBuilder()).append("ERROR: ").append(ioexception.toString()).toString());
            callback.call("/images/log.gif");
            try
            {
                inputstream.close();
                bytearrayoutputstream.close();
                return;
            }
            catch(Exception exception2)
            {
                return;
            }
_L5:
            callback.call(new String(bytearrayoutputstream1.toByteArray(), "UTF-8"));
            bytearrayoutputstream = bytearrayoutputstream1;
              goto _L7
            exception;
_L9:
            try
            {
                inputstream.close();
                bytearrayoutputstream.close();
            }
            catch(Exception exception1) { }
            throw exception;
            exception;
            bytearrayoutputstream = bytearrayoutputstream1;
            if(true) goto _L9; else goto _L8
_L8:
            ioexception;
            bytearrayoutputstream = null;
              goto _L10
        }

        public TargetCallback callback;
        final MboxFactory this$0;
        public String url;

        public TargetBackgroundTask(Mbox mbox, String s, TargetCallback targetcallback)
        {
            this$0 = MboxFactory.this;
            super();
            url = s;
            callback = targetcallback;
        }
    }

    protected static interface TargetCallback
    {

        public abstract void call(Object obj);
    }


    public MboxFactory(Context context, String s)
    {
        mboxList = new ConcurrentHashMap();
        if(context == null)
        {
            Log.d("TARGET", "Parameter 'parentContext' in MboxFactory() cannot be null");
            return;
        }
        if(s == null || s.length() == 0)
        {
            Log.d("TARGET", "Parameter 'clientCode' in MboxFactory() cannot be null or empty");
            return;
        } else
        {
            parentContext = context;
            clientCode = s;
            disableDuration = 0xdbba0L;
            factoryEnabled = true;
            mboxServerURL = (new StringBuilder()).append("http://").append(s).append(".tt.omtrdc.net").toString();
            preferences = context.getSharedPreferences((new StringBuilder()).append("TestAndTarget").append(s).toString(), 0);
            loadCookie("mboxPC");
            loadCookie("mboxSession");
            return;
        }
    }

    private void deleteCookie(String s)
    {
        android.content.SharedPreferences.Editor editor = preferences.edit();
        editor.remove((new StringBuilder()).append(s).append("_Value").toString());
        editor.remove((new StringBuilder()).append(s).append("_Expires").toString());
        editor.commit();
    }

    private void loadCookie(String s)
    {
        this;
        JVM INSTR monitorenter ;
        long l;
        long l1;
        l = System.currentTimeMillis();
        l1 = preferences.getLong((new StringBuilder()).append(s).append("_Expires").toString(), 0L);
        if(l1 <= 0L) goto _L2; else goto _L1
_L1:
        if(l1 <= l)
            break MISSING_BLOCK_LABEL_169;
        String s1 = preferences.getString((new StringBuilder()).append(s).append("_Value").toString(), "");
        if(cookies != null) goto _L4; else goto _L3
_L3:
        cookies = (new StringBuilder()).append(s).append("=").append(s1).toString();
_L2:
        this;
        JVM INSTR monitorexit ;
        return;
_L4:
        cookies = (new StringBuilder()).append(cookies).append("; ").append(s).append("=").append(s1).toString();
          goto _L2
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        deleteCookie(s);
          goto _L2
    }

    private void saveCookies(CookieStore cookiestore)
    {
        this;
        JVM INSTR monitorenter ;
        Iterator iterator = cookiestore.getCookies().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Cookie cookie = (Cookie)iterator.next();
            String s = cookie.getName();
            if(s.equals("mboxSession") || s.equals("mboxPC"))
                storeCookie(s, cookie);
        } while(true);
        break MISSING_BLOCK_LABEL_79;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        loadCookie("mboxPC");
        loadCookie("mboxSession");
        this;
        JVM INSTR monitorexit ;
    }

    private void storeCookie(String s, Cookie cookie)
    {
        this;
        JVM INSTR monitorenter ;
        this;
        JVM INSTR monitorenter ;
        android.content.SharedPreferences.Editor editor = preferences.edit();
        editor.putString((new StringBuilder()).append(s).append("_Value").toString(), cookie.getValue());
        editor.putLong((new StringBuilder()).append(s).append("_Expires").toString(), cookie.getExpiryDate().getTime());
        editor.commit();
        this;
        JVM INSTR monitorexit ;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception1;
        exception1;
        this;
        JVM INSTR monitorexit ;
        throw exception1;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public void clearCookies()
    {
        cookies = null;
        deleteCookie("mboxPC");
        deleteCookie("mboxSession");
    }

    public Mbox create(String s)
    {
        if(s == null || s.length() == 0)
        {
            Log.d("TARGET", "Parameter 'mboxName' in create() cannot be null or empty");
            return null;
        } else
        {
            Mbox mbox = new Mbox(this, s);
            mboxList.put(s, mbox);
            return mbox;
        }
    }

    public void disable()
    {
        this;
        JVM INSTR monitorenter ;
        factoryEnabled = false;
        long l = System.currentTimeMillis();
        android.content.SharedPreferences.Editor editor = preferences.edit();
        editor.putLong("DisableTime", l);
        editor.commit();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
    }

    protected String encode(String s)
    {
        String s1;
        try
        {
            s1 = URLEncoder.encode(s, "UTF-8");
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            Log.e("MboxFactory", unsupportedencodingexception.toString());
            return s;
        }
        return s1;
    }

    protected String getBaseRequestURL()
    {
        return (new StringBuilder()).append(mboxServerURL).append("/m2/").append(clientCode).append("/ubox/raw?").toString();
    }

    protected String getCookies()
    {
        return cookies;
    }

    protected void getMboxResponse(final Mbox mbox, String s)
    {
        this;
        JVM INSTR monitorenter ;
        (new Thread(new TargetBackgroundTask(mbox, s, new TargetCallback() {

            public volatile void call(Object obj)
            {
                call((String)obj);
            }

            public void call(String s1)
            {
                mbox.callOnLoadConsumers(s1);
            }

            final MboxFactory this$0;
            final Mbox val$mbox;

            
            {
                this$0 = MboxFactory.this;
                mbox = mbox1;
                super();
            }
        }))).start();
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    protected boolean isEnabled()
    {
        this;
        JVM INSTR monitorenter ;
        long l;
        if(preferences == null)
            preferences = parentContext.getSharedPreferences((new StringBuilder()).append("TestAndTarget").append(clientCode).toString(), 0);
        l = preferences.getLong("DisableTime", 0L);
        if(l <= 0L)
            break MISSING_BLOCK_LABEL_125;
        long l1 = System.currentTimeMillis() - l;
        if(l1 >= disableDuration)
            break MISSING_BLOCK_LABEL_136;
        Log.w("MboxFactory", (new StringBuilder()).append("WARNING: ").append(String.valueOf(disableDuration - l1)).append("ms until MboxFactory is re-enabled.").toString());
        factoryEnabled = false;
_L1:
        boolean flag = factoryEnabled;
        this;
        JVM INSTR monitorexit ;
        return flag;
        factoryEnabled = true;
          goto _L1
        Exception exception;
        exception;
        throw exception;
    }

    public void recordEvent(String s)
    {
        String s1 = String.valueOf(System.currentTimeMillis());
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(getBaseRequestURL()).append("mbox=").append(encode(s)).append("&mboxDefault=").append(encode("/images/log.gif")).append("&mboxTime=").append(s1);
        (new Thread(new RecordEventTask(stringbuilder.toString()))).start();
    }

    public void setDisableDuration(long l)
    {
        this;
        JVM INSTR monitorenter ;
        disableDuration = l;
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    private static final int BUFFER_SIZE = 512;
    private static final String COOKIE_EXPIRES_KEY_SUFFIX = "_Expires";
    private static final String COOKIE_VALUE_KEY_SUFFIX = "_Value";
    private static final long DEFAULT_DISABLE_DURATION = 0xdbba0L;
    private static final String LOG_TAG = "MboxFactory";
    private static final String MBOX_DEFAULT = "/images/log.gif";
    private static final String MBOX_DEFAULT_CONTENT_TYPE = "image/gif";
    private static final String MBOX_SERVER_PROTOCOL = "http://";
    private static final String MBOX_SERVER_SUFFIX = ".tt.omtrdc.net";
    private static final String OFFER_ENCODING = "UTF-8";
    private static final String PREFERENCES_DISABLE_KEY = "DisableTime";
    private static final String PREFERENCES_PREFIX = "TestAndTarget";
    protected static final String USER_AGENT = "Apache-HttpClient (Test&Target Android SDK)";
    private String clientCode;
    private String cookies;
    private long disableDuration;
    private boolean factoryEnabled;
    private ConcurrentHashMap mboxList;
    private String mboxServerURL;
    private Context parentContext;
    private SharedPreferences preferences;


}
