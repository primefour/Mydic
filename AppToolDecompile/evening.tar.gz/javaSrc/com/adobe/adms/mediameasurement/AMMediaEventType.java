// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.adobe.adms.mediameasurement;


public class AMMediaEventType
{

    public AMMediaEventType()
    {
    }

    public static final int AMMediaEventTypeClose = 0;
    public static final int AMMediaEventTypeComplete = 5;
    public static final int AMMediaEventTypeMonitor = 3;
    public static final int AMMediaEventTypePlay = 1;
    public static final int AMMediaEventTypeStop = 2;
    public static final int AMMediaEventTypeTrack = 4;
}
