// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.adobe.adms.mediameasurement;

import java.util.Date;

public class ADMS_MediaState
{

    public ADMS_MediaState()
    {
    }

    public boolean complete;
    public boolean eventFirstTime;
    public double length;
    public String mediaEvent;
    public int milestone;
    public String name;
    public double offset;
    public int offsetMilestone;
    public Date openTime;
    public double percent;
    public String playerName;
    public String segment;
    public double segmentLength;
    public int segmentNum;
    public double timePlayed;
}
