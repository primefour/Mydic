// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.views;


public final class R
{
    public static final class attr
    {

        public static final int autoScroll = 0x7f010007;
        public static final int axisColor = 0x7f01001b;
        public static final int axisWidth = 0x7f01001e;
        public static final int backTextColor = 0x7f010052;
        public static final int bottomBarColor = 0x7f010050;
        public static final int bottomBarHeight = 0x7f010053;
        public static final int disableButtons = 0x7f01004d;
        public static final int dragndrop_background = 0x7f010058;
        public static final int expanded_height = 0x7f010056;
        public static final int fixedDimension = 0x7f010003;
        public static final int frontTextColor = 0x7f010051;
        public static final int grabber = 0x7f010057;
        public static final int gradientDirection = 0x7f010014;
        public static final int gradientEndColor = 0x7f010012;
        public static final int gradientStartColor = 0x7f010011;
        public static final int gradientTileMode = 0x7f010015;
        public static final int gridColor = 0x7f01001c;
        public static final int gridWidth = 0x7f01001f;
        public static final int lCVLayoutReference = 0x7f010023;
        public static final int lCVPercentageHeight = 0x7f010025;
        public static final int lCVPercentageWidth = 0x7f010024;
        public static final int labelColor = 0x7f010019;
        public static final int labelSize = 0x7f010018;
        public static final int layoutReference = 0x7f01000c;
        public static final int lineColor = 0x7f01001a;
        public static final int lineWidth = 0x7f01001d;
        public static final int maxTextSize = 0x7f010005;
        public static final int minTextSize = 0x7f010004;
        public static final int normal_height = 0x7f010055;
        public static final int orientation = 0x7f01004e;
        public static final int pCVBoxLineColor = 0x7f01003b;
        public static final int pCVBoxLineWidth = 0x7f01003a;
        public static final int pCVLabelColor = 0x7f01003d;
        public static final int pCVLabelSize = 0x7f01003c;
        public static final int pCVLayoutReference = 0x7f010034;
        public static final int pCVPercentageHeight = 0x7f010037;
        public static final int pCVPercentageWidth = 0x7f010036;
        public static final int pCVPieBorder = 0x7f010035;
        public static final int pCVPieLineColor = 0x7f010039;
        public static final int pCVPieLineWidth = 0x7f010038;
        public static final int percentWidth = 0x7f01004b;
        public static final int percentage = 0x7f010021;
        public static final int percentageHeight = 0x7f01000b;
        public static final int percentageWidth = 0x7f01000a;
        public static final int ptrAdapterViewBackground = 0x7f010046;
        public static final int ptrBottomArrow = 0x7f010042;
        public static final int ptrBottomPullText = 0x7f010043;
        public static final int ptrBottomRefreshingText = 0x7f010044;
        public static final int ptrBottomReleaseText = 0x7f010045;
        public static final int ptrHeaderBackground = 0x7f010047;
        public static final int ptrHeaderTextColor = 0x7f010048;
        public static final int ptrLastDate = 0x7f010049;
        public static final int ptrMode = 0x7f01004a;
        public static final int ptrTopArrow = 0x7f01003e;
        public static final int ptrTopPullText = 0x7f01003f;
        public static final int ptrTopRefreshingText = 0x7f010040;
        public static final int ptrTopReleaseText = 0x7f010041;
        public static final int remove_mode = 0x7f010059;
        public static final int screenOrientation = 0x7f010006;
        public static final int scrollTickTime = 0x7f010009;
        public static final int scrollTime = 0x7f010008;
        public static final int shadowBlurRadius = 0x7f01000e;
        public static final int shadowColor = 0x7f01000d;
        public static final int shadowXOffset = 0x7f01000f;
        public static final int shadowYOffset = 0x7f010010;
        public static final int slideDuration = 0x7f01004c;
        public static final int squarePriority = 0x7f01004f;
        public static final int startColorPercentage = 0x7f010013;
        public static final int tabIndicatorHeight = 0x7f010054;
        public static final int tip = 0x7f010020;
        public static final int type = 0x7f010022;
        public static final int xLabel = 0x7f010017;
        public static final int yLabel = 0x7f010016;

        public attr()
        {
        }
    }

    public static final class drawable
    {

        public static final int ic_launcher = 0x7f02003c;
        public static final int pulltorefresh_down_arrow = 0x7f020056;
        public static final int pulltorefresh_up_arrow = 0x7f020057;

        public drawable()
        {
        }
    }

    public static final class id
    {

        public static final int bigger = 0x7f09001e;
        public static final int both = 0x7f090014;
        public static final int bottom = 0x7f090019;
        public static final int circle = 0x7f09000c;
        public static final int clamp = 0x7f090008;
        public static final int fling = 0x7f09001f;
        public static final int footer = 0x7f090013;
        public static final int header = 0x7f090012;
        public static final int heigth = 0x7f09001c;
        public static final int horizontal = 0x7f090000;
        public static final int horizontalAfterFirstImage = 0x7f090002;
        public static final int landscape = 0x7f090004;
        public static final int left = 0x7f090018;
        public static final int line = 0x7f09000b;
        public static final int mirror = 0x7f090009;
        public static final int none = 0x7f09000d;
        public static final int parent = 0x7f090006;
        public static final int portrait = 0x7f090005;
        public static final int pullDownFromTop = 0x7f090015;
        public static final int pullUpFromBottom = 0x7f090016;
        public static final int pull_to_refresh_image = 0x7f09018b;
        public static final int pull_to_refresh_progress = 0x7f09018e;
        public static final int pull_to_refresh_sub_text = 0x7f09018d;
        public static final int pull_to_refresh_text = 0x7f09018c;
        public static final int repeat = 0x7f09000a;
        public static final int right = 0x7f09001a;
        public static final int screen = 0x7f090007;
        public static final int slide = 0x7f090020;
        public static final int slideLeft = 0x7f090022;
        public static final int slideRight = 0x7f090021;
        public static final int smaller = 0x7f09001d;
        public static final int top = 0x7f090017;
        public static final int vertical = 0x7f090001;
        public static final int verticalAfterFirstImage = 0x7f090003;
        public static final int width = 0x7f09001b;

        public id()
        {
        }
    }

    public static final class layout
    {

        public static final int pull_to_refresh_header = 0x7f030036;

        public layout()
        {
        }
    }

    public static final class string
    {

        public static final int pull_to_refresh_from_bottom_pull_label = 0x7f0c01d6;
        public static final int pull_to_refresh_from_bottom_refreshing_label = 0x7f0c01d7;
        public static final int pull_to_refresh_from_bottom_release_label = 0x7f0c01d8;
        public static final int pull_to_refresh_pull_label = 0x7f0c01d9;
        public static final int pull_to_refresh_refreshing_label = 0x7f0c01da;
        public static final int pull_to_refresh_release_label = 0x7f0c01db;

        public string()
        {
        }
    }

    public static final class styleable
    {

        public static final int AspectRatioImageView[] = {
            0x7f010003
        };
        public static final int AspectRatioImageView_fixedDimension = 0;
        public static final int AutoFitTextView[] = {
            0x7f010004, 0x7f010005
        };
        public static final int AutoFitTextView_maxTextSize = 1;
        public static final int AutoFitTextView_minTextSize = 0;
        public static final int CameraView[] = {
            0x7f010006
        };
        public static final int CameraView_screenOrientation = 0;
        public static final int CarouselViewPager[] = {
            0x7f010007, 0x7f010008, 0x7f010009, 0x7f01000a, 0x7f01000b, 0x7f01000c
        };
        public static final int CarouselViewPager_autoScroll = 0;
        public static final int CarouselViewPager_layoutReference = 5;
        public static final int CarouselViewPager_percentageHeight = 4;
        public static final int CarouselViewPager_percentageWidth = 3;
        public static final int CarouselViewPager_scrollTickTime = 2;
        public static final int CarouselViewPager_scrollTime = 1;
        public static final int GradientTextView[] = {
            0x7f01000d, 0x7f01000e, 0x7f01000f, 0x7f010010, 0x7f010011, 0x7f010012, 0x7f010013, 0x7f010014, 0x7f010015
        };
        public static final int GradientTextView_gradientDirection = 7;
        public static final int GradientTextView_gradientEndColor = 5;
        public static final int GradientTextView_gradientStartColor = 4;
        public static final int GradientTextView_gradientTileMode = 8;
        public static final int GradientTextView_shadowBlurRadius = 1;
        public static final int GradientTextView_shadowColor = 0;
        public static final int GradientTextView_shadowXOffset = 2;
        public static final int GradientTextView_shadowYOffset = 3;
        public static final int GradientTextView_startColorPercentage = 6;
        public static final int LinearChartView[] = {
            0x7f010016, 0x7f010017, 0x7f010018, 0x7f010019, 0x7f01001a, 0x7f01001b, 0x7f01001c, 0x7f01001d, 0x7f01001e, 0x7f01001f, 
            0x7f010020, 0x7f010021, 0x7f010022, 0x7f010023, 0x7f010024, 0x7f010025
        };
        public static final int LinearChartView_axisColor = 5;
        public static final int LinearChartView_axisWidth = 8;
        public static final int LinearChartView_gridColor = 6;
        public static final int LinearChartView_gridWidth = 9;
        public static final int LinearChartView_lCVLayoutReference = 13;
        public static final int LinearChartView_lCVPercentageHeight = 15;
        public static final int LinearChartView_lCVPercentageWidth = 14;
        public static final int LinearChartView_labelColor = 3;
        public static final int LinearChartView_labelSize = 2;
        public static final int LinearChartView_lineColor = 4;
        public static final int LinearChartView_lineWidth = 7;
        public static final int LinearChartView_percentage = 11;
        public static final int LinearChartView_tip = 10;
        public static final int LinearChartView_type = 12;
        public static final int LinearChartView_xLabel = 1;
        public static final int LinearChartView_yLabel = 0;
        public static final int PieChartView[] = {
            0x7f010034, 0x7f010035, 0x7f010036, 0x7f010037, 0x7f010038, 0x7f010039, 0x7f01003a, 0x7f01003b, 0x7f01003c, 0x7f01003d
        };
        public static final int PieChartView_pCVBoxLineColor = 7;
        public static final int PieChartView_pCVBoxLineWidth = 6;
        public static final int PieChartView_pCVLabelColor = 9;
        public static final int PieChartView_pCVLabelSize = 8;
        public static final int PieChartView_pCVLayoutReference = 0;
        public static final int PieChartView_pCVPercentageHeight = 3;
        public static final int PieChartView_pCVPercentageWidth = 2;
        public static final int PieChartView_pCVPieBorder = 1;
        public static final int PieChartView_pCVPieLineColor = 5;
        public static final int PieChartView_pCVPieLineWidth = 4;
        public static final int PullToRefresh[] = {
            0x7f01003e, 0x7f01003f, 0x7f010040, 0x7f010041, 0x7f010042, 0x7f010043, 0x7f010044, 0x7f010045, 0x7f010046, 0x7f010047, 
            0x7f010048, 0x7f010049, 0x7f01004a
        };
        public static final int PullToRefresh_ptrAdapterViewBackground = 8;
        public static final int PullToRefresh_ptrBottomArrow = 4;
        public static final int PullToRefresh_ptrBottomPullText = 5;
        public static final int PullToRefresh_ptrBottomRefreshingText = 6;
        public static final int PullToRefresh_ptrBottomReleaseText = 7;
        public static final int PullToRefresh_ptrHeaderBackground = 9;
        public static final int PullToRefresh_ptrHeaderTextColor = 10;
        public static final int PullToRefresh_ptrLastDate = 11;
        public static final int PullToRefresh_ptrMode = 12;
        public static final int PullToRefresh_ptrTopArrow = 0;
        public static final int PullToRefresh_ptrTopPullText = 1;
        public static final int PullToRefresh_ptrTopRefreshingText = 2;
        public static final int PullToRefresh_ptrTopReleaseText = 3;
        public static final int SlideMenu[] = {
            0x7f01004b, 0x7f01004c, 0x7f01004d, 0x7f01004e
        };
        public static final int SlideMenu_disableButtons = 2;
        public static final int SlideMenu_orientation = 3;
        public static final int SlideMenu_percentWidth = 0;
        public static final int SlideMenu_slideDuration = 1;
        public static final int SquareImageView[] = {
            0x7f01004f
        };
        public static final int SquareImageView_squarePriority = 0;
        public static final int SwipeyTabs[] = {
            0x7f010050, 0x7f010051, 0x7f010052, 0x7f010053, 0x7f010054
        };
        public static final int SwipeyTabs_backTextColor = 2;
        public static final int SwipeyTabs_bottomBarColor = 0;
        public static final int SwipeyTabs_bottomBarHeight = 3;
        public static final int SwipeyTabs_frontTextColor = 1;
        public static final int SwipeyTabs_tabIndicatorHeight = 4;
        public static final int TouchListView[] = {
            0x7f010055, 0x7f010056, 0x7f010057, 0x7f010058, 0x7f010059
        };
        public static final int TouchListView_dragndrop_background = 3;
        public static final int TouchListView_expanded_height = 1;
        public static final int TouchListView_grabber = 2;
        public static final int TouchListView_normal_height = 0;
        public static final int TouchListView_remove_mode = 4;


        public styleable()
        {
        }
    }


    public R()
    {
    }
}
