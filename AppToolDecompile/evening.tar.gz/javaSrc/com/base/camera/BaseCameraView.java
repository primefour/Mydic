// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.camera;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.hardware.Camera;
import android.util.AttributeSet;
import android.util.Log;
import android.view.*;
import android.widget.Toast;
import java.io.IOException;
import java.lang.reflect.Method;

public class BaseCameraView extends SurfaceView
    implements android.view.SurfaceHolder.Callback
{

    public BaseCameraView(Context context1)
    {
        this(context1, null);
    }

    public BaseCameraView(Context context1, AttributeSet attributeset)
    {
        this(context1, attributeset, 0);
    }

    public BaseCameraView(Context context1, AttributeSet attributeset, int i)
    {
        super(context1, attributeset, i);
        mAngle = 0;
        context = context1;
        mHolder = getHolder();
        mHolder.addCallback(this);
        mHolder.setType(3);
        if(attributeset == null)
            Log.e(">>> CameraView", "attrs == null ");
        screenOrientation = context1.getTheme().obtainStyledAttributes(attributeset, com.base.views.R.styleable.CameraView, 0, 0).getInteger(0, 0);
        if(screenOrientation == 1)
            screenOrientation = 90;
        Log.e(">>> CameraView", (new StringBuilder()).append("screenOrientation ").append(screenOrientation).toString());
    }

    public Camera getmCamera()
    {
        return mCamera;
    }

    public void setAngle(int i)
    {
        mAngle = i;
    }

    public void setCameraDisplayOrientation(int i)
    {
        android.hardware.Camera.CameraInfo camerainfo;
        int j;
        int k;
        camerainfo = new android.hardware.Camera.CameraInfo();
        Camera.getCameraInfo(i, camerainfo);
        j = ((Activity)context).getWindowManager().getDefaultDisplay().getRotation();
        k = 0;
        j;
        JVM INSTR tableswitch 0 3: default 68
    //                   0 106
    //                   1 112
    //                   2 119
    //                   3 127;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        break; /* Loop/switch isn't completed */
_L5:
        break MISSING_BLOCK_LABEL_127;
_L6:
        int l;
        if(camerainfo.facing == 1)
            l = (360 - (k + camerainfo.orientation) % 360) % 360;
        else
            l = (360 + (camerainfo.orientation - k)) % 360;
        mCamera.setDisplayOrientation(l);
        return;
_L2:
        k = 0;
          goto _L6
_L3:
        k = 90;
          goto _L6
_L4:
        k = 180;
          goto _L6
        k = 270;
          goto _L6
    }

    public void setCameraFlashMode(String s)
    {
        mCamera.stopPreview();
        android.hardware.Camera.Parameters parameters = mCamera.getParameters();
        parameters.setFlashMode(s);
        mCamera.setParameters(parameters);
        mCamera.startPreview();
    }

    public void setDisplayOrientation(Camera camera, int i)
    {
        if(mCamera != null)
            mCamera.stopPreview();
        Method method;
        Class class1 = camera.getClass();
        Class aclass[] = new Class[1];
        aclass[0] = Integer.TYPE;
        method = class1.getMethod("setDisplayOrientation", aclass);
        if(method != null)
            try
            {
                Object aobj[] = new Object[1];
                aobj[0] = Integer.valueOf(i);
                method.invoke(camera, aobj);
            }
            catch(Exception exception) { }
        if(mCamera != null)
            mCamera.startPreview();
        return;
    }

    public void surfaceChanged(SurfaceHolder surfaceholder, int i, int j, int k)
    {
        Log.e(">>> CameraView", "Cambiando Surface");
        if(mCamera != null)
            mCamera.startPreview();
    }

    public void surfaceCreated(SurfaceHolder surfaceholder)
    {
        Log.e(">>> CameraView", (new StringBuilder()).append("Creando Surface ").append(screenOrientation).toString());
        if(android.os.Build.VERSION.SDK_INT >= 9)
            break MISSING_BLOCK_LABEL_67;
        mCamera = Camera.open();
_L1:
        setDisplayOrientation(mCamera, screenOrientation);
        mCamera.setPreviewDisplay(surfaceholder);
        mCamera.startPreview();
        return;
        try
        {
            mCamera = Camera.open(0);
        }
        catch(IOException ioexception)
        {
            ioexception.printStackTrace();
            return;
        }
        catch(RuntimeException runtimeexception)
        {
            runtimeexception.printStackTrace();
            Toast.makeText(context, "There was an error starting the camera.", 1).show();
            return;
        }
          goto _L1
    }

    public void surfaceDestroyed(SurfaceHolder surfaceholder)
    {
        if(mCamera != null)
        {
            mCamera.stopPreview();
            mCamera.release();
            mCamera = null;
        }
    }

    public static String FLASH_MODE_AUTO = "auto";
    public static String FLASH_MODE_OFF = "off";
    public static String FLASH_MODE_ON = "on";
    private static final int PORTRAIT = 1;
    private static final int PORTRAIT_VALUE = 90;
    public static final int REFERENCE_SCREEN = 0;
    private static final String TAG = ">>> CameraView";
    private static Camera mCamera;
    private Context context;
    private int mAngle;
    private SurfaceHolder mHolder;
    private int screenOrientation;

}
