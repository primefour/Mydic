// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.drawing.utils.brushes;

import android.graphics.Path;

// Referenced classes of package com.base.drawing.utils.brushes:
//            Brush

public class CircleBrush extends Brush
{

    public CircleBrush()
    {
    }

    public void mouseMove(Path path, float f, float f1)
    {
        path.addCircle(f, f1, 10F, android.graphics.Path.Direction.CW);
    }
}
