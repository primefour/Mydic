// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.drawing.utils.brushes;

import android.graphics.Path;

// Referenced classes of package com.base.drawing.utils.brushes:
//            Brush

public class PenBrush extends Brush
{

    public PenBrush()
    {
    }

    public void mouseDown(Path path, float f, float f1)
    {
        path.moveTo(f, f1);
        path.lineTo(f, f1);
    }

    public void mouseMove(Path path, float f, float f1)
    {
        path.lineTo(f, f1);
    }

    public void mouseUp(Path path, float f, float f1)
    {
        path.lineTo(f, f1);
    }

    public void mouseUpClosing(Path path)
    {
        path.close();
    }
}
