// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.drawing.utils.brushes;

import android.graphics.Path;

public interface IBrush
{

    public abstract void mouseDown(Path path, float f, float f1);

    public abstract void mouseMove(Path path, float f, float f1);

    public abstract void mouseUp(Path path, float f, float f1);
}
