// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.drawing.utils.brushes;

import android.graphics.Path;

// Referenced classes of package com.base.drawing.utils.brushes:
//            IBrush

public class Brush
    implements IBrush
{

    public Brush()
    {
    }

    public void mouseDown(Path path, float f, float f1)
    {
    }

    public void mouseMove(Path path, float f, float f1)
    {
    }

    public void mouseUp(Path path, float f, float f1)
    {
    }
}
