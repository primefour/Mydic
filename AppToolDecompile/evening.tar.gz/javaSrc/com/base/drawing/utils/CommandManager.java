// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.drawing.utils;

import android.graphics.Canvas;
import android.os.Handler;
import java.util.*;

// Referenced classes of package com.base.drawing.utils:
//            DrawingPath

public class CommandManager
{

    public CommandManager()
    {
        currentStack = Collections.synchronizedList(new ArrayList());
        redoStack = Collections.synchronizedList(new ArrayList());
    }

    public void addCommand(DrawingPath drawingpath)
    {
        redoStack.clear();
        currentStack.add(drawingpath);
    }

    public int currentStackLength()
    {
        return currentStack.toArray().length;
    }

    public void executeAll(Canvas canvas, Handler handler)
    {
        if(currentStack == null) goto _L2; else goto _L1
_L1:
        List list = currentStack;
        list;
        JVM INSTR monitorenter ;
        for(Iterator iterator = currentStack.iterator(); iterator.hasNext(); ((DrawingPath)iterator.next()).draw(canvas));
        break MISSING_BLOCK_LABEL_59;
        Exception exception;
        exception;
        list;
        JVM INSTR monitorexit ;
        throw exception;
        list;
        JVM INSTR monitorexit ;
_L2:
    }

    public DrawingPath getFirstCommand()
    {
        return (DrawingPath)currentStack.get(0);
    }

    public int getStackSize()
    {
        return currentStack.size();
    }

    public boolean hasMoreRedo()
    {
        return redoStack.toArray().length > 0;
    }

    public boolean hasMoreUndo()
    {
        return currentStack.toArray().length > 0;
    }

    public void redo()
    {
        int i = redoStack.toArray().length;
        if(i > 0)
        {
            DrawingPath drawingpath = (DrawingPath)redoStack.get(i - 1);
            redoStack.remove(i - 1);
            currentStack.add(drawingpath);
        }
    }

    public void removeCommand(DrawingPath drawingpath)
    {
        redoStack.clear();
        currentStack.remove(drawingpath);
    }

    public void removeFirstCommand()
    {
        currentStack.remove(0);
    }

    public void undo()
    {
        int i = currentStackLength();
        if(i > 0)
        {
            DrawingPath drawingpath = (DrawingPath)currentStack.get(i - 1);
            currentStack.remove(i - 1);
            drawingpath.undo();
            redoStack.add(drawingpath);
        }
    }

    private List currentStack;
    private List redoStack;
}
