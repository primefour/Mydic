// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.drawing.utils;

import android.graphics.*;

// Referenced classes of package com.base.drawing.utils:
//            ICanvasCommand

public class DrawingPath
    implements ICanvasCommand
{

    public DrawingPath()
    {
    }

    public void draw(Canvas canvas)
    {
        canvas.drawPath(path, paint);
    }

    public void undo()
    {
    }

    public Paint paint;
    public Path path;
}
