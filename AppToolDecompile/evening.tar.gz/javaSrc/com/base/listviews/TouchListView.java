// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.listviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.*;
import android.widget.ImageView;
import android.widget.ListView;

public class TouchListView extends ListView
{
    public static interface DragListener
    {

        public abstract void drag(int i, int j);
    }

    public static interface DropListener
    {

        public abstract void drop(int i, int j);
    }

    public static interface RemoveListener
    {

        public abstract void remove(int i);
    }


    public TouchListView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public TouchListView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        mRemoveMode = -1;
        mTempRect = new Rect();
        mItemHeightNormal = -1;
        mItemHeightExpanded = -1;
        grabberId = -1;
        dragndropBackgroundColor = 0;
        mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        if(attributeset != null)
        {
            TypedArray typedarray = getContext().obtainStyledAttributes(attributeset, com.base.views.R.styleable.TouchListView, 0, 0);
            mItemHeightNormal = typedarray.getDimensionPixelSize(0, 0);
            mItemHeightExpanded = typedarray.getDimensionPixelSize(1, mItemHeightNormal);
            grabberId = typedarray.getResourceId(2, -1);
            dragndropBackgroundColor = typedarray.getColor(3, 0);
            mRemoveMode = typedarray.getInt(4, -1);
            typedarray.recycle();
        }
    }

    private void adjustScrollBounds(int i)
    {
        if(i >= mHeight / 3)
            mUpperBound = mHeight / 3;
        if(i <= (2 * mHeight) / 3)
            mLowerBound = (2 * mHeight) / 3;
    }

    private void doExpansion()
    {
        int i;
        View view;
        int j;
        i = mDragPos - getFirstVisiblePosition();
        if(mDragPos > mFirstDragPos)
            i++;
        view = getChildAt(mFirstDragPos - getFirstVisiblePosition());
        j = 0;
_L2:
        int k;
        byte byte0;
        View view1 = getChildAt(j);
        if(view1 == null)
        {
            layoutChildren();
            return;
        }
        k = mItemHeightNormal;
        if(!view1.equals(view))
            break; /* Loop/switch isn't completed */
        android.view.ViewGroup.LayoutParams layoutparams;
        if(mDragPos == mFirstDragPos)
        {
            byte0 = 4;
        } else
        {
            k = 1;
            byte0 = 0;
        }
_L3:
        if(isDraggableRow(view1))
        {
            layoutparams = view1.getLayoutParams();
            layoutparams.height = k;
            view1.setLayoutParams(layoutparams);
            view1.setVisibility(byte0);
        }
        j++;
        if(true) goto _L2; else goto _L1
_L1:
        byte0 = 0;
        if(j == i)
        {
            int l = mDragPos;
            int i1 = -1 + getCount();
            byte0 = 0;
            if(l < i1)
            {
                k = mItemHeightExpanded;
                byte0 = 0;
            }
        }
          goto _L3
        if(true) goto _L2; else goto _L4
_L4:
    }

    private void dragView(int i, int j)
    {
        float f;
        int k;
        f = 1.0F;
        k = mDragView.getWidth();
        if(mRemoveMode != 1) goto _L2; else goto _L1
_L1:
        if(i > k / 2)
            f = (float)(k - i) / (float)(k / 2);
        mWindowParams.alpha = f;
_L4:
        mWindowParams.y = (j - mDragPoint) + mCoordOffset;
        mWindowManager.updateViewLayout(mDragView, mWindowParams);
        return;
_L2:
        if(mRemoveMode == 2)
        {
            if(i < k / 2)
                f = (float)i / (float)(k / 2);
            mWindowParams.alpha = f;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    private int getItemForPosition(int i)
    {
        int j = i - mDragPoint - mItemHeightNormal / 2;
        int k = myPointToPosition(0, j);
        if(k >= 0)
        {
            if(k <= mFirstDragPos)
                k++;
        } else
        if(j < 0)
            return 0;
        return k;
    }

    private int myPointToPosition(int i, int j)
    {
        Rect rect = mTempRect;
        for(int k = -1 + getChildCount(); k >= 0; k--)
        {
            getChildAt(k).getHitRect(rect);
            if(rect.contains(i, j))
                return k + getFirstVisiblePosition();
        }

        return -1;
    }

    private void startDragging(Bitmap bitmap, int i, int j)
    {
        stopDragging();
        mWindowParams = new android.view.WindowManager.LayoutParams();
        mWindowParams.gravity = 51;
        mWindowParams.x = i;
        mWindowParams.y = (j - mDragPoint) + mCoordOffset;
        mWindowParams.height = -2;
        mWindowParams.width = -2;
        mWindowParams.flags = 408;
        mWindowParams.format = -3;
        mWindowParams.windowAnimations = 0;
        ImageView imageview = new ImageView(getContext());
        imageview.setBackgroundColor(dragndropBackgroundColor);
        imageview.setImageBitmap(bitmap);
        mDragBitmap = bitmap;
        mWindowManager = (WindowManager)getContext().getSystemService("window");
        mWindowManager.addView(imageview, mWindowParams);
        mDragView = imageview;
    }

    private void stopDragging()
    {
        if(mDragView != null)
        {
            ((WindowManager)getContext().getSystemService("window")).removeView(mDragView);
            mDragView.setImageDrawable(null);
            mDragView = null;
        }
        if(mDragBitmap != null)
        {
            mDragBitmap.recycle();
            mDragBitmap = null;
        }
    }

    private void unExpandViews(boolean flag)
    {
        int i = 0;
        do
        {
            View view = getChildAt(i);
            if(view == null)
            {
                if(flag)
                {
                    int j = getFirstVisiblePosition();
                    int k = getChildAt(0).getTop();
                    setAdapter(getAdapter());
                    setSelectionFromTop(j, k);
                }
                layoutChildren();
                view = getChildAt(i);
                if(view == null)
                    return;
            }
            if(isDraggableRow(view))
            {
                android.view.ViewGroup.LayoutParams layoutparams = view.getLayoutParams();
                layoutparams.height = mItemHeightNormal;
                view.setLayoutParams(layoutparams);
                view.setVisibility(0);
            }
            i++;
        } while(true);
    }

    public final void addFooterView(View view)
    {
        if(mRemoveMode == 2 || mRemoveMode == 1)
            throw new RuntimeException("Footers are not supported with TouchListView in conjunction with remove_mode");
        else
            return;
    }

    public final void addFooterView(View view, Object obj, boolean flag)
    {
        if(mRemoveMode == 2 || mRemoveMode == 1)
            throw new RuntimeException("Footers are not supported with TouchListView in conjunction with remove_mode");
        else
            return;
    }

    public final void addHeaderView(View view)
    {
        throw new RuntimeException("Headers are not supported with TouchListView");
    }

    public final void addHeaderView(View view, Object obj, boolean flag)
    {
        throw new RuntimeException("Headers are not supported with TouchListView");
    }

    protected boolean isDraggableRow(View view)
    {
        return view.findViewById(grabberId) != null;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        if(mRemoveListener != null && mGestureDetector == null && mRemoveMode == 0)
            mGestureDetector = new GestureDetector(getContext(), new android.view.GestureDetector.SimpleOnGestureListener() {

                public boolean onFling(MotionEvent motionevent1, MotionEvent motionevent2, float f, float f1)
                {
                    if(mDragView != null)
                    {
                        if(f > 1000F)
                        {
                            Rect rect2 = mTempRect;
                            mDragView.getDrawingRect(rect2);
                            if(motionevent2.getX() > (float)((2 * rect2.right) / 3))
                            {
                                stopDragging();
                                mRemoveListener.remove(mFirstDragPos);
                                unExpandViews(true);
                            }
                        }
                        return true;
                    } else
                    {
                        return false;
                    }
                }

                final TouchListView this$0;

            
            {
                this$0 = TouchListView.this;
                super();
            }
            });
        if(mDragListener == null && mDropListener == null) goto _L2; else goto _L1
_L1:
        motionevent.getAction();
        JVM INSTR tableswitch 0 0: default 80
    //                   0 86;
           goto _L2 _L3
_L2:
        return super.onInterceptTouchEvent(motionevent);
_L3:
        int i = (int)motionevent.getX();
        int j = (int)motionevent.getY();
        int k = pointToPosition(i, j);
        if(k != -1)
        {
            View view = getChildAt(k - getFirstVisiblePosition());
            if(isDraggableRow(view))
            {
                mDragPoint = j - view.getTop();
                mCoordOffset = (int)motionevent.getRawY() - j;
                View view1 = view.findViewById(grabberId);
                Rect rect = mTempRect;
                rect.left = view1.getLeft();
                rect.right = view1.getRight();
                rect.top = view1.getTop();
                rect.bottom = view1.getBottom();
                if(rect.left < i && i < rect.right)
                {
                    view.setDrawingCacheEnabled(true);
                    Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
                    view.setDrawingCacheEnabled(false);
                    Rect rect1 = new Rect();
                    getGlobalVisibleRect(rect1, null);
                    startDragging(bitmap, rect1.left, j);
                    mDragPos = k;
                    mFirstDragPos = mDragPos;
                    mHeight = getHeight();
                    int l = mTouchSlop;
                    mUpperBound = Math.min(j - l, mHeight / 3);
                    mLowerBound = Math.max(j + l, (2 * mHeight) / 3);
                    return false;
                }
                mDragView = null;
            }
        }
        if(true) goto _L2; else goto _L4
_L4:
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if(mGestureDetector != null)
            mGestureDetector.onTouchEvent(motionevent);
        if(mDragListener == null && mDropListener == null || mDragView == null) goto _L2; else goto _L1
_L1:
        int i = motionevent.getAction();
        i;
        JVM INSTR tableswitch 0 3: default 72
    //                   0 258
    //                   1 74
    //                   2 258
    //                   3 74;
           goto _L3 _L4 _L5 _L4 _L5
_L3:
        return true;
_L5:
        Rect rect = mTempRect;
        mDragView.getDrawingRect(rect);
        stopDragging();
        if(mRemoveMode == 1 && motionevent.getX() > (float)(rect.left + (3 * rect.width()) / 4))
        {
            if(mRemoveListener != null)
                mRemoveListener.remove(mFirstDragPos);
            unExpandViews(true);
            return true;
        }
        if(mRemoveMode == 2 && motionevent.getX() < (float)(rect.left + rect.width() / 4))
        {
            if(mRemoveListener != null)
                mRemoveListener.remove(mFirstDragPos);
            unExpandViews(true);
            return true;
        }
        if(mDropListener != null && mDragPos >= 0 && mDragPos < getCount())
            mDropListener.drop(mFirstDragPos, mDragPos);
        unExpandViews(false);
        return true;
_L4:
        int k;
        byte byte0;
        int j = (int)motionevent.getX();
        k = (int)motionevent.getY();
        dragView(j, k);
        int l = getItemForPosition(k);
        if(l < 0)
            continue; /* Loop/switch isn't completed */
        if(i == 0 || l != mDragPos)
        {
            if(mDragListener != null)
                mDragListener.drag(mDragPos, l);
            mDragPos = l;
            doExpansion();
        }
        adjustScrollBounds(k);
        if(k <= mLowerBound)
            break; /* Loop/switch isn't completed */
        int j1;
        View view;
        if(k > (mHeight + mLowerBound) / 2)
            byte0 = 16;
        else
            byte0 = 4;
_L7:
        if(byte0 != 0)
        {
            j1 = pointToPosition(0, mHeight / 2);
            if(j1 == -1)
                j1 = pointToPosition(0, 64 + (mHeight / 2 + getDividerHeight()));
            view = getChildAt(j1 - getFirstVisiblePosition());
            if(view != null)
            {
                setSelectionFromTop(j1, view.getTop() - byte0);
                return true;
            }
        }
        if(true) goto _L3; else goto _L6
_L6:
        int i1 = mUpperBound;
        byte0 = 0;
        if(k < i1)
            if(k < mUpperBound / 2)
                byte0 = -16;
            else
                byte0 = -4;
          goto _L7
        if(true) goto _L3; else goto _L2
_L2:
        return super.onTouchEvent(motionevent);
    }

    public void setDragListener(DragListener draglistener)
    {
        mDragListener = draglistener;
    }

    public void setDropListener(DropListener droplistener)
    {
        mDropListener = droplistener;
    }

    public void setRemoveListener(RemoveListener removelistener)
    {
        mRemoveListener = removelistener;
    }

    public static final int FLING = 0;
    public static final int SLIDE_LEFT = 2;
    public static final int SLIDE_RIGHT = 1;
    private int dragndropBackgroundColor;
    private int grabberId;
    private int mCoordOffset;
    private Bitmap mDragBitmap;
    private DragListener mDragListener;
    private int mDragPoint;
    private int mDragPos;
    private ImageView mDragView;
    private DropListener mDropListener;
    private int mFirstDragPos;
    private GestureDetector mGestureDetector;
    private int mHeight;
    private int mItemHeightExpanded;
    private int mItemHeightNormal;
    private int mLowerBound;
    private RemoveListener mRemoveListener;
    private int mRemoveMode;
    private Rect mTempRect;
    private final int mTouchSlop;
    private int mUpperBound;
    private WindowManager mWindowManager;
    private android.view.WindowManager.LayoutParams mWindowParams;






}
