// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.listviews.pulltorefresh;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.view.animation.*;
import android.widget.*;

public class LoadingLayout extends FrameLayout
{

    public LoadingLayout(Context context, int i, TypedArray typedarray)
    {
        super(context);
        ViewGroup viewgroup = (ViewGroup)LayoutInflater.from(context).inflate(com.base.views.R.layout.pull_to_refresh_header, this);
        mHeaderText = (TextView)viewgroup.findViewById(com.base.views.R.id.pull_to_refresh_text);
        mSubHeaderText = (TextView)viewgroup.findViewById(com.base.views.R.id.pull_to_refresh_sub_text);
        mHeaderImage = (ImageView)viewgroup.findViewById(com.base.views.R.id.pull_to_refresh_image);
        mHeaderProgress = (ProgressBar)viewgroup.findViewById(com.base.views.R.id.pull_to_refresh_progress);
        LinearInterpolator linearinterpolator = new LinearInterpolator();
        mRotateAnimation = new RotateAnimation(0.0F, -180F, 1, 0.5F, 1, 0.5F);
        mRotateAnimation.setInterpolator(linearinterpolator);
        mRotateAnimation.setDuration(150L);
        mRotateAnimation.setFillAfter(true);
        mResetRotateAnimation = new RotateAnimation(-180F, 0.0F, 1, 0.5F, 1, 0.5F);
        mResetRotateAnimation.setInterpolator(linearinterpolator);
        mResetRotateAnimation.setDuration(150L);
        mResetRotateAnimation.setFillAfter(true);
        switch(i)
        {
        default:
            if(typedarray.hasValue(0))
                mHeaderImage.setImageResource(typedarray.getResourceId(0, com.base.views.R.drawable.ic_launcher));
            else
                mHeaderImage.setImageResource(com.base.views.R.drawable.pulltorefresh_down_arrow);
            if(typedarray.hasValue(1))
            {
                if(typedarray.getString(1) != null)
                    mPullLabel = typedarray.getString(1);
                else
                    mPullLabel = context.getString(typedarray.getResourceId(1, com.base.views.R.string.pull_to_refresh_pull_label));
            } else
            {
                mPullLabel = context.getString(com.base.views.R.string.pull_to_refresh_pull_label);
            }
            if(typedarray.hasValue(2))
            {
                if(typedarray.getString(2) != null)
                    mRefreshingLabel = typedarray.getString(2);
                else
                    mRefreshingLabel = context.getString(typedarray.getResourceId(2, com.base.views.R.string.pull_to_refresh_refreshing_label));
            } else
            {
                mRefreshingLabel = context.getString(com.base.views.R.string.pull_to_refresh_refreshing_label);
            }
            if(typedarray.hasValue(3))
            {
                if(typedarray.getString(3) != null)
                    mReleaseLabel = typedarray.getString(3);
                else
                    mReleaseLabel = context.getString(typedarray.getResourceId(3, com.base.views.R.string.pull_to_refresh_release_label));
            } else
            {
                mReleaseLabel = context.getString(com.base.views.R.string.pull_to_refresh_release_label);
            }
            break;

        case 2: // '\002'
            break MISSING_BLOCK_LABEL_335;
        }
        if(typedarray.hasValue(10))
        {
            ColorStateList colorstatelist = typedarray.getColorStateList(10);
            if(colorstatelist == null)
                colorstatelist = ColorStateList.valueOf(0xff000000);
            setTextColor(colorstatelist);
        }
        reset();
        return;
        if(typedarray.hasValue(4))
            mHeaderImage.setImageResource(typedarray.getResourceId(4, com.base.views.R.drawable.ic_launcher));
        else
            mHeaderImage.setImageResource(com.base.views.R.drawable.pulltorefresh_up_arrow);
        if(typedarray.hasValue(5))
        {
            if(typedarray.getString(5) != null)
                mPullLabel = typedarray.getString(5);
            else
                mPullLabel = context.getString(typedarray.getResourceId(5, com.base.views.R.string.pull_to_refresh_from_bottom_pull_label));
        } else
        {
            mPullLabel = context.getString(com.base.views.R.string.pull_to_refresh_from_bottom_pull_label);
        }
        if(typedarray.hasValue(6))
        {
            if(typedarray.getString(6) != null)
                mRefreshingLabel = typedarray.getString(6);
            else
                mRefreshingLabel = context.getString(typedarray.getResourceId(6, com.base.views.R.string.pull_to_refresh_from_bottom_refreshing_label));
        } else
        {
            mRefreshingLabel = context.getString(com.base.views.R.string.pull_to_refresh_from_bottom_refreshing_label);
        }
        if(typedarray.hasValue(7))
        {
            if(typedarray.getString(7) != null)
                mReleaseLabel = typedarray.getString(7);
            else
                mReleaseLabel = context.getString(typedarray.getResourceId(7, com.base.views.R.string.pull_to_refresh_from_bottom_release_label));
        } else
        {
            mReleaseLabel = context.getString(com.base.views.R.string.pull_to_refresh_from_bottom_release_label);
        }
        break MISSING_BLOCK_LABEL_302;
    }

    public void pullToRefresh()
    {
        mHeaderText.setText(Html.fromHtml(mPullLabel));
        mHeaderImage.clearAnimation();
        mHeaderImage.startAnimation(mResetRotateAnimation);
    }

    public void refreshing()
    {
        mHeaderText.setText(Html.fromHtml(mRefreshingLabel));
        mHeaderImage.clearAnimation();
        mHeaderImage.setVisibility(4);
        mHeaderProgress.setVisibility(0);
        mSubHeaderText.setVisibility(8);
    }

    public void releaseToRefresh()
    {
        mHeaderText.setText(Html.fromHtml(mReleaseLabel));
        mHeaderImage.clearAnimation();
        mHeaderImage.startAnimation(mRotateAnimation);
    }

    public void reset()
    {
        mHeaderText.setText(Html.fromHtml(mPullLabel));
        mHeaderImage.setVisibility(0);
        mHeaderProgress.setVisibility(8);
        if(TextUtils.isEmpty(mSubHeaderText.getText()))
        {
            mSubHeaderText.setVisibility(8);
            return;
        } else
        {
            mSubHeaderText.setVisibility(0);
            return;
        }
    }

    public void setPullLabel(String s)
    {
        mPullLabel = s;
    }

    public void setRefreshingLabel(String s)
    {
        mRefreshingLabel = s;
    }

    public void setReleaseLabel(String s)
    {
        mReleaseLabel = s;
    }

    public void setSubHeaderText(CharSequence charsequence)
    {
        if(TextUtils.isEmpty(charsequence))
        {
            mSubHeaderText.setVisibility(8);
            return;
        } else
        {
            mSubHeaderText.setText(charsequence);
            mSubHeaderText.setVisibility(0);
            return;
        }
    }

    public void setTextColor(int i)
    {
        setTextColor(ColorStateList.valueOf(i));
    }

    public void setTextColor(ColorStateList colorstatelist)
    {
        mHeaderText.setTextColor(colorstatelist);
        mSubHeaderText.setTextColor(colorstatelist);
    }

    static final int DEFAULT_ROTATION_ANIMATION_DURATION = 150;
    private final ImageView mHeaderImage;
    private final ProgressBar mHeaderProgress;
    private final TextView mHeaderText;
    private String mPullLabel;
    private String mRefreshingLabel;
    private String mReleaseLabel;
    private final Animation mResetRotateAnimation;
    private final Animation mRotateAnimation;
    private final TextView mSubHeaderText;
}
