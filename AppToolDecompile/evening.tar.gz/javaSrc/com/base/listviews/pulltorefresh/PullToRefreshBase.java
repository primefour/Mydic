// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.listviews.pulltorefresh;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.*;
import android.util.AttributeSet;
import android.util.Log;
import android.view.*;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import java.util.Calendar;

// Referenced classes of package com.base.listviews.pulltorefresh:
//            LoadingLayout

public abstract class PullToRefreshBase extends LinearLayout
{
    public static interface OnLastItemVisibleListener
    {

        public abstract void onLastItemVisible();
    }

    public static interface OnRefreshListener
    {

        public abstract void onRefresh();
    }

    public static interface OnRefreshListener2
    {

        public abstract void onPullDownToRefresh();

        public abstract void onPullUpToRefresh();
    }

    final class SmoothScrollRunnable
        implements Runnable
    {

        public void run()
        {
            if(mStartTime == -1L)
            {
                mStartTime = System.currentTimeMillis();
            } else
            {
                long l = Math.max(Math.min((1000L * (System.currentTimeMillis() - mStartTime)) / 190L, 1000L), 0L);
                int i = Math.round((float)(mScrollFromY - mScrollToY) * mInterpolator.getInterpolation((float)l / 1000F));
                mCurrentY = mScrollFromY - i;
                setHeaderScroll(mCurrentY);
            }
            if(mContinueRunning && mScrollToY != mCurrentY)
                mHandler.postDelayed(this, 16L);
        }

        public void stop()
        {
            mContinueRunning = false;
            mHandler.removeCallbacks(this);
        }

        static final int ANIMATION_DURATION_MS = 190;
        static final int ANIMATION_FPS = 16;
        private boolean mContinueRunning;
        private int mCurrentY;
        private final Handler mHandler;
        private final Interpolator mInterpolator = new AccelerateDecelerateInterpolator();
        private final int mScrollFromY;
        private final int mScrollToY;
        private long mStartTime;
        final PullToRefreshBase this$0;

        public SmoothScrollRunnable(Handler handler, int i, int j)
        {
            this$0 = PullToRefreshBase.this;
            super();
            mContinueRunning = true;
            mStartTime = -1L;
            mCurrentY = -1;
            mHandler = handler;
            mScrollFromY = i;
            mScrollToY = j;
        }
    }


    public PullToRefreshBase(Context context)
    {
        super(context);
        mIsBeingDragged = false;
        mState = 0;
        mMode = 1;
        mPullToRefreshEnabled = true;
        mShowViewWhileRefreshing = true;
        mDisableScrollingWhileRefreshing = true;
        mHandler = new Handler();
        Log.e("TAG", "MDE 0");
        init(context, null);
    }

    public PullToRefreshBase(Context context, int i)
    {
        super(context);
        mIsBeingDragged = false;
        mState = 0;
        mMode = 1;
        mPullToRefreshEnabled = true;
        mShowViewWhileRefreshing = true;
        mDisableScrollingWhileRefreshing = true;
        mHandler = new Handler();
        mMode = i;
        Log.e("TAG", "MDE 1");
        init(context, null);
    }

    public PullToRefreshBase(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mIsBeingDragged = false;
        mState = 0;
        mMode = 1;
        mPullToRefreshEnabled = true;
        mShowViewWhileRefreshing = true;
        mDisableScrollingWhileRefreshing = true;
        mHandler = new Handler();
        Log.e("TAG", "MDE 2");
        init(context, attributeset);
    }

    private CharSequence calculateUpdateText()
    {
        Calendar calendar = Calendar.getInstance();
        StringBuilder stringbuilder = (new StringBuilder()).append("Last updated: ");
        Object aobj[] = new Object[1];
        aobj[0] = Integer.valueOf(calendar.get(5));
        StringBuilder stringbuilder1 = stringbuilder.append(String.format("%02d", aobj)).append("/");
        Object aobj1[] = new Object[1];
        aobj1[0] = Integer.valueOf(1 + calendar.get(2));
        StringBuilder stringbuilder2 = stringbuilder1.append(String.format("%02d", aobj1)).append("/").append(calendar.get(1)).append(" ");
        Object aobj2[] = new Object[1];
        aobj2[0] = Integer.valueOf(calendar.get(10));
        StringBuilder stringbuilder3 = stringbuilder2.append(String.format("%02d", aobj2)).append(":");
        Object aobj3[] = new Object[1];
        aobj3[0] = Integer.valueOf(calendar.get(12));
        StringBuilder stringbuilder4 = stringbuilder3.append(String.format("%02d", aobj3)).append(" ");
        String s;
        if(calendar.get(9) == 0)
            s = "AM";
        else
            s = "PM";
        return stringbuilder4.append(s).toString();
    }

    private void init(Context context, AttributeSet attributeset)
    {
        int i = 1;
        setOrientation(i);
        mTouchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.PullToRefresh);
        if(typedarray.hasValue(12))
            mMode = typedarray.getInteger(12, i);
        if(typedarray.hasValue(11))
            mDateMode = typedarray.getInteger(11, i);
        mRefreshableView = createRefreshableView(context, attributeset);
        addRefreshableView(context, mRefreshableView);
        if(mMode == i)
        {
            mHeaderLayout = new LoadingLayout(context, i, typedarray);
            addView(mHeaderLayout, 0, new android.widget.LinearLayout.LayoutParams(-1, -2));
            measureView(mHeaderLayout);
            Log.e("TRDRU HEADER init ", (new StringBuilder()).append(mHeaderLayout.getMeasuredHeight()).append("").toString());
            int k = mHeaderLayout.getMeasuredHeight();
            mHeaderHeight = k;
            mFooterHeight = k;
        } else
        if(mMode == 2)
        {
            mFooterLayout = new LoadingLayout(context, 2, typedarray);
            addView(mFooterLayout, new android.widget.LinearLayout.LayoutParams(-1, -2));
            measureView(mFooterLayout);
            int j = mFooterLayout.getMeasuredHeight();
            mHeaderHeight = j;
            mFooterHeight = j;
        } else
        {
            mHeaderLayout = new LoadingLayout(context, i, typedarray);
            addView(mHeaderLayout, 0, new android.widget.LinearLayout.LayoutParams(-1, -2));
            measureView(mHeaderLayout);
            mHeaderHeight = mHeaderLayout.getMeasuredHeight();
            mFooterLayout = new LoadingLayout(context, 2, typedarray);
            addView(mFooterLayout, new android.widget.LinearLayout.LayoutParams(-1, -2));
            measureView(mFooterLayout);
            mFooterHeight = mFooterLayout.getMeasuredHeight();
        }
        initialMFooterHeight = mFooterHeight;
        initialMHeaderHeight = mHeaderHeight;
        if(typedarray.hasValue(9))
        {
            android.graphics.drawable.Drawable drawable1 = typedarray.getDrawable(9);
            if(drawable1 != null)
                setBackgroundDrawable(drawable1);
        }
        if(typedarray.hasValue(8))
        {
            android.graphics.drawable.Drawable drawable = typedarray.getDrawable(8);
            if(drawable != null)
                mRefreshableView.setBackgroundDrawable(drawable);
        }
        typedarray.recycle();
        measurePadding();
        if(mMode != 3)
            i = mMode;
        mCurrentMode = i;
    }

    private boolean isReadyForPull()
    {
        mMode;
        JVM INSTR tableswitch 1 3: default 32
    //                   1 34
    //                   2 39
    //                   3 44;
           goto _L1 _L2 _L3 _L4
_L1:
        return false;
_L2:
        return isReadyForPullDown();
_L3:
        return isReadyForPullUp();
_L4:
        if(isReadyForPullUp() || isReadyForPullDown())
            return true;
        if(true) goto _L1; else goto _L5
_L5:
    }

    private void measurePadding()
    {
        switch(mMode)
        {
        default:
            setPadding(0, -mHeaderHeight, 0, 0);
            return;

        case 3: // '\003'
            setPadding(0, -mHeaderHeight, 0, -mHeaderHeight);
            return;

        case 2: // '\002'
            setPadding(0, 0, 0, -mHeaderHeight);
            return;
        }
    }

    private void measureView(View view)
    {
        android.view.ViewGroup.LayoutParams layoutparams = view.getLayoutParams();
        if(layoutparams == null)
            layoutparams = new android.view.ViewGroup.LayoutParams(-1, -2);
        int i = ViewGroup.getChildMeasureSpec(0, 0, layoutparams.width);
        int j = layoutparams.height;
        int k;
        if(j > 0)
            k = android.view.View.MeasureSpec.makeMeasureSpec(j, 0x40000000);
        else
            k = android.view.View.MeasureSpec.makeMeasureSpec(0, 0);
        view.measure(i, k);
    }

    private boolean pullEvent()
    {
        int i = getScrollY();
        mCurrentMode;
        JVM INSTR tableswitch 2 2: default 28
    //                   2 106;
           goto _L1 _L2
_L1:
        int j = Math.round(Math.min(mInitialMotionY - mLastMotionY, 0.0F) / 2.0F);
_L12:
        setHeaderScroll(j);
        if(j == 0) goto _L4; else goto _L3
_L3:
        if(mState != 0 || mHeaderHeight >= Math.abs(j)) goto _L6; else goto _L5
_L5:
        mState = 1;
        mCurrentMode;
        JVM INSTR tableswitch 1 2: default 104
    //                   1 137
    //                   2 128;
           goto _L7 _L8 _L9
_L7:
        return true;
_L2:
        j = Math.round(Math.max(mInitialMotionY - mLastMotionY, 0.0F) / 2.0F);
        continue; /* Loop/switch isn't completed */
_L9:
        mFooterLayout.releaseToRefresh();
        return true;
_L8:
        mHeaderLayout.releaseToRefresh();
        return true;
_L6:
        if(mState == 1 && mHeaderHeight >= Math.abs(j))
        {
            mState = 0;
            switch(mCurrentMode)
            {
            default:
                return true;

            case 1: // '\001'
                mHeaderLayout.pullToRefresh();
                return true;

            case 2: // '\002'
                mFooterLayout.pullToRefresh();
                break;
            }
            return true;
        }
_L4:
        if(i != j) goto _L7; else goto _L10
_L10:
        return false;
        if(true) goto _L12; else goto _L11
_L11:
    }

    protected void addRefreshableView(Context context, View view)
    {
        addView(view, new android.widget.LinearLayout.LayoutParams(-1, 0, 1.0F));
    }

    protected abstract View createRefreshableView(Context context, AttributeSet attributeset);

    public final View getAdapterView()
    {
        return mRefreshableView;
    }

    public final int getCurrentMode()
    {
        return mCurrentMode;
    }

    protected final int getFooterHeight()
    {
        return mFooterHeight;
    }

    protected final LoadingLayout getFooterLayout()
    {
        return mFooterLayout;
    }

    protected final int getHeaderHeight()
    {
        return mHeaderHeight;
    }

    protected final LoadingLayout getHeaderLayout()
    {
        return mHeaderLayout;
    }

    public final int getMode()
    {
        return mMode;
    }

    public final View getRefreshableView()
    {
        return mRefreshableView;
    }

    public final boolean getShowViewWhileRefreshing()
    {
        return mShowViewWhileRefreshing;
    }

    protected final int getState()
    {
        return mState;
    }

    public final boolean hasPullFromTop()
    {
        return mCurrentMode != 2;
    }

    public final boolean isDisableScrollingWhileRefreshing()
    {
        return mDisableScrollingWhileRefreshing;
    }

    public final boolean isPullToRefreshEnabled()
    {
        return mPullToRefreshEnabled;
    }

    protected abstract boolean isReadyForPullDown();

    protected abstract boolean isReadyForPullUp();

    public final boolean isRefreshing()
    {
        return mState == 2 || mState == 3;
    }

    public final boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        int i;
        if(!mPullToRefreshEnabled)
            return false;
        if(isRefreshing() && mDisableScrollingWhileRefreshing)
            return true;
        i = motionevent.getAction();
        if(i == 3 || i == 1)
        {
            mIsBeingDragged = false;
            return false;
        }
        if(i != 0 && mIsBeingDragged)
            return true;
        i;
        JVM INSTR tableswitch 0 2: default 88
    //                   0 273
    //                   1 88
    //                   2 93;
           goto _L1 _L2 _L1 _L3
_L1:
        return mIsBeingDragged;
_L3:
        if(isReadyForPull())
        {
            float f1 = motionevent.getY();
            float f2 = f1 - mLastMotionY;
            float f3 = Math.abs(f2);
            float f4 = Math.abs(motionevent.getX() - mLastMotionX);
            if(f3 > (float)mTouchSlop && f3 > f4)
                if((mMode == 1 || mMode == 3) && f2 >= 1E-04F && isReadyForPullDown())
                {
                    mLastMotionY = f1;
                    mIsBeingDragged = true;
                    if(mMode == 3)
                        mCurrentMode = 1;
                } else
                if((mMode == 2 || mMode == 3) && f2 <= 1E-04F && isReadyForPullUp())
                {
                    mLastMotionY = f1;
                    mIsBeingDragged = true;
                    if(mMode == 3)
                        mCurrentMode = 2;
                }
        }
        continue; /* Loop/switch isn't completed */
_L2:
        if(isReadyForPull())
        {
            float f = motionevent.getY();
            mInitialMotionY = f;
            mLastMotionY = f;
            mLastMotionX = motionevent.getX();
            mIsBeingDragged = false;
        }
        if(true) goto _L1; else goto _L4
_L4:
    }

    public final void onRefreshComplete()
    {
        if(mState != 0)
        {
            resetHeader();
            setLastUpdatedLabel();
        }
    }

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        if(parcelable instanceof Bundle)
        {
            Bundle bundle = (Bundle)parcelable;
            int i = bundle.getInt("ptr_state", 0);
            mMode = bundle.getInt("ptr_mode", 1);
            mCurrentMode = bundle.getInt("ptr_current_mode", 1);
            mDisableScrollingWhileRefreshing = bundle.getBoolean("ptr_disable_scrolling", true);
            mShowViewWhileRefreshing = bundle.getBoolean("ptr_show_refreshing_view", true);
            super.onRestoreInstanceState(bundle.getParcelable("ptr_super"));
            if(i == 2)
            {
                setRefreshingInternal(true);
                mState = i;
            }
            return;
        } else
        {
            super.onRestoreInstanceState(parcelable);
            return;
        }
    }

    protected Parcelable onSaveInstanceState()
    {
        Bundle bundle = new Bundle();
        bundle.putInt("ptr_state", mState);
        bundle.putInt("ptr_mode", mMode);
        bundle.putInt("ptr_current_mode", mCurrentMode);
        bundle.putBoolean("ptr_disable_scrolling", mDisableScrollingWhileRefreshing);
        bundle.putBoolean("ptr_show_refreshing_view", mShowViewWhileRefreshing);
        bundle.putParcelable("ptr_super", super.onSaveInstanceState());
        return bundle;
    }

    public final boolean onTouchEvent(MotionEvent motionevent)
    {
        if(mPullToRefreshEnabled) goto _L2; else goto _L1
_L1:
        return false;
_L2:
        if(isRefreshing() && mDisableScrollingWhileRefreshing)
            return true;
        if(motionevent.getAction() == 0 && motionevent.getEdgeFlags() != 0) goto _L1; else goto _L3
_L3:
        motionevent.getAction();
        JVM INSTR tableswitch 0 3: default 72
    //                   0 74
    //                   1 120
    //                   2 98
    //                   3 120;
           goto _L4 _L5 _L6 _L7 _L6
_L6:
        continue; /* Loop/switch isn't completed */
_L4:
        return false;
_L5:
        if(!isReadyForPull()) goto _L1; else goto _L8
_L8:
        float f = motionevent.getY();
        mInitialMotionY = f;
        mLastMotionY = f;
        return true;
_L7:
        if(!mIsBeingDragged) goto _L1; else goto _L9
_L9:
        mLastMotionY = motionevent.getY();
        pullEvent();
        return true;
        if(!mIsBeingDragged) goto _L1; else goto _L10
_L10:
        mIsBeingDragged = false;
        if(mState != 1) goto _L12; else goto _L11
_L11:
        if(mOnRefreshListener != null)
        {
            setRefreshingInternal(true);
            mOnRefreshListener.onRefresh();
            return true;
        }
        if(mOnRefreshListener2 == null) goto _L14; else goto _L13
_L13:
        setRefreshingInternal(true);
        if(mCurrentMode != 1) goto _L16; else goto _L15
_L15:
        mOnRefreshListener2.onPullDownToRefresh();
_L17:
        return true;
_L16:
        if(mCurrentMode == 2)
            mOnRefreshListener2.onPullUpToRefresh();
        if(true) goto _L17; else goto _L14
_L14:
        return true;
_L12:
        smoothScrollTo(0);
        return true;
    }

    protected void resetHeader()
    {
        Log.e("TRDRU HEADER", (new StringBuilder()).append(mHeaderLayout.getMeasuredHeight()).append("").toString());
        mState = 0;
        mIsBeingDragged = false;
        if(mHeaderLayout != null)
            mHeaderLayout.reset();
        if(mFooterLayout != null)
            mFooterLayout.reset();
        if(mFooterLayout != null)
            mFooterHeight = mFooterLayout.getMeasuredHeight();
        if(mHeaderLayout != null)
            mHeaderHeight = mHeaderLayout.getMeasuredHeight();
        smoothScrollTo(0);
    }

    public final void setDisableScrollingWhileRefreshing(boolean flag)
    {
        mDisableScrollingWhileRefreshing = flag;
    }

    protected final void setHeaderScroll(int i)
    {
        scrollTo(0, i);
    }

    public void setLastUpdatedLabel()
    {
        setLastUpdatedLabel(calculateUpdateText());
    }

    public void setLastUpdatedLabel(CharSequence charsequence)
    {
        if(mDateMode != 4)
        {
            if(mHeaderLayout != null && (mDateMode == 1 || mDateMode == 3))
                mHeaderLayout.setSubHeaderText(charsequence);
            if(mFooterLayout != null && (mDateMode == 2 || mDateMode == 3))
                mFooterLayout.setSubHeaderText(charsequence);
            if(mMode == 1)
            {
                measureView(mHeaderLayout);
                int j = mHeaderLayout.getMeasuredHeight();
                mHeaderHeight = j;
                mFooterHeight = j;
            } else
            if(mMode == 2)
            {
                measureView(mFooterLayout);
                int i = mFooterLayout.getMeasuredHeight();
                mHeaderHeight = i;
                mFooterHeight = i;
            } else
            {
                measureView(mHeaderLayout);
                mHeaderHeight = mHeaderLayout.getMeasuredHeight();
                measureView(mFooterLayout);
                mFooterHeight = mFooterLayout.getMeasuredHeight();
            }
            measurePadding();
        }
    }

    public void setLongClickable(boolean flag)
    {
        getRefreshableView().setLongClickable(flag);
    }

    public final void setOnRefreshListener(OnRefreshListener2 onrefreshlistener2)
    {
        mOnRefreshListener2 = onrefreshlistener2;
    }

    public final void setOnRefreshListener(OnRefreshListener onrefreshlistener)
    {
        mOnRefreshListener = onrefreshlistener;
    }

    public void setPullLabel(String s)
    {
        setPullLabel(s, 3);
    }

    public void setPullLabel(String s, int i)
    {
        if(mHeaderLayout != null && (i == 1 || i == 3))
            mHeaderLayout.setPullLabel(s);
        if(mFooterLayout != null && (i == 2 || i == 3))
            mFooterLayout.setPullLabel(s);
    }

    public final void setPullToRefreshEnabled(boolean flag)
    {
        mPullToRefreshEnabled = flag;
    }

    public final void setRefreshing()
    {
        setRefreshing(true);
    }

    public final void setRefreshing(boolean flag)
    {
        if(!isRefreshing())
        {
            setRefreshingInternal(flag);
            mState = 3;
        }
    }

    protected void setRefreshingInternal(boolean flag)
    {
label0:
        {
            mState = 2;
            if(mHeaderLayout != null)
                mHeaderLayout.refreshing();
            if(mFooterLayout != null)
                mFooterLayout.refreshing();
            if(flag)
            {
                if(!mShowViewWhileRefreshing)
                    break label0;
                int i;
                if(mCurrentMode == 1)
                    i = -mHeaderHeight;
                else
                    i = mHeaderHeight;
                smoothScrollTo(i);
            }
            return;
        }
        smoothScrollTo(0);
    }

    public void setRefreshingLabel(String s)
    {
        setRefreshingLabel(s, 3);
    }

    public void setRefreshingLabel(String s, int i)
    {
        if(mHeaderLayout != null && (i == 1 || i == 3))
            mHeaderLayout.setRefreshingLabel(s);
        if(mFooterLayout != null && (i == 2 || i == 3))
            mFooterLayout.setRefreshingLabel(s);
    }

    public void setReleaseLabel(String s)
    {
        setReleaseLabel(s, 3);
    }

    public void setReleaseLabel(String s, int i)
    {
        if(mHeaderLayout != null && (i == 1 || i == 3))
            mHeaderLayout.setReleaseLabel(s);
        if(mFooterLayout != null && (i == 2 || i == 3))
            mFooterLayout.setReleaseLabel(s);
        Log.e("TRDRU HEADERsetr releasen header", (new StringBuilder()).append(mHeaderLayout.getMeasuredHeight()).append("").toString());
    }

    public final void setShowViewWhileRefreshing(boolean flag)
    {
        mShowViewWhileRefreshing = flag;
    }

    protected final void smoothScrollTo(int i)
    {
        if(mCurrentSmoothScrollRunnable != null)
            mCurrentSmoothScrollRunnable.stop();
        if(getScrollY() != i)
        {
            mCurrentSmoothScrollRunnable = new SmoothScrollRunnable(mHandler, getScrollY(), i);
            mHandler.post(mCurrentSmoothScrollRunnable);
        }
    }

    static final float FRICTION = 2F;
    static final String LOG_TAG = "PullToRefresh";
    static final int MANUAL_REFRESHING = 3;
    public static final int MODE_BOTH = 3;
    public static final int MODE_DATE_ON_BOTH = 3;
    public static final int MODE_DATE_ON_FOOTER = 2;
    public static final int MODE_DATE_ON_HEADER = 1;
    public static final int MODE_DATE_ON_NONE = 4;
    public static final int MODE_PULL_DOWN_TO_REFRESH = 1;
    public static final int MODE_PULL_UP_TO_REFRESH = 2;
    static final int PULL_TO_REFRESH = 0;
    static final int REFRESHING = 2;
    static final int RELEASE_TO_REFRESH = 1;
    static final String STATE_CURRENT_MODE = "ptr_current_mode";
    static final String STATE_DISABLE_SCROLLING_REFRESHING = "ptr_disable_scrolling";
    static final String STATE_MODE = "ptr_mode";
    static final String STATE_SHOW_REFRESHING_VIEW = "ptr_show_refreshing_view";
    static final String STATE_STATE = "ptr_state";
    static final String STATE_SUPER = "ptr_super";
    private int initialMFooterHeight;
    private int initialMHeaderHeight;
    private int mCurrentMode;
    private SmoothScrollRunnable mCurrentSmoothScrollRunnable;
    private int mDateMode;
    private boolean mDisableScrollingWhileRefreshing;
    private int mFooterHeight;
    private LoadingLayout mFooterLayout;
    private final Handler mHandler;
    private int mHeaderHeight;
    private LoadingLayout mHeaderLayout;
    private float mInitialMotionY;
    private boolean mIsBeingDragged;
    private float mLastMotionX;
    private float mLastMotionY;
    private int mMode;
    private OnRefreshListener mOnRefreshListener;
    private OnRefreshListener2 mOnRefreshListener2;
    private boolean mPullToRefreshEnabled;
    View mRefreshableView;
    private boolean mShowViewWhileRefreshing;
    private int mState;
    private int mTouchSlop;
}
