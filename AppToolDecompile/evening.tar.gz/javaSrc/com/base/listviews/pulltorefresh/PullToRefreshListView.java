// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.listviews.pulltorefresh;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import android.widget.*;

// Referenced classes of package com.base.listviews.pulltorefresh:
//            PullToRefreshAdapterViewBase, LoadingLayout, EmptyViewMethodAccessor

public class PullToRefreshListView extends PullToRefreshAdapterViewBase
{
    class InternalListView extends ListView
        implements EmptyViewMethodAccessor
    {

        public void draw(Canvas canvas)
        {
            try
            {
                super.draw(canvas);
                return;
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
        }

        public android.view.ContextMenu.ContextMenuInfo getContextMenuInfo()
        {
            return super.getContextMenuInfo();
        }

        public volatile void setAdapter(Adapter adapter)
        {
            setAdapter((ListAdapter)adapter);
        }

        public void setAdapter(ListAdapter listadapter)
        {
            if(!mAddedLvFooter && mLvFooterLoadingFrame != null)
            {
                addFooterView(mLvFooterLoadingFrame, null, false);
                mAddedLvFooter = true;
            }
            super.setAdapter(listadapter);
        }

        public void setEmptyView(View view)
        {
            PullToRefreshListView.this.setEmptyView(view);
        }

        public void setEmptyViewInternal(View view)
        {
            super.setEmptyView(view);
        }

        final PullToRefreshListView this$0;

        public InternalListView(Context context, AttributeSet attributeset)
        {
            this$0 = PullToRefreshListView.this;
            super(context, attributeset);
        }
    }


    public PullToRefreshListView(Context context)
    {
        super(context);
        mAddedLvFooter = false;
        setDisableScrollingWhileRefreshing(false);
    }

    public PullToRefreshListView(Context context, int i)
    {
        super(context, i);
        mAddedLvFooter = false;
        setDisableScrollingWhileRefreshing(false);
    }

    public PullToRefreshListView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mAddedLvFooter = false;
        setDisableScrollingWhileRefreshing(false);
    }

    protected volatile View createRefreshableView(Context context, AttributeSet attributeset)
    {
        return createRefreshableView(context, attributeset);
    }

    protected final ListView createRefreshableView(Context context, AttributeSet attributeset)
    {
        InternalListView internallistview = new InternalListView(context, attributeset);
        int i = getMode();
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.PullToRefresh);
        if(i == 1 || i == 3)
        {
            FrameLayout framelayout = new FrameLayout(context);
            mHeaderLoadingView = new LoadingLayout(context, 1, typedarray);
            framelayout.addView(mHeaderLoadingView, -1, -2);
            mHeaderLoadingView.setVisibility(8);
            internallistview.addHeaderView(framelayout, null, false);
        }
        if(i == 2 || i == 3)
        {
            mLvFooterLoadingFrame = new FrameLayout(context);
            mFooterLoadingView = new LoadingLayout(context, 2, typedarray);
            mLvFooterLoadingFrame.addView(mFooterLoadingView, -1, -2);
            mFooterLoadingView.setVisibility(8);
        }
        typedarray.recycle();
        internallistview.setId(0x102000a);
        return internallistview;
    }

    public android.view.ContextMenu.ContextMenuInfo getContextMenuInfo()
    {
        return ((InternalListView)getRefreshableView()).getContextMenuInfo();
    }

    protected int getNumberInternalFooterViews()
    {
        return mFooterLoadingView == null ? 0 : 1;
    }

    protected int getNumberInternalHeaderViews()
    {
        return mHeaderLoadingView == null ? 0 : 1;
    }

    protected void resetHeader()
    {
        int i;
        ListAdapter listadapter = ((ListView)mRefreshableView).getAdapter();
        if(!getShowViewWhileRefreshing() || listadapter == null || listadapter.isEmpty())
        {
            super.resetHeader();
            return;
        }
        i = getHeaderHeight();
        getCurrentMode();
        JVM INSTR tableswitch 2 2: default 64
    //                   2 124;
           goto _L1 _L2
_L1:
        LoadingLayout loadinglayout;
        LoadingLayout loadinglayout1;
        int j;
        loadinglayout = getHeaderLayout();
        loadinglayout1 = mHeaderLoadingView;
        i *= -1;
        j = 0;
_L4:
        loadinglayout.setVisibility(0);
        if(getState() != 3)
        {
            ((ListView)mRefreshableView).setSelection(j);
            setHeaderScroll(i);
        }
        loadinglayout1.setVisibility(8);
        super.resetHeader();
        return;
_L2:
        loadinglayout = getFooterLayout();
        loadinglayout1 = mFooterLoadingView;
        j = -1 + ((ListView)mRefreshableView).getCount();
        if(true) goto _L4; else goto _L3
_L3:
    }

    public void setAdapter(ListAdapter listadapter)
    {
        ((ListView)getRefreshableView()).setAdapter(listadapter);
        setLastUpdatedLabel();
    }

    public void setPullLabel(String s, int i)
    {
        super.setPullLabel(s, i);
        if(mHeaderLoadingView != null && (i == 1 || i == 3))
            mHeaderLoadingView.setPullLabel(s);
        if(mFooterLoadingView != null && (i == 2 || i == 3))
            mFooterLoadingView.setPullLabel(s);
    }

    protected void setRefreshingInternal(boolean flag)
    {
        ListAdapter listadapter = ((ListView)mRefreshableView).getAdapter();
        if(getShowViewWhileRefreshing() && listadapter != null && !listadapter.isEmpty()) goto _L2; else goto _L1
_L1:
        super.setRefreshingInternal(flag);
_L4:
        return;
_L2:
        LoadingLayout loadinglayout;
        LoadingLayout loadinglayout1;
        int i;
        int j;
        super.setRefreshingInternal(false);
        switch(getCurrentMode())
        {
        default:
            loadinglayout = getHeaderLayout();
            loadinglayout1 = mHeaderLoadingView;
            i = 0;
            j = getScrollY() + getHeaderHeight();
            break;

        case 2: // '\002'
            break; /* Loop/switch isn't completed */
        }
_L5:
        if(flag)
            setHeaderScroll(j);
        loadinglayout.setVisibility(4);
        loadinglayout1.setVisibility(0);
        loadinglayout1.refreshing();
        if(flag)
        {
            ((ListView)mRefreshableView).setSelection(i);
            smoothScrollTo(0);
            return;
        }
        if(true) goto _L4; else goto _L3
_L3:
        loadinglayout = getFooterLayout();
        loadinglayout1 = mFooterLoadingView;
        i = -1 + ((ListView)mRefreshableView).getCount();
        j = getScrollY() - getFooterHeight();
          goto _L5
        if(true) goto _L4; else goto _L6
_L6:
    }

    public void setRefreshingLabel(String s, int i)
    {
        super.setRefreshingLabel(s, i);
        if(mHeaderLoadingView != null && (i == 1 || i == 3))
            mHeaderLoadingView.setRefreshingLabel(s);
        if(mFooterLoadingView != null && (i == 2 || i == 3))
            mFooterLoadingView.setRefreshingLabel(s);
    }

    public void setReleaseLabel(String s, int i)
    {
        super.setReleaseLabel(s, i);
        if(mHeaderLoadingView != null && (i == 1 || i == 3))
            mHeaderLoadingView.setReleaseLabel(s);
        if(mFooterLoadingView != null && (i == 2 || i == 3))
            mFooterLoadingView.setReleaseLabel(s);
    }

    private boolean mAddedLvFooter;
    private LoadingLayout mFooterLoadingView;
    private LoadingLayout mHeaderLoadingView;
    private FrameLayout mLvFooterLoadingFrame;



/*
    static boolean access$002(PullToRefreshListView pulltorefreshlistview, boolean flag)
    {
        pulltorefreshlistview.mAddedLvFooter = flag;
        return flag;
    }

*/

}
