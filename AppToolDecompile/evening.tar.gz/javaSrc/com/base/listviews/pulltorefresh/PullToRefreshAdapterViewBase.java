// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.listviews.pulltorefresh;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.FrameLayout;

// Referenced classes of package com.base.listviews.pulltorefresh:
//            PullToRefreshBase, EmptyViewMethodAccessor

public abstract class PullToRefreshAdapterViewBase extends PullToRefreshBase
    implements android.widget.AbsListView.OnScrollListener
{

    public PullToRefreshAdapterViewBase(Context context)
    {
        super(context);
        mSavedLastVisibleIndex = -1;
        ((AbsListView)mRefreshableView).setOnScrollListener(this);
    }

    public PullToRefreshAdapterViewBase(Context context, int i)
    {
        super(context, i);
        mSavedLastVisibleIndex = -1;
        ((AbsListView)mRefreshableView).setOnScrollListener(this);
    }

    public PullToRefreshAdapterViewBase(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
        mSavedLastVisibleIndex = -1;
        ((AbsListView)mRefreshableView).setOnScrollListener(this);
    }

    private boolean isFirstItemVisible()
    {
        if(((AbsListView)mRefreshableView).getCount() <= getNumberInternalViews())
            return true;
        if(((AbsListView)mRefreshableView).getFirstVisiblePosition() == 0)
        {
            View view = ((AbsListView)mRefreshableView).getChildAt(0);
            if(view != null)
            {
                boolean flag;
                if(view.getTop() >= ((AbsListView)mRefreshableView).getTop())
                    flag = true;
                else
                    flag = false;
                return flag;
            }
        }
        return false;
    }

    private boolean isLastItemVisible()
    {
        int i = ((AbsListView)mRefreshableView).getCount();
        int j = ((AbsListView)mRefreshableView).getLastVisiblePosition();
        if(i <= getNumberInternalViews())
            return true;
        if(j == i - 1)
        {
            int k = j - ((AbsListView)mRefreshableView).getFirstVisiblePosition();
            View view = ((AbsListView)mRefreshableView).getChildAt(k);
            if(view != null)
            {
                boolean flag;
                if(view.getBottom() <= ((AbsListView)mRefreshableView).getBottom())
                    flag = true;
                else
                    flag = false;
                return flag;
            }
        }
        return false;
    }

    protected volatile void addRefreshableView(Context context, View view)
    {
        addRefreshableView(context, (AbsListView)view);
    }

    protected void addRefreshableView(Context context, AbsListView abslistview)
    {
        mRefreshableViewHolder = new FrameLayout(context);
        mRefreshableViewHolder.addView(abslistview, -1, -1);
        addView(mRefreshableViewHolder, new android.widget.LinearLayout.LayoutParams(-1, 0, 1.0F));
    }

    public abstract android.view.ContextMenu.ContextMenuInfo getContextMenuInfo();

    protected int getNumberInternalFooterViews()
    {
        return 0;
    }

    protected int getNumberInternalHeaderViews()
    {
        return 0;
    }

    protected int getNumberInternalViews()
    {
        return getNumberInternalHeaderViews() + getNumberInternalFooterViews();
    }

    protected boolean isReadyForPullDown()
    {
        return isFirstItemVisible();
    }

    protected boolean isReadyForPullUp()
    {
        return isLastItemVisible();
    }

    public final void onScroll(AbsListView abslistview, int i, int j, int k)
    {
        if(mOnLastItemVisibleListener != null)
        {
            int l = i + j;
            if(j > 0 && l + 1 == k && l != mSavedLastVisibleIndex)
            {
                mSavedLastVisibleIndex = l;
                mOnLastItemVisibleListener.onLastItemVisible();
            }
        }
        if(mOnScrollListener != null)
            mOnScrollListener.onScroll(abslistview, i, j, k);
    }

    public final void onScrollStateChanged(AbsListView abslistview, int i)
    {
        if(mOnScrollListener != null)
            mOnScrollListener.onScrollStateChanged(abslistview, i);
    }

    public final void setEmptyView(View view)
    {
label0:
        {
            if(mEmptyView != null)
                mRefreshableViewHolder.removeView(mEmptyView);
            if(view != null)
            {
                view.setClickable(true);
                android.view.ViewParent viewparent = view.getParent();
                if(viewparent != null && (viewparent instanceof ViewGroup))
                    ((ViewGroup)viewparent).removeView(view);
                mRefreshableViewHolder.addView(view, -1, -1);
                if(!(mRefreshableView instanceof EmptyViewMethodAccessor))
                    break label0;
                ((EmptyViewMethodAccessor)mRefreshableView).setEmptyViewInternal(view);
            }
            return;
        }
        ((AbsListView)mRefreshableView).setEmptyView(view);
    }

    public final void setOnLastItemVisibleListener(PullToRefreshBase.OnLastItemVisibleListener onlastitemvisiblelistener)
    {
        mOnLastItemVisibleListener = onlastitemvisiblelistener;
    }

    public final void setOnScrollListener(android.widget.AbsListView.OnScrollListener onscrolllistener)
    {
        mOnScrollListener = onscrolllistener;
    }

    private View mEmptyView;
    private PullToRefreshBase.OnLastItemVisibleListener mOnLastItemVisibleListener;
    private android.widget.AbsListView.OnScrollListener mOnScrollListener;
    private FrameLayout mRefreshableViewHolder;
    private int mSavedLastVisibleIndex;
}
