// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.slidemenu;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.*;
import java.lang.reflect.Method;

public abstract class SlideMenu extends LinearLayout
{

    public SlideMenu(Context context)
    {
        this(context, null);
    }

    public SlideMenu(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public SlideMenu(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset);
        animationState = 3;
        percentWidth = 0;
        slideDuration = 0;
        act = (Activity)context;
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.SlideMenu, i, 0);
        percentWidth = typedarray.getInt(0, 0);
        slideDuration = typedarray.getInt(1, 0);
        orientation = typedarray.getInt(3, 1);
        disableButtons = typedarray.getBoolean(2, true);
        init();
    }

    private void applyStatusbarOffset()
    {
        Rect rect = new Rect();
        act.getWindow().getDecorView().getWindowVisibleDisplayFrame(rect);
        statusHeight = rect.top;
    }

    private void enableDisableViewGroup(ViewGroup viewgroup, boolean flag)
    {
        int i = viewgroup.getChildCount();
        int j = 0;
        while(j < i) 
        {
            View view = viewgroup.getChildAt(j);
            if(view.isFocusable())
                view.setEnabled(flag);
            if(view instanceof ViewGroup)
                enableDisableViewGroup((ViewGroup)view, flag);
            else
            if(view instanceof ListView)
            {
                if(view.isFocusable())
                    view.setEnabled(flag);
                ListView listview = (ListView)view;
                int k = listview.getChildCount();
                int l = 0;
                while(l < k) 
                {
                    if(view.isFocusable())
                        listview.getChildAt(l).setEnabled(false);
                    l++;
                }
            }
            j++;
        }
    }

    private void show(boolean flag)
    {
        android.widget.FrameLayout.LayoutParams layoutparams;
        android.widget.FrameLayout.LayoutParams layoutparams1;
        try
        {
            content = (LinearLayout)act.findViewById(0x1020002).getParent();
        }
        catch(ClassCastException classcastexception)
        {
            content = (FrameLayout)act.findViewById(0x1020002);
        }
        if(orientation == 1 || orientation == 3)
            layoutparams = new android.widget.FrameLayout.LayoutParams(-1, -1, 3);
        else
            layoutparams = new android.widget.FrameLayout.LayoutParams(-1, -1, 80);
        if(orientation == 3)
            layoutparams.setMargins(-menuSize, 0, menuSize, 0);
        else
        if(orientation == 0)
            layoutparams.setMargins(0, menuSize, 0, -menuSize);
        else
        if(orientation == 2)
            layoutparams.setMargins(0, -menuSize, 0, menuSize);
        else
            layoutparams.setMargins(menuSize, 0, -menuSize, 0);
        content.setLayoutParams(layoutparams);
        if(flag)
            content.startAnimation(slideRightAnim);
        parent = (FrameLayout)content.getParent();
        initView();
        if(orientation == 3)
            layoutparams1 = new android.widget.FrameLayout.LayoutParams(menuSize, -1, 5);
        else
        if(orientation == 0)
            layoutparams1 = new android.widget.FrameLayout.LayoutParams(-1, menuSize, 48);
        else
        if(orientation == 2)
            layoutparams1 = new android.widget.FrameLayout.LayoutParams(-1, menuSize, 80);
        else
            layoutparams1 = new android.widget.FrameLayout.LayoutParams(menuSize, -1, 3);
        layoutparams1.setMargins(0, statusHeight, 0, 0);
        menu.setLayoutParams(layoutparams1);
        parent.addView(menu);
        initListeners();
        if(orientation == 2)
            parent.getChildAt(0).bringToFront();
        if(flag && orientation != 2)
            menu.startAnimation(slideRightAnim);
        if(disableButtons)
            enableDisableViewGroup(content, false);
        menuShown = true;
    }

    public void finishSlide()
    {
        content = null;
        parent = null;
        callback = null;
        act = null;
        removeAllViews();
        invalidate();
    }

    public int getAnimationState()
    {
        return animationState;
    }

    public void hide()
    {
        menu.startAnimation(slideMenuLeftAnim);
        parent.removeView(menu);
        content.startAnimation(slideContentLeftAnim);
        android.widget.FrameLayout.LayoutParams layoutparams = (android.widget.FrameLayout.LayoutParams)content.getLayoutParams();
        layoutparams.setMargins(0, 0, 0, 0);
        content.setLayoutParams(layoutparams);
        if(disableButtons)
            enableDisableViewGroup(content, true);
        menuShown = false;
        onHide();
    }

    public void hideAtOnce()
    {
        parent.removeView(menu);
        android.widget.FrameLayout.LayoutParams layoutparams = (android.widget.FrameLayout.LayoutParams)content.getLayoutParams();
        layoutparams.setMargins(0, 0, 0, 0);
        content.setLayoutParams(layoutparams);
        if(disableButtons)
            enableDisableViewGroup(content, true);
        menuShown = false;
        animationState = 3;
        onHide();
    }

    public void init()
    {
        if(orientation == 1)
        {
            menuSize = (act.getResources().getDisplayMetrics().widthPixels * percentWidth) / 100;
            slideRightAnim = new TranslateAnimation(-menuSize, 0.0F, 0.0F, 0.0F);
            slideRightAnim.setDuration(slideDuration);
            slideRightAnim.setFillAfter(true);
            slideMenuLeftAnim = new TranslateAnimation(0.0F, -menuSize, 0.0F, 0.0F);
            slideMenuLeftAnim.setDuration(slideDuration);
            slideMenuLeftAnim.setFillAfter(true);
            slideContentLeftAnim = new TranslateAnimation(menuSize, 0.0F, 0.0F, 0.0F);
            slideContentLeftAnim.setDuration(slideDuration);
            slideContentLeftAnim.setFillAfter(true);
        } else
        {
            if(orientation == 0)
            {
                menuSize = (act.getResources().getDisplayMetrics().heightPixels * percentWidth) / 100;
                slideRightAnim = new TranslateAnimation(0.0F, 0.0F, -menuSize, 0.0F);
                slideRightAnim.setDuration(slideDuration);
                slideRightAnim.setFillAfter(true);
                slideMenuLeftAnim = new TranslateAnimation(0.0F, 0.0F, 0.0F, -menuSize);
                slideMenuLeftAnim.setDuration(slideDuration);
                slideMenuLeftAnim.setFillAfter(true);
                slideContentLeftAnim = new TranslateAnimation(0.0F, 0.0F, menuSize, 0.0F);
                slideContentLeftAnim.setDuration(slideDuration);
                slideContentLeftAnim.setFillAfter(true);
                return;
            }
            if(orientation == 3)
            {
                menuSize = (act.getResources().getDisplayMetrics().widthPixels * percentWidth) / 100;
                slideRightAnim = new TranslateAnimation(menuSize, 0.0F, 0.0F, 0.0F);
                slideRightAnim.setDuration(slideDuration);
                slideRightAnim.setFillAfter(true);
                slideMenuLeftAnim = new TranslateAnimation(0.0F, menuSize, 0.0F, 0.0F);
                slideMenuLeftAnim.setDuration(slideDuration);
                slideMenuLeftAnim.setFillAfter(true);
                slideContentLeftAnim = new TranslateAnimation(-menuSize, 0.0F, 0.0F, 0.0F);
                slideContentLeftAnim.setDuration(slideDuration);
                slideContentLeftAnim.setFillAfter(true);
                return;
            }
            if(orientation == 2)
            {
                menuSize = (act.getResources().getDisplayMetrics().heightPixels * percentWidth) / 100;
                slideRightAnim = new TranslateAnimation(0.0F, 0.0F, menuSize, 0.0F);
                slideRightAnim.setDuration(slideDuration);
                slideRightAnim.setFillAfter(true);
                slideMenuLeftAnim = new TranslateAnimation(0.0F, 0.0F, 0.0F, menuSize);
                slideMenuLeftAnim.setDuration(slideDuration);
                slideMenuLeftAnim.setFillAfter(true);
                slideContentLeftAnim = new TranslateAnimation(0.0F, 0.0F, -menuSize, 0.0F);
                slideContentLeftAnim.setDuration(slideDuration);
                slideContentLeftAnim.setFillAfter(true);
                slideRightAnim.setAnimationListener(new android.view.animation.Animation.AnimationListener() {

                    public void onAnimationEnd(Animation animation)
                    {
                        animationState = 1;
                    }

                    public void onAnimationRepeat(Animation animation)
                    {
                    }

                    public void onAnimationStart(Animation animation)
                    {
                        animationState = 0;
                    }

                    final SlideMenu this$0;

            
            {
                this$0 = SlideMenu.this;
                super();
            }
                });
                slideMenuLeftAnim.setAnimationListener(new android.view.animation.Animation.AnimationListener() {

                    public void onAnimationEnd(Animation animation)
                    {
                        animationState = 3;
                    }

                    public void onAnimationRepeat(Animation animation)
                    {
                    }

                    public void onAnimationStart(Animation animation)
                    {
                    }

                    final SlideMenu this$0;

            
            {
                this$0 = SlideMenu.this;
                super();
            }
                });
                slideContentLeftAnim.setAnimationListener(new android.view.animation.Animation.AnimationListener() {

                    public void onAnimationEnd(Animation animation)
                    {
                    }

                    public void onAnimationRepeat(Animation animation)
                    {
                    }

                    public void onAnimationStart(Animation animation)
                    {
                        animationState = 2;
                    }

                    final SlideMenu this$0;

            
            {
                this$0 = SlideMenu.this;
                super();
            }
                });
                return;
            }
        }
    }

    protected abstract void initListeners();

    protected abstract void initView();

    public boolean isMenuShown()
    {
        return menuShown;
    }

    protected abstract void onHide();

    protected void onRestoreInstanceState(Parcelable parcelable)
    {
        try
        {
            if(parcelable instanceof Bundle)
            {
                Bundle bundle = (Bundle)parcelable;
                statusHeight = bundle.getInt("statusBarHeight");
                if(bundle.getBoolean("menuWasShown"))
                    show(false);
                super.onRestoreInstanceState(bundle.getParcelable("superState"));
                return;
            }
        }
        catch(NullPointerException nullpointerexception)
        {
            return;
        }
        super.onRestoreInstanceState(parcelable);
        return;
    }

    protected Parcelable onSaveInstanceState()
    {
        Bundle bundle = new Bundle();
        bundle.putParcelable("superState", super.onSaveInstanceState());
        bundle.putBoolean("menuWasShown", menuShown);
        bundle.putInt("statusBarHeight", statusHeight);
        return bundle;
    }

    protected abstract void onShow();

    public void setAnimationState(int i)
    {
        animationState = i;
    }

    public void setCallback(SlideMenuInterface.OnSlideMenuItemClickListener onslidemenuitemclicklistener)
    {
        callback = onslidemenuitemclicklistener;
    }

    public void show()
    {
        onShow();
        try
        {
            act.getClass().getMethod("getSupportActionBar", (Class[])null).invoke(act, (Object[])null).toString();
            if(android.os.Build.VERSION.SDK_INT >= 11)
                applyStatusbarOffset();
        }
        catch(Exception exception)
        {
            applyStatusbarOffset();
        }
        show(true);
    }

    private static final int BOTTOM = 2;
    public static final int FINISHED_TO_HIDE = 3;
    public static final int FINISHED_TO_SHOW = 1;
    private static final String KEY_MENUSHOWN = "menuWasShown";
    private static final String KEY_STATUSBARHEIGHT = "statusBarHeight";
    private static final String KEY_SUPERSTATE = "superState";
    private static final int LEFT = 1;
    private static final int RIGHT = 3;
    public static final int STARTING_TO_HIDE = 2;
    public static final int STARTING_TO_SHOW;
    private static final int TOP;
    protected static boolean menuShown = false;
    protected static int menuSize;
    protected Activity act;
    private int animationState;
    protected SlideMenuInterface.OnSlideMenuItemClickListener callback;
    private ViewGroup content;
    private boolean disableButtons;
    protected View menu;
    private int orientation;
    private FrameLayout parent;
    private int percentWidth;
    private TranslateAnimation slideContentLeftAnim;
    private int slideDuration;
    private TranslateAnimation slideMenuLeftAnim;
    private TranslateAnimation slideRightAnim;
    private int statusHeight;



/*
    static int access$002(SlideMenu slidemenu, int i)
    {
        slidemenu.animationState = i;
        return i;
    }

*/
}
