// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.textviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.text.Layout;
import android.text.StaticLayout;
import android.util.AttributeSet;
import android.widget.TextView;
import java.util.*;

public class EllipsizingTextView extends TextView
{
    public static interface EllipsizeListener
    {

        public abstract void ellipsizeStateChanged(boolean flag);
    }


    public EllipsizingTextView(Context context)
    {
        this(context, null);
    }

    public EllipsizingTextView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public EllipsizingTextView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        ellipsizeListeners = new ArrayList();
        lineSpacingMultiplier = 1.0F;
        lineAdditionalVerticalPadding = 0.0F;
        super.setEllipsize(null);
        setMaxLines(context.obtainStyledAttributes(attributeset, new int[] {
            0x1010153
        }).getInt(0, 0x7fffffff));
    }

    private Layout createWorkingLayout(String s)
    {
        return new StaticLayout(s, getPaint(), getWidth() - getPaddingLeft() - getPaddingRight(), android.text.Layout.Alignment.ALIGN_NORMAL, lineSpacingMultiplier, lineAdditionalVerticalPadding, false);
    }

    private int getFullyVisibleLinesCount()
    {
        Layout layout = createWorkingLayout("");
        return (getHeight() - getPaddingTop() - getPaddingBottom()) / layout.getLineBottom(0);
    }

    private int getLinesCount()
    {
        if(ellipsizingLastFullyVisibleLine())
        {
            int i = getFullyVisibleLinesCount();
            if(i == -1)
                i = 1;
            return i;
        } else
        {
            return maxLines;
        }
    }

    private void resetText()
    {
        String s;
        Layout layout;
        int i;
        int j;
        boolean flag;
        s = fullText;
        layout = createWorkingLayout(s);
        i = getLinesCount();
        j = layout.getLineCount();
        flag = false;
        if(j <= i) goto _L2; else goto _L1
_L1:
        String s1 = fullText.substring(0, layout.getLineEnd(i - 1)).trim();
_L7:
        if(createWorkingLayout((new StringBuilder()).append(s1).append("...").toString()).getLineCount() <= i) goto _L4; else goto _L3
_L3:
        int k = s1.lastIndexOf(' ');
        if(k != -1) goto _L5; else goto _L4
_L4:
        s = (new StringBuilder()).append(s1).append("...").toString();
        flag = true;
_L2:
        if(s.equals(getText()))
            break MISSING_BLOCK_LABEL_147;
        programmaticChange = true;
        setText(s);
        programmaticChange = false;
        isStale = false;
        if(flag != isEllipsized)
        {
            isEllipsized = flag;
            for(Iterator iterator = ellipsizeListeners.iterator(); iterator.hasNext(); ((EllipsizeListener)iterator.next()).ellipsizeStateChanged(flag));
        }
        break; /* Loop/switch isn't completed */
_L5:
        s1 = s1.substring(0, k);
        if(true) goto _L7; else goto _L6
        Exception exception;
        exception;
        programmaticChange = false;
        throw exception;
_L6:
    }

    public void addEllipsizeListener(EllipsizeListener ellipsizelistener)
    {
        if(ellipsizelistener == null)
        {
            throw new NullPointerException();
        } else
        {
            ellipsizeListeners.add(ellipsizelistener);
            return;
        }
    }

    public boolean ellipsizingLastFullyVisibleLine()
    {
        return maxLines == 0x7fffffff;
    }

    public int getMaxLines()
    {
        return maxLines;
    }

    public boolean isEllipsized()
    {
        return isEllipsized;
    }

    protected void onDraw(Canvas canvas)
    {
        if(isStale)
            resetText();
        super.onDraw(canvas);
    }

    protected void onSizeChanged(int i, int j, int k, int l)
    {
        super.onSizeChanged(i, j, k, l);
        if(ellipsizingLastFullyVisibleLine())
            isStale = true;
    }

    protected void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
        super.onTextChanged(charsequence, i, j, k);
        if(!programmaticChange)
        {
            fullText = charsequence.toString();
            isStale = true;
        }
    }

    public void removeEllipsizeListener(EllipsizeListener ellipsizelistener)
    {
        ellipsizeListeners.remove(ellipsizelistener);
    }

    public void setEllipsize(android.text.TextUtils.TruncateAt truncateat)
    {
    }

    public void setLineSpacing(float f, float f1)
    {
        lineAdditionalVerticalPadding = f;
        lineSpacingMultiplier = f1;
        super.setLineSpacing(f, f1);
    }

    public void setMaxLines(int i)
    {
        super.setMaxLines(i);
        maxLines = i;
        isStale = true;
    }

    public void setPadding(int i, int j, int k, int l)
    {
        super.setPadding(i, j, k, l);
        if(ellipsizingLastFullyVisibleLine())
            isStale = true;
    }

    private static final String ELLIPSIS = "...";
    private final List ellipsizeListeners;
    private String fullText;
    private boolean isEllipsized;
    private boolean isStale;
    private float lineAdditionalVerticalPadding;
    private float lineSpacingMultiplier;
    private int maxLines;
    private boolean programmaticChange;
}
