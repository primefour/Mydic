// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.textviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.widget.TextView;

public class AutoFitTextView extends TextView
{

    public AutoFitTextView(Context context)
    {
        this(context, null);
    }

    public AutoFitTextView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public AutoFitTextView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.AutoFitTextView, i, 0);
        minTextSize = typedarray.getDimension(0, 20F);
        maxTextSize = typedarray.getDimension(1, 40F);
        if(getTextSize() > maxTextSize)
            maxTextSize = getTextSize();
    }

    private void refitText(String s, int i)
    {
        if(i <= 0) goto _L2; else goto _L1
_L1:
        int j;
        float f;
        j = i - getPaddingLeft() - getPaddingRight();
        f = maxTextSize;
        setTextSize(0, f);
_L8:
        if(f <= minTextSize || getPaint().measureText(s) <= (float)j) goto _L4; else goto _L3
_L3:
        f--;
        if(f > minTextSize) goto _L6; else goto _L5
_L5:
        f = minTextSize;
_L4:
        setTextSize(0, f);
_L2:
        return;
_L6:
        setTextSize(0, f);
        if(true) goto _L8; else goto _L7
_L7:
    }

    public float getMaxTextSize()
    {
        return maxTextSize;
    }

    public float getMinTextSize()
    {
        return minTextSize;
    }

    protected void onMeasure(int i, int j)
    {
        super.onMeasure(i, j);
        int k = android.view.View.MeasureSpec.getSize(i);
        refitText(getText().toString(), k);
    }

    protected void onSizeChanged(int i, int j, int k, int l)
    {
        if(i != k)
            refitText(getText().toString(), i);
    }

    protected void onTextChanged(CharSequence charsequence, int i, int j, int k)
    {
        refitText(charsequence.toString(), getWidth());
    }

    public void setMaxTextSize(int i)
    {
        maxTextSize = i;
    }

    public void setMinTextSize(int i)
    {
        minTextSize = i;
    }

    private float maxTextSize;
    private float minTextSize;
}
