// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.textviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.TextView;

public class GradientTextView extends TextView
{

    public GradientTextView(Context context)
    {
        this(context, null);
    }

    public GradientTextView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public GradientTextView(Context context, AttributeSet attributeset, int i)
    {
        TypedArray typedarray;
        super(context, attributeset, i);
        shadowColor = 0;
        gradientStart = 0;
        gradientEnd = 100;
        startColorPercentage = 0.0F;
        shadowBlurRadius = 0.0F;
        shadowXOffset = 0.0F;
        shadowYOffset = 0.0F;
        gradientDirection = 0;
        gradientTileMode = 0;
        typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.GradientTextView, i, 0);
        shadowColor = typedarray.getInt(0, 0);
        shadowBlurRadius = typedarray.getDimension(1, 0.0F);
        shadowXOffset = typedarray.getDimension(2, 0.0F);
        shadowYOffset = typedarray.getDimension(3, 0.0F);
        Log.e("GradientTextView", (new StringBuilder()).append("Blur: ").append(shadowBlurRadius).append(" XOffset: ").append(shadowXOffset).append(" YOffset: ").append(shadowYOffset).toString());
        gradientStart = typedarray.getInt(4, 0);
        gradientEnd = typedarray.getInt(5, 0);
        gradientDirection = typedarray.getInt(7, 0);
        gradientTileMode = typedarray.getInt(8, 0);
        if(gradientTileMode != 0) goto _L2; else goto _L1
_L1:
        tileMode = android.graphics.Shader.TileMode.CLAMP;
_L4:
        startColorPercentage = typedarray.getFloat(6, 0.0F);
        typedarray.recycle();
        return;
_L2:
        if(gradientTileMode == 1)
            tileMode = android.graphics.Shader.TileMode.MIRROR;
        else
        if(gradientTileMode == 2)
            tileMode = android.graphics.Shader.TileMode.REPEAT;
        if(true) goto _L4; else goto _L3
_L3:
    }

    protected void onDraw(Canvas canvas)
    {
        getPaint().setShadowLayer(shadowBlurRadius, shadowXOffset, shadowYOffset, shadowColor);
        getPaint().setShader(null);
        super.onDraw(canvas);
        getPaint().clearShadowLayer();
        if(gradientDirection != 0) goto _L2; else goto _L1
_L1:
        getPaint().setShader(new LinearGradient(0.0F, ((float)getHeight() * startColorPercentage) / 100F, 0.0F, 0.0F, gradientStart, gradientEnd, tileMode));
_L4:
        super.onDraw(canvas);
        return;
_L2:
        if(gradientDirection == 1)
            getPaint().setShader(new LinearGradient(((float)getWidth() * startColorPercentage) / 100F, 0.0F, 0.0F, 0.0F, gradientStart, gradientEnd, tileMode));
        if(true) goto _L4; else goto _L3
_L3:
    }

    private static final int CLAMP = 0;
    private static final int HORIZONTAL = 1;
    private static final int MIRROR = 1;
    private static final int REPEAT = 2;
    private static final int VERTICAL;
    private int gradientDirection;
    private int gradientEnd;
    private int gradientStart;
    private int gradientTileMode;
    private float shadowBlurRadius;
    private int shadowColor;
    private float shadowXOffset;
    private float shadowYOffset;
    private float startColorPercentage;
    private android.graphics.Shader.TileMode tileMode;
}
