// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.scrollviews;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.webkit.WebView;
import android.widget.ScrollView;

public class ScrollViewForWebView extends ScrollView
{

    public ScrollViewForWebView(Context context)
    {
        super(context);
    }

    public ScrollViewForWebView(Context context, AttributeSet attributeset)
    {
        super(context, attributeset);
    }

    public ScrollViewForWebView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
    }

    public void requestChildFocus(View view, View view1)
    {
        if(view1 instanceof WebView)
        {
            return;
        } else
        {
            super.requestChildFocus(view, view1);
            return;
        }
    }
}
