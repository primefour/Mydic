// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.swipeytabs;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.*;
import android.support.v4.view.*;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.TextView;

// Referenced classes of package com.base.swipeytabs:
//            PageIndicator, SwipeyTabsAdapter

public class SwipeyTabs extends ViewGroup
    implements PageIndicator
{
    public static interface OnCenterItemClickListener
    {

        public abstract void onCenterItemClick(int i);
    }

    public static interface OnSwipeyTabChangedListener
    {

        public abstract void onSwipeyTabSelected(int i);
    }


    public SwipeyTabs(Context context)
    {
        this(context, null);
    }

    public SwipeyTabs(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public SwipeyTabs(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        TAG = com/base/swipeytabs/SwipeyTabs.getSimpleName();
        mCurrentPos = -1;
        mBottomBarHeight = 2;
        mTabIndicatorHeight = 3;
        mBottomBarColor = 0xff96aa39;
        mWidth = -1;
        mActivePointerId = -1;
        mLastMotionX = -1F;
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.SwipeyTabs, i, 0);
        mTextColor = typedarray.getInt(2, 0xff949494);
        mFrotendTabTextColor = typedarray.getInt(1, 0xff96aa39);
        mBottomBarColor = typedarray.getColor(0, mBottomBarColor);
        mBottomBarHeight = typedarray.getDimensionPixelSize(3, 2);
        mTabIndicatorHeight = typedarray.getDimensionPixelSize(4, 3);
        typedarray.recycle();
        init();
    }

    private void calculateTabPosition(int i, int ai[])
    {
        if(mAdapter != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        int j = mAdapter.getCount();
        if(i < 0 || i >= j)
            break; /* Loop/switch isn't completed */
        int l = getMeasuredWidth();
        View view = getChildAt(i);
        ai[i] = l / 2 - view.getMeasuredWidth() / 2;
        for(int i1 = i - 1; i1 >= 0; i1--)
        {
            TextView textview1 = (TextView)getChildAt(i1);
            ai[i1] = 0 - textview1.getMeasuredWidth() / 2;
            ai[i1] = Math.min(ai[i1], ai[i1 + 1] - textview1.getMeasuredWidth());
        }

        int j1 = i + 1;
        while(j1 < j) 
        {
            ai[j1] = l - ((TextView)getChildAt(j1)).getMeasuredWidth() / 2;
            TextView textview = (TextView)getChildAt(j1 - 1);
            ai[j1] = Math.max(ai[j1], ai[j1 - 1] + textview.getMeasuredWidth());
            j1++;
        }
        if(true) goto _L1; else goto _L3
_L3:
        int k = 0;
        while(k < ai.length) 
        {
            ai[k] = -1;
            k++;
        }
        if(true) goto _L1; else goto _L4
_L4:
    }

    private void init()
    {
        setHorizontalFadingEdgeEnabled(true);
        setFadingEdgeLength((int)(0.5F + 35F * getResources().getDisplayMetrics().density));
        setWillNotDraw(false);
        mCachedTabPaint = new Paint();
        mCachedTabPaint.setColor(mBottomBarColor);
    }

    private int interpolateColor(int i, int j, float f)
    {
        float f1 = (float)Color.alpha(i) / 255F;
        float f2 = (float)Color.red(i) / 255F;
        float f3 = (float)Color.green(i) / 255F;
        float f4 = (float)Color.blue(i) / 255F;
        float f5 = (float)Color.alpha(j) / 255F;
        float f6 = (float)Color.red(j) / 255F;
        float f7 = (float)Color.green(j) / 255F;
        float f8 = (float)Color.blue(j) / 255F;
        float f9 = f5 - f1;
        float f10 = f6 - f2;
        float f11 = f7 - f3;
        float f12 = f8 - f4;
        float f13 = f1 + f9 * f;
        float f14 = f2 + f10 * f;
        float f15 = f3 + f11 * f;
        float f16 = f4 + f12 * f;
        float f17 = Math.max(Math.min(f13, 1.0F), 0.0F);
        float f18 = Math.max(Math.min(f14, 1.0F), 0.0F);
        float f19 = Math.max(Math.min(f15, 1.0F), 0.0F);
        float f20 = Math.max(Math.min(f16, 1.0F), 0.0F);
        return Color.argb((int)(255F * f17), (int)(255F * f18), (int)(255F * f19), (int)(255F * f20));
    }

    private void measureTabs(int i, int j)
    {
        if(mAdapter != null)
        {
            int k = (int)(0.59999999999999998D * (double)android.view.View.MeasureSpec.getSize(i));
            int l = mAdapter.getCount();
            int i1 = 0;
            while(i1 < l) 
            {
                android.view.ViewGroup.LayoutParams layoutparams = getChildAt(i1).getLayoutParams();
                int j1 = android.view.View.MeasureSpec.makeMeasureSpec(k, 0x80000000);
                int k1 = android.view.View.MeasureSpec.makeMeasureSpec(layoutparams.height, 0x40000000);
                getChildAt(i1).measure(j1, k1);
                i1++;
            }
        }
    }

    private void updateEllipsize()
    {
        if(mAdapter != null)
        {
            int i = mAdapter.getCount();
            int j = 0;
            while(j < i) 
            {
                TextView textview = (TextView)getChildAt(j);
                if(j < mCurrentPos)
                {
                    textview.setEllipsize(null);
                    textview.setGravity(21);
                } else
                if(j == mCurrentPos)
                {
                    textview.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    textview.setGravity(19);
                } else
                if(j > mCurrentPos)
                {
                    textview.setEllipsize(null);
                    textview.setGravity(19);
                }
                j++;
            }
        }
    }

    private void updateTabPositions(boolean flag)
    {
        if(mAdapter != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        calculateTabPosition(mCurrentPos, mFrontedTabPos);
        calculateTabPosition(1 + mCurrentPos, mLeftTabPos);
        calculateTabPosition(-1 + mCurrentPos, mRightTabPos);
        updateEllipsize();
        if(flag)
        {
            int i = mAdapter.getCount();
            int j = 0;
            while(j < i) 
            {
                mCurrentTabPos[j] = mFrontedTabPos[j];
                j++;
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    protected void dispatchDraw(Canvas canvas)
    {
        if(mCurrentPos != -1)
        {
            int i = getHeight() - getPaddingBottom() - mBottomBarHeight - mTabIndicatorHeight;
            View view = getChildAt(mCurrentPos);
            int j = (mCurrentTabPos[mCurrentPos] + view.getMeasuredWidth()) - view.getMeasuredWidth() / 2;
            int k = getWidth() / 2;
            int l = k / 3;
            float f = 1.0F - Math.min(Math.abs((float)(j - k) / (float)l), 1.0F);
            mCachedTabPaint.setAlpha((int)(255F * f));
            canvas.drawRect(mCurrentTabPos[mCurrentPos], i, mCurrentTabPos[mCurrentPos] + view.getMeasuredWidth(), i + mTabIndicatorHeight, mCachedTabPaint);
            int i1 = mAdapter.getCount();
            int j1 = 0;
            while(j1 < i1) 
            {
                TextView textview = (TextView)getChildAt(j1);
                if(mCurrentPos == j1)
                    textview.setTextColor(interpolateColor(mFrotendTabTextColor, mTextColor, 1.0F - f));
                else
                    textview.setTextColor(mTextColor);
                textview.setBackgroundColor(0);
                j1++;
            }
        }
        super.dispatchDraw(canvas);
    }

    public void draw(Canvas canvas)
    {
        super.draw(canvas);
        int i = getHeight() - getPaddingBottom() - mBottomBarHeight;
        mCachedTabPaint.setAlpha(255);
        canvas.drawRect(0.0F, i, getWidth(), i + mBottomBarHeight, mCachedTabPaint);
    }

    public int getBottomBarColor()
    {
        return mBottomBarColor;
    }

    public int getForegroundTabTextColor()
    {
        return mTextColor;
    }

    public int getFrotendTabTextColor()
    {
        return mFrotendTabTextColor;
    }

    protected float getLeftFadingEdgeStrength()
    {
        return 1.0F;
    }

    protected float getRightFadingEdgeStrength()
    {
        return 1.0F;
    }

    protected void myEventFired(int i)
    {
        if(mySwipeyTabChangedListener != null)
            mySwipeyTabChangedListener.onSwipeyTabSelected(i);
    }

    public void notifyDataSetChanged()
    {
        invalidate();
    }

    public boolean onInterceptTouchEvent(MotionEvent motionevent)
    {
        return false;
    }

    protected void onLayout(boolean flag, int i, int j, int k, int l)
    {
        if(mAdapter != null)
        {
            int i1 = mAdapter.getCount();
            int j1 = 0;
            while(j1 < i1) 
            {
                View view = getChildAt(j1);
                view.layout(mCurrentTabPos[j1], getPaddingTop(), mCurrentTabPos[j1] + view.getMeasuredWidth(), getPaddingTop() + view.getMeasuredHeight());
                j1++;
            }
        }
    }

    protected void onMeasure(int i, int j)
    {
        int k = android.view.View.MeasureSpec.getSize(i);
        measureTabs(i, j);
        View view = getChildAt(0);
        int l = 0;
        if(view != null)
            l = view.getMeasuredHeight();
        setMeasuredDimension(resolveSize(k + getPaddingLeft() + getPaddingRight(), i), resolveSize(l + mBottomBarHeight + getPaddingTop() + getPaddingBottom(), j));
        if(mWidth != k)
        {
            mWidth = k;
            updateTabPositions(true);
        }
    }

    public void onPageScrollStateChanged(int i)
    {
    }

    public void onPageScrolled(int i, float f, int j)
    {
        byte byte0;
        if(mAdapter == null)
            return;
        int k = mAdapter.getCount();
        float f1;
        float f2;
        int j1;
        if(j != 0 && mCurrentPos == i)
        {
            byte0 = -1;
            f1 = f;
            break MISSING_BLOCK_LABEL_37;
        } else
        {
            byte0 = 0;
            f1 = 0.0F;
            if(j != 0)
            {
                int l = mCurrentPos;
                byte0 = 0;
                f1 = 0.0F;
                if(l != i)
                {
                    byte0 = 1;
                    f1 = 1.0F - f;
                }
            }
            continue;
        }
        do
        {
            int i1 = 0;
            while(i1 < k) 
            {
                f2 = mFrontedTabPos[i1];
                float f3;
                if(byte0 < 0)
                    f3 = mLeftTabPos[i1];
                else
                if(byte0 > 0)
                    f3 = mRightTabPos[i1];
                else
                    f3 = mFrontedTabPos[i1];
                j1 = (int)(f2 + (float)(int)(0.5F + f1 * (f3 - f2)));
                mCurrentTabPos[i1] = j1;
                i1++;
            }
            requestLayout();
            invalidate();
            return;
        } while(true);
    }

    public void onPageSelected(int i)
    {
        mCurrentPos = i;
        updateTabPositions(false);
        myEventFired(i);
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if(super.onTouchEvent(motionevent))
            return true;
        if(mViewPager == null || mViewPager.getAdapter().getCount() == 0)
            return false;
        0xff & motionevent.getAction();
        JVM INSTR tableswitch 0 6: default 84
    //                   0 86
    //                   1 198
    //                   2 106
    //                   3 198
    //                   4 84
    //                   5 373
    //                   6 402;
           goto _L1 _L2 _L3 _L4 _L3 _L1 _L5 _L6
_L1:
        return true;
_L2:
        mActivePointerId = MotionEventCompat.getPointerId(motionevent, 0);
        mLastMotionX = motionevent.getX();
        continue; /* Loop/switch isn't completed */
_L4:
        float f5 = MotionEventCompat.getX(motionevent, MotionEventCompat.findPointerIndex(motionevent, mActivePointerId));
        float f6 = f5 - mLastMotionX;
        if(!mIsDragging && Math.abs(f6) > (float)mTouchSlop)
            mIsDragging = true;
        if(mIsDragging)
        {
            if(!mViewPager.isFakeDragging())
                mViewPager.beginFakeDrag();
            mLastMotionX = f5;
            mViewPager.fakeDragBy(f6);
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if(!mIsDragging)
        {
            int l = mViewPager.getAdapter().getCount();
            int i1 = getWidth();
            float f = (float)i1 / 2.0F;
            float f1 = (float)i1 / 6F;
            float f2 = f - f1;
            float f3 = f + f1;
            float f4 = motionevent.getX();
            if(f4 < f2)
            {
                if(mCurrentPage > 0)
                {
                    mViewPager.setCurrentItem(-1 + mCurrentPage);
                    return true;
                }
            } else
            if(f4 > f3)
            {
                if(mCurrentPage < l - 1)
                {
                    mViewPager.setCurrentItem(1 + mCurrentPage);
                    return true;
                }
            } else
            if(mCenterItemClickListener != null)
                mCenterItemClickListener.onCenterItemClick(mCurrentPage);
        }
        mIsDragging = false;
        mActivePointerId = -1;
        if(mViewPager.isFakeDragging())
            mViewPager.endFakeDrag();
        continue; /* Loop/switch isn't completed */
_L5:
        int k = MotionEventCompat.getActionIndex(motionevent);
        mLastMotionX = MotionEventCompat.getX(motionevent, k);
        mActivePointerId = MotionEventCompat.getPointerId(motionevent, k);
        continue; /* Loop/switch isn't completed */
_L6:
        int i = MotionEventCompat.getActionIndex(motionevent);
        if(MotionEventCompat.getPointerId(motionevent, i) == mActivePointerId)
        {
            int j;
            if(i == 0)
                j = 1;
            else
                j = 0;
            mActivePointerId = MotionEventCompat.getPointerId(motionevent, j);
        }
        mLastMotionX = MotionEventCompat.getX(motionevent, MotionEventCompat.findPointerIndex(motionevent, mActivePointerId));
        if(true) goto _L1; else goto _L7
_L7:
    }

    public void setAdapter(SwipeyTabsAdapter swipeytabsadapter)
    {
        if(mAdapter == null);
        mAdapter = swipeytabsadapter;
        mCurrentPos = -1;
        mFrontedTabPos = null;
        mLeftTabPos = null;
        mRightTabPos = null;
        mCurrentTabPos = null;
        removeAllViews();
        if(mAdapter != null)
        {
            int i = mAdapter.getCount();
            for(int j = 0; j < i; j++)
                addView(mAdapter.getTab(j, this));

            mCurrentPos = 0;
            mFrontedTabPos = new int[i];
            mLeftTabPos = new int[i];
            mRightTabPos = new int[i];
            mCurrentTabPos = new int[i];
            mWidth = -1;
            requestLayout();
        }
    }

    public void setBottomBarColor(int i)
    {
        mBottomBarColor = i;
        mCachedTabPaint.setColor(i);
    }

    public void setCurrentItem(int i)
    {
        if(mViewPager == null)
        {
            throw new IllegalStateException("ViewPager has not been bound.");
        } else
        {
            mViewPager.setCurrentItem(i);
            mCurrentPage = i;
            invalidate();
            return;
        }
    }

    public void setForegroundTabTextColor(int i)
    {
        mTextColor = i;
    }

    public void setFrotendTabTextColor(int i)
    {
        mFrotendTabTextColor = i;
    }

    public void setOnPageChangeListener(android.support.v4.view.ViewPager.OnPageChangeListener onpagechangelistener)
    {
        mListener = onpagechangelistener;
    }

    public void setOnSwipeyTabChangedListener(OnSwipeyTabChangedListener onswipeytabchangedlistener)
    {
        mySwipeyTabChangedListener = onswipeytabchangedlistener;
    }

    public void setViewPager(ViewPager viewpager)
    {
        if(viewpager.getAdapter() == null)
        {
            throw new IllegalStateException("ViewPager does not have adapter instance.");
        } else
        {
            mViewPager = viewpager;
            mViewPager.setOnPageChangeListener(this);
            invalidate();
            return;
        }
    }

    public void setViewPager(ViewPager viewpager, int i)
    {
        setViewPager(viewpager);
        setCurrentItem(i);
    }

    private static final int INVALID_POINTER = -1;
    protected final String TAG;
    private int mActivePointerId;
    private SwipeyTabsAdapter mAdapter;
    private int mBottomBarColor;
    private int mBottomBarHeight;
    private Paint mCachedTabPaint;
    private OnCenterItemClickListener mCenterItemClickListener;
    private int mCurrentPage;
    private int mCurrentPos;
    private int mCurrentTabPos[];
    private int mFrontedTabPos[];
    private int mFrotendTabTextColor;
    private boolean mIsDragging;
    private float mLastMotionX;
    private int mLeftTabPos[];
    private android.support.v4.view.ViewPager.OnPageChangeListener mListener;
    private int mRightTabPos[];
    private int mTabIndicatorHeight;
    private int mTextColor;
    private int mTouchSlop;
    private ViewPager mViewPager;
    private int mWidth;
    OnSwipeyTabChangedListener mySwipeyTabChangedListener;
}
