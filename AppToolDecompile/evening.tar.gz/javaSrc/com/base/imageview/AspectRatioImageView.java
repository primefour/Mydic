// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.imageview;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.*;
import android.util.AttributeSet;
import android.widget.ImageView;
import android.widget.RelativeLayout;

public class AspectRatioImageView extends ImageView
{

    public AspectRatioImageView(Context context)
    {
        this(context, null);
    }

    public AspectRatioImageView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public AspectRatioImageView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        somebodySetMe = false;
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.AspectRatioImageView, i, 0);
        stretchMode = typedarray.getInt(0, 0);
        typedarray.recycle();
    }

    private void recalculateLayout()
    {
        if(getParent() instanceof RelativeLayout)
        {
            android.widget.RelativeLayout.LayoutParams _tmp = (android.widget.RelativeLayout.LayoutParams)getLayoutParams();
            android.widget.RelativeLayout.LayoutParams layoutparams;
            if(stretchMode == 2)
                layoutparams = new android.widget.RelativeLayout.LayoutParams(-1, -2);
            else
                layoutparams = new android.widget.RelativeLayout.LayoutParams(-2, -1);
            setLayoutParams(layoutparams);
        }
    }

    protected void onMeasure(int i, int j)
    {
        boolean flag1;
        float f;
        int k;
        int l;
        if((getDrawable() == null || stretchMode != 0 && stretchMode != 1) && (stretchMode != 2 && stretchMode != 3 || !somebodySetMe))
            break MISSING_BLOCK_LABEL_301;
        boolean flag;
        float f2;
        int k1;
        if(android.view.View.MeasureSpec.getMode(i) == 0x40000000)
            flag = true;
        else
            flag = false;
        if(android.view.View.MeasureSpec.getMode(j) == 0x40000000)
            flag1 = true;
        else
            flag1 = false;
        if(!(getDrawable() instanceof BitmapDrawable)) goto _L2; else goto _L1
_L1:
        f2 = ((BitmapDrawable)getDrawable()).getIntrinsicWidth();
        k1 = ((BitmapDrawable)getDrawable()).getIntrinsicHeight();
        f = f2 / (float)k1;
_L3:
        k = android.view.View.MeasureSpec.makeMeasureSpec((int)((float)android.view.View.MeasureSpec.getSize(i) / f), 0x40000000);
        l = android.view.View.MeasureSpec.makeMeasureSpec((int)(f * (float)android.view.View.MeasureSpec.getSize(j)), 0x40000000);
        ClassCastException classcastexception;
        ArithmeticException arithmeticexception;
        int i1;
        float f1;
        int j1;
        if(flag)
            if(flag1)
            {
                super.onMeasure(i, j);
                return;
            } else
            {
                super.onMeasure(i, k);
                return;
            }
        break MISSING_BLOCK_LABEL_257;
_L2:
        f1 = ((TransitionDrawable)getDrawable()).getIntrinsicWidth();
        j1 = ((TransitionDrawable)getDrawable()).getIntrinsicHeight();
        f = f1 / (float)j1;
          goto _L3
        classcastexception;
        classcastexception.printStackTrace();
        i1 = android.view.View.MeasureSpec.getSize(i) / android.view.View.MeasureSpec.getSize(j);
        f = i1;
          goto _L3
        arithmeticexception;
        arithmeticexception.printStackTrace();
        f = (float)i / (float)j;
          goto _L3
        if(flag1)
        {
            super.onMeasure(l, j);
            return;
        }
        if(stretchMode == 0 || stretchMode == 2)
        {
            super.onMeasure(i, k);
            return;
        } else
        {
            super.onMeasure(l, j);
            return;
        }
        super.onMeasure(i, j);
        return;
    }

    public void setBackgroundResource(int i)
    {
        super.setBackgroundResource(i);
    }

    public void setImageBitmap(Bitmap bitmap)
    {
        somebodySetMe = true;
        if(stretchMode == 2 || stretchMode == 3)
            recalculateLayout();
        super.setImageBitmap(bitmap);
    }

    public void setImageDrawable(Drawable drawable)
    {
        if(drawable instanceof TransitionDrawable)
        {
            somebodySetMe = true;
            if(stretchMode == 2 || stretchMode == 3)
                recalculateLayout();
        }
        super.setImageDrawable(drawable);
    }

    private static final int HORIZONTAL = 0;
    private static final int HORIZONTAL_AFTER_FIRST_IMAGE = 2;
    private static final int VERTICAL = 1;
    private static final int VERTICAL_AFTER_FIRST_IMAGE = 3;
    private boolean somebodySetMe;
    private final int stretchMode;
}
