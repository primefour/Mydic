// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.imageview;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.widget.ImageView;

public class SquareImageView extends ImageView
{

    public SquareImageView(Context context)
    {
        this(context, null);
    }

    public SquareImageView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public SquareImageView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        TypedArray typedarray = context.obtainStyledAttributes(attributeset, com.base.views.R.styleable.SquareImageView, i, 0);
        squarePriority = typedarray.getInt(0, 0);
        typedarray.recycle();
    }

    protected void onMeasure(int i, int j)
    {
        super.onMeasure(i, j);
        squarePriority;
        JVM INSTR tableswitch 0 3: default 40
    //                   0 49
    //                   1 57
    //                   2 65
    //                   3 92;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        int k = 0;
_L7:
        setMeasuredDimension(k, k);
        return;
_L2:
        k = getMeasuredWidth();
        continue; /* Loop/switch isn't completed */
_L3:
        k = getMeasuredHeight();
        continue; /* Loop/switch isn't completed */
_L4:
        if(getMeasuredWidth() < getMeasuredHeight())
            k = getMeasuredWidth();
        else
            k = getMeasuredHeight();
        continue; /* Loop/switch isn't completed */
_L5:
        if(getMeasuredWidth() > getMeasuredHeight())
            k = getMeasuredWidth();
        else
            k = getMeasuredHeight();
        if(true) goto _L7; else goto _L6
_L6:
    }

    private static final int BIGGER = 3;
    private static final int HEIGHT = 1;
    private static final int SMALLER = 2;
    private static final int WIDTH;
    private final int squarePriority;
}
