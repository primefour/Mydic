// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.viewpager;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.CountDownTimer;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.*;

public class CarouselViewPager extends ViewPager
{
    public static interface OnCenterItemClickListener
    {

        public abstract void onCenterItemClick(int i);
    }


    public CarouselViewPager(Context context1)
    {
        this(context1, null);
    }

    public CarouselViewPager(Context context1, AttributeSet attributeset)
    {
        super(context1, attributeset);
        context = context1;
        TypedArray typedarray = context1.getTheme().obtainStyledAttributes(attributeset, com.base.views.R.styleable.CarouselViewPager, 0, 0);
        autoScrollEnabled = typedarray.getBoolean(0, false);
        autoScrolling = autoScrollEnabled;
        scrollTime = typedarray.getInteger(1, 5000);
        scrollTickTime = typedarray.getInteger(2, 1000);
        percentageWidth = typedarray.getInteger(3, 0);
        percentageHeight = typedarray.getInteger(4, 0);
        layoutReference = typedarray.getInteger(5, 1);
        typedarray.recycle();
        initTimer();
        if(autoScrollEnabled)
            timer.start();
    }

    private void initTimer()
    {
        timer = new CountDownTimer(scrollTime, scrollTickTime) {

            public void onFinish()
            {
                if(autoScrolling)
                {
                    KeyEvent keyevent = new KeyEvent(0, 22);
                    executeKeyEvent(keyevent);
                    timer.start();
                }
            }

            public void onTick(long l)
            {
            }

            final CarouselViewPager this$0;

            
            {
                this$0 = CarouselViewPager.this;
                super(l, l1);
            }
        };
    }

    public int getLayoutReference()
    {
        return layoutReference;
    }

    public int getPercentageHeight()
    {
        return percentageHeight;
    }

    public int getPercentageWidth()
    {
        return percentageWidth;
    }

    public CountDownTimer getTimer()
    {
        return timer;
    }

    public boolean isAutoScrollEnabled()
    {
        return autoScrollEnabled;
    }

    protected void onDetachedFromWindow()
    {
        timer.cancel();
        super.onDetachedFromWindow();
    }

    protected void onMeasure(int i, int j)
    {
        super.onMeasure(i, j);
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        if(layoutReference == 1)
        {
            DisplayMetrics displaymetrics = new DisplayMetrics();
            ((Activity)context).getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
            k = displaymetrics.widthPixels;
            l = displaymetrics.heightPixels;
        } else
        {
            k = ((View)getParent()).getMeasuredWidth();
            l = ((View)getParent()).getMeasuredHeight();
        }
        setMeasuredDimension((k * percentageWidth) / 100, (l * percentageHeight) / 100);
        i1 = android.view.View.MeasureSpec.makeMeasureSpec(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), 0x40000000);
        j1 = android.view.View.MeasureSpec.makeMeasureSpec(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), 0x40000000);
        k1 = getChildCount();
        for(int l1 = 0; l1 < k1; l1++)
        {
            View view = getChildAt(l1);
            if(view.getVisibility() != 8)
                view.measure(i1, j1);
        }

    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        if(motionevent.getAction() != 2 && motionevent.getAction() != 0 || getParent() == null) goto _L2; else goto _L1
_L1:
        getParent().requestDisallowInterceptTouchEvent(true);
        if(autoScrollEnabled)
            autoScrolling = false;
_L4:
        if(motionevent.getAction() != 3)
            super.onTouchEvent(motionevent);
        return true;
_L2:
        if((motionevent.getAction() == 1 || motionevent.getAction() == 3) && autoScrollEnabled)
        {
            autoScrolling = true;
            timer.start();
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public void setAutoScrollEnabled(boolean flag)
    {
        autoScrollEnabled = flag;
        autoScrolling = flag;
        if(flag)
        {
            timer.start();
            return;
        } else
        {
            timer.cancel();
            return;
        }
    }

    public void setLayoutReference(int i)
    {
        layoutReference = i;
    }

    public void setPercentageHeight(int i)
    {
        percentageHeight = i;
    }

    public void setPercentageWidth(int i)
    {
        percentageWidth = i;
    }

    public static final int REFERENCE_PARENT = 0;
    public static final int REFERENCE_SCREEN = 1;
    private boolean autoScrollEnabled;
    private boolean autoScrolling;
    private Context context;
    private int layoutReference;
    private int percentageHeight;
    private int percentageWidth;
    private long scrollTickTime;
    private long scrollTime;
    private CountDownTimer timer;


}
