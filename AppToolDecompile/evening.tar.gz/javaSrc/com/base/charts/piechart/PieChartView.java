// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.charts.piechart;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.*;
import android.util.*;
import android.view.*;
import android.widget.ImageView;
import com.base.charts.DifferentSizeToPlotException;
import java.util.ArrayList;
import java.util.Random;

public class PieChartView extends ImageView
{

    public PieChartView(Context context)
    {
        this(context, null, 0);
    }

    public PieChartView(Context context, AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public PieChartView(Context context, AttributeSet attributeset, int i)
    {
        super(context, attributeset, i);
        hasDrawed = false;
        bounds = new Rect();
        mContext = context;
        TypedArray typedarray = getContext().obtainStyledAttributes(attributeset, com.base.views.R.styleable.PieChartView, 0, 0);
        layoutReference = typedarray.getInt(0, -1);
        percentageWidth = typedarray.getFloat(2, 0.0F);
        percentageHeight = typedarray.getFloat(3, 0.0F);
        pieLineWidth = typedarray.getDimensionPixelSize(4, 1);
        pieLineColor = typedarray.getColor(5, -1);
        boxLineWidth = typedarray.getDimensionPixelSize(6, 1);
        boxLineColor = typedarray.getColor(7, -1);
        pieLineEnabled = typedarray.getBoolean(1, true);
        labelSize = typedarray.getDimensionPixelSize(8, 1);
        labelColor = typedarray.getColor(9, -1);
        typedarray.recycle();
        init();
    }

    private int calculateHeightFromFontSize(String s, int i)
    {
        Rect rect = new Rect();
        Paint paint = new Paint();
        paint.setTextSize(i);
        paint.getTextBounds(s, 0, s.length(), rect);
        return (int)Math.ceil(rect.height());
    }

    private void doBoxes()
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(mBitmap);
        currentPaint.setStyle(android.graphics.Paint.Style.FILL);
        currentPaint.setStrokeWidth(boxLineWidth);
        int i = Math.min(5, xData.size());
        float f = 0.5F * boxSize;
        int j = 0;
        while(j < i) 
        {
            RectF rectf;
            if(j < colors.size())
                currentPaint.setColor(((Integer)colors.get(j)).intValue());
            else
            if(j < 5)
            {
                colors.add(Integer.valueOf(Color.rgb((new Random()).nextInt(256), (new Random()).nextInt(256), (new Random()).nextInt(256))));
                currentPaint.setColor(j);
            } else
            {
                currentPaint.setColor(Color.rgb((new Random()).nextInt(256), (new Random()).nextInt(256), (new Random()).nextInt(256)));
            }
            rectf = new RectF();
            rectf.set(halfWitdh + boxOffsetX, f, halfWitdh + boxOffsetX + boxSize, f + boxSize);
            canvas.drawRect(rectf, currentPaint);
            f += 1.5F * boxSize;
            j++;
        }
        setImageBitmap(mBitmap);
    }

    private void doBoxesBorders()
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(mBitmap);
        currentPaint.setColor(boxLineColor);
        currentPaint.setStyle(android.graphics.Paint.Style.STROKE);
        currentPaint.setStrokeWidth(boxLineWidth);
        int i = Math.min(5, xData.size());
        float f = 0.5F * boxSize;
        for(int j = 0; j < i; j++)
        {
            RectF rectf = new RectF();
            rectf.set(halfWitdh + boxOffsetX, f, halfWitdh + boxOffsetX + boxSize, f + boxSize);
            canvas.drawRect(rectf, currentPaint);
            f += 1.5F * boxSize;
        }

        setImageBitmap(mBitmap);
    }

    private void doLabels()
    {
        int i = Math.min(5, xData.size());
        float f = 1.0F * boxSize;
        for(int j = 0; j < i; j++)
        {
            onDrawText((String)xData.get(j), halfWitdh + 2.0F * boxOffsetX + boxSize, f + 0.1F * boxSize);
            f += 1.5F * boxSize;
        }

    }

    private void doPie()
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(mBitmap);
        float f = 0.0F;
        float f1 = 0.0F;
        for(int i = 0; i < values.size(); i++)
            f1 += ((Float)values.get(i)).floatValue();

        float f2 = 360F / f1;
        RectF rectf = new RectF();
        rectf.set(offsetX, offsetY, offsetX + (float)getRadius(), offsetY + (float)getRadius());
        int j = 0;
        while(j < values.size()) 
        {
            if(j < colors.size())
                currentPaint.setColor(((Integer)colors.get(j)).intValue());
            else
            if(j < 5)
            {
                colors.add(Integer.valueOf(Color.rgb((new Random()).nextInt(256), (new Random()).nextInt(256), (new Random()).nextInt(256))));
                currentPaint.setColor(j);
            } else
            {
                currentPaint.setColor(Color.rgb((new Random()).nextInt(256), (new Random()).nextInt(256), (new Random()).nextInt(256)));
            }
            if(j == 0)
            {
                canvas.drawArc(rectf, 0.0F, f2 * ((Float)values.get(j)).floatValue(), true, currentPaint);
            } else
            {
                float f3 = f2 * ((Float)values.get(j)).floatValue();
                Paint paint = currentPaint;
                canvas.drawArc(rectf, f, f3, true, paint);
            }
            f += f2 * ((Float)values.get(j)).floatValue();
            j++;
        }
        setImageBitmap(mBitmap);
    }

    private void doPieLine()
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(mBitmap);
        float f = 0.0F;
        float f1 = 0.0F;
        for(int i = 0; i < values.size(); i++)
            f1 += ((Float)values.get(i)).floatValue();

        float f2 = 360F / f1;
        RectF rectf = new RectF();
        rectf.set(offsetX, offsetY, offsetX + (float)getRadius(), offsetY + (float)getRadius());
        currentPaint.setColor(pieLineColor);
        currentPaint.setStyle(android.graphics.Paint.Style.STROKE);
        currentPaint.setStrokeWidth(pieLineWidth);
        int j = 0;
        while(j < values.size()) 
        {
            if(j == 0)
            {
                canvas.drawArc(rectf, 0.0F, f2 * ((Float)values.get(j)).floatValue(), true, currentPaint);
            } else
            {
                float f3 = f2 * ((Float)values.get(j)).floatValue();
                Paint paint = currentPaint;
                canvas.drawArc(rectf, f, f3, true, paint);
            }
            f += f2 * ((Float)values.get(j)).floatValue();
            j++;
        }
        setImageBitmap(mBitmap);
    }

    private void init()
    {
        colors = new ArrayList();
        values = new ArrayList();
        colors.add(Integer.valueOf(0xff00ff00));
        colors.add(Integer.valueOf(0xff00ffff));
        colors.add(Integer.valueOf(-65281));
        colors.add(Integer.valueOf(0xff0000ff));
        colors.add(Integer.valueOf(0xffff0000));
    }

    private void onDrawText(String s, float f, float f1)
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        String as[] = s.split("\n");
        Canvas canvas = new Canvas(mBitmap);
        int i = (int)(1.2F * (float)calculateHeightFromFontSize(s, labelSize));
        int j = i * (-1 * (as.length / 2));
        int k = i / 4;
        for(int l = 0; l < as.length; l++)
        {
            canvas.drawText(as[l], f, f1 + (float)k + (float)(j / 2), currentPaint);
            currentPaint.getTextBounds(as[l], 0, as[l].length(), bounds);
            k += bounds.height();
        }

    }

    private void setCurrentPaint()
    {
        currentPaint = new Paint();
        currentPaint.setAntiAlias(true);
    }

    private void setCurrentPaintForText(int i)
    {
        currentPaint = new Paint();
        currentPaint.setTextSize(labelSize);
        currentPaint.setDither(true);
        currentPaint.setColor(labelColor);
        currentPaint.setStyle(android.graphics.Paint.Style.STROKE);
        currentPaint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        currentPaint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        currentPaint.setAntiAlias(true);
    }

    public ArrayList getColors()
    {
        return colors;
    }

    public int getRadius()
    {
        return radius;
    }

    public ArrayList getValues()
    {
        return values;
    }

    protected void onMeasure(int i, int j)
    {
        int k;
        int l;
        if(layoutReference == -1)
        {
            DisplayMetrics displaymetrics = new DisplayMetrics();
            ((Activity)mContext).getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
            k = displaymetrics.widthPixels;
            l = displaymetrics.heightPixels;
        } else
        {
            k = ((View)getParent()).getMeasuredWidth();
            l = ((View)getParent()).getMeasuredHeight();
        }
        setMeasuredDimension((int)(((float)k * percentageWidth) / 100F), (int)(((float)l * percentageHeight) / 100F));
        if(getMeasuredWidth() > 0 && getHeight() > 0 && !hasDrawed && xData != null && xData.size() > 0)
        {
            hasDrawed = true;
            radius = (int)(0.45F * (float)getMeasuredWidth());
            if(radius > getHeight())
                radius = (int)(0.9F * (float)getHeight());
            offsetX = 0.25F * (float)getMeasuredWidth() - 0.5F * (float)radius;
            offsetY = 0.5F * (float)getHeight() - 0.5F * (float)radius;
            boxSize = 0.125F * (float)getHeight();
            boxOffsetX = 0.05F * (float)getMeasuredWidth();
            halfWitdh = 0.5F * (float)getMeasuredWidth();
            setCurrentPaint();
            doPie();
            if(pieLineEnabled)
                doPieLine();
            setCurrentPaint();
            doBoxes();
            setCurrentPaint();
            doBoxesBorders();
            setCurrentPaintForText(labelColor);
            doLabels();
        }
    }

    public boolean onTouchEvent(MotionEvent motionevent)
    {
        return super.onTouchEvent(motionevent);
    }

    public void setColors(ArrayList arraylist)
    {
        int i = Math.min(5, arraylist.size());
        for(int j = 0; j < i; j++)
            colors.add(j, arraylist.get(j));

    }

    public void setData(ArrayList arraylist, ArrayList arraylist1)
        throws DifferentSizeToPlotException
    {
        if(arraylist.size() != arraylist1.size())
            throw new DifferentSizeToPlotException();
        Log.e(com/base/charts/piechart/PieChartView.getSimpleName(), "SET DATA");
        for(int i = 0; i < arraylist1.size(); i++)
            values.add(arraylist1.get(i));

        xData = arraylist;
        measure(getMeasuredWidth(), getMeasuredHeight());
    }

    public void setRadius(int i)
    {
        radius = i;
    }

    public void setValues(ArrayList arraylist)
    {
        values = arraylist;
    }

    private static final int REFERENCE_PARENT = 0;
    private static final int REFERENCE_SCREEN = -1;
    Rect bounds;
    private int boxLineColor;
    private int boxLineWidth;
    private float boxOffsetX;
    private float boxSize;
    private ArrayList colors;
    private Paint currentPaint;
    private float halfWitdh;
    private boolean hasDrawed;
    private int labelColor;
    private int labelSize;
    private int layoutReference;
    private Bitmap mBitmap;
    Context mContext;
    private float offsetX;
    private float offsetY;
    private float percentageHeight;
    private float percentageWidth;
    private int pieLineColor;
    private boolean pieLineEnabled;
    private int pieLineWidth;
    private int radius;
    private ArrayList values;
    private ArrayList xData;
}
