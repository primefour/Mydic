// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.base.charts.linearchart;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.*;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.ImageView;
import com.base.charts.DifferentSizeToPlotException;
import com.base.drawing.utils.CommandManager;
import com.base.drawing.utils.DrawingPath;
import com.base.drawing.utils.brushes.*;
import java.util.ArrayList;
import java.util.Iterator;

public class LinearChartView extends ImageView
{

    public LinearChartView(Context context1)
    {
        this(context1, null, 0);
    }

    public LinearChartView(Context context1, AttributeSet attributeset)
    {
        this(context1, attributeset, 0);
    }

    public LinearChartView(Context context1, AttributeSet attributeset, int i)
    {
        super(context1, attributeset, i);
        hasDrawed = false;
        yLabel = "";
        context = context1;
        TypedArray typedarray = getContext().obtainStyledAttributes(attributeset, com.base.views.R.styleable.LinearChartView, 0, 0);
        lineColor = typedarray.getColor(4, 0xffff0000);
        axisColor = typedarray.getColor(5, 0xff000000);
        gridColor = typedarray.getColor(6, 0x77000000);
        labelColor = typedarray.getColor(3, 0x77000000);
        lineWidth = typedarray.getDimensionPixelSize(7, 1);
        axisWidth = typedarray.getDimensionPixelSize(8, 1);
        gridWidth = typedarray.getDimensionPixelSize(9, 1);
        labelSize = typedarray.getDimensionPixelSize(2, 1);
        tip = typedarray.getBoolean(10, true);
        type = typedarray.getInt(12, -1);
        layoutReference = typedarray.getInt(13, -1);
        percentageWidth = typedarray.getFloat(14, 0.0F);
        percentageHeight = typedarray.getFloat(15, 0.0F);
        yLabel = typedarray.getString(0);
        xLabel = typedarray.getString(1);
        typedarray.recycle();
        init();
    }

    private double calculateAngle(Float float1, Float float2, Float float3, Float float4)
    {
        return Math.atan((float3.floatValue() - float4.floatValue()) / (float2.floatValue() - float1.floatValue()));
    }

    private void doAxis()
    {
        currentDrawingPath = new DrawingPath();
        currentDrawingPath.paint = currentPaint;
        currentDrawingPath.path = new Path();
        currentBrush.mouseDown(currentDrawingPath.path, ((Float)distancesX.get(0)).floatValue(), (float)getMeasuredHeight() - offsetY);
        commandManager.addCommand(currentDrawingPath);
        addDrawingPath(currentDrawingPath);
        onDraw();
        currentBrush.mouseMove(currentDrawingPath.path, extraDistanceX, (float)getMeasuredHeight() - offsetY);
        onDraw();
        currentBrush.mouseUp(currentDrawingPath.path, extraDistanceX, (float)getMeasuredHeight() - offsetY);
        onDraw();
        currentDrawingPath = new DrawingPath();
        currentDrawingPath.paint = currentPaint;
        currentDrawingPath.path = new Path();
        currentBrush.mouseDown(currentDrawingPath.path, ((Float)distancesX.get(0)).floatValue(), offsetY);
        commandManager.addCommand(currentDrawingPath);
        addDrawingPath(currentDrawingPath);
        onDraw();
        currentBrush.mouseMove(currentDrawingPath.path, ((Float)distancesX.get(0)).floatValue(), (float)getMeasuredHeight() - offsetY);
        onDraw();
        currentBrush.mouseUp(currentDrawingPath.path, ((Float)distancesX.get(0)).floatValue(), (float)getMeasuredHeight() - offsetY);
        onDraw();
    }

    private void doGrid()
        throws ArrayIndexOutOfBoundsException
    {
        for(int i = 0; i < -1 + distancesX.size(); i++)
        {
            currentDrawingPath = new DrawingPath();
            currentDrawingPath.paint = currentPaint;
            currentDrawingPath.path = new Path();
            currentBrush.mouseDown(currentDrawingPath.path, ((Float)distancesX.get(i)).floatValue(), ((Float)distancesY.get(0)).floatValue());
            commandManager.addCommand(currentDrawingPath);
            addDrawingPath(currentDrawingPath);
            onDraw();
            currentBrush.mouseMove(currentDrawingPath.path, ((Float)distancesX.get(i)).floatValue(), offsetY);
            onDraw();
            currentBrush.mouseUp(currentDrawingPath.path, ((Float)distancesX.get(i)).floatValue(), offsetY);
            onDraw();
        }

        currentDrawingPath = new DrawingPath();
        currentDrawingPath.paint = currentPaint;
        currentDrawingPath.path = new Path();
        currentBrush.mouseDown(currentDrawingPath.path, extraDistanceY.floatValue(), ((Float)distancesY.get(0)).floatValue());
        commandManager.addCommand(currentDrawingPath);
        addDrawingPath(currentDrawingPath);
        onDraw();
        currentBrush.mouseMove(currentDrawingPath.path, extraDistanceY.floatValue(), offsetY);
        onDraw();
        currentBrush.mouseUp(currentDrawingPath.path, extraDistanceY.floatValue(), offsetY);
        onDraw();
        float f = ((float)getMeasuredHeight() - 2.0F * offsetY) / (float)(-1 + distancesY.size());
        for(int j = 0; j < -1 + distancesY.size(); j++)
        {
            currentDrawingPath = new DrawingPath();
            currentDrawingPath.paint = currentPaint;
            currentDrawingPath.path = new Path();
            currentBrush.mouseDown(currentDrawingPath.path, offsetX, offsetY + f * (float)j);
            commandManager.addCommand(currentDrawingPath);
            addDrawingPath(currentDrawingPath);
            onDraw();
            currentBrush.mouseMove(currentDrawingPath.path, extraDistanceX, offsetY + f * (float)j);
            onDraw();
            currentBrush.mouseUp(currentDrawingPath.path, extraDistanceX, offsetY + f * (float)j);
            onDraw();
        }

    }

    private void doLabels()
    {
        onDrawText(xLabel, (float)getMeasuredWidth() - offsetX / 2.0F, (float)getMeasuredHeight() - offsetY);
        onDrawText(yLabel, offsetX, offsetY / 2.0F);
        int i = 0;
        float f = ((float)getMeasuredHeight() - 2.0F * offsetY) / (float)(-1 + distancesY.size());
        for(Iterator iterator = yLabels.iterator(); iterator.hasNext();)
        {
            Integer integer = (Integer)iterator.next();
            if(i != 0 && i != -1 + yLabels.size())
                onDrawText((new StringBuilder()).append(integer).append("").toString(), offsetX / 2.0F, (float)getMeasuredHeight() - offsetY - f * (float)i);
            i++;
        }

        int j = 0;
        for(Iterator iterator1 = xData.iterator(); iterator1.hasNext();)
        {
            String s = (String)iterator1.next();
            if(j != 0)
                onDrawText(s, ((Float)distancesX.get(j)).floatValue(), (float)getMeasuredHeight() - offsetY / 2.0F);
            j++;
        }

    }

    private void doPlot()
    {
        for(int i = 0; i < -1 + distancesX.size(); i++)
        {
            currentDrawingPath = new DrawingPath();
            currentDrawingPath.paint = currentPaint;
            currentDrawingPath.path = new Path();
            currentBrush.mouseDown(currentDrawingPath.path, ((Float)distancesX.get(i)).floatValue(), ((Float)distancesY.get(i)).floatValue());
            commandManager.addCommand(currentDrawingPath);
            addDrawingPath(currentDrawingPath);
            onDraw();
            currentBrush.mouseMove(currentDrawingPath.path, ((Float)distancesX.get(i + 1)).floatValue(), ((Float)distancesY.get(i + 1)).floatValue());
            onDraw();
            currentBrush.mouseUp(currentDrawingPath.path, ((Float)distancesX.get(i + 1)).floatValue(), ((Float)distancesY.get(i + 1)).floatValue());
            onDraw();
        }

    }

    private void drawTriangleTip()
        throws ArrayIndexOutOfBoundsException
    {
        double d = calculateAngle((Float)distancesX.get(-2 + distancesX.size()), (Float)distancesX.get(-1 + distancesX.size()), (Float)distancesY.get(-2 + distancesY.size()), (Float)distancesY.get(-1 + distancesY.size()));
        double d1 = d - 0.78539816339744828D;
        double d2 = 1.5707963267948966D - d1;
        float f = 0.025F * (float)getMeasuredWidth();
        float f1 = f * (float)Math.cos(d1);
        float f2 = f * (float)Math.sin(d1);
        float f3 = f * (float)Math.cos(d2);
        float f4 = f * (float)Math.sin(d2);
        float f5 = (float)lineWidth * (float)Math.cos(d);
        float f6 = (float)lineWidth * (float)Math.sin(d);
        currentDrawingPath = new DrawingPath();
        currentDrawingPath.paint = currentPaint;
        currentDrawingPath.path = new Path();
        currentDrawingPath.paint.setStyle(android.graphics.Paint.Style.FILL);
        currentBrush.mouseDown(currentDrawingPath.path, f5 + ((Float)distancesX.get(-1 + distancesX.size())).floatValue(), ((Float)distancesY.get(-1 + distancesY.size())).floatValue() - f6);
        commandManager.addCommand(currentDrawingPath);
        addDrawingPath(currentDrawingPath);
        onDraw();
        currentBrush.mouseMove(currentDrawingPath.path, ((Float)distancesX.get(-1 + distancesX.size())).floatValue() - f1, f2 + ((Float)distancesY.get(-1 + distancesY.size())).floatValue());
        onDraw();
        currentBrush.mouseMove(currentDrawingPath.path, f3 + ((Float)distancesX.get(-1 + distancesX.size())).floatValue(), f4 + ((Float)distancesY.get(-1 + distancesY.size())).floatValue());
        onDraw();
        ((PenBrush)currentBrush).mouseUpClosing(currentDrawingPath.path);
        onDraw();
    }

    private void init()
    {
        if(type == -1)
            currentBrush = new PenBrush();
        else
            currentBrush = new CircleBrush();
        commandManager = new CommandManager();
    }

    private void measureXData()
    {
        distancesX = new ArrayList();
        float f = 0.0F;
        for(Iterator iterator = xData.iterator(); iterator.hasNext();)
        {
            String _tmp = (String)iterator.next();
            distancesX.add(Float.valueOf(f + offsetX));
            f += ((float)getMeasuredWidth() - 2.0F * offsetX) * (1.0F / (float)xData.size());
        }

        extraDistanceX = f + offsetX;
        extraDistanceY = (Float)distancesX.get(-1 + distancesX.size());
    }

    private void measureYData()
    {
        float f = 0.0F;
        float f1 = 0.0F;
        Iterator iterator = yData.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            Float float1 = (Float)iterator.next();
            if(float1.floatValue() < f)
                f = float1.floatValue();
            else
            if(float1.floatValue() > f1)
                f1 = float1.floatValue();
        } while(true);
        float f2 = f1 - f;
        distancesY = new ArrayList();
        yLabels = new ArrayList();
        int i = 0;
        for(Iterator iterator1 = yData.iterator(); iterator1.hasNext();)
        {
            float f3 = ((Float)iterator1.next()).floatValue() / f2;
            distancesY.add(Float.valueOf((float)getMeasuredHeight() - offsetY - f3 * ((float)getMeasuredHeight() - 2.0F * offsetY)));
            yLabels.add(Integer.valueOf((int)(f + (f2 / (float)(-1 + yData.size())) * (float)i)));
            i++;
        }

        float _tmp = f1 - f;
    }

    private void onDrawText(String s, float f, float f1)
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getMeasuredHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        (new Canvas(mBitmap)).drawText(s, f, f1, currentPaint);
    }

    private void setCurrentPaint(int i, float f)
    {
        currentPaint = new Paint();
        currentPaint.setDither(true);
        currentPaint.setColor(i);
        currentPaint.setStyle(android.graphics.Paint.Style.STROKE);
        currentPaint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        currentPaint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        currentPaint.setAntiAlias(true);
        currentPaint.setStrokeWidth(f);
    }

    private void setCurrentPaintForText(int i)
    {
        currentPaint = new Paint();
        currentPaint.setTextSize(labelSize);
        currentPaint.setTextAlign(android.graphics.Paint.Align.CENTER);
        currentPaint.setDither(true);
        currentPaint.setColor(labelColor);
        currentPaint.setStyle(android.graphics.Paint.Style.STROKE);
        currentPaint.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        currentPaint.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        currentPaint.setAntiAlias(true);
    }

    public void addDrawingPath(DrawingPath drawingpath)
    {
        commandManager.addCommand(drawingpath);
    }

    public void onDraw()
    {
        if(mBitmap == null)
            mBitmap = Bitmap.createBitmap(getMeasuredWidth(), getMeasuredHeight(), android.graphics.Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(mBitmap);
        canvas.drawPath(currentDrawingPath.path, currentDrawingPath.paint);
        commandManager.executeAll(canvas, doneHandler);
        setImageBitmap(mBitmap);
    }

    protected void onMeasure(int i, int j)
    {
        int k;
        int l;
        if(layoutReference == -1)
        {
            DisplayMetrics displaymetrics = new DisplayMetrics();
            ((Activity)context).getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
            k = displaymetrics.widthPixels;
            l = displaymetrics.heightPixels;
        } else
        {
            k = ((View)getParent()).getMeasuredWidth();
            l = ((View)getParent()).getMeasuredHeight();
        }
        setMeasuredDimension((int)(((float)k * percentageWidth) / 100F), (int)(((float)l * percentageHeight) / 100F));
        if(getMeasuredWidth() > 0 && getMeasuredHeight() > 0 && !hasDrawed)
        {
            hasDrawed = true;
            offsetX = 0.2F * (float)getMeasuredWidth();
            offsetY = 0.2F * (float)getMeasuredHeight();
            measureYData();
            measureXData();
            setCurrentPaintForText(labelColor);
            doLabels();
            if(type == 0)
                currentBrush = new PenBrush();
            setCurrentPaint(gridColor, gridWidth);
            try
            {
                doGrid();
            }
            catch(Exception exception)
            {
                hasDrawed = false;
            }
            if(type == 0)
                currentBrush = new CircleBrush();
            setCurrentPaint(lineColor, lineWidth);
            doPlot();
            if(type == -1)
            {
                setCurrentPaint(lineColor, lineWidth);
                if(tip)
                    try
                    {
                        drawTriangleTip();
                    }
                    catch(Exception exception1)
                    {
                        hasDrawed = false;
                    }
            }
            if(type == 0)
                currentBrush = new PenBrush();
            setCurrentPaint(axisColor, axisWidth);
            doAxis();
        }
    }

    public void setData(ArrayList arraylist, ArrayList arraylist1)
        throws DifferentSizeToPlotException
    {
        if(arraylist.size() != arraylist1.size())
        {
            throw new DifferentSizeToPlotException();
        } else
        {
            arraylist1.add(0, Float.valueOf(0.0F));
            arraylist.add(0, "0");
            yData = arraylist1;
            xData = arraylist;
            measure(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
    }

    private static final int CIRCLE = 0;
    private static final int LINE = -1;
    private static final int REFERENCE_PARENT = 0;
    private static final int REFERENCE_SCREEN = -1;
    private int axisColor;
    private int axisWidth;
    private CommandManager commandManager;
    private Context context;
    private Brush currentBrush;
    private DrawingPath currentDrawingPath;
    private Paint currentPaint;
    private ArrayList distancesX;
    private ArrayList distancesY;
    private Handler doneHandler = new Handler() {

        public void handleMessage(Message message)
        {
        }

        final LinearChartView this$0;

            
            {
                this$0 = LinearChartView.this;
                super();
            }
    };
    private float extraDistanceX;
    private Float extraDistanceY;
    private int gridColor;
    private int gridWidth;
    private boolean hasDrawed;
    private int labelColor;
    private int labelSize;
    private int layoutReference;
    private int lineColor;
    private int lineWidth;
    private Bitmap mBitmap;
    private float offsetX;
    private float offsetY;
    private float percentageHeight;
    private float percentageWidth;
    private boolean tip;
    private int type;
    private ArrayList xData;
    private String xLabel;
    private ArrayList yData;
    private String yLabel;
    private ArrayList yLabels;
}
