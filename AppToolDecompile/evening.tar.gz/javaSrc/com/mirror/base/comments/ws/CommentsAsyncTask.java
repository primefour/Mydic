// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments.ws;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.app.KogiActivity;
import android.support.v4.app.KogiAsyncTask;
import android.util.Log;
import android.widget.Toast;
import com.mirror.base.article_page.NewsDetailActivity;
import com.mirror.base.article_page.NewsDetailFragment;
import com.mirror.base.comments.CommentsActivity;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.mirror.base.comments.ws:
//            WSCommentaries

public class CommentsAsyncTask extends KogiAsyncTask
{

    public CommentsAsyncTask(Enum enum, KogiActivity kogiactivity)
    {
        super(enum, kogiactivity);
    }

    public CommentsAsyncTask(Enum enum, KogiActivity kogiactivity, String s, String s1)
    {
        super(enum, kogiactivity, s, s1);
    }

    protected volatile Object doInBackground(Object aobj[])
    {
        return doInBackground((JSONObject[])aobj);
    }

    protected transient JSONObject doInBackground(JSONObject ajsonobject[])
    {
        JSONObject jsonobject;
        JSONObject jsonobject3;
        if(command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_ORDERED) || command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_LOAD_MORE))
        {
            JSONObject jsonobject1 = ajsonobject[0];
            if(command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_ORDERED))
                jsonobject1.put("currentPage", 1);
            ArrayList arraylist = (new WSCommentaries(parentActivity)).getComments(jsonobject1);
            jsonobject = (new JSONObject()).put("response", arraylist);
            if(jsonobject1.has("userOption") && jsonobject1.getInt("userOption") == parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user))
                return jsonobject.put("userLogged", true);
            break MISSING_BLOCK_LABEL_488;
        }
        if(command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_SCORE_REVIEW))
        {
            JSONObject jsonobject5 = ajsonobject[0];
            boolean flag = (new WSCommentaries(parentActivity)).getScoreReview(jsonobject5);
            return (new JSONObject()).put("response", flag);
        }
        if(command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND))
        {
            JSONObject jsonobject4 = ajsonobject[0];
            WSCommentaries wscommentaries1 = new WSCommentaries(parentActivity);
            if(wscommentaries1.writeComment(jsonobject4))
            {
                jsonobject4.put("userOption", parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user));
                jsonobject4.put("currentPage", 1);
                ArrayList arraylist2 = wscommentaries1.getComments(jsonobject4);
                jsonobject = (new JSONObject()).put("response", arraylist2);
                if(jsonobject4.has("userOption") && jsonobject4.getInt("userOption") == parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user))
                    return jsonobject.put("userLogged", true);
            } else
            {
                if(command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND))
                    return (new JSONObject()).put("serverResponse", wscommentaries1.getResponseMessage());
                break MISSING_BLOCK_LABEL_490;
            }
            break MISSING_BLOCK_LABEL_488;
        }
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.REPORT_ABUSE))
            break MISSING_BLOCK_LABEL_486;
        JSONObject jsonobject2 = ajsonobject[0];
        WSCommentaries wscommentaries = new WSCommentaries(parentActivity);
        if(!wscommentaries.reportAbuse(jsonobject2))
            break MISSING_BLOCK_LABEL_479;
        jsonobject2.put("currentPage", 1);
        jsonobject2.put("userOption", jsonobject2.get("userOption"));
        ArrayList arraylist1 = wscommentaries.getComments(jsonobject2);
        jsonobject = (new JSONObject()).put("response", arraylist1);
        if(!jsonobject2.has("userOption") || jsonobject2.getInt("userOption") != parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user))
            break MISSING_BLOCK_LABEL_488;
        jsonobject3 = jsonobject.put("userLogged", true);
        return jsonobject3;
        return null;
        Exception exception;
        exception;
        exception.printStackTrace();
        jsonobject = null;
        return jsonobject;
        return null;
    }

    protected volatile void onPostExecute(Object obj)
    {
        onPostExecute((JSONObject)obj);
    }

    protected void onPostExecute(JSONObject jsonobject)
    {
        super.onPostExecute(jsonobject);
        boolean flag = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_ORDERED);
        if(!flag) goto _L2; else goto _L1
_L1:
        ((CommentsActivity)parentActivity).setComments((ArrayList)jsonobject.get("response"));
        if(jsonobject.has("userLogged"))
            ((CommentsActivity)parentActivity).setLastCommentsWithUser(true);
_L10:
        return;
        JSONException jsonexception3;
        jsonexception3;
        try
        {
            Log.e(TAG, (new StringBuilder()).append("JSONException ").append(command).toString(), jsonexception3);
            Toast.makeText(parentActivity, com.mirror.base.R.string.match_centre_error_from_server_body, 1).show();
            return;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        return;
        NullPointerException nullpointerexception3;
        nullpointerexception3;
        Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception3);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
        return;
_L2:
        boolean flag1 = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_SCORE_REVIEW);
        if(!flag1)
            break MISSING_BLOCK_LABEL_345;
        jsonobject.getBoolean("response");
        Toast.makeText(parentActivity, com.mirror.base.R.string.comment_vote_saved, 0).show();
        return;
        JSONException jsonexception2;
        jsonexception2;
        Log.e(TAG, (new StringBuilder()).append("JSONException ").append(command).toString(), jsonexception2);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
        return;
        NullPointerException nullpointerexception2;
        nullpointerexception2;
        Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception2);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
        return;
        boolean flag2;
        if(command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND))
            break MISSING_BLOCK_LABEL_375;
        flag2 = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.REPORT_ABUSE);
        if(!flag2)
            break MISSING_BLOCK_LABEL_805;
        Log.e("***********", (new StringBuilder()).append("Result: ").append(jsonobject).toString());
        if(!jsonobject.has("serverResponse")) goto _L4; else goto _L3
_L3:
        if(parentActivity instanceof CommentsActivity)
        {
            ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), jsonobject.getString("serverResponse"));
            return;
        }
          goto _L5
        JSONException jsonexception;
        jsonexception;
        Log.e(TAG, (new StringBuilder()).append("JSONException ").append(command).toString(), jsonexception);
        if(parentActivity instanceof CommentsActivity)
        {
            Toast.makeText(parentActivity, com.mirror.base.R.string.match_centre_error_from_server_body, 1).show();
            return;
        }
          goto _L6
_L5:
        ((NewsDetailActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), jsonobject.getString("serverResponse"));
        return;
        NullPointerException nullpointerexception;
        nullpointerexception;
        KogiActivity kogiactivity;
        int i;
        Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception);
        if(!(parentActivity instanceof CommentsActivity))
            break MISSING_BLOCK_LABEL_790;
        kogiactivity = parentActivity;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND))
            break MISSING_BLOCK_LABEL_782;
        i = com.mirror.base.R.string.comment_error;
_L15:
        Toast.makeText(kogiactivity, i, 1).show();
        return;
_L4:
        KogiActivity kogiactivity2 = parentActivity;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND)) goto _L8; else goto _L7
_L7:
        int k = com.mirror.base.R.string.comment_posted;
_L11:
        Toast.makeText(kogiactivity2, k, 0).show();
        if(!(parentActivity instanceof CommentsActivity))
            break MISSING_BLOCK_LABEL_713;
        ((CommentsActivity)parentActivity).setComments((ArrayList)jsonobject.get("response"));
_L12:
        if(!jsonobject.has("userLogged") || !(parentActivity instanceof CommentsActivity)) goto _L10; else goto _L9
_L9:
        ((CommentsActivity)parentActivity).setLastCommentsWithUser(true);
        return;
_L8:
        k = com.mirror.base.R.string.comment_reported;
          goto _L11
        ((NewsDetailActivity)parentActivity).getCurrentFragment().reloadComments((ArrayList)jsonobject.get("response"));
          goto _L12
_L6:
        KogiActivity kogiactivity1;
        int j;
        kogiactivity1 = parentActivity;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND))
            break MISSING_BLOCK_LABEL_774;
        j = com.mirror.base.R.string.comment_error;
_L14:
        Toast.makeText(kogiactivity1, j, 1).show();
        return;
        j = com.mirror.base.R.string.match_centre_error_from_server_body;
        if(true) goto _L14; else goto _L13
_L13:
        i = com.mirror.base.R.string.match_centre_error_from_server_body;
          goto _L15
        Toast.makeText(parentActivity, com.mirror.base.R.string.match_centre_error_from_server_body, 1).show();
        return;
        boolean flag3 = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_LOAD_MORE);
        if(!flag3) goto _L10; else goto _L16
_L16:
        ((CommentsActivity)parentActivity).addComments((ArrayList)jsonobject.get("response"));
        if(jsonobject.has("userLogged"))
        {
            ((CommentsActivity)parentActivity).setLastCommentsWithUser(true);
            return;
        }
          goto _L10
        JSONException jsonexception1;
        jsonexception1;
        Log.e(TAG, (new StringBuilder()).append("JSONException ").append(command).toString(), jsonexception1);
        Toast.makeText(parentActivity, com.mirror.base.R.string.match_centre_error_from_server_body, 1).show();
        return;
        NullPointerException nullpointerexception1;
        nullpointerexception1;
        Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception1);
        Toast.makeText(parentActivity, com.mirror.base.R.string.match_centre_error_from_server_body, 1).show();
        return;
    }
}
