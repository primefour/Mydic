// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments.ws;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.KogiActivity;
import android.support.v4.app.KogiAsyncTask;
import android.util.Log;
import com.facebook.android.Facebook;
import com.mirror.base.article_page.NewsDetailActivity;
import com.mirror.base.comments.CommentsActivity;
import com.pluck.sdk.Interfaces.BaseKey;
import org.json.JSONException;
import org.json.JSONObject;

public class FacebookCommentsAsyncTask extends KogiAsyncTask
{

    public FacebookCommentsAsyncTask(Enum enum, KogiActivity kogiactivity)
    {
        super(enum, kogiactivity);
    }

    public FacebookCommentsAsyncTask(Enum enum, KogiActivity kogiactivity, String s, String s1)
    {
        super(enum, kogiactivity, s, s1);
    }

    protected volatile Object doInBackground(Object aobj[])
    {
        return doInBackground((JSONObject[])aobj);
    }

    protected transient JSONObject doInBackground(JSONObject ajsonobject[])
    {
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_RETURNING))
            break MISSING_BLOCK_LABEL_96;
        JSONObject jsonobject3 = ajsonobject[0];
        Bundle bundle3 = new Bundle();
        bundle3.putString("fields", jsonobject3.getString("fields"));
        bundle3.putString("access_token", jsonobject3.getString("access_token"));
        ((CommentsActivity)parentActivity).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA, new JSONObject(((CommentsActivity)parentActivity).getFaceBookLocal().request("me", bundle3, "GET")));
        return null;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_WRITE_COMMENT)) goto _L2; else goto _L1
_L1:
        JSONObject jsonobject2 = ajsonobject[0];
        Bundle bundle2 = new Bundle();
        bundle2.putString("fields", jsonobject2.getString("fields"));
        bundle2.putString("access_token", jsonobject2.getString("access_token"));
        if(parentActivity instanceof CommentsActivity)
        {
            ((CommentsActivity)parentActivity).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA, new JSONObject(((CommentsActivity)parentActivity).getFaceBookLocal().request("me", bundle2, "GET")));
            break MISSING_BLOCK_LABEL_442;
        }
        try
        {
            ((NewsDetailActivity)parentActivity).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA, new JSONObject(((NewsDetailActivity)parentActivity).getFacebookLocal().request("me", bundle2, "GET")));
            break MISSING_BLOCK_LABEL_442;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
_L4:
        return null;
_L2:
        JSONObject jsonobject1;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_DO_ITEM_SCORE))
            continue; /* Loop/switch isn't completed */
        jsonobject1 = ajsonobject[0];
        Bundle bundle1 = new Bundle();
        bundle1.putString("fields", jsonobject1.getString("fields"));
        bundle1.putString("access_token", jsonobject1.getString("access_token"));
        ((CommentsActivity)parentActivity).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA, new JSONObject(((CommentsActivity)parentActivity).getFaceBookLocal().request("me", bundle1, "GET")));
        return jsonobject1;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_DO_REPORT_ABUSE)) goto _L4; else goto _L3
_L3:
        JSONObject jsonobject;
        jsonobject = ajsonobject[0];
        Bundle bundle = new Bundle();
        bundle.putString("fields", jsonobject.getString("fields"));
        bundle.putString("access_token", jsonobject.getString("access_token"));
        ((CommentsActivity)parentActivity).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA, new JSONObject(((CommentsActivity)parentActivity).getFaceBookLocal().request("me", bundle, "GET")));
        return jsonobject;
        return null;
    }

    protected volatile void onPostExecute(Object obj)
    {
        onPostExecute((JSONObject)obj);
    }

    protected void onPostExecute(JSONObject jsonobject)
    {
        super.onPostExecute(jsonobject);
        boolean flag = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_WRITE_COMMENT);
        if(!flag)
            break MISSING_BLOCK_LABEL_122;
        if(parentActivity instanceof CommentsActivity)
        {
            ((CommentsActivity)parentActivity).writeComment();
            return;
        }
        ((NewsDetailActivity)parentActivity).writeComment();
        return;
        NullPointerException nullpointerexception2;
        nullpointerexception2;
        try
        {
            Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception2);
            ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
            return;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        return;
        boolean flag1 = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_DO_ITEM_SCORE);
        if(!flag1)
            break MISSING_BLOCK_LABEL_334;
        ((CommentsActivity)parentActivity).doItemScoreAction(jsonobject.getInt("i"), (BaseKey)jsonobject.get("articleKey"), (BaseKey)jsonobject.get("reviewKey"));
        if(jsonobject.getBoolean("needToUpdate"))
        {
            ((CommentsActivity)parentActivity).loadComments(parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user));
            return;
        }
        break MISSING_BLOCK_LABEL_549;
        JSONException jsonexception1;
        jsonexception1;
        Log.e(TAG, (new StringBuilder()).append("JSONException ").append(command).toString(), jsonexception1);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
        return;
        NullPointerException nullpointerexception1;
        nullpointerexception1;
        Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception1);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
        return;
        boolean flag2 = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_DO_REPORT_ABUSE);
        if(!flag2)
            break MISSING_BLOCK_LABEL_549;
        ((CommentsActivity)parentActivity).doReportAbuse((BaseKey)jsonobject.get("reviewKey"), jsonobject.getInt("position"), parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user));
        if(jsonobject.getBoolean("needToUpdate"))
        {
            ((CommentsActivity)parentActivity).loadComments(parentActivity.getResources().getInteger(com.mirror.base.R.integer.with_user));
            return;
        }
        break MISSING_BLOCK_LABEL_549;
        JSONException jsonexception;
        jsonexception;
        Log.e(TAG, (new StringBuilder()).append("JSONException ").append(command).toString(), jsonexception);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
        return;
        NullPointerException nullpointerexception;
        nullpointerexception;
        Log.e(TAG, (new StringBuilder()).append("Null Pointer ").append(command).toString(), nullpointerexception);
        ((CommentsActivity)parentActivity).showDialog(parentActivity.getString(com.mirror.base.R.string.match_centre_error_from_server_title), context.getString(com.mirror.base.R.string.match_centre_error_from_server_body));
    }
}
