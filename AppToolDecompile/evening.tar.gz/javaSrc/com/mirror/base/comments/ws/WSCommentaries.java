// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments.ws;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.app.KogiActivity;
import android.util.Log;
import com.mirror.base.comments.ExceptionPrettyPrinter;
import com.mirror.base.main.MirrorNewsApp;
import com.pluck.sdk.Interfaces.IResponse;
import com.pluck.sdk.Models.External.ExternalResourceKey;
import com.pluck.sdk.Models.Reactions.Comment;
import com.pluck.sdk.Models.System.Exceptions.ResponseExceptionLevel;
import com.pluck.sdk.Models.System.ResponseStatus;
import com.pluck.sdk.Models.System.ResponseStatusCode;
import com.pluck.sdk.Models.System.Sorting.*;
import com.pluck.sdk.PluckServer;
import com.pluck.sdk.Requests.Reactions.CommentsPageRequest;
import com.pluck.sdk.Responses.Reactions.CommentsPageResponse;
import com.pluck.sdk.auth.AuthenticationTokenException;
import com.pluck.sdk.auth.UserAuthenticationToken;
import com.pluck.sdk.batching.*;
import com.pluck.sdk.util.ResponseExceptionChecker;
import java.io.PrintStream;
import java.net.MalformedURLException;
import java.util.*;
import org.json.JSONException;
import org.json.JSONObject;

public class WSCommentaries
{

    public WSCommentaries(Context context1)
    {
        context = context1;
    }

    private Comment[] handleResponseBatch(ResponseBatch responsebatch, String s)
        throws Exception
    {
        IResponse iresponse = ((ResponseEnvelope)responsebatch.getEnvelopes().get(0)).getPayload();
        if(iresponse instanceof CommentsPageResponse)
            return ((CommentsPageResponse)iresponse).getItems();
        else
            return null;
    }

    public ArrayList getComments(JSONObject jsonobject)
        throws JSONException
    {
        String s1;
        PluckServer pluckserver1;
        ArrayList arraylist;
        CommentsPageRequest commentspagerequest;
        RequestBatch requestbatch;
        ResponseBatch responsebatch;
        String s = jsonobject.getString("articleId");
        s1 = jsonobject.getString("order");
        PluckServer pluckserver;
        ExternalResourceKey externalresourcekey;
        TimestampSort timestampsort;
        Comment acomment[];
        int i;
        ResponseBatch responsebatch3;
        JSONObject jsonobject1;
        try
        {
            pluckserver = new PluckServer(context.getString(com.mirror.base.R.string.pluck_server));
        }
        catch(MalformedURLException malformedurlexception)
        {
            malformedurlexception.printStackTrace();
            pluckserver1 = null;
            continue; /* Loop/switch isn't completed */
        }
        pluckserver1 = pluckserver;
_L10:
        arraylist = new ArrayList();
        externalresourcekey = new ExternalResourceKey();
        externalresourcekey.setKey(s);
        commentspagerequest = new CommentsPageRequest();
        commentspagerequest.setCommentedOnKey(externalresourcekey);
        commentspagerequest.setOneBasedOnPage(jsonobject.getInt("currentPage"));
        commentspagerequest.setItemsPerPage(context.getResources().getInteger(com.mirror.base.R.integer.pluck_items_perpage));
        if(s1.equalsIgnoreCase(context.getString(com.mirror.base.R.string.comments_oldest)))
        {
            timestampsort = new TimestampSort();
            timestampsort.setSortOrder(SortOrder.Ascending);
            commentspagerequest.setSortType(timestampsort);
        } else
        if(s1.equalsIgnoreCase(context.getString(com.mirror.base.R.string.comments_best_rated)))
        {
            ScoreSort scoresort = new ScoreSort();
            scoresort.setSortOrder(SortOrder.Descending);
            scoresort.setScoreId("Thumbs");
            scoresort.setScoreSortColumn(ScoreSortColumn.DeltaScore);
            commentspagerequest.setSortType(scoresort);
        } else
        if(s1.equalsIgnoreCase(context.getString(com.mirror.base.R.string.comments_worst_rated)))
        {
            ScoreSort scoresort1 = new ScoreSort();
            scoresort1.setSortOrder(SortOrder.Ascending);
            scoresort1.setScoreId("Thumbs");
            scoresort1.setScoreSortColumn(ScoreSortColumn.DeltaScore);
            commentspagerequest.setSortType(scoresort1);
        } else
        {
            TimestampSort timestampsort1 = new TimestampSort();
            timestampsort1.setSortOrder(SortOrder.Descending);
            commentspagerequest.setSortType(timestampsort1);
        }
        requestbatch = new RequestBatch();
        try
        {
            requestbatch.addRequest(commentspagerequest);
        }
        catch(JSONException jsonexception)
        {
            Log.e("PLUCK", "JSONException on RequestBatch.addRequest:");
            jsonexception.printStackTrace();
        }
        if(!jsonobject.has("userOption")) goto _L2; else goto _L1
_L1:
        if(jsonobject.getInt("userOption") != context.getResources().getInteger(com.mirror.base.R.integer.with_user)) goto _L4; else goto _L3
_L3:
        UserAuthenticationToken userauthenticationtoken;
        try
        {
            jsonobject1 = ((KogiActivity)context).getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA);
            userauthenticationtoken = new UserAuthenticationToken((new StringBuilder()).append("fb_").append(jsonobject1.getString("id")).append("_fb").toString(), jsonobject1.getString("username"), jsonobject1.getString("email"), context.getString(com.mirror.base.R.string.pluck_shared_secret), "at");
        }
        catch(AuthenticationTokenException authenticationtokenexception)
        {
            authenticationtokenexception.printStackTrace();
            userauthenticationtoken = null;
        }
        catch(JSONException jsonexception1)
        {
            jsonexception1.printStackTrace();
            userauthenticationtoken = null;
        }
        try
        {
            responsebatch3 = pluckserver1.sendRequest(requestbatch, userauthenticationtoken);
        }
        catch(Exception exception3)
        {
            Log.e("PLUCK", "Exception on PluckServer.sendRequest:", exception3);
            exception3.printStackTrace();
            responsebatch = null;
            continue; /* Loop/switch isn't completed */
        }
        responsebatch = responsebatch3;
_L8:
        if(responsebatch == null)
            break; /* Loop/switch isn't completed */
        acomment = handleResponseBatch(responsebatch, s);
        i = 0;
_L6:
        if(i >= acomment.length)
            break; /* Loop/switch isn't completed */
        arraylist.add(acomment[i]);
        i++;
        if(true) goto _L6; else goto _L5
_L4:
        ResponseBatch responsebatch2;
        try
        {
            String s3 = UserAuthenticationToken.EXTENDED_COOKIE;
            org.apache.http.client.CookieStore cookiestore1 = ((MirrorNewsApp)context.getApplicationContext()).getCookieStore();
            responsebatch2 = pluckserver1.sendRequest(requestbatch, "", s3, cookiestore1);
        }
        catch(Exception exception2)
        {
            Log.e("PLUCK", "Exception on PluckServer.sendRequest:", exception2);
            exception2.printStackTrace();
            responsebatch = null;
            continue; /* Loop/switch isn't completed */
        }
        responsebatch = responsebatch2;
        continue; /* Loop/switch isn't completed */
_L2:
        ResponseBatch responsebatch1;
        String s2 = UserAuthenticationToken.EXTENDED_COOKIE;
        org.apache.http.client.CookieStore cookiestore = ((MirrorNewsApp)context.getApplicationContext()).getCookieStore();
        responsebatch1 = pluckserver1.sendRequest(requestbatch, "", s2, cookiestore);
        responsebatch = responsebatch1;
        continue; /* Loop/switch isn't completed */
        Exception exception;
        exception;
        Log.e("PLUCK", "Exception on PluckServer.sendRequest:", exception);
        exception.printStackTrace();
        responsebatch = null;
        if(true) goto _L8; else goto _L7
        Exception exception1;
        exception1;
        exception1.printStackTrace();
_L7:
        arraylist = null;
_L5:
        return arraylist;
        if(true) goto _L10; else goto _L9
_L9:
    }

    public String getResponseMessage()
    {
        return responseMessage;
    }

    public boolean getScoreReview(JSONObject jsonobject)
        throws JSONException
    {
        ResponseBatch responsebatch;
        PluckServer pluckserver;
        PluckServer pluckserver1;
        RequestBatch requestbatch;
        UserAuthenticationToken userauthenticationtoken;
        IResponse iresponse;
        ResponseBatch responsebatch1;
        try
        {
            pluckserver = new PluckServer(context.getString(com.mirror.base.R.string.pluck_server));
        }
        catch(MalformedURLException malformedurlexception)
        {
            malformedurlexception.printStackTrace();
            pluckserver1 = null;
            continue; /* Loop/switch isn't completed */
        }
        pluckserver1 = pluckserver;
_L3:
        requestbatch = (RequestBatch)jsonobject.get("request");
        userauthenticationtoken = (UserAuthenticationToken)jsonobject.get("authToken");
        responsebatch1 = pluckserver1.sendRequest(requestbatch, userauthenticationtoken);
        responsebatch = responsebatch1;
_L1:
        if(responsebatch != null)
        {
            iresponse = ((ResponseEnvelope)responsebatch.getEnvelopes().get(0)).getPayload();
            Exception exception;
            if(!iresponse.getResponseStatus().getStatusCode().equals(ResponseStatusCode.OK))
            {
                if(!ExceptionPrettyPrinter.handleUserFacingExceptions(iresponse))
                {
                    System.out.println("Response had 1 or more error-level exceptions; info follows:\n");
                    ExceptionPrettyPrinter.printExceptionMessages(iresponse, ResponseExceptionLevel.Error);
                    return false;
                }
            } else
            {
                System.out.println("Success");
                return true;
            }
        }
        break MISSING_BLOCK_LABEL_173;
        exception;
        System.out.println("Exception on PluckServer.sendRequest:");
        exception.printStackTrace();
        responsebatch = null;
          goto _L1
        return false;
        if(true) goto _L3; else goto _L2
_L2:
    }

    public boolean reportAbuse(JSONObject jsonobject)
        throws JSONException
    {
        PluckServer pluckserver1;
        RequestBatch requestbatch;
        UserAuthenticationToken userauthenticationtoken;
        ResponseBatch responsebatch;
        PluckServer pluckserver;
        boolean flag;
        IResponse iresponse;
        ResponseBatch responsebatch2;
        try
        {
            pluckserver = new PluckServer(context.getString(com.mirror.base.R.string.pluck_server));
        }
        catch(MalformedURLException malformedurlexception)
        {
            malformedurlexception.printStackTrace();
            pluckserver1 = null;
            continue; /* Loop/switch isn't completed */
        }
        pluckserver1 = pluckserver;
_L5:
        requestbatch = (RequestBatch)jsonobject.get("request");
        flag = jsonobject.has("authToken");
        userauthenticationtoken = null;
        if(flag)
            userauthenticationtoken = (UserAuthenticationToken)jsonobject.get("authToken");
        if(userauthenticationtoken != null) goto _L2; else goto _L1
_L1:
        responsebatch2 = pluckserver1.sendRequest(requestbatch, "", UserAuthenticationToken.EXTENDED_COOKIE, ((MirrorNewsApp)context.getApplicationContext()).getCookieStore());
        responsebatch = responsebatch2;
_L3:
        if(responsebatch != null)
        {
            iresponse = ((ResponseEnvelope)responsebatch.getEnvelopes().get(0)).getPayload();
            Exception exception;
            ResponseBatch responsebatch1;
            if(!iresponse.getResponseStatus().getStatusCode().equals(ResponseStatusCode.OK))
            {
                if(!ExceptionPrettyPrinter.handleUserFacingExceptions(iresponse))
                {
                    System.out.println("Response had 1 or more error-level exceptions; info follows:\n");
                    ExceptionPrettyPrinter.printExceptionMessages(iresponse, ResponseExceptionLevel.Error);
                    return false;
                }
            } else
            {
                System.out.println("Success");
                return true;
            }
        }
        break MISSING_BLOCK_LABEL_229;
_L2:
        responsebatch1 = pluckserver1.sendRequest(requestbatch, userauthenticationtoken);
        responsebatch = responsebatch1;
          goto _L3
        exception;
        System.out.println("Exception on PluckServer.sendRequest:");
        exception.printStackTrace();
        responsebatch = null;
          goto _L3
        return false;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public void setResponseMessage(String s)
    {
        responseMessage = s;
    }

    public boolean writeComment(JSONObject jsonobject)
        throws JSONException
    {
        ResponseBatch responsebatch;
        PluckServer pluckserver;
        PluckServer pluckserver1;
        RequestBatch requestbatch;
        UserAuthenticationToken userauthenticationtoken;
        ResponseBatch responsebatch1;
        try
        {
            pluckserver = new PluckServer(context.getString(com.mirror.base.R.string.pluck_server));
        }
        catch(MalformedURLException malformedurlexception)
        {
            malformedurlexception.printStackTrace();
            pluckserver1 = null;
            continue; /* Loop/switch isn't completed */
        }
        pluckserver1 = pluckserver;
_L3:
        requestbatch = (RequestBatch)jsonobject.get("request");
        userauthenticationtoken = (UserAuthenticationToken)jsonobject.get("authToken");
        responsebatch1 = pluckserver1.sendRequest(requestbatch, userauthenticationtoken);
        responsebatch = responsebatch1;
_L1:
        if(responsebatch != null)
        {
            IResponse iresponse = ((ResponseEnvelope)responsebatch.getEnvelopes().get(0)).getPayload();
            if(!iresponse.getResponseStatus().getStatusCode().equals(ResponseStatusCode.OK))
            {
                Exception exception;
                if(!ExceptionPrettyPrinter.handleUserFacingExceptions(iresponse))
                {
                    System.out.println("Response had 1 or more error-level exceptions; info follows:\n");
                    ExceptionPrettyPrinter.printExceptionMessages(iresponse, ResponseExceptionLevel.Error);
                } else
                {
                    List list = ResponseExceptionChecker.getDirtyWords(iresponse);
                    if(!list.isEmpty())
                    {
                        String s = "Please remove the following words from your input: ";
                        for(Iterator iterator = list.iterator(); iterator.hasNext();)
                            s = (new StringBuilder()).append(s).append((String)iterator.next()).toString();

                        setResponseMessage(s);
                    }
                }
                return false;
            } else
            {
                System.out.println("Success");
                return true;
            }
        }
        break MISSING_BLOCK_LABEL_256;
        exception;
        System.out.println("Exception on PluckServer.sendRequest:");
        exception.printStackTrace();
        responsebatch = null;
          goto _L1
        return false;
        if(true) goto _L3; else goto _L2
_L2:
    }

    private Context context;
    private String responseMessage;
}
