// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.KogiActivity;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import com.base.listviews.pulltorefresh.PullToRefreshListView;
import com.facebook.AppEventsLogger;
import com.facebook.android.*;
import com.kogi.webservices.InternetChangedListener;
import com.mirror.base.comments.ws.CommentsAsyncTask;
import com.mirror.base.comments.ws.FacebookCommentsAsyncTask;
import com.mirror.base.main.MirrorNewsApp;
import com.mirror.base.tracking.TrackingHelper;
import com.pluck.sdk.Interfaces.BaseKey;
import com.pluck.sdk.Models.External.ExternalResourceKey;
import com.pluck.sdk.Requests.Moderation.ReportAbuseActionRequest;
import com.pluck.sdk.Requests.Reactions.CommentActionRequest;
import com.pluck.sdk.Requests.Reactions.SetItemScoreActionRequest;
import com.pluck.sdk.auth.AuthenticationTokenException;
import com.pluck.sdk.auth.UserAuthenticationToken;
import com.pluck.sdk.batching.RequestBatch;
import java.io.PrintStream;
import java.util.*;
import org.json.*;

// Referenced classes of package com.mirror.base.comments:
//            CommentsAdapter, AdapterDropDownListComments

public class CommentsActivity extends KogiActivity
{

    public CommentsActivity()
    {
        currentPage = 1;
        loadingMore = true;
        noMoreToLoad = false;
        isPullToRefresh = false;
        isDropDownMenuOn = false;
        isDropdownSubMenuOn = false;
        lastCommentsWithUser = false;
    }

    private void getUserData()
        throws JSONException
    {
        if(getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA).toString().equalsIgnoreCase((new JSONObject()).toString()))
        {
            loadComments(getResources().getInteger(com.mirror.base.R.integer.without_user));
            return;
        } else
        {
            loadComments(getResources().getInteger(com.mirror.base.R.integer.with_user));
            return;
        }
    }

    private void getUserDataForScore(final int i, final BaseKey articleKey, final BaseKey reviewKey, final boolean needToUpdate)
        throws JSONException
    {
        if(facebookLocal.isSessionValid())
        {
            doItemScoreAction(i, articleKey, reviewKey);
            if(needToUpdate)
                loadComments(getResources().getInteger(com.mirror.base.R.integer.with_user));
            return;
        } else
        {
            facebookLocal.authorize(this, getResources().getStringArray(com.mirror.base.R.array.facebook_permissions), new com.facebook.android.Facebook.DialogListener() {

                public void onCancel()
                {
                }

                public void onComplete(Bundle bundle)
                {
                    try
                    {
                        (new FacebookCommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_DO_ITEM_SCORE, CommentsActivity.this, getString(com.mirror.base.R.string.comments_getting_comments_title), getString(com.mirror.base.R.string.comments_getting_comments_body))).execute(new JSONObject[] {
                            (new JSONObject()).put("fields", "id,username,email").put("access_token", facebookLocal.getAccessToken()).put("i", i).put("articleKey", articleKey).put("reviewKey", reviewKey).put("needToUpdate", needToUpdate)
                        });
                        return;
                    }
                    catch(JSONException jsonexception)
                    {
                        showDialog(getString(com.mirror.base.R.string.comments_getting_fb_data_error_title), getString(com.mirror.base.R.string.comments_getting_fb_data_error_body));
                        jsonexception.printStackTrace();
                        return;
                    }
                }

                public void onError(DialogError dialogerror)
                {
                    Toast.makeText(CommentsActivity.this, (new StringBuilder()).append("Could not log in, ERROR: ").append(dialogerror.getMessage()).toString(), 1).show();
                }

                public void onFacebookError(FacebookError facebookerror)
                {
                }

                final CommentsActivity this$0;
                final BaseKey val$articleKey;
                final int val$i;
                final boolean val$needToUpdate;
                final BaseKey val$reviewKey;

            
            {
                this$0 = CommentsActivity.this;
                i = j;
                articleKey = basekey;
                reviewKey = basekey1;
                needToUpdate = flag;
                super();
            }
            });
            return;
        }
    }

    private void setLoadMoreListener()
    {
        loadmoreView = ((LayoutInflater)getSystemService("layout_inflater")).inflate(com.mirror.base.R.layout.list_load_more_footer, null, false);
        ((ListView)listViewComments.getRefreshableView()).addFooterView(loadmoreView);
        listViewComments.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {

            public void onScroll(AbsListView abslistview, int i, int j, int k)
            {
                if(i + j == k && !loadingMore && !noMoreToLoad)
                {
                    loadmoreView.setVisibility(0);
                    loadingMore = true;
                    try
                    {
                        JSONObject jsonobject = new JSONObject();
                        jsonobject.put("userOption", getResources().getInteger(com.mirror.base.R.integer.without_user));
                        jsonobject.put("articleId", articleId);
                        jsonobject.put("order", getString(com.mirror.base.R.string.comments_newest));
                        jsonobject.put("currentPage", currentPage);
                        jsonobject.put("order", (new StringBuilder()).append(bCommentsPopupButton.getText()).append("").toString());
                        (new CommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_LOAD_MORE, CommentsActivity.this)).execute(new JSONObject[] {
                            jsonobject
                        });
                    }
                    catch(JSONException jsonexception)
                    {
                        jsonexception.printStackTrace();
                    }
                }
                if(noMoreToLoad)
                    loadmoreView.setVisibility(8);
            }

            public void onScrollStateChanged(AbsListView abslistview, int i)
            {
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
    }

    public void addComments(ArrayList arraylist)
    {
        boolean flag = true;
        if(arraylist != null && arraylist.size() > 0)
        {
            commentsAdapter.addComments(arraylist);
            currentPage = 1 + currentPage;
        } else
        {
            noMoreToLoad = flag;
            loadmoreView.setVisibility(8);
        }
        if(loadingMore)
        {
            if(loadingMore)
                flag = false;
            loadingMore = flag;
        }
    }

    public void changeandUpdateOpinionsBaseUrl(String s, String s1)
        throws JSONException
    {
        if(s1 == null || s1.equals("")) goto _L2; else goto _L1
_L1:
        title = s1.toUpperCase(Locale.ENGLISH);
        if(s1.equalsIgnoreCase((new StringBuilder()).append(bCommentsPopupButton.getText()).append("").toString())) goto _L2; else goto _L3
_L3:
        int j;
        bCommentsPopupButton.setText(s1);
        String as[];
        AdapterDropDownListComments adapterdropdownlistcomments;
        int i;
        if(getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA).toString().equalsIgnoreCase((new JSONObject()).toString()))
            loadComments(getResources().getInteger(com.mirror.base.R.integer.without_user), s1);
        else
            loadComments(getResources().getInteger(com.mirror.base.R.integer.with_user), s1);
        as = new String[3];
        as[0] = "comments";
        adapterdropdownlistcomments = dropDownMenuAdapter;
        i = dropDownMenuAdapter.getSelectedPos();
        j = 0;
        if(i != -1) goto _L5; else goto _L4
_L4:
        int k;
        try
        {
            as[1] = adapterdropdownlistcomments.getItem(j).getString("name").toLowerCase();
            as[2] = "";
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
        trackEvent(as);
_L2:
        return;
_L5:
        k = dropDownMenuAdapter.getSelectedPos();
        j = k;
          goto _L4
    }

    public void disLikeComment(BaseKey basekey, BaseKey basekey1, boolean flag)
        throws JSONException
    {
        if(getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA).toString().equalsIgnoreCase((new JSONObject()).toString()))
        {
            getUserDataForScore(-1, basekey, basekey1, flag);
        } else
        {
            doItemScoreAction(-1, basekey, basekey1);
            if(flag)
            {
                loadComments(getResources().getInteger(com.mirror.base.R.integer.with_user));
                return;
            }
        }
    }

    public void doItemScoreAction(int i, BaseKey basekey, BaseKey basekey1)
    {
        SetItemScoreActionRequest setitemscoreactionrequest = new SetItemScoreActionRequest();
        setitemscoreactionrequest.setParentKey(basekey);
        setitemscoreactionrequest.setTargetKey(basekey1);
        setitemscoreactionrequest.setScore(i);
        setitemscoreactionrequest.setScoreId("Thumbs");
        RequestBatch requestbatch = new RequestBatch();
        UserAuthenticationToken userauthenticationtoken;
        CommentsAsyncTask commentsasynctask;
        try
        {
            requestbatch.addRequest(setitemscoreactionrequest);
        }
        catch(JSONException jsonexception)
        {
            System.out.println("JSONException on RequestBatch.addRequest:");
            jsonexception.printStackTrace();
        }
        try
        {
            JSONObject jsonobject = getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA);
            userauthenticationtoken = new UserAuthenticationToken((new StringBuilder()).append("fb_").append(jsonobject.getString("id")).append("_fb").toString(), jsonobject.getString("username"), jsonobject.getString("email"), getString(com.mirror.base.R.string.pluck_shared_secret), "at");
        }
        catch(AuthenticationTokenException authenticationtokenexception)
        {
            authenticationtokenexception.printStackTrace();
            userauthenticationtoken = null;
        }
        catch(JSONException jsonexception1)
        {
            jsonexception1.printStackTrace();
            userauthenticationtoken = null;
        }
        commentsasynctask = new CommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_SCORE_REVIEW, this);
        try
        {
            commentsasynctask.execute(new JSONObject[] {
                (new JSONObject()).put("request", requestbatch).put("authToken", userauthenticationtoken)
            });
            return;
        }
        catch(JSONException jsonexception2)
        {
            jsonexception2.printStackTrace();
        }
    }

    public void doReportAbuse(final BaseKey reviewKey, int i, final int userOption)
    {
        final Dialog dialog = new Dialog(this, com.mirror.base.R.style.CustomDialogTheme);
        dialog.setContentView(com.mirror.base.R.layout.comments_write_dialog);
        ((TextView)dialog.findViewById(com.mirror.base.R.id.dTTitle)).setText(getString(com.mirror.base.R.string.comments_abuse));
        dialog.show();
        dialog.getWindow().setGravity(1);
        Button button = (Button)dialog.findViewById(com.mirror.base.R.id.bCommentsWriteCancel);
        Button button1 = (Button)dialog.findViewById(com.mirror.base.R.id.bCommentsWriteOk);
        final EditText eTCommentsWrite = (EditText)dialog.findViewById(com.mirror.base.R.id.eTCommentsWrite);
        button.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                dialog.dismiss();
            }

            final CommentsActivity this$0;
            final Dialog val$dialog;

            
            {
                this$0 = CommentsActivity.this;
                dialog = dialog1;
                super();
            }
        });
        button1.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                ReportAbuseActionRequest reportabuseactionrequest;
                reportabuseactionrequest = new ReportAbuseActionRequest();
                reportabuseactionrequest.setAbuseOnKey(reviewKey);
                if(TextUtils.isEmpty(eTCommentsWrite.getText().toString()))
                {
                    Toast.makeText(CommentsActivity.this, com.mirror.base.R.string.comments_report_no_text, 0).show();
                    return;
                }
                RequestBatch requestbatch;
                reportabuseactionrequest.setReason((new StringBuilder()).append(eTCommentsWrite.getText()).append("").toString());
                requestbatch = new RequestBatch();
                requestbatch.addRequest(reportabuseactionrequest);
_L1:
                UserAuthenticationToken userauthenticationtoken;
                JSONObject jsonobject1 = getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA);
                if(jsonobject1.equals(new JSONObject()))
                    break MISSING_BLOCK_LABEL_343;
                userauthenticationtoken = new UserAuthenticationToken((new StringBuilder()).append("fb_").append(jsonobject1.getString("id")).append("_fb").toString(), jsonobject1.getString("username"), jsonobject1.getString("email"), getString(com.mirror.base.R.string.pluck_shared_secret), "at");
_L2:
                try
                {
                    JSONObject jsonobject = (new JSONObject()).put("request", requestbatch).put("authToken", userauthenticationtoken).put("order", (new StringBuilder()).append(bCommentsPopupButton.getText()).append("").toString()).put("articleId", articleId).put("userOption", userOption);
                    (new CommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.REPORT_ABUSE, CommentsActivity.this, "Please Wait...", "Sending your message")).execute(new JSONObject[] {
                        jsonobject
                    });
                    dialog.dismiss();
                    return;
                }
                catch(JSONException jsonexception)
                {
                    jsonexception.printStackTrace();
                }
                return;
                JSONException jsonexception1;
                jsonexception1;
                System.out.println("JSONException on RequestBatch.addRequest:");
                jsonexception1.printStackTrace();
                  goto _L1
                AuthenticationTokenException authenticationtokenexception;
                authenticationtokenexception;
                authenticationtokenexception.printStackTrace();
                userauthenticationtoken = null;
                  goto _L2
                JSONException jsonexception2;
                jsonexception2;
                jsonexception2.printStackTrace();
                userauthenticationtoken = null;
                  goto _L2
            }

            final CommentsActivity this$0;
            final Dialog val$dialog;
            final EditText val$eTCommentsWrite;
            final BaseKey val$reviewKey;
            final int val$userOption;

            
            {
                this$0 = CommentsActivity.this;
                reviewKey = basekey;
                eTCommentsWrite = edittext;
                userOption = i;
                dialog = dialog1;
                super();
            }
        });
    }

    public Facebook getFaceBookLocal()
    {
        return facebookLocal;
    }

    public void hideDropDownMenus()
    {
        dropDownMenuContentComments.setVisibility(8);
        dropDownSubMenuContentComments.setVisibility(8);
        isDropDownMenuOn = false;
        isDropdownSubMenuOn = false;
    }

    protected void initData()
    {
        try
        {
            getUserData();
            return;
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
    }

    protected void initListeners()
    {
        setInternetChangedListener(new InternetChangedListener() {

            public void onInternetConnectionChanged(boolean flag)
            {
                if(!flag)
                {
                    Toast.makeText(CommentsActivity.this, com.mirror.base.R.string.comments_no_internet, 0).show();
                    if(isPullToRefresh)
                        listViewComments.onRefreshComplete();
                }
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
        listViewComments.setOnRefreshListener(new com.base.listviews.pulltorefresh.PullToRefreshBase.OnRefreshListener() {

            public void onRefresh()
            {
                isPullToRefresh = true;
                try
                {
                    getUserData();
                    return;
                }
                catch(JSONException jsonexception)
                {
                    jsonexception.printStackTrace();
                }
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
        bCommentsPopupButton.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                if(isDropDownMenuOn)
                {
                    hideDropDownMenus();
                    return;
                } else
                {
                    dropDownMenuAdapter.notifyDataSetChanged();
                    dropDownSubMenuAdapter.notifyDataSetChanged();
                    dropDownMenuContentComments.setVisibility(0);
                    isDropDownMenuOn = true;
                    return;
                }
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
        tvCommentsWriteComment.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                if(!((MirrorNewsApp)getApplicationContext()).isConnectedToInternet())
                {
                    showDialog(getString(com.mirror.base.R.string.no_internet_title), getString(com.mirror.base.R.string.comments_reconnect));
                    return;
                }
                if(getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA).toString().equalsIgnoreCase((new JSONObject()).toString()))
                {
                    logAndComment();
                    return;
                } else
                {
                    writeComment();
                    return;
                }
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
        relativeTopBannerBack.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                view.setBackgroundColor(getResources().getColor(0x106000d));
                finish();
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
        relativeTopBannerBack.setOnTouchListener(new android.view.View.OnTouchListener() {

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if(motionevent.getAction() == 3 || motionevent.getAction() == 1)
                    view.setBackgroundColor(getResources().getColor(0x106000d));
                else
                    view.setBackgroundColor(getResources().getColor(com.mirror.base.R.color.settings_divider));
                return false;
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
    }

    protected void initVars()
    {
        int j;
        facebookLocal = new Facebook(getResources().getString(com.mirror.base.R.string.facebook_app_id));
        articleId = getIntent().getExtras().getString("articleId");
        JSONArray jsonarray = new JSONArray();
        String as[];
        AdapterDropDownListComments adapterdropdownlistcomments;
        int i;
        try
        {
            jsonarray.put((new JSONObject()).put("url", getString(com.mirror.base.R.string.comments_newest)).put("name", getString(com.mirror.base.R.string.comments_newest)));
            jsonarray.put((new JSONObject()).put("url", getString(com.mirror.base.R.string.comments_oldest)).put("name", getString(com.mirror.base.R.string.comments_oldest)));
            jsonarray.put((new JSONObject()).put("url", getString(com.mirror.base.R.string.comments_best_rated)).put("name", getString(com.mirror.base.R.string.comments_best_rated)));
            jsonarray.put((new JSONObject()).put("url", getString(com.mirror.base.R.string.comments_worst_rated)).put("name", getString(com.mirror.base.R.string.comments_worst_rated)));
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
        dropDownMenuAdapter = new AdapterDropDownListComments(this, jsonarray, true, com.mirror.base.R.color.DropDownMenuFirstMenuUnselectedBG);
        dropDownSubMenuAdapter = new AdapterDropDownListComments(this, jsonarray, true, com.mirror.base.R.color.DropDownMenuFirstMenuUnselectedBG);
        as = new String[3];
        as[0] = "comments";
        adapterdropdownlistcomments = dropDownMenuAdapter;
        i = dropDownMenuAdapter.getSelectedPos();
        j = 0;
        if(i != -1) goto _L2; else goto _L1
_L1:
        int k;
        try
        {
            as[1] = adapterdropdownlistcomments.getItem(j).getString("name").toLowerCase();
            as[2] = "";
        }
        catch(JSONException jsonexception1)
        {
            jsonexception1.printStackTrace();
        }
        trackEvent(as);
        return;
_L2:
        k = dropDownMenuAdapter.getSelectedPos();
        j = k;
          goto _L1
    }

    protected void initViews(Bundle bundle)
    {
        relativeTopBannerBack = (RelativeLayout)findViewById(com.mirror.base.R.id.relativeTopBannerBack);
        imageViewTopBannerBack = (ImageView)findViewById(com.mirror.base.R.id.imageViewTopBannerBack);
        textViewTopBannerBackTitle = (TextView)findViewById(com.mirror.base.R.id.textViewTopBannerBackTitle);
        bCommentsPopupButton = (Button)findViewById(com.mirror.base.R.id.bCommentsPopupButton);
        tvCommentsWriteComment = (TextView)findViewById(com.mirror.base.R.id.tvCommentsWriteComment);
        listViewComments = (PullToRefreshListView)findViewById(com.mirror.base.R.id.listViewComments);
        setLoadMoreListener();
        dropDownMenuContentComments = (RelativeLayout)findViewById(com.mirror.base.R.id.dropDownMenuContentComments);
        listViewDropDownMenuComments = (ListView)findViewById(com.mirror.base.R.id.listViewDropDownMenuComments);
        dropDownSubMenuContentComments = (RelativeLayout)findViewById(com.mirror.base.R.id.dropDownSubMenuContentComments);
        listViewDropDownSubMenuComments = (ListView)findViewById(com.mirror.base.R.id.listViewDropDownSubMenuComments);
        loadingPanelComments = (RelativeLayout)findViewById(com.mirror.base.R.id.loadingPanelComments);
        textViewTopBannerBackTitle.setText(getString(com.mirror.base.R.string.comments));
        listViewDropDownMenuComments.setAdapter(dropDownMenuAdapter);
        if(title == null || title.equals(""))
        {
            bCommentsPopupButton.setText(getString(com.mirror.base.R.string.comments_newest));
            return;
        } else
        {
            bCommentsPopupButton.setText(title);
            return;
        }
    }

    public boolean isLastCommentsWithUser()
    {
        return lastCommentsWithUser;
    }

    public void likeComment(BaseKey basekey, BaseKey basekey1, boolean flag)
        throws JSONException
    {
        if(getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA).toString().equalsIgnoreCase((new JSONObject()).toString()))
        {
            getUserDataForScore(1, basekey, basekey1, flag);
        } else
        {
            doItemScoreAction(1, basekey, basekey1);
            if(flag)
            {
                loadComments(getResources().getInteger(com.mirror.base.R.integer.with_user));
                return;
            }
        }
    }

    public void loadComments(int i)
        throws JSONException
    {
        loadComments(i, getString(com.mirror.base.R.string.comments_newest));
    }

    public void loadComments(int i, String s)
        throws JSONException
    {
        comments = new ArrayList();
        JSONObject jsonobject = new JSONObject();
        jsonobject.put("userOption", i);
        jsonobject.put("articleId", articleId);
        jsonobject.put("order", s);
        CommentsAsyncTask commentsasynctask;
        if(i == getResources().getInteger(com.mirror.base.R.integer.with_user))
        {
            UserAuthenticationToken userauthenticationtoken;
            try
            {
                JSONObject jsonobject1 = getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA);
                userauthenticationtoken = new UserAuthenticationToken((new StringBuilder()).append("fb_").append(jsonobject1.getString("id")).append("_fb").toString(), jsonobject1.getString("username"), jsonobject1.getString("email"), getString(com.mirror.base.R.string.pluck_shared_secret), "at");
            }
            catch(AuthenticationTokenException authenticationtokenexception)
            {
                authenticationtokenexception.printStackTrace();
                userauthenticationtoken = null;
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
                userauthenticationtoken = null;
            }
            jsonobject.put("authToken", userauthenticationtoken);
        }
        if(isPullToRefresh)
            commentsasynctask = new CommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_ORDERED, this);
        else
            commentsasynctask = new CommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_ORDERED, this, getString(com.mirror.base.R.string.comments_getting_comments_title), getString(com.mirror.base.R.string.comments_getting_comments_body));
        if(!((MirrorNewsApp)getApplicationContext()).isConnectedToInternet() && isPullToRefresh)
            listViewComments.onRefreshComplete();
        commentsasynctask.execute(new JSONObject[] {
            jsonobject
        });
    }

    void logAndComment()
    {
        if(facebookLocal.isSessionValid())
        {
            writeComment();
            return;
        } else
        {
            facebookLocal.authorize(this, getResources().getStringArray(com.mirror.base.R.array.facebook_permissions), new com.facebook.android.Facebook.DialogListener() {

                public void onCancel()
                {
                }

                public void onComplete(Bundle bundle)
                {
                    Bundle bundle1 = new Bundle();
                    bundle1.putString("fields", "id,username,email");
                    bundle1.putString("access_token", facebookLocal.getAccessToken());
                    try
                    {
                        (new FacebookCommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_WRITE_COMMENT, CommentsActivity.this, getString(com.mirror.base.R.string.comments_getting_comments_title), getString(com.mirror.base.R.string.comments_getting_comments_body))).execute(new JSONObject[] {
                            (new JSONObject()).put("fields", "id,username,email").put("access_token", facebookLocal.getAccessToken())
                        });
                        return;
                    }
                    catch(JSONException jsonexception)
                    {
                        showDialog(getString(com.mirror.base.R.string.comments_getting_fb_data_error_title), getString(com.mirror.base.R.string.comments_getting_fb_data_error_body));
                        jsonexception.printStackTrace();
                        return;
                    }
                }

                public void onError(DialogError dialogerror)
                {
                    Toast.makeText(CommentsActivity.this, (new StringBuilder()).append("Could not log in, ERROR: ").append(dialogerror.getMessage()).toString(), 1).show();
                }

                public void onFacebookError(FacebookError facebookerror)
                {
                }

                final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
            });
            return;
        }
    }

    protected void onActivityResult(int i, int j, Intent intent)
    {
        super.onActivityResult(i, j, intent);
        if(i != getResources().getInteger(com.mirror.base.R.integer.facebook_katana_request_code))
            break MISSING_BLOCK_LABEL_96;
        facebookLocal.authorizeCallback(i, j, intent);
        (new FacebookCommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.COMMENTS_FB_RETURNING, this, getString(com.mirror.base.R.string.comments_getting_comments_title), getString(com.mirror.base.R.string.comments_getting_comments_body))).execute(new JSONObject[] {
            (new JSONObject()).put("fields", "id,username,email").put("access_token", facebookLocal.getAccessToken())
        });
        return;
        JSONException jsonexception;
        jsonexception;
        showDialog(getString(com.mirror.base.R.string.comments_getting_fb_data_error_title), getString(com.mirror.base.R.string.comments_getting_fb_data_error_body));
        jsonexception.printStackTrace();
        return;
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(com.mirror.base.R.layout.comments_activity);
    }

    protected void onResume()
    {
        super.onResume();
        AppEventsLogger.activateApp(this, getString(com.mirror.base.R.string.facebook_app_id));
    }

    public void reportComment(BaseKey basekey, int i, boolean flag)
        throws JSONException
    {
        if(!getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA).toString().equalsIgnoreCase((new JSONObject()).toString()) || facebookLocal.isSessionValid())
        {
            doReportAbuse(basekey, i, getResources().getInteger(com.mirror.base.R.integer.with_user));
            if(flag)
                loadComments(getResources().getInteger(com.mirror.base.R.integer.with_user));
        } else
        {
            doReportAbuse(basekey, i, getResources().getInteger(com.mirror.base.R.integer.without_user));
            if(flag)
            {
                loadComments(getResources().getInteger(com.mirror.base.R.integer.without_user));
                return;
            }
        }
    }

    public void setComments(ArrayList arraylist)
    {
        loadingPanelComments.setVisibility(8);
        comments = arraylist;
        if(commentsAdapter != null)
        {
            commentsAdapter.setComments(arraylist);
        } else
        {
            commentsAdapter = new CommentsAdapter(this, arraylist);
            listViewComments.setAdapter(commentsAdapter);
        }
        setLoadMoreListener();
        commentsAdapter.notifyDataSetInvalidated();
        currentPage = 2;
        loadingMore = false;
        noMoreToLoad = false;
        if(isPullToRefresh)
        {
            isPullToRefresh = false;
            listViewComments.onRefreshComplete();
        }
    }

    public void setLastCommentsWithUser(boolean flag)
    {
        lastCommentsWithUser = flag;
    }

    public void showDialog(String s, String s1)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setMessage(s1).setTitle(s).setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialoginterface, int i)
            {
                dialoginterface.cancel();
            }

            final CommentsActivity this$0;

            
            {
                this$0 = CommentsActivity.this;
                super();
            }
        });
        builder.create().show();
    }

    public void showDropDownSubMenu(JSONArray jsonarray)
    {
        dropDownSubMenuAdapter.updateData(jsonarray);
        dropDownSubMenuAdapter.notifyDataSetChanged();
        dropDownMenuContentComments.setVisibility(0);
    }

    public void trackEvent(String as[])
    {
        Hashtable hashtable = new Hashtable();
        Hashtable hashtable1 = new Hashtable();
        String s = getString(com.mirror.base.R.string.omniture_products);
        int i = com.mirror.base.R.string.omniture_appstate_section;
        Object aobj[] = new Object[2];
        aobj[0] = as[0];
        aobj[1] = as[1];
        String s1 = getString(i, aobj).trim();
        String s2 = getString(com.mirror.base.R.string.omniture_app_section_events);
        String s3 = getString(com.mirror.base.R.string.omniture_hire1_section);
        Object aobj1[] = new Object[3];
        String s4;
        String s5;
        String s6;
        Display display;
        DisplayMetrics displaymetrics;
        String s7;
        Integer integer;
        String s8;
        Object aobj2[];
        if(as[0] == "")
            s4 = "na";
        else
            s4 = as[0];
        aobj1[0] = s4;
        if(as[1] == "")
            s5 = "na";
        else
            s5 = as[1];
        aobj1[1] = s5;
        aobj1[2] = s1;
        s6 = String.format(s3, aobj1);
        hashtable.put(Integer.valueOf(1), as[0]);
        hashtable.put(Integer.valueOf(2), as[1]);
        hashtable.put(Integer.valueOf(5), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_owner_site)));
        hashtable.put(Integer.valueOf(15), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_not_an_article)));
        hashtable.put(Integer.valueOf(16), getString(com.mirror.base.R.string.omniture_prop16));
        hashtable.put(Integer.valueOf(19), "");
        hashtable.put(Integer.valueOf(21), getString(com.mirror.base.R.string.omniture_prop21));
        hashtable.put(Integer.valueOf(27), "");
        hashtable.put(Integer.valueOf(30), as[2]);
        hashtable.put(Integer.valueOf(31), "");
        hashtable.put(Integer.valueOf(32), "");
        hashtable.put(Integer.valueOf(35), "");
        display = getWindowManager().getDefaultDisplay();
        displaymetrics = new DisplayMetrics();
        display.getMetrics(displaymetrics);
        hashtable.put(Integer.valueOf(36), TrackingHelper.SCStrip2((new StringBuilder()).append(displaymetrics.widthPixels).append("x").append(displaymetrics.heightPixels).toString()));
        hashtable.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
        hashtable.put(Integer.valueOf(42), TrackingHelper.SCStrip2(TrackingHelper.checkInternetType(this)));
        hashtable.put(Integer.valueOf(49), TrackingHelper.SCStrip2(TrackingHelper.getVisitorID()));
        hashtable.put(Integer.valueOf(50), "");
        s7 = TrackingHelper.CalculateDate(this);
        hashtable.put(Integer.valueOf(51), TrackingHelper.SCStrip2(s7));
        hashtable.put(Integer.valueOf(52), getString(com.mirror.base.R.string.omniture_prop52));
        hashtable.put(Integer.valueOf(53), getString(com.mirror.base.R.string.omniture_prop53));
        hashtable.put(Integer.valueOf(64), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_mobile)));
        hashtable.put(Integer.valueOf(72), (new StringBuilder()).append(getString(com.mirror.base.R.string.omniture_prop72_prefix)).append(as[0]).toString());
        hashtable.put(Integer.valueOf(75), TrackingHelper.SCStrip2((new StringBuilder()).append("mobile_").append(Build.MANUFACTURER).append("_").append(Build.MODEL).append(getString(com.mirror.base.R.string.omniture_prop75_sufix)).toString()));
        hashtable1.put(Integer.valueOf(9), hashtable.get(Integer.valueOf(16)));
        hashtable1.put(Integer.valueOf(10), hashtable.get(Integer.valueOf(21)));
        hashtable1.put(Integer.valueOf(11), hashtable.get(Integer.valueOf(5)));
        hashtable1.put(Integer.valueOf(12), hashtable.get(Integer.valueOf(35)));
        hashtable1.put(Integer.valueOf(14), hashtable.get(Integer.valueOf(15)));
        hashtable1.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
        hashtable1.put(Integer.valueOf(41), hashtable.get(Integer.valueOf(2)));
        hashtable1.put(Integer.valueOf(42), "");
        hashtable1.put(Integer.valueOf(43), hashtable.get(Integer.valueOf(30)));
        hashtable1.put(Integer.valueOf(45), hashtable.get(Integer.valueOf(19)));
        hashtable1.put(Integer.valueOf(47), hashtable.get(Integer.valueOf(51)));
        hashtable1.put(Integer.valueOf(48), hashtable.get(Integer.valueOf(52)));
        hashtable1.put(Integer.valueOf(49), hashtable.get(Integer.valueOf(53)));
        integer = Integer.valueOf(50);
        s8 = getString(com.mirror.base.R.string.omniture_evar50_section);
        aobj2 = new Object[2];
        aobj2[0] = as[0];
        aobj2[1] = as[1];
        hashtable1.put(integer, String.format(s8, aobj2).trim());
        hashtable1.put(Integer.valueOf(51), hashtable.get(Integer.valueOf(49)));
        hashtable1.put(Integer.valueOf(57), hashtable.get(Integer.valueOf(51)));
        hashtable1.put(Integer.valueOf(59), "");
        hashtable1.put(Integer.valueOf(61), hashtable.get(Integer.valueOf(75)));
        hashtable1.put(Integer.valueOf(64), hashtable.get(Integer.valueOf(64)));
        TrackingHelper.logEvent(hashtable, hashtable1, s2, s, s1, s6, false);
    }

    public void writeComment()
    {
        final Dialog dialog = new Dialog(this, com.mirror.base.R.style.CustomDialogTheme);
        dialog.setContentView(com.mirror.base.R.layout.comments_write_dialog);
        dialog.show();
        dialog.getWindow().setGravity(1);
        Button button = (Button)dialog.findViewById(com.mirror.base.R.id.bCommentsWriteCancel);
        Button button1 = (Button)dialog.findViewById(com.mirror.base.R.id.bCommentsWriteOk);
        final EditText eTCommentsWrite = (EditText)dialog.findViewById(com.mirror.base.R.id.eTCommentsWrite);
        button.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                dialog.dismiss();
            }

            final CommentsActivity this$0;
            final Dialog val$dialog;

            
            {
                this$0 = CommentsActivity.this;
                dialog = dialog1;
                super();
            }
        });
        button1.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                if(TextUtils.isEmpty(eTCommentsWrite.getText().toString()))
                {
                    Toast.makeText(CommentsActivity.this, com.mirror.base.R.string.comments_comment_no_text, 0).show();
                    return;
                }
                CommentActionRequest commentactionrequest;
                RequestBatch requestbatch;
                ExternalResourceKey externalresourcekey = new ExternalResourceKey();
                externalresourcekey.setKey(articleId);
                commentactionrequest = new CommentActionRequest();
                commentactionrequest.setCommentedOnKey(externalresourcekey);
                commentactionrequest.setBody((new StringBuilder()).append(eTCommentsWrite.getText()).append("").toString());
                requestbatch = new RequestBatch();
                requestbatch.addRequest(commentactionrequest);
_L1:
                UserAuthenticationToken userauthenticationtoken;
                JSONObject jsonobject1 = getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_FB_DATA);
                userauthenticationtoken = new UserAuthenticationToken((new StringBuilder()).append("fb_").append(jsonobject1.getString("id")).append("_fb").toString(), jsonobject1.getString("username"), jsonobject1.getString("email"), getString(com.mirror.base.R.string.pluck_shared_secret), "at");
_L2:
                try
                {
                    JSONObject jsonobject = (new JSONObject()).put("request", requestbatch).put("authToken", userauthenticationtoken).put("order", (new StringBuilder()).append(bCommentsPopupButton.getText()).append("").toString()).put("articleId", articleId);
                    (new CommentsAsyncTask(com.mirror.base.main.MirrorNewsApp.COMMAND.WRITE_COMMAND, CommentsActivity.this, "Please Wait...", "Sending your message")).execute(new JSONObject[] {
                        jsonobject
                    });
                    dialog.dismiss();
                    return;
                }
                catch(JSONException jsonexception)
                {
                    jsonexception.printStackTrace();
                }
                return;
                JSONException jsonexception1;
                jsonexception1;
                System.out.println("JSONException on RequestBatch.addRequest:");
                jsonexception1.printStackTrace();
                  goto _L1
                AuthenticationTokenException authenticationtokenexception;
                authenticationtokenexception;
                authenticationtokenexception.printStackTrace();
                userauthenticationtoken = null;
                  goto _L2
                JSONException jsonexception2;
                jsonexception2;
                jsonexception2.printStackTrace();
                userauthenticationtoken = null;
                  goto _L2
            }

            final CommentsActivity this$0;
            final Dialog val$dialog;
            final EditText val$eTCommentsWrite;

            
            {
                this$0 = CommentsActivity.this;
                eTCommentsWrite = edittext;
                dialog = dialog1;
                super();
            }
        });
    }

    private String articleId;
    Button bCommentsPopupButton;
    private ArrayList comments;
    private CommentsAdapter commentsAdapter;
    private int currentPage;
    private AdapterDropDownListComments dropDownMenuAdapter;
    RelativeLayout dropDownMenuContentComments;
    private AdapterDropDownListComments dropDownSubMenuAdapter;
    RelativeLayout dropDownSubMenuContentComments;
    protected Facebook facebookLocal;
    ImageView imageViewTopBannerBack;
    public boolean isDropDownMenuOn;
    public boolean isDropdownSubMenuOn;
    private boolean isPullToRefresh;
    private boolean lastCommentsWithUser;
    PullToRefreshListView listViewComments;
    ListView listViewDropDownMenuComments;
    ListView listViewDropDownSubMenuComments;
    private boolean loadingMore;
    RelativeLayout loadingPanelComments;
    private View loadmoreView;
    private boolean noMoreToLoad;
    RelativeLayout relativeTopBannerBack;
    TextView textViewTopBannerBackTitle;
    private String title;
    TextView tvCommentsWriteComment;



/*
    static boolean access$002(CommentsActivity commentsactivity, boolean flag)
    {
        commentsactivity.loadingMore = flag;
        return flag;
    }

*/







/*
    static boolean access$502(CommentsActivity commentsactivity, boolean flag)
    {
        commentsactivity.isPullToRefresh = flag;
        return flag;
    }

*/



}
