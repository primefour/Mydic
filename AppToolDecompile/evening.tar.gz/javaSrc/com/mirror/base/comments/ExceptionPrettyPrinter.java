// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments;

import com.pluck.sdk.Interfaces.IResponse;
import com.pluck.sdk.Models.System.Exceptions.ResponseException;
import com.pluck.sdk.Models.System.Exceptions.ResponseExceptionLevel;
import com.pluck.sdk.Models.System.ResponseStatus;
import com.pluck.sdk.batching.ResponseBatch;
import com.pluck.sdk.batching.ResponseEnvelope;
import com.pluck.sdk.util.ResponseExceptionChecker;
import java.io.PrintStream;
import java.util.Iterator;
import java.util.List;

public abstract class ExceptionPrettyPrinter
{

    public ExceptionPrettyPrinter()
    {
    }

    public static String getExceptionMessages(IResponse iresponse, ResponseExceptionLevel responseexceptionlevel)
    {
        String s = "";
        ResponseException aresponseexception[] = iresponse.getResponseStatus().getExceptions();
        int i = aresponseexception.length;
        for(int j = 0; j < i; j++)
        {
            ResponseException responseexception = aresponseexception[j];
            ResponseExceptionLevel responseexceptionlevel1 = responseexception.getExceptionLevel();
            if(responseexceptionlevel1.equals(responseexceptionlevel))
            {
                String s1 = (new StringBuilder()).append(s).append("[").append(responseexceptionlevel1).append("] ").append(responseexception.getExceptionCode()).toString();
                String s2 = (new StringBuilder()).append(s1).append("\n         name:  ").append(responseexception.getName()).toString();
                String s3 = (new StringBuilder()).append(s2).append("\n        value:  ").append(responseexception.getValue()).toString();
                String s4 = (new StringBuilder()).append(s3).append("\n").append(responseexception.getExceptionMessage()).toString();
                s = (new StringBuilder()).append(s4).append("\n").toString();
            }
        }

        return s;
    }

    public static String getExceptionMessages(ResponseBatch responsebatch, ResponseExceptionLevel responseexceptionlevel)
    {
        String s = "";
        for(Iterator iterator = responsebatch.getEnvelopes().iterator(); iterator.hasNext();)
            s = (new StringBuilder()).append(s).append(getExceptionMessages(((ResponseEnvelope)iterator.next()).getPayload(), responseexceptionlevel)).toString();

        return s;
    }

    public static boolean handleUserFacingExceptions(IResponse iresponse)
    {
        if(ResponseExceptionChecker.wasUnauthorizedAttempt(iresponse))
        {
            System.out.println("You're either not logged in or don't have permission to do that.");
            return true;
        }
        if(ResponseExceptionChecker.wasFloodAttempt(iresponse))
        {
            System.out.println("Your submission was rejected due to rapid posting.");
            return true;
        }
        if(ResponseExceptionChecker.thresholdWasExceeded(iresponse))
        {
            System.out.println("You have exceeded the number 'large' inputs (comments, reviews, photos, etc.) allowed for a given time period.");
            return true;
        }
        if(ResponseExceptionChecker.metadataWasRejected(iresponse))
        {
            System.out.println("Your post was rejected due to metadata filtering such as your IP address.");
            return true;
        }
        List list = ResponseExceptionChecker.getDirtyWords(iresponse);
        if(!list.isEmpty())
        {
            System.out.println("Please remove the following words from your input: ");
            for(Iterator iterator = list.iterator(); iterator.hasNext(); System.out.println((String)iterator.next()));
            return true;
        } else
        {
            return false;
        }
    }

    public static void printExceptionMessages(IResponse iresponse, ResponseExceptionLevel responseexceptionlevel)
    {
        System.out.println(getExceptionMessages(iresponse, responseexceptionlevel));
    }

    public static void printExceptionMessages(ResponseBatch responsebatch, ResponseExceptionLevel responseexceptionlevel)
    {
        System.out.println(getExceptionMessages(responsebatch, responseexceptionlevel));
    }
}
