// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments;

import android.content.Context;
import android.text.Html;
import android.text.util.Linkify;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.mirror.base.main.MirrorNewsApp;
import com.pluck.sdk.Models.Moderation.AbuseCount;
import com.pluck.sdk.Models.Reactions.Comment;
import com.pluck.sdk.Models.Reactions.ItemScore;
import com.pluck.sdk.Models.Users.User;
import java.text.SimpleDateFormat;
import java.util.*;
import org.json.JSONException;

// Referenced classes of package com.mirror.base.comments:
//            CommentsActivity

public class CommentsAdapter extends BaseAdapter
{
    public static class ViewHolder
    {

        public TextView authorTextView;
        public TextView dateTextView;
        public ImageView disLikesThumb;
        public TextView globeTextView;
        public ImageView likesThumb;
        public TextView reportAbuseTextView;
        public TextView totalScore;

        public ViewHolder()
        {
        }
    }


    public CommentsAdapter(Context context1, ArrayList arraylist)
    {
        sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a", Locale.ENGLISH);
        context = context1;
        mInflater = LayoutInflater.from(context1);
        comments = arraylist;
    }

    public void addComments(ArrayList arraylist)
    {
        Comment comment;
        for(Iterator iterator = arraylist.iterator(); iterator.hasNext(); comments.add(comment))
            comment = (Comment)iterator.next();

        notifyDataSetChanged();
    }

    public int getCount()
    {
        return comments.size();
    }

    public Comment getItem(int i)
    {
        return (Comment)comments.get(i);
    }

    public volatile Object getItem(int i)
    {
        return getItem(i);
    }

    public long getItemId(int i)
    {
        return 0L;
    }

    public View getView(final int position, View view, ViewGroup viewgroup)
    {
        ViewHolder viewholder = new ViewHolder();
        View view1 = mInflater.inflate(com.mirror.base.R.layout.comments_article_item, null);
        viewholder.globeTextView = (TextView)view1.findViewById(com.mirror.base.R.id.tVCommentsArticleGlobe);
        viewholder.likesThumb = (ImageView)view1.findViewById(com.mirror.base.R.id.tVCommentsArticleLikeThumb);
        viewholder.disLikesThumb = (ImageView)view1.findViewById(com.mirror.base.R.id.tVCommentsArticleDisLikeThumb);
        viewholder.authorTextView = (TextView)view1.findViewById(com.mirror.base.R.id.tVCommentsArticleAuthor);
        viewholder.totalScore = (TextView)view1.findViewById(com.mirror.base.R.id.tVCommentsArticleScore);
        viewholder.dateTextView = (TextView)view1.findViewById(com.mirror.base.R.id.tVCommentsArticleDate);
        viewholder.reportAbuseTextView = (TextView)view1.findViewById(com.mirror.base.R.id.tVCommentsReportAbuse);
        view1.setTag(viewholder);
        Comment comment = (Comment)comments.get(position);
        viewholder.authorTextView.setText(comment.getOwner().getDisplayName());
        viewholder.globeTextView.setText(Html.fromHtml(comment.getBody()));
        if(comment.getOwner().getIsBlocked())
        {
            viewholder.globeTextView.setText(com.mirror.base.R.string.comment_user_blocked);
            viewholder.authorTextView.setText(com.mirror.base.R.string.comment_author_withheld);
            viewholder.reportAbuseTextView.setVisibility(8);
            viewholder.likesThumb.setVisibility(8);
            viewholder.disLikesThumb.setVisibility(8);
            viewholder.totalScore.setVisibility(8);
        }
        if(comment.getAbuseCounts().getCurrentUserHasReportedAbuse())
        {
            viewholder.globeTextView.setText(com.mirror.base.R.string.comments_reported_comment);
            viewholder.authorTextView.setText(com.mirror.base.R.string.comment_author_withheld);
            viewholder.reportAbuseTextView.setVisibility(8);
            viewholder.likesThumb.setVisibility(8);
            viewholder.disLikesThumb.setVisibility(8);
            viewholder.totalScore.setVisibility(8);
        }
        if(comment.getAbuseCounts().getContentExceedsAbuseThreshold())
        {
            viewholder.globeTextView.setText(com.mirror.base.R.string.comment_under_review);
            viewholder.authorTextView.setText(com.mirror.base.R.string.comment_author_withheld);
            viewholder.reportAbuseTextView.setVisibility(8);
            viewholder.likesThumb.setVisibility(8);
            viewholder.disLikesThumb.setVisibility(8);
            viewholder.totalScore.setVisibility(8);
        }
        Linkify.addLinks(viewholder.globeTextView, 3);
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(comment.getPostedAtTime());
        viewholder.dateTextView.setText(sdf.format(calendar.getTime()));
        viewholder.likesThumb.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view2)
            {
                if(!((MirrorNewsApp)context.getApplicationContext()).isConnectedToInternet())
                {
                    ((CommentsActivity)context).showDialog(context.getString(com.mirror.base.R.string.no_internet_title), context.getString(com.mirror.base.R.string.comments_reconnect));
                    return;
                }
                CommentsActivity commentsactivity = (CommentsActivity)context;
                if(commentsactivity.isLastCommentsWithUser())
                {
                    Comment comment2 = (Comment)comments.get(position);
                    if(!comment2.getScoreData().getCurrentUserHasScored())
                        try
                        {
                            commentsactivity.likeComment(comment2.getScoreData().getParentKey(), comment2.getScoreData().getTargetKey(), false);
                            comment2.getScoreData().setPositiveCount(1 + comment2.getScoreData().getPositiveCount());
                            comment2.getScoreData().setCurrentUserHasScored(true);
                            comment2.setScoreData(comment2.getScoreData());
                        }
                        catch(JSONException jsonexception1)
                        {
                            jsonexception1.printStackTrace();
                        }
                    else
                        Toast.makeText(commentsactivity, commentsactivity.getString(com.mirror.base.R.string.comment_already_voted), 0).show();
                    notifyDataSetChanged();
                    return;
                }
                Comment comment1 = (Comment)comments.get(position);
                try
                {
                    commentsactivity.likeComment(comment1.getScoreData().getParentKey(), comment1.getScoreData().getTargetKey(), true);
                    comment1.getScoreData().setPositiveCount(1 + comment1.getScoreData().getPositiveCount());
                    comment1.getScoreData().setCurrentUserHasScored(true);
                    comment1.getScoreData().setCurrentUserScore(1L);
                    comment1.setScoreData(comment1.getScoreData());
                    return;
                }
                catch(JSONException jsonexception)
                {
                    jsonexception.printStackTrace();
                }
            }

            final CommentsAdapter this$0;
            final int val$position;

            
            {
                this$0 = CommentsAdapter.this;
                position = i;
                super();
            }
        });
        int i = comment.getScoreData().getPositiveCount();
        int j = comment.getScoreData().getNegativeCount();
        viewholder.totalScore.setText(Integer.toString(i - j));
        viewholder.disLikesThumb.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view2)
            {
                if(!((MirrorNewsApp)context.getApplicationContext()).isConnectedToInternet())
                {
                    ((CommentsActivity)context).showDialog(context.getString(com.mirror.base.R.string.no_internet_title), context.getString(com.mirror.base.R.string.comments_reconnect));
                    return;
                }
                CommentsActivity commentsactivity = (CommentsActivity)context;
                if(commentsactivity.isLastCommentsWithUser())
                {
                    Comment comment2 = (Comment)comments.get(position);
                    if(!comment2.getScoreData().getCurrentUserHasScored())
                        try
                        {
                            commentsactivity.disLikeComment(comment2.getScoreData().getParentKey(), comment2.getScoreData().getTargetKey(), false);
                            Log.e("Sending dislike without refresh", (new StringBuilder()).append("").append(comment2.getScoreData().getNegativeCount()).toString());
                            comment2.getScoreData().setNegativeCount(1 + comment2.getScoreData().getNegativeCount());
                            comment2.getScoreData().setCurrentUserHasScored(true);
                            comment2.setScoreData(comment2.getScoreData());
                        }
                        catch(JSONException jsonexception1)
                        {
                            jsonexception1.printStackTrace();
                        }
                    else
                        Toast.makeText(commentsactivity, commentsactivity.getString(com.mirror.base.R.string.comment_already_voted), 0).show();
                    notifyDataSetChanged();
                    return;
                }
                Comment comment1 = (Comment)comments.get(position);
                try
                {
                    commentsactivity.disLikeComment(comment1.getScoreData().getParentKey(), comment1.getScoreData().getTargetKey(), true);
                    comment1.getScoreData().setNegativeCount(1 + comment1.getScoreData().getNegativeCount());
                    comment1.getScoreData().setCurrentUserHasScored(true);
                    comment1.setScoreData(comment1.getScoreData());
                    return;
                }
                catch(JSONException jsonexception)
                {
                    jsonexception.printStackTrace();
                }
            }

            final CommentsAdapter this$0;
            final int val$position;

            
            {
                this$0 = CommentsAdapter.this;
                position = i;
                super();
            }
        });
        viewholder.reportAbuseTextView.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view2)
            {
                if(!((MirrorNewsApp)context.getApplicationContext()).isConnectedToInternet())
                {
                    ((CommentsActivity)context).showDialog(context.getString(com.mirror.base.R.string.no_internet_title), context.getString(com.mirror.base.R.string.comments_reconnect));
                    return;
                }
                CommentsActivity commentsactivity = (CommentsActivity)context;
                if(commentsactivity.isLastCommentsWithUser())
                {
                    Comment comment2 = (Comment)comments.get(position);
                    if(!comment2.getAbuseCounts().getCurrentUserHasReportedAbuse())
                        try
                        {
                            commentsactivity.reportComment(comment2.getScoreData().getTargetKey(), position, false);
                        }
                        catch(JSONException jsonexception1)
                        {
                            jsonexception1.printStackTrace();
                        }
                    else
                        Toast.makeText(commentsactivity, commentsactivity.getString(com.mirror.base.R.string.comments_already_reported), 0).show();
                    notifyDataSetChanged();
                    return;
                }
                Comment comment1 = (Comment)comments.get(position);
                try
                {
                    commentsactivity.reportComment(comment1.getScoreData().getTargetKey(), position, true);
                    return;
                }
                catch(JSONException jsonexception)
                {
                    jsonexception.printStackTrace();
                }
            }

            final CommentsAdapter this$0;
            final int val$position;

            
            {
                this$0 = CommentsAdapter.this;
                position = i;
                super();
            }
        });
        return view1;
    }

    public void setComments(ArrayList arraylist)
    {
        comments = arraylist;
        notifyDataSetChanged();
    }

    public void setReportedAbused(int i)
    {
        ((Comment)comments.get(i)).getAbuseCounts().setCurrentUserHasReportedAbuse(true);
        notifyDataSetChanged();
    }

    private ArrayList comments;
    private Context context;
    private LayoutInflater mInflater;
    private SimpleDateFormat sdf;


}
