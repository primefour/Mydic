// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.comments;

import android.view.*;
import android.widget.BaseAdapter;
import android.widget.TextView;
import org.json.*;

// Referenced classes of package com.mirror.base.comments:
//            CommentsActivity

class AdapterDropDownListComments extends BaseAdapter
{
    public static class ViewHolder
    {

        public TextView title;

        public ViewHolder()
        {
        }
    }


    public AdapterDropDownListComments(CommentsActivity commentsactivity, JSONArray jsonarray, boolean flag, int i)
    {
        selectedPos = -1;
        context = commentsactivity;
        isMainMenu = flag;
        mInflater = (LayoutInflater)commentsactivity.getSystemService("layout_inflater");
        items = jsonarray;
        unselectedBackgroundColor = i;
    }

    public int getCount()
    {
        return items.length();
    }

    public volatile Object getItem(int i)
    {
        return getItem(i);
    }

    public JSONObject getItem(int i)
    {
        JSONObject jsonobject;
        try
        {
            jsonobject = items.getJSONObject(i);
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
            return null;
        }
        return jsonobject;
    }

    public long getItemId(int i)
    {
        return 0L;
    }

    public int getSelectedPos()
    {
        return selectedPos;
    }

    public View getView(final int position, View view, ViewGroup viewgroup)
    {
        ViewHolder viewholder;
        if(view == null)
        {
            viewholder = new ViewHolder();
            view = mInflater.inflate(com.mirror.base.R.layout.dropdown_item, null);
            viewholder.title = (TextView)view.findViewById(com.mirror.base.R.id.stvDropdownMenuItemText);
            view.setTag(viewholder);
        } else
        {
            viewholder = (ViewHolder)view.getTag();
        }
        if(isMainMenu && selectedPos == -1)
            selectedPos = 0;
        if(position != selectedPos || selectedPos == -1) goto _L2; else goto _L1
_L1:
        viewholder.title.setBackgroundResource(com.mirror.base.R.drawable.dropdown_selected);
_L3:
        viewholder.title.setText(getItem(position).getString("name"));
        viewholder.title.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view1)
            {
                selectedPos = position;
                if(isMainMenu)
                {
                    if(!getItem(position).has("NO_DROPDOWN"))
                        if(getItem(position).has("sections"))
                            try
                            {
                                context.showDropDownSubMenu(getItem(position).getJSONArray("sections"));
                                context.isDropdownSubMenuOn = true;
                                notifyDataSetChanged();
                            }
                            catch(JSONException jsonexception3)
                            {
                                jsonexception3.printStackTrace();
                            }
                        else
                            try
                            {
                                context.changeandUpdateOpinionsBaseUrl(getItem(position).getString("url"), getItem(position).getString("name"));
                                context.hideDropDownMenus();
                            }
                            catch(JSONException jsonexception2)
                            {
                                jsonexception2.printStackTrace();
                            }
                } else
                {
                    try
                    {
                        context.changeandUpdateOpinionsBaseUrl(getItem(position).getString("url"), getItem(position).getString("name"));
                        context.hideDropDownMenus();
                    }
                    catch(JSONException jsonexception1)
                    {
                        jsonexception1.printStackTrace();
                    }
                }
                notifyDataSetChanged();
            }

            final AdapterDropDownListComments this$0;
            final int val$position;

            
            {
                this$0 = AdapterDropDownListComments.this;
                position = i;
                super();
            }
        });
        return view;
_L2:
        JSONException jsonexception;
label0:
        {
            if(isMainMenu && context.isDropdownSubMenuOn)
                break label0;
            viewholder.title.setBackgroundResource(com.mirror.base.R.color.MatchCentreBackgroundTittle);
        }
          goto _L3
        try
        {
            viewholder.title.setBackgroundResource(unselectedBackgroundColor);
        }
        // Misplaced declaration of an exception variable
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
            return view;
        }
          goto _L3
    }

    public void updateData(JSONArray jsonarray)
    {
        items = jsonarray;
    }

    private CommentsActivity context;
    private boolean isMainMenu;
    private JSONArray items;
    private LayoutInflater mInflater;
    private int selectedPos;
    private int unselectedBackgroundColor;


/*
    static int access$002(AdapterDropDownListComments adapterdropdownlistcomments, int i)
    {
        adapterdropdownlistcomments.selectedPos = i;
        return i;
    }

*/


}
