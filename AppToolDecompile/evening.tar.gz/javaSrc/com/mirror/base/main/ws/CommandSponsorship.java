// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.ws;

import android.content.Context;
import com.mirror.base.parsers.ParserSplash;
import com.mirror.base.webservices.*;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class CommandSponsorship extends WSCommand
{

    public CommandSponsorship(Context context)
    {
        super(context);
    }

    protected void doParse(RestClient restclient)
    {
        String s;
        JSONObject jsonobject;
        s = restclient.getResponse();
        jsonobject = new JSONObject();
        jsonobject = ParserSplash.xmlToJson(s);
        cfm.updateCache(getURL().hashCode(), s, restclient.getH());
_L2:
        resultMap.put(TAG, jsonobject);
        return;
        Exception exception;
        exception;
        String s1;
        s1 = cfm.getFromCache(getURL().hashCode());
        if(s1 == null || s1.equals(""))
            continue; /* Loop/switch isn't completed */
        JSONObject jsonobject1 = ParserSplash.xmlToJson(s1);
        jsonobject = jsonobject1;
        continue; /* Loop/switch isn't completed */
        JSONException jsonexception;
        jsonexception;
        jsonexception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public void setUrl(JSONObject jsonobject)
        throws JSONException
    {
        Object aobj[] = new Object[1];
        aobj[0] = context.getString(com.mirror.base.R.string.url_sponsorship);
        url = String.format("%s", aobj);
    }
}
