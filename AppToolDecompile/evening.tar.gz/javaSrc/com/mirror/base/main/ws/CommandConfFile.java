// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.ws;

import android.content.Context;
import com.mirror.base.utils.ReadJsonFileFromResource;
import com.mirror.base.webservices.*;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class CommandConfFile extends WSCommand
{

    public CommandConfFile(Context context)
    {
        super(context);
    }

    protected void doParse(RestClient restclient)
    {
        String s;
        JSONObject jsonobject;
        s = restclient.getResponse();
        jsonobject = new JSONObject();
        JSONObject jsonobject1 = new JSONObject(s);
        cfm.updateCache(getURL().hashCode(), s, restclient.getH());
        JSONObject jsonobject2 = jsonobject1;
_L2:
        resultMap.put(TAG, jsonobject2);
        return;
        Exception exception1;
        exception1;
        jsonobject1 = jsonobject;
_L3:
        String s1 = cfm.getFromCache(getURL().hashCode());
        if(s1 != null && s1 != "")
            try
            {
                jsonobject2 = new JSONObject(s1);
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
                jsonobject2 = jsonobject1;
            }
        else
            jsonobject2 = ReadJsonFileFromResource.getJsonString(context, com.mirror.base.R.raw.base_config_file);
        if(true) goto _L2; else goto _L1
_L1:
        Exception exception;
        exception;
          goto _L3
    }

    public void setUrl(JSONObject jsonobject)
        throws JSONException
    {
        Object aobj[] = new Object[1];
        aobj[0] = context.getString(com.mirror.base.R.string.url_config_file);
        url = String.format("%s", aobj);
    }
}
