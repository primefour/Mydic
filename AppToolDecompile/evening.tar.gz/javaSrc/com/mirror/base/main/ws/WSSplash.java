// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.ws;

import android.content.Context;
import com.mirror.base.webservices.RestClient;
import org.json.JSONObject;

// Referenced classes of package com.mirror.base.main.ws:
//            CommandConfFile, CommandConfFileMatchCentre, CommandSponsorship

public class WSSplash
{

    public WSSplash(Context context1)
    {
        context = context1;
    }

    public JSONObject getConfFile()
        throws Exception
    {
        CommandConfFile commandconffile = new CommandConfFile(context);
        commandconffile.setUrl(new JSONObject());
        commandconffile.setCacheEnabled(true);
        try
        {
            commandconffile.execute();
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            commandconffile.doParse(new RestClient(""));
        }
        return (JSONObject)commandconffile.getResult();
    }

    public JSONObject getConfFileMatchCentre()
        throws Exception
    {
        CommandConfFileMatchCentre commandconffilematchcentre = new CommandConfFileMatchCentre(context);
        commandconffilematchcentre.setUrl(new JSONObject());
        commandconffilematchcentre.setCacheEnabled(true);
        commandconffilematchcentre.execute();
        return new JSONObject((String)commandconffilematchcentre.getResult());
    }

    public JSONObject getSponsorship()
        throws Exception
    {
        CommandSponsorship commandsponsorship = new CommandSponsorship(context);
        commandsponsorship.setUrl(new JSONObject());
        commandsponsorship.setCacheEnabled(false);
        commandsponsorship.execute();
        return (JSONObject)commandsponsorship.getResult();
    }

    private Context context;
}
