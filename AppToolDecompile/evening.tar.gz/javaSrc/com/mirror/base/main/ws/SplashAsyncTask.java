// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.ws;

import android.support.v4.app.KogiActivity;
import android.support.v4.app.KogiAsyncTask;
import org.json.JSONObject;

public class SplashAsyncTask extends KogiAsyncTask
{

    public SplashAsyncTask(Enum enum, KogiActivity kogiactivity, String s, String s1)
    {
        super(enum, kogiactivity, s, s1);
    }

    protected volatile Object doInBackground(Object aobj[])
    {
        return doInBackground((JSONObject[])aobj);
    }

    protected transient JSONObject doInBackground(JSONObject ajsonobject[])
    {
        return null;
    }
}
