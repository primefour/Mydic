// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.ws;

import android.content.Context;
import org.json.JSONObject;

// Referenced classes of package com.mirror.base.main.ws:
//            CommandConfFile, CommandSponsorship

public class WSMain
{

    public WSMain(Context context1)
    {
        context = context1;
    }

    public JSONObject getConfFile()
        throws Exception
    {
        CommandConfFile commandconffile = new CommandConfFile(context);
        commandconffile.setUrl(new JSONObject());
        commandconffile.setCacheEnabled(true);
        commandconffile.execute();
        return new JSONObject((String)commandconffile.getResult());
    }

    public JSONObject getSponsorship()
        throws Exception
    {
        CommandSponsorship commandsponsorship = new CommandSponsorship(context);
        commandsponsorship.setUrl(new JSONObject());
        commandsponsorship.execute();
        return (JSONObject)commandsponsorship.getResult();
    }

    private Context context;
}
