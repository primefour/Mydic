// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.ws;

import android.content.Context;
import com.mirror.base.webservices.*;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public class CommandConfFileMatchCentre extends WSCommand
{

    public CommandConfFileMatchCentre(Context context)
    {
        super(context);
    }

    protected void doParse(RestClient restclient)
    {
        String s = restclient.getResponse();
        cfm.updateCache(getURL().hashCode(), s, restclient.getH());
        resultMap.put(TAG, s);
    }

    public void setUrl(JSONObject jsonobject)
        throws JSONException
    {
        Object aobj[] = new Object[1];
        aobj[0] = context.getString(com.mirror.base.R.string.url_config_file_match_centre);
        url = String.format("%s", aobj);
    }
}
