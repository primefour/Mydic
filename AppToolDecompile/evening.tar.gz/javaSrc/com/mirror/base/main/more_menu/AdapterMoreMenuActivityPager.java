// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.content.Context;
import android.support.v4.app.*;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.base.swipeytabs.SwipeyTabs;
import com.base.swipeytabs.SwipeyTabsAdapter;
import org.json.JSONArray;

// Referenced classes of package com.mirror.base.main.more_menu:
//            MoreMenuNewsFragment, MoreMenuActivity

public class AdapterMoreMenuActivityPager extends FragmentPagerAdapter
    implements SwipeyTabsAdapter
{

    public AdapterMoreMenuActivityPager(Context context, FragmentManager fragmentmanager, JSONArray jsonarray, String s, int i, String s1)
    {
        super(fragmentmanager);
        mContext = context;
        data = jsonarray;
        title = s;
        sectionPosition = i;
        father = s1;
    }

    public int getCount()
    {
        return 1;
    }

    public Fragment getItem(int i)
    {
        switch(i)
        {
        default:
            return null;

        case 0: // '\0'
            break;
        }
        if(moreMenuFragment == null)
            moreMenuFragment = new MoreMenuNewsFragment(data, title, ((MoreMenuActivity)mContext).getHideSubMenu(), sectionPosition, father);
        return moreMenuFragment;
    }

    public TextView getTab(final int position, SwipeyTabs swipeytabs)
    {
        TextView textview = (TextView)LayoutInflater.from(mContext).inflate(com.mirror.base.R.layout.swipey_tab_indicator, swipeytabs, false);
        textview.setText(title);
        textview.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                ((KogiActivity)mContext).getmViewPager().setCurrentItem(position);
            }

            final AdapterMoreMenuActivityPager this$0;
            final int val$position;

            
            {
                this$0 = AdapterMoreMenuActivityPager.this;
                position = i;
                super();
            }
        });
        return textview;
    }

    private JSONArray data;
    private String father;
    private final Context mContext;
    MoreMenuNewsFragment moreMenuFragment;
    private int sectionPosition;
    private String title;

}
