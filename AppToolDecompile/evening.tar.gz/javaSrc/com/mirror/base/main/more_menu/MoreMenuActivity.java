// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.content.Intent;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.KogiActivity;
import android.support.v4.view.ViewPager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import com.facebook.AppEventsLogger;
import com.flurry.android.FlurryAgent;
import com.kogi.bitmapfun.*;
import com.kogi.utils.MenuChangeBackground;
import com.mirror.base.ad.AdBanner;
import com.mirror.base.constants.Constants;
import com.mirror.base.main.news_section_page.NewsSectionPageFragment;
import com.mirror.base.main.sports_page.SportsPageFragment;
import com.mirror.base.main.three_am_page.ThreeAMPageFragment;
import com.mirror.base.settings.SettingsActivity;
import com.mirror.base.tracking.TrackingHelper;
import java.util.*;
import org.json.*;

// Referenced classes of package com.mirror.base.main.more_menu:
//            AdapterMoreMenuActivityPager, MoreMenuNewsFragment, MoreMenuFragment

public class MoreMenuActivity extends KogiActivity
{

    public MoreMenuActivity()
    {
        jsaSponsorship = new JSONArray();
        posSponsorship = 0;
        updateMyClub = true;
        hideSubMenu = false;
    }

    private void updateImageSponsorship()
    {
        boolean flag;
        if(jsaSponsorship.length() == 0)
            break MISSING_BLOCK_LABEL_120;
        flag = false;
        if(jsaSponsorship.getString(posSponsorship).equals("")) goto _L2; else goto _L1
_L1:
        mImageWorker.loadImage(jsaSponsorship.getString(posSponsorship), imageViewMainSponsorship);
_L3:
        posSponsorship = 1 + posSponsorship;
        if(posSponsorship == jsaSponsorship.length())
            posSponsorship = 0;
        Throwable throwable;
        if(flag)
        {
            textViewTopBannerBackTitle.setVisibility(0);
            return;
        } else
        {
            textViewTopBannerBackTitle.setVisibility(8);
            return;
        }
_L2:
        flag = true;
          goto _L3
        throwable;
        throwable.printStackTrace();
        flag = true;
          goto _L3
        textViewTopBannerBackTitle.setVisibility(0);
        return;
    }

    public void finish()
    {
        if(mAdBanner != null)
        {
            mAdBanner.stop();
            mAdBanner.hideAd();
        }
        super.finish();
    }

    public String getCurrentSection()
    {
        return title;
    }

    public String getHeaderTitle()
    {
        return adapter.moreMenuFragment.getHeaderTitle();
    }

    public boolean getHideSubMenu()
    {
        return hideSubMenu;
    }

    public String getTittle()
    {
        return title;
    }

    public void hideDropDownMenus()
    {
        int i = 0;
_L2:
        if(i >= adapter.getCount())
            break MISSING_BLOCK_LABEL_208;
        if(adapter.getItem(i) == null)
            break MISSING_BLOCK_LABEL_209;
        if(adapter.getItem(i) instanceof NewsSectionPageFragment)
        {
            ((NewsSectionPageFragment)adapter.getItem(i)).isDropDownMenuOn = false;
            ((NewsSectionPageFragment)adapter.getItem(i)).hideDropDownMenus();
            break MISSING_BLOCK_LABEL_209;
        }
        if(adapter.getItem(i) instanceof SportsPageFragment)
        {
            ((SportsPageFragment)adapter.getItem(i)).isDropDownMenuOn = false;
            ((SportsPageFragment)adapter.getItem(i)).hideDropDownMenus();
            break MISSING_BLOCK_LABEL_209;
        }
        if(adapter.getItem(i) instanceof ThreeAMPageFragment)
        {
            ((ThreeAMPageFragment)adapter.getItem(i)).isDropDownMenuOn = false;
            ((ThreeAMPageFragment)adapter.getItem(i)).hideDropDownMenus();
            break MISSING_BLOCK_LABEL_209;
        }
        try
        {
            if(adapter.getItem(i) instanceof MoreMenuNewsFragment)
            {
                ((MoreMenuNewsFragment)adapter.getItem(i)).isDropDownMenuOn = false;
                ((MoreMenuNewsFragment)adapter.getItem(i)).hideDropDownMenus();
            }
        }
        catch(NullPointerException nullpointerexception) { }
        break MISSING_BLOCK_LABEL_209;
        return;
        i++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    protected void initData()
    {
    }

    protected void initListeners()
    {
        JSONObject jsonobject = getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_SPORSONSHIP);
        if(jsonobject.has((new StringBuilder()).append(title.toLowerCase().replace(" ", "")).append("url").toString()))
            try
            {
                final String url = jsonobject.getString((new StringBuilder()).append(title.toLowerCase().replace(" ", "")).append("url").toString());
                if(!url.equals(""))
                    imageViewMainSponsorship.setOnClickListener(new android.view.View.OnClickListener() {

                        public void onClick(View view)
                        {
                            try
                            {
                                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
                                startActivity(intent);
                                return;
                            }
                            catch(Exception exception)
                            {
                                return;
                            }
                        }

                        final MoreMenuActivity this$0;
                        final String val$url;

            
            {
                this$0 = MoreMenuActivity.this;
                url = s;
                super();
            }
                    });
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
        relativeTopBannerBack.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                view.setBackgroundColor(getResources().getColor(com.mirror.base.R.color.nav_bar_article_backgroud));
                finish();
            }

            final MoreMenuActivity this$0;

            
            {
                this$0 = MoreMenuActivity.this;
                super();
            }
        });
        relativeTopBannerBack.setOnTouchListener(new android.view.View.OnTouchListener() {

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if(motionevent.getAction() == 3 || motionevent.getAction() == 1)
                    view.setBackgroundColor(getResources().getColor(com.mirror.base.R.color.nav_bar_article_backgroud));
                else
                    view.setBackgroundColor(getResources().getColor(com.mirror.base.R.color.settings_divider));
                return false;
            }

            final MoreMenuActivity this$0;

            
            {
                this$0 = MoreMenuActivity.this;
                super();
            }
        });
    }

    protected void initUI()
    {
    }

    protected void initVars()
    {
        if(!getIntent().hasExtra("news_data"))
            break MISSING_BLOCK_LABEL_308;
        jsaNews = new JSONArray(getIntent().getExtras().getString("news_data"));
_L1:
        title = getIntent().getExtras().getString("newsDetailsTitle");
        getIntent().getExtras().getString("subSubSection");
        currentSection = getIntent().getExtras().getInt("sectionPosition", 0);
        father = getIntent().getExtras().getString("fatherActivity");
        if(father == null)
            father = "MoreMenu";
        JSONException jsonexception;
        com.kogi.bitmapfun.ImageCache.ImageCacheParams imagecacheparams;
        try
        {
            hideSubMenu = getIntent().getExtras().getBoolean("hideSubMenu", false);
        }
        catch(Exception exception) { }
        imagecacheparams = new com.kogi.bitmapfun.ImageCache.ImageCacheParams(getResources().getString(com.mirror.base.R.string.images_dir));
        imagecacheparams.memCacheSize = (Constants.SCREEN_WIDTH * Constants.SCREEN_HEIGHT * Utils.getMemoryClass(this)) / 8;
        imagecacheparams.compressFormat = android.graphics.Bitmap.CompressFormat.PNG;
        mImageWorker = new ImageFetcher(this, 300);
        mImageWorker.setImageFadeIn(false);
        if(Constants.SCREEN_WIDTH == 0 || Constants.SCREEN_HEIGHT == 0)
        {
            Display display = getWindowManager().getDefaultDisplay();
            Constants.SCREEN_WIDTH = display.getWidth();
            Constants.SCREEN_HEIGHT = display.getHeight();
        }
        mImageWorker.setImageCache(ImageCache.findOrCreateCache(this, imagecacheparams));
        try
        {
            JSONObject jsonobject = getJSONObjectParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JO_SPORSONSHIP);
            if(jsonobject.has(title.toLowerCase().replace(" ", "")))
                jsaSponsorship = jsonobject.getJSONArray(title.toLowerCase().replace(" ", ""));
            return;
        }
        catch(JSONException jsonexception1)
        {
            jsonexception1.printStackTrace();
        }
        break MISSING_BLOCK_LABEL_337;
        try
        {
            jsaNews = getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_NEWS_DATA);
        }
        // Misplaced declaration of an exception variable
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
          goto _L1
    }

    protected void initViews(Bundle bundle)
    {
        mViewPager = (ViewPager)findViewById(com.mirror.base.R.id.viewpager);
        adapter = new AdapterMoreMenuActivityPager(this, getSupportFragmentManager(), jsaNews, title, currentSection, father);
        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(0);
        textViewTopBannerBackTitle = (TextView)findViewById(com.mirror.base.R.id.textViewTopBannerBackTitle);
        textViewTopBannerBackTitle.setText(title.toUpperCase());
        relativeTopBannerBack = (RelativeLayout)findViewById(com.mirror.base.R.id.relativeTopBannerBack);
        imageViewMainSponsorship = (ImageView)findViewById(com.mirror.base.R.id.imageViewMainSponsorship);
        showAD("");
    }

    protected void onCreate(Bundle bundle)
    {
        MenuChangeBackground.addOptionsMenuHackerInflaterFactory(getResources().getColor(com.mirror.base.R.color.settings_background), -1, this);
        super.onCreate(bundle);
        setContentView(com.mirror.base.R.layout.more_menu_activity);
        initVars();
    }

    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(com.mirror.base.R.menu.settings_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuitem)
    {
        if(menuitem.getItemId() == com.mirror.base.R.id.menuSettings)
        {
            startActivity(new Intent(this, com/mirror/base/settings/SettingsActivity));
            return true;
        } else
        {
            return super.onOptionsItemSelected(menuitem);
        }
    }

    protected void onPause()
    {
        if(timerSponsorship != null)
            timerSponsorship.cancel();
        if(timerPolling != null)
            timerPolling.cancel();
        super.onPause();
        TrackingHelper.stopActivity();
    }

    protected void onResume()
    {
        super.onResume();
        TrackingHelper.startActivity(this);
        AppEventsLogger.activateApp(this, getString(com.mirror.base.R.string.facebook_app_id));
        timerSponsorship = new Timer();
        timerSponsorship.schedule(new TimerTask() {

            public void run()
            {
                runOnUiThread(new Runnable() {

                    public void run()
                    {
                        updateImageSponsorship();
                    }

                    final _cls4 this$1;

            
            {
                this$1 = _cls4.this;
                super();
            }
                });
            }

            final MoreMenuActivity this$0;

            
            {
                this$0 = MoreMenuActivity.this;
                super();
            }
        }, 0L, getResources().getInteger(com.mirror.base.R.integer.time_update_sponsorship));
        if(updateMyClub)
        {
            timerPolling = new Timer();
            timerPolling.schedule(new TimerTask() {

                public void run()
                {
                    runOnUiThread(new Runnable() {

                        public void run()
                        {
                            if(!updateMyClub);
                        }

                        final _cls5 this$1;

            
            {
                this$1 = _cls5.this;
                super();
            }
                    });
                }

                final MoreMenuActivity this$0;

            
            {
                this$0 = MoreMenuActivity.this;
                super();
            }
            }, getResources().getInteger(com.mirror.base.R.integer.polling_time_live_games), getResources().getInteger(com.mirror.base.R.integer.polling_time_live_games));
        }
    }

    protected void onStart()
    {
        super.onStart();
        if(getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            FlurryAgent.onStartSession(this, getResources().getString(com.mirror.base.R.string.flurry_key));
    }

    protected void onStop()
    {
        super.onStop();
        if(getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            FlurryAgent.onEndSession(this);
    }

    public void showAD(String s)
    {
        String s1 = "";
        String s2 = "";
        String s3 = getString(com.mirror.base.R.string.ADMOB_EXTRA_TEMPL_INDEX);
        String s4 = getString(com.mirror.base.R.string.RUBICON_AD_PUBID);
        String s5 = getString(com.mirror.base.R.string.RUBICON_AD_SERVER);
        String s6 = "";
        if(father.equalsIgnoreCase(com/mirror/base/main/more_menu/MoreMenuFragment.getSimpleName()))
        {
            if(title.toUpperCase().contains("BUSINESS"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_BUSINESS_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_BUSINESS_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_BUSINESS_APPID);
            } else
            if(title.toUpperCase().contains("SPORT"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_SPORT_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_SPORT_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_SPORT_APPID);
            } else
            if(title.toUpperCase().contains("TV"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_TV_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_TV_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_TV_APPID);
            } else
            if(title.toUpperCase().contains("LIFE STYLE") || title.contains("LIFESTYLE"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_LIFE_STYLE_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_LIFE_STYLE_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_LIFESTYLE_APPID);
            } else
            if(title.toUpperCase().contains("MONEY"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_MONEY_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_MONEY_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_MONEY_APPID);
            } else
            if(title.toUpperCase().contains("OPINION"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_OPINION_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_OPINION_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_OPINION_APPID);
            } else
            if(title.toUpperCase().contains("TRAVEL"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_TRAVEL_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_TRAVEL_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_TRAVEL_APPID);
            } else
            if(title.toUpperCase().contains("CRIME"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_MORE_CRIME_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_MORE_CTIME_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_CRIME_APPID);
            } else
            if(title.toUpperCase().contains("TOP STORIES"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_MORE_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_MORE_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_TOP_STORIES_APPID);
            } else
            if(title.toUpperCase().contains("TOP FEATURES"))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_MORE_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_MORE_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_TOP_FEATURES_APPID);
            }
            if(s1.equals(""))
            {
                s1 = getString(com.mirror.base.R.string.ADMOB_MORE_PSECT);
                if(TextUtils.isEmpty(s))
                    s2 = getString(com.mirror.base.R.string.ADMOB_MORE_SECT);
                else
                    s2 = AdBanner.getSect(s);
                s6 = getString(com.mirror.base.R.string.RUBICON_AD_MORE_APPID);
            }
        }
        if(mAdBanner != null)
            mAdBanner = null;
        mAdBanner = new AdBanner(com.mirror.base.R.id.lLMoreBanner, this, com.mirror.base.main.MirrorNewsApp.PARAMETERS.BOOL_IS_AD_SHOWING_SECOND);
        mAdBanner.showAD(s1, s2, s3, s5, s4, s6);
    }

    public void trackEvent(String s, String s1)
    {
        Hashtable hashtable = new Hashtable();
        Hashtable hashtable1 = new Hashtable();
        String s2 = getString(com.mirror.base.R.string.omniture_products);
        String s3 = getString(com.mirror.base.R.string.omniture_appstate_section, new Object[] {
            s, s1
        }).trim();
        String s4 = getString(com.mirror.base.R.string.omniture_app_section_events);
        String s5 = String.format(getString(com.mirror.base.R.string.omniture_hire1_section), new Object[] {
            s, s1, s3
        }).trim();
        hashtable.put(Integer.valueOf(1), s);
        hashtable.put(Integer.valueOf(2), s1);
        hashtable.put(Integer.valueOf(5), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_owner_site)));
        hashtable.put(Integer.valueOf(15), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_not_an_article)));
        hashtable.put(Integer.valueOf(16), getString(com.mirror.base.R.string.omniture_prop16));
        hashtable.put(Integer.valueOf(19), "");
        hashtable.put(Integer.valueOf(21), getString(com.mirror.base.R.string.omniture_prop21));
        hashtable.put(Integer.valueOf(27), "");
        hashtable.put(Integer.valueOf(30), getString(com.mirror.base.R.string.omniture_prop30_section));
        hashtable.put(Integer.valueOf(31), "");
        hashtable.put(Integer.valueOf(32), "");
        hashtable.put(Integer.valueOf(35), "");
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        display.getMetrics(displaymetrics);
        hashtable.put(Integer.valueOf(36), TrackingHelper.SCStrip2((new StringBuilder()).append(displaymetrics.widthPixels).append("x").append(displaymetrics.heightPixels).toString()));
        hashtable.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
        hashtable.put(Integer.valueOf(41), hashtable.get(Integer.valueOf(2)));
        hashtable.put(Integer.valueOf(42), TrackingHelper.SCStrip2(TrackingHelper.checkInternetType(this)));
        hashtable.put(Integer.valueOf(49), TrackingHelper.SCStrip2(TrackingHelper.getVisitorID()));
        hashtable.put(Integer.valueOf(50), "");
        String s6 = TrackingHelper.CalculateDate(this);
        hashtable.put(Integer.valueOf(51), TrackingHelper.SCStrip2(s6));
        hashtable.put(Integer.valueOf(52), getString(com.mirror.base.R.string.omniture_prop52));
        hashtable.put(Integer.valueOf(53), getString(com.mirror.base.R.string.omniture_prop53));
        hashtable.put(Integer.valueOf(64), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_mobile)));
        hashtable.put(Integer.valueOf(72), (new StringBuilder()).append(getString(com.mirror.base.R.string.omniture_prop72_prefix)).append(s).toString());
        hashtable.put(Integer.valueOf(75), TrackingHelper.SCStrip2((new StringBuilder()).append("mobile_").append(Build.MANUFACTURER).append("_").append(Build.MODEL).append(getString(com.mirror.base.R.string.omniture_prop75_sufix)).toString()));
        hashtable1.put(Integer.valueOf(9), hashtable.get(Integer.valueOf(16)));
        hashtable1.put(Integer.valueOf(10), hashtable.get(Integer.valueOf(21)));
        hashtable1.put(Integer.valueOf(11), hashtable.get(Integer.valueOf(5)));
        hashtable1.put(Integer.valueOf(12), hashtable.get(Integer.valueOf(35)));
        hashtable1.put(Integer.valueOf(14), hashtable.get(Integer.valueOf(15)));
        hashtable1.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
        hashtable1.put(Integer.valueOf(42), "");
        hashtable1.put(Integer.valueOf(43), hashtable.get(Integer.valueOf(30)));
        hashtable1.put(Integer.valueOf(45), hashtable.get(Integer.valueOf(19)));
        hashtable1.put(Integer.valueOf(47), hashtable.get(Integer.valueOf(51)));
        hashtable1.put(Integer.valueOf(48), hashtable.get(Integer.valueOf(52)));
        hashtable1.put(Integer.valueOf(49), hashtable.get(Integer.valueOf(53)));
        hashtable1.put(Integer.valueOf(50), String.format(getString(com.mirror.base.R.string.omniture_evar50_section), new Object[] {
            s, ""
        }).trim());
        hashtable1.put(Integer.valueOf(51), hashtable.get(Integer.valueOf(49)));
        TrackingHelper.logEvent(hashtable, hashtable1, s4, s2, s3, s5, false);
    }

    protected void updateUI()
    {
    }

    AdapterMoreMenuActivityPager adapter;
    private int currentSection;
    private String father;
    private boolean hideSubMenu;
    ImageView imageViewMainSponsorship;
    private JSONArray jsaNews;
    private JSONArray jsaSponsorship;
    AdBanner mAdBanner;
    private ImageWorker mImageWorker;
    private int posSponsorship;
    private RelativeLayout relativeTopBannerBack;
    private TextView textViewTopBannerBackTitle;
    private Timer timerPolling;
    private Timer timerSponsorship;
    private String title;
    private boolean updateMyClub;


}
