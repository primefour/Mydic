// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.content.Context;
import android.content.res.Resources;
import android.support.v4.app.*;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.base.swipeytabs.SwipeyTabs;
import com.base.swipeytabs.SwipeyTabsAdapter;
import com.mirror.base.main.my_mirror_page.MyMirrorPageFragment;
import com.mirror.base.main.news_section_page.NewsSectionPageFragment;
import com.mirror.base.main.sports_page.SportsPageFragment;
import com.mirror.base.main.three_am_page.ThreeAMPageFragment;

// Referenced classes of package com.mirror.base.main.more_menu:
//            MoreMenuFragment

public class MoreActivityPagerAdapter extends FragmentPagerAdapter
    implements SwipeyTabsAdapter
{

    public MoreActivityPagerAdapter(Context context, FragmentManager fragmentmanager)
    {
        super(fragmentmanager);
        mContext = context;
        SLIDE_MAIN_TITLES = context.getResources().getStringArray(com.mirror.base.R.array.slide_main_titles);
    }

    public int getCount()
    {
        return SLIDE_MAIN_TITLES.length;
    }

    public Fragment getItem(int i)
    {
        switch(i)
        {
        default:
            return null;

        case 0: // '\0'
            if(myMirrorPageFragment == null)
                myMirrorPageFragment = new MyMirrorPageFragment();
            return myMirrorPageFragment;

        case 1: // '\001'
            if(newsSectionPageFragment == null)
                newsSectionPageFragment = new NewsSectionPageFragment();
            return newsSectionPageFragment;

        case 2: // '\002'
            if(sportsPageFragment == null)
                sportsPageFragment = new SportsPageFragment();
            return sportsPageFragment;

        case 3: // '\003'
            if(threeAMPageFragment == null)
                threeAMPageFragment = new ThreeAMPageFragment();
            return threeAMPageFragment;

        case 4: // '\004'
            break;
        }
        if(moreMenuFragment == null)
            moreMenuFragment = new MoreMenuFragment();
        return moreMenuFragment;
    }

    public TextView getTab(final int position, SwipeyTabs swipeytabs)
    {
        TextView textview = (TextView)LayoutInflater.from(mContext).inflate(com.mirror.base.R.layout.swipey_tab_indicator, swipeytabs, false);
        textview.setText(SLIDE_MAIN_TITLES[position]);
        textview.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                ((KogiActivity)mContext).getmViewPager().setCurrentItem(position);
            }

            final MoreActivityPagerAdapter this$0;
            final int val$position;

            
            {
                this$0 = MoreActivityPagerAdapter.this;
                position = i;
                super();
            }
        });
        return textview;
    }

    private String SLIDE_MAIN_TITLES[];
    private final Context mContext;
    MoreMenuFragment moreMenuFragment;
    MyMirrorPageFragment myMirrorPageFragment;
    NewsSectionPageFragment newsSectionPageFragment;
    SportsPageFragment sportsPageFragment;
    ThreeAMPageFragment threeAMPageFragment;

}
