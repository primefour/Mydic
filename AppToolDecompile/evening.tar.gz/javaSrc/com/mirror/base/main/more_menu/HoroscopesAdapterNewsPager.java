// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.content.Context;
import android.os.Build;
import android.support.v4.app.*;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.*;
import android.widget.Button;
import android.widget.TextView;
import com.base.swipeytabs.SwipeyTabs;
import com.base.swipeytabs.SwipeyTabsAdapter;
import com.mirror.base.article_page.NewsDetailActivity;
import com.mirror.base.article_page.NewsDetailFragment;
import com.mirror.base.main.MirrorNewsApp;
import com.mirror.base.tracking.TrackingHelper;
import java.util.Enumeration;
import java.util.Hashtable;
import org.json.*;

public class HoroscopesAdapterNewsPager extends FragmentStatePagerAdapter
    implements SwipeyTabsAdapter
{

    public HoroscopesAdapterNewsPager(FragmentManager fragmentmanager, Context context, JSONArray jsonarray)
    {
        super(fragmentmanager);
        myFragments = new Hashtable();
        ctx = context;
        newsItems = jsonarray;
    }

    public void decreaseWebViewFotnSize()
    {
        Enumeration enumeration = myFragments.keys();
        if(fontStep > -3)
        {
            fontStep = -1 + fontStep;
            for(; enumeration.hasMoreElements(); ((NewsDetailFragment)myFragments.get(enumeration.nextElement())).updateUI(15 - -1 * (4 * fontStep)));
        }
    }

    public int getCount()
    {
        if(newsItems.length() < 1)
            return 1;
        else
            return newsItems.length();
    }

    public Fragment getItem(int i)
    {
        int j = i % 3;
        if(NewsDetailFragment.fontSize == 0)
            NewsDetailFragment.fontSize = 15;
        NewsDetailFragment newsdetailfragment = NewsDetailFragment.newInstance(i);
        newsdetailfragment.setNewsItem(newsItems);
        myFragments.put(Integer.valueOf(j), newsdetailfragment);
        return newsdetailfragment;
    }

    public TextView getTab(final int position, SwipeyTabs swipeytabs)
    {
        TextView textview = (TextView)LayoutInflater.from(ctx).inflate(com.mirror.base.R.layout.swipey_tab_indicator, swipeytabs, false);
        try
        {
            textview.setText(newsItems.getJSONObject(position).getString("title"));
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
        textview.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                ((KogiActivity)ctx).getmViewPager().setCurrentItem(position);
            }

            final HoroscopesAdapterNewsPager this$0;
            final int val$position;

            
            {
                this$0 = HoroscopesAdapterNewsPager.this;
                position = i;
                super();
            }
        });
        return textview;
    }

    public void increaseWebViewFotnSize()
    {
        Enumeration enumeration = myFragments.keys();
        if(fontStep < 3)
        {
            fontStep = 1 + fontStep;
            for(; enumeration.hasMoreElements(); ((NewsDetailFragment)myFragments.get(enumeration.nextElement())).updateUI(15 + 4 * fontStep));
        }
    }

    public void setPrimaryItem(View view, int i, Object obj)
    {
        NewsDetailFragment newsdetailfragment = (NewsDetailFragment)obj;
        if(newsdetailfragment.isHoroscope() && !newsdetailfragment.getTitle().toLowerCase().contains("title"))
            trackEvent(newsdetailfragment);
        if(newsdetailfragment != mCurrentPrimaryItem && newsdetailfragment.isHoroscope() && !newsdetailfragment.getTitle().toLowerCase().contains("title"))
        {
            mCurrentPrimaryItem = newsdetailfragment;
            mCurrentPrimaryItem.setWebviewFontSize();
        }
    }

    public void setPrimaryItem(ViewGroup viewgroup, int i, Object obj)
    {
        NewsDetailFragment newsdetailfragment = (NewsDetailFragment)obj;
        if(newsdetailfragment.isHoroscope() && !newsdetailfragment.getTitle().toLowerCase().contains("title"))
            trackEvent(newsdetailfragment);
        if(newsdetailfragment != mCurrentPrimaryItem && newsdetailfragment.isHoroscope() && !newsdetailfragment.getTitle().toLowerCase().contains("title"))
        {
            mCurrentPrimaryItem = newsdetailfragment;
            mCurrentPrimaryItem.setWebviewFontSize();
        }
    }

    public void trackEvent(NewsDetailFragment newsdetailfragment)
    {
        if(newsdetailfragment == mCurrentPrimaryItem) goto _L2; else goto _L1
_L1:
        if(!newsdetailfragment.hasComments())
            break MISSING_BLOCK_LABEL_1416;
        if(!(ctx instanceof NewsDetailActivity)) goto _L4; else goto _L3
_L3:
        if(((MirrorNewsApp)ctx.getApplicationContext()).isConnectedToInternet()) goto _L6; else goto _L5
_L5:
        ((NewsDetailActivity)ctx).setCurrentFragment(newsdetailfragment);
_L7:
        String s;
        Hashtable hashtable;
        Hashtable hashtable1;
        String s1;
        String s2;
        String s3;
        String s4;
        Object aobj[];
        s = newsdetailfragment.getTitle();
        TrackingHelper.configureAppMeasurement((KogiActivity)ctx);
        hashtable = new Hashtable();
        hashtable1 = new Hashtable();
        s1 = ctx.getString(com.mirror.base.R.string.omniture_products);
        s2 = ctx.getString(com.mirror.base.R.string.omniture_appstate_article, new Object[] {
            "horoscopes", s
        }).trim().toLowerCase();
        s3 = ctx.getString(com.mirror.base.R.string.omniture_standard_screen_tracking_events);
        s4 = ctx.getString(com.mirror.base.R.string.omniture_hire1_article);
        aobj = new Object[4];
        String s5;
        if("horoscopes" == "")
            s5 = "na";
        else
            s5 = "horoscopes";
        aobj[0] = s5;
        Exception exception;
        String s6;
        if("" == "")
            s6 = "na";
        else
            s6 = "";
        try
        {
            aobj[1] = s6;
            aobj[2] = "horoscopes";
            aobj[3] = s;
            String s7 = String.format(s4, aobj).trim().toLowerCase();
            hashtable.put(Integer.valueOf(1), TrackingHelper.SCStrip2("horoscopes"));
            hashtable.put(Integer.valueOf(2), TrackingHelper.SCStrip2(""));
            hashtable.put(Integer.valueOf(5), TrackingHelper.SCStrip2(ctx.getString(com.mirror.base.R.string.omniture_owner_site)));
            hashtable.put(Integer.valueOf(15), TrackingHelper.SCStrip2(s));
            hashtable.put(Integer.valueOf(16), ctx.getString(com.mirror.base.R.string.omniture_prop16));
            hashtable.put(Integer.valueOf(19), TrackingHelper.SCStrip2(newsdetailfragment.getGUID()));
            hashtable.put(Integer.valueOf(21), ctx.getString(com.mirror.base.R.string.omniture_prop21));
            hashtable.put(Integer.valueOf(27), "");
            hashtable.put(Integer.valueOf(30), ctx.getString(com.mirror.base.R.string.omniture_prop30_article));
            hashtable.put(Integer.valueOf(31), "");
            hashtable.put(Integer.valueOf(32), "");
            Display display = ((KogiActivity)ctx).getWindowManager().getDefaultDisplay();
            DisplayMetrics displaymetrics = new DisplayMetrics();
            display.getMetrics(displaymetrics);
            hashtable.put(Integer.valueOf(35), "");
            hashtable.put(Integer.valueOf(36), TrackingHelper.SCStrip2((new StringBuilder()).append(displaymetrics.widthPixels).append("x").append(displaymetrics.heightPixels).toString()));
            hashtable.put(Integer.valueOf(41), hashtable.get(Integer.valueOf(2)));
            hashtable.put(Integer.valueOf(42), TrackingHelper.SCStrip2(TrackingHelper.checkInternetType(ctx)));
            hashtable.put(Integer.valueOf(49), TrackingHelper.SCStrip2(TrackingHelper.getVisitorID()));
            String s8 = TrackingHelper.CalculateDate(ctx);
            hashtable.put(Integer.valueOf(50), "");
            hashtable.put(Integer.valueOf(51), TrackingHelper.SCStrip2(s8));
            hashtable.put(Integer.valueOf(52), ctx.getString(com.mirror.base.R.string.omniture_prop52));
            hashtable.put(Integer.valueOf(53), ctx.getString(com.mirror.base.R.string.omniture_prop53));
            hashtable.put(Integer.valueOf(59), TrackingHelper.SCStrip2(newsdetailfragment.getPubDate()));
            hashtable.put(Integer.valueOf(64), TrackingHelper.SCStrip2(ctx.getString(com.mirror.base.R.string.omniture_mobile)));
            hashtable.put(Integer.valueOf(72), TrackingHelper.SCStrip2((new StringBuilder()).append(ctx.getString(com.mirror.base.R.string.omniture_prop72_prefix)).append((String)hashtable.get(Integer.valueOf(1))).append("_").append(ctx.getString(com.mirror.base.R.string.omniture_prop30_article)).toString()));
            hashtable.put(Integer.valueOf(75), TrackingHelper.SCStrip2((new StringBuilder()).append("mobile_").append(Build.MANUFACTURER).append("_").append(Build.MODEL).append(ctx.getString(com.mirror.base.R.string.omniture_prop75_sufix)).toString()));
            hashtable1.put(Integer.valueOf(9), hashtable.get(Integer.valueOf(16)));
            hashtable1.put(Integer.valueOf(10), hashtable.get(Integer.valueOf(21)));
            hashtable1.put(Integer.valueOf(11), hashtable.get(Integer.valueOf(5)));
            hashtable1.put(Integer.valueOf(12), hashtable.get(Integer.valueOf(35)));
            hashtable1.put(Integer.valueOf(14), hashtable.get(Integer.valueOf(15)));
            hashtable1.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
            hashtable1.put(Integer.valueOf(41), hashtable.get(Integer.valueOf(2)));
            hashtable1.put(Integer.valueOf(42), "");
            hashtable1.put(Integer.valueOf(43), hashtable.get(Integer.valueOf(30)));
            hashtable1.put(Integer.valueOf(45), hashtable.get(Integer.valueOf(19)));
            hashtable1.put(Integer.valueOf(47), hashtable.get(Integer.valueOf(51)));
            hashtable1.put(Integer.valueOf(48), hashtable.get(Integer.valueOf(52)));
            hashtable1.put(Integer.valueOf(49), hashtable.get(Integer.valueOf(53)));
            hashtable1.put(Integer.valueOf(50), String.format(ctx.getString(com.mirror.base.R.string.omniture_evar50_article), new Object[] {
                "horoscopes", s
            }).trim().toLowerCase());
            hashtable1.put(Integer.valueOf(51), hashtable.get(Integer.valueOf(49)));
            hashtable1.put(Integer.valueOf(57), hashtable.get(Integer.valueOf(51)));
            hashtable1.put(Integer.valueOf(61), hashtable.get(Integer.valueOf(75)));
            hashtable1.put(Integer.valueOf(62), TrackingHelper.SCStrip2(TrackingHelper.SCStrip2((new StringBuilder()).append("mobile_").append(Build.MANUFACTURER).append("_").append(Build.MODEL).append(ctx.getString(com.mirror.base.R.string.omniture_prop75_sufix)).toString())));
            hashtable1.put(Integer.valueOf(64), hashtable.get(Integer.valueOf(64)));
            TrackingHelper.logEvent(hashtable, hashtable1, s3, s1, s2, s7, false);
        }
        catch(Exception exception1)
        {
            exception1.printStackTrace();
        }
        mCurrentPrimaryItem = newsdetailfragment;
        mCurrentPrimaryItem.setWebviewFontSize();
_L2:
        return;
_L6:
label0:
        {
            ((NewsDetailActivity)ctx).showCommentsButton(true);
            if(newsdetailfragment.getCommentNumber() <= 0)
                break label0;
            ((NewsDetailActivity)ctx).getbNewsDetailComments().setBackgroundResource(com.mirror.base.R.drawable.comment_red);
            ((NewsDetailActivity)ctx).setCommentNumber(newsdetailfragment.getCommentNumber());
        }
          goto _L5
        Log.e(com/mirror/base/main/more_menu/HoroscopesAdapterNewsPager.getCanonicalName(), "comments allowed but 0 comments");
        ((NewsDetailActivity)ctx).getbNewsDetailComments().setBackgroundResource(com.mirror.base.R.drawable.comment);
        ((NewsDetailActivity)ctx).getbNewsDetailComments().setText("");
          goto _L5
_L4:
        try
        {
            ((NewsDetailActivity)ctx).showCommentsButton(false);
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
          goto _L7
        ((NewsDetailActivity)ctx).showCommentsButton(false);
          goto _L7
    }

    public void updateUI()
    {
        for(Enumeration enumeration = myFragments.keys(); enumeration.hasMoreElements(); ((NewsDetailFragment)myFragments.get(enumeration.nextElement())).updateUI());
    }

    public static final int DEFAULT_FONT_SIZE = 15;
    private static final int FONT_SIZE_MAX_STEPS = 3;
    private static final int FONT_SIZE_RATE = 4;
    public static int fontSize = 0;
    private static int fontStep = 0;
    private Context ctx;
    public NewsDetailFragment mCurrentPrimaryItem;
    private Hashtable myFragments;
    private JSONArray newsItems;


}
