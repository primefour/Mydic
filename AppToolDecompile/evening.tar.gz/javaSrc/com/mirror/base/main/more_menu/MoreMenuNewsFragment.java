// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.*;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.view.*;
import android.view.animation.*;
import android.widget.*;
import com.base.listviews.pulltorefresh.PullToRefreshListView;
import com.flurry.android.FlurryAgent;
import com.kogi.bitmapfun.*;
import com.mirror.base.constants.Constants;
import com.mirror.base.main.MirrorNewsApp;
import com.mirror.base.main.news_section_page.AdapterDropDown;
import com.mirror.base.main.news_section_page.ws.WSNewsSection;
import java.util.HashMap;
import java.util.Map;
import org.json.*;

// Referenced classes of package com.mirror.base.main.more_menu:
//            MoreMenuFragment, MoreMenuActivity, AdapterListMoreSectionPage

public class MoreMenuNewsFragment extends Fragment
    implements android.support.v4.app.LoaderManager.LoaderCallbacks
{
    public static class dataLoader extends AsyncTaskLoader
    {

        public volatile void deliverResult(Object obj)
        {
            deliverResult((JSONArray)obj);
        }

        public void deliverResult(JSONArray jsonarray)
        {
            MoreMenuNewsFragment.dataToUpdate = true;
            super.deliverResult(jsonarray);
        }

        public void forceLoad()
        {
            super.forceLoad();
        }

        public volatile Object loadInBackground()
        {
            return loadInBackground();
        }

        public JSONArray loadInBackground()
        {
            JSONArray jsonarray;
            try
            {
                jsonarray = MoreMenuNewsFragment.wsNewsSection.getNewsSectionNews(MoreMenuNewsFragment.jCurrentSection.getString("url"));
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
                return null;
            }
            return jsonarray;
        }

        public volatile void onCanceled(Object obj)
        {
            onCanceled((JSONArray)obj);
        }

        public void onCanceled(JSONArray jsonarray)
        {
            super.onCanceled(jsonarray);
        }

        protected void onReset()
        {
            super.onReset();
        }

        protected void onStartLoading()
        {
            MoreMenuNewsFragment.dataToUpdate = false;
            super.onStartLoading();
            forceLoad();
        }

        protected void onStopLoading()
        {
            super.onStopLoading();
        }

        public dataLoader(Context context)
        {
            super(context);
        }
    }


    public MoreMenuNewsFragment(JSONArray jsonarray, String s, boolean flag, int i, String s1)
    {
        isPullToRefresh = false;
        isDropDownMenuOn = false;
        hideSubMenu = false;
        data = jsonarray;
        hideSubMenu = flag;
        currentNewsSection = i;
        father = s1;
        title = s;
    }

    private void initListeners()
    {
        barListener = new android.view.View.OnClickListener() {

            public void onClick(View view)
            {
                if(isDropDownMenuOn)
                {
                    hideDropDownMenus();
                    return;
                } else
                {
                    setDropdownListsAnimation();
                    adapterDropDown.notifyDataSetChanged();
                    rlDropDownContent.setVisibility(0);
                    isDropDownMenuOn = true;
                    lvDropDownMenuNews.startLayoutAnimation();
                    return;
                }
            }

            final MoreMenuNewsFragment this$0;

            
            {
                this$0 = MoreMenuNewsFragment.this;
                super();
            }
        };
        bButtonNewsSections.setOnClickListener(barListener);
        rlNewsSections.setOnClickListener(barListener);
        try
        {
            ivLine.setOnClickListener(barListener);
            ivTriangle.setOnClickListener(barListener);
        }
        catch(NullPointerException nullpointerexception) { }
        ((ListView)pTRLVNews.getRefreshableView()).setOnTouchListener(new android.view.View.OnTouchListener() {

            public boolean onTouch(View view, MotionEvent motionevent)
            {
                if(isDropDownMenuOn)
                    hideDropDownMenus();
                return false;
            }

            final MoreMenuNewsFragment this$0;

            
            {
                this$0 = MoreMenuNewsFragment.this;
                super();
            }
        });
    }

    private void initVars()
    {
        wsNewsSection = new WSNewsSection(getActivity());
        getLoaderManager().initLoader(0, null, this);
        adapterDropDown = new AdapterDropDown(this);
        com.kogi.bitmapfun.ImageCache.ImageCacheParams imagecacheparams = new com.kogi.bitmapfun.ImageCache.ImageCacheParams(getResources().getString(com.mirror.base.R.string.images_dir));
        imagecacheparams.memCacheSize = (Constants.SCREEN_WIDTH * Constants.SCREEN_HEIGHT * Utils.getMemoryClass(getActivity())) / 8;
        mImageWorker = new ImageFetcher(getActivity(), 300);
        mImageWorker.setLoadingImage(com.mirror.base.R.drawable.placeholder_big);
        mImageWorker.setImageCache(ImageCache.findOrCreateCache(getActivity(), imagecacheparams));
        if(getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            FlurryAgent.onPageView();
    }

    private void initViews()
    {
        rlNewsSections = (RelativeLayout)getActivity().findViewById(com.mirror.base.R.id.rlNewsSections);
        ivTriangle = (ImageView)getActivity().findViewById(com.mirror.base.R.id.ivTriangle);
        ivLine = (ImageView)getActivity().findViewById(com.mirror.base.R.id.ivLine);
        if(hideSubMenu)
        {
            rlNewsSections.setVisibility(8);
            ivTriangle.setVisibility(8);
            ivLine.setVisibility(8);
        }
        bButtonNewsSections = (Button)getActivity().findViewById(com.mirror.base.R.id.bButtonNewsSections);
        pTRLVNews = (PullToRefreshListView)getActivity().findViewById(com.mirror.base.R.id.pTRLVNews);
        View view = LayoutInflater.from(getActivity()).inflate(com.mirror.base.R.layout.footer_for_list, null);
        ((ListView)pTRLVNews.getRefreshableView()).addFooterView(view);
        pTRLVNews.setOnRefreshListener(new com.base.listviews.pulltorefresh.PullToRefreshBase.OnRefreshListener() {

            public void onRefresh()
            {
                isPullToRefresh = true;
                getLoaderManager().restartLoader(0, null, MoreMenuNewsFragment.this);
            }

            final MoreMenuNewsFragment this$0;

            
            {
                this$0 = MoreMenuNewsFragment.this;
                super();
            }
        });
        rlLoadingPanelNews = (RelativeLayout)getActivity().findViewById(com.mirror.base.R.id.loadingPanelNews);
        if(!father.equalsIgnoreCase("MyMirror")) goto _L2; else goto _L1
_L1:
        if(!((KogiActivity)getActivity()).getBooleanParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.BOOL_HASPREFERENCES, false)) goto _L4; else goto _L3
_L3:
        jCurrentSection = ((KogiActivity)getActivity()).getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_MY_MIRROR_USER_SECTIONS).getJSONObject(currentNewsSection);
_L7:
        if(data.length() >= 2) goto _L6; else goto _L5
_L5:
        rlNewsSections.setVisibility(8);
        JSONException jsonexception;
        Animation animation;
        if(com/mirror/base/main/more_menu/MoreMenuFragment.getSimpleName().equalsIgnoreCase(father) && getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            try
            {
                ((MoreMenuActivity)getActivity()).getCurrentSection();
                new HashMap();
                FlurryAgent.logEvent(title);
            }
            catch(Exception exception1)
            {
                exception1.printStackTrace();
            }
_L8:
        lvDropDownMenuNews = (ListView)getActivity().findViewById(com.mirror.base.R.id.lvDropDownMenuNews);
        rlDropDownContent = (LinearLayout)getActivity().findViewById(com.mirror.base.R.id.dropDownMenuContentNews);
        lvDropDownMenuNews.setAdapter(adapterDropDown);
        setDropdownListsAnimation();
        tvErrorMessageMore = (TextView)getActivity().findViewById(com.mirror.base.R.id.tvErrorMessageNews);
        pbIndeterminate = (ProgressBar)getActivity().findViewById(com.mirror.base.R.id.pbIndeterminateNews);
        pbIndeterminate.setIndeterminateDrawable(getResources().getDrawable(com.mirror.base.R.drawable.androidspinner));
        animation = AnimationUtils.loadAnimation(getActivity(), com.mirror.base.R.anim.rotate360);
        pbIndeterminate.setAnimation(animation);
        return;
_L4:
        try
        {
            jCurrentSection = ((MirrorNewsApp)getActivity().getApplicationContext()).getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_MY_MIRROR).getJSONObject(currentNewsSection);
        }
        // Misplaced declaration of an exception variable
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
          goto _L7
_L2:
        jCurrentSection = data.getJSONObject(currentNewsSection);
          goto _L7
_L6:
        boolean flag = getResources().getBoolean(com.mirror.base.R.bool.flurry_active);
        if(!flag)
            break MISSING_BLOCK_LABEL_557;
        ((MoreMenuActivity)getActivity()).getCurrentSection();
        HashMap hashmap = new HashMap();
        hashmap.put("Parameter", jCurrentSection.getString("name"));
        FlurryAgent.logEvent(title, hashmap);
_L9:
        bButtonNewsSections.setText((new StringBuilder()).append("").append(jCurrentSection.getString("name").toUpperCase()).toString());
          goto _L8
        JSONException jsonexception1;
        jsonexception1;
        jsonexception1.printStackTrace();
          goto _L8
        Exception exception;
        exception;
        exception.printStackTrace();
          goto _L9
        NullPointerException nullpointerexception;
        nullpointerexception;
        bButtonNewsSections.setText(title);
          goto _L8
    }

    private void setDropdownHideListsAnimation()
    {
        AnimationSet animationset = new AnimationSet(true);
        AlphaAnimation alphaanimation = new AlphaAnimation(1.0F, 0.0F);
        alphaanimation.setDuration(0L);
        animationset.addAnimation(alphaanimation);
        TranslateAnimation translateanimation = new TranslateAnimation(1, 0.0F, 1, 0.0F, 1, 0.0F, 1, -1F);
        translateanimation.setDuration(0L);
        animationset.addAnimation(translateanimation);
        ScaleAnimation scaleanimation = new ScaleAnimation(1.0F, 0.9F, 1.0F, 0.9F, 1, 1.0F, 1, 1.0F);
        scaleanimation.setDuration(0L);
        animationset.addAnimation(scaleanimation);
        animationset.setAnimationListener(new android.view.animation.Animation.AnimationListener() {

            public void onAnimationEnd(Animation animation)
            {
                rlDropDownContent.setVisibility(8);
                isDropDownMenuOn = false;
            }

            public void onAnimationRepeat(Animation animation)
            {
            }

            public void onAnimationStart(Animation animation)
            {
            }

            final MoreMenuNewsFragment this$0;

            
            {
                this$0 = MoreMenuNewsFragment.this;
                super();
            }
        });
        controller = new LayoutAnimationController(animationset, 0.0F);
        lvDropDownMenuNews.setLayoutAnimation(controller);
    }

    private void setDropdownListsAnimation()
    {
        AnimationSet animationset = new AnimationSet(true);
        AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, 1.0F);
        alphaanimation.setDuration(0L);
        animationset.addAnimation(alphaanimation);
        TranslateAnimation translateanimation = new TranslateAnimation(1, 0.0F, 1, 0.0F, 1, -1F, 1, 0.0F);
        translateanimation.setDuration(0L);
        animationset.addAnimation(translateanimation);
        ScaleAnimation scaleanimation = new ScaleAnimation(0.75F, 1.0F, 0.75F, 1.0F, 1, 0.5F, 1, 0.5F);
        scaleanimation.setDuration(0L);
        animationset.addAnimation(scaleanimation);
        controller = new LayoutAnimationController(animationset, 0.0F);
        lvDropDownMenuNews.setLayoutAnimation(controller);
    }

    private void updateNews(JSONArray jsonarray)
    {
        if(jsonarray == null || jsonarray.length() < 1)
            tvErrorMessageMore.setVisibility(0);
        else
            tvErrorMessageMore.setVisibility(8);
        if(adapterListNewsSection != null)
        {
            adapterListNewsSection.setData(jsonarray);
            if(((ListView)pTRLVNews.getRefreshableView()).getAdapter() == null)
                pTRLVNews.setAdapter(adapterListNewsSection);
            else
                adapterListNewsSection.notifyDataSetChanged();
        } else
        {
            adapterListNewsSection = new AdapterListMoreSectionPage(this, jsonarray, title, mImageWorker);
            pTRLVNews.setAdapter(adapterListNewsSection);
        }
        if(isPullToRefresh)
        {
            isPullToRefresh = false;
            pTRLVNews.onRefreshComplete();
        }
    }

    public String getCurrentParentSection()
    {
        return ((MoreMenuActivity)getActivity()).getCurrentSection();
    }

    public String getCurrentSection()
    {
        return (new StringBuilder()).append(bButtonNewsSections.getText()).append("").toString();
    }

    public JSONArray getData()
    {
        return data;
    }

    public String getFather()
    {
        return father;
    }

    public String getHeaderTitle()
    {
        return (new StringBuilder()).append(bButtonNewsSections.getText()).append("").toString();
    }

    public void hideDropDownMenus()
    {
        setDropdownHideListsAnimation();
        lvDropDownMenuNews.startLayoutAnimation();
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        initViews();
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        initVars();
        ((MoreMenuActivity)getActivity()).trackEvent(title.toLowerCase().trim(), adapterDropDown.getDropdownTitle(0));
    }

    public Loader onCreateLoader(int i, Bundle bundle)
    {
        return new dataLoader(getActivity());
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        if(viewgroup == null)
            return null;
        else
            return layoutinflater.inflate(com.mirror.base.R.layout.news_section_page_fragment, viewgroup, false);
    }

    public volatile void onLoadFinished(Loader loader, Object obj)
    {
        onLoadFinished(loader, (JSONArray)obj);
    }

    public void onLoadFinished(Loader loader, JSONArray jsonarray)
    {
        if(dataToUpdate)
        {
            updateNews(jsonarray);
            rlLoadingPanelNews.setVisibility(8);
        }
    }

    public void onLoaderReset(Loader loader)
    {
    }

    public void onStart()
    {
        super.onStart();
        initListeners();
    }

    public void setFather(String s)
    {
        father = s;
    }

    public void showProgressDialog()
    {
        rlLoadingPanelNews.setVisibility(0);
    }

    public void updateNews(String s, int i)
    {
        currentNewsSection = i;
        try
        {
            jCurrentSection = data.getJSONObject(currentNewsSection);
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
        bButtonNewsSections.setText((new StringBuilder()).append(s.toUpperCase()).append("").toString());
        ((MoreMenuActivity)getActivity()).showAD(s.toLowerCase());
        getLoaderManager().restartLoader(0, null, this);
    }

    private static final String TAG = com/mirror/base/main/more_menu/MoreMenuNewsFragment.getSimpleName();
    static int currentNewsSection = 0;
    static boolean dataToUpdate;
    private static JSONObject jCurrentSection;
    static WSNewsSection wsNewsSection;
    AdapterDropDown adapterDropDown;
    AdapterListMoreSectionPage adapterListNewsSection;
    Button bButtonNewsSections;
    android.view.View.OnClickListener barListener;
    LayoutAnimationController controller;
    private JSONArray data;
    private String father;
    private boolean hideSubMenu;
    public boolean isDropDownMenuOn;
    boolean isPullToRefresh;
    ImageView ivLine;
    ImageView ivTriangle;
    ListView lvDropDownMenuNews;
    private ImageWorker mImageWorker;
    PullToRefreshListView pTRLVNews;
    private ProgressBar pbIndeterminate;
    LinearLayout rlDropDownContent;
    RelativeLayout rlLoadingPanelNews;
    RelativeLayout rlNewsSections;
    private String title;
    private TextView tvErrorMessageMore;



}
