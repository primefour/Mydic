// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu.ws;

import android.support.v4.app.KogiActivity;
import android.support.v4.app.KogiAsyncTask;
import com.mirror.base.main.more_menu.HoroscopesDetailActivity;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.mirror.base.main.more_menu.ws:
//            WSHoroscopes

public class HoroscopesAsyncTask extends KogiAsyncTask
{

    public HoroscopesAsyncTask(Enum enum, KogiActivity kogiactivity)
    {
        super(enum, kogiactivity);
    }

    protected volatile Object doInBackground(Object aobj[])
    {
        return doInBackground((JSONObject[])aobj);
    }

    protected transient JSONObject doInBackground(JSONObject ajsonobject[])
    {
        JSONObject jsonobject;
        if(!command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.GET_HOROSCOPES))
            break MISSING_BLOCK_LABEL_65;
        jsonobject = new JSONObject();
        jsonobject.put("response", ((HoroscopesDetailActivity)parentActivity).getWsHoroscopes().getHoroscopes(ajsonobject[0].getJSONArray("data")));
        return jsonobject;
        JSONException jsonexception;
        jsonexception;
        jsonexception.printStackTrace();
        return jsonobject;
        Exception exception;
        exception;
        exception.printStackTrace();
        return null;
    }

    protected volatile void onPostExecute(Object obj)
    {
        onPostExecute((JSONObject)obj);
    }

    protected void onPostExecute(JSONObject jsonobject)
    {
        super.onPostExecute(jsonobject);
        boolean flag;
        try
        {
            flag = command.equals(com.mirror.base.main.MirrorNewsApp.COMMAND.GET_HOROSCOPES);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            return;
        }
        if(!flag)
            break MISSING_BLOCK_LABEL_36;
        ((HoroscopesDetailActivity)parentActivity).setHoroscopesArticles(jsonobject.getJSONArray("response"));
        return;
        NullPointerException nullpointerexception;
        nullpointerexception;
        return;
        JSONException jsonexception;
        jsonexception;
    }
}
