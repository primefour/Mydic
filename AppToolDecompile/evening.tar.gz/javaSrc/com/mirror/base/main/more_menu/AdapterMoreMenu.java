// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v4.app.Fragment;
import android.support.v4.app.KogiActivity;
import android.text.Html;
import android.view.*;
import android.widget.*;
import com.flurry.android.FlurryAgent;
import org.json.*;

// Referenced classes of package com.mirror.base.main.more_menu:
//            ViewHolderMoreMenu, HoroscopesDetailActivity, MoreMenuActivity

public class AdapterMoreMenu extends BaseAdapter
{

    public AdapterMoreMenu(Context context1, JSONArray jsonarray, Fragment fragment)
    {
        data = jsonarray;
        context = context1;
        parentFragment = fragment;
    }

    public int getCount()
    {
        return data.length();
    }

    public Object getItem(int i)
    {
        return null;
    }

    public long getItemId(int i)
    {
        return (long)i;
    }

    public View getView(final int position, View view, ViewGroup viewgroup)
    {
        View view1 = LayoutInflater.from(context).inflate(com.mirror.base.R.layout.more_menu_item, null);
        ViewHolderMoreMenu viewholdermoremenu = new ViewHolderMoreMenu();
        viewholdermoremenu.name = (TextView)view1.findViewById(com.mirror.base.R.id.tvMoreMenuSectionName);
        viewholdermoremenu.icon = (ImageView)view1.findViewById(com.mirror.base.R.id.ivMoreMenuSectionHeader);
        view1.setTag(viewholdermoremenu);
        try
        {
            viewholdermoremenu.sName = Html.fromHtml(data.getJSONObject(position).getString("name")).toString().toUpperCase();
            viewholdermoremenu.name.setText(viewholdermoremenu.sName);
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
        if(viewholdermoremenu.sName.equals("SPORT"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.sport_big);
        else
        if(viewholdermoremenu.sName.equals("TV"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.tv);
        else
        if(viewholdermoremenu.sName.equals("LIFESTYLE"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.lifestyle);
        else
        if(viewholdermoremenu.sName.equals("HOROSCOPES"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.horoscopes);
        else
        if(viewholdermoremenu.sName.equals("MONEY"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.money);
        else
        if(viewholdermoremenu.sName.equals("OPINION"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.opinion);
        else
        if(viewholdermoremenu.sName.equals("TRAVEL"))
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.travel);
        else
            viewholdermoremenu.icon.setImageResource(com.mirror.base.R.drawable.top_stories);
        view1.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view2)
            {
                Intent intent;
                if(((Activity)context).getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
                    FlurryAgent.onPageView();
                if(!data.getJSONObject(position).getString("name").equalsIgnoreCase("HOROSCOPES"))
                    break MISSING_BLOCK_LABEL_231;
                intent = new Intent(context, com/mirror/base/main/more_menu/HoroscopesDetailActivity);
                intent.putExtra("news_selected", 0);
                ((KogiActivity)context).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_NEWS_DATA, data.getJSONObject(position).getJSONArray("sections"));
_L1:
                intent.putExtra("newsDetailsTitle", data.getJSONObject(position).getString("name"));
_L2:
                JSONException jsonexception2;
                try
                {
                    intent.putExtra("father", ((ViewHolderMoreMenu)view2.getTag()).name.getText().toString().replace(" ", "").toLowerCase());
                    intent.putExtra("fatherActivity", parentFragment.getClass().getSimpleName());
                    context.startActivity(intent);
                    return;
                }
                catch(JSONException jsonexception1)
                {
                    jsonexception1.printStackTrace();
                }
                break MISSING_BLOCK_LABEL_220;
                jsonexception2;
                jsonexception2.printStackTrace();
                  goto _L1
                return;
                JSONException jsonexception3;
                jsonexception3;
                jsonexception3.printStackTrace();
                  goto _L2
                Intent intent1 = new Intent(context, com/mirror/base/main/more_menu/MoreMenuActivity);
                ((KogiActivity)context).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_NEWS_DATA, data.getJSONObject(position).getJSONArray("sections"));
_L3:
                intent1.putExtra("newsDetailsTitle", data.getJSONObject(position).getString("name"));
_L4:
                intent1.putExtra("father", ((ViewHolderMoreMenu)view2.getTag()).name.getText().toString().replace(" ", "").toLowerCase());
                intent1.putExtra("fatherActivity", parentFragment.getClass().getSimpleName());
                context.startActivity(intent1);
                return;
                JSONException jsonexception4;
                jsonexception4;
                jsonexception4.printStackTrace();
                  goto _L3
                JSONException jsonexception5;
                jsonexception5;
                jsonexception5.printStackTrace();
                  goto _L4
            }

            final AdapterMoreMenu this$0;
            final int val$position;

            
            {
                this$0 = AdapterMoreMenu.this;
                position = i;
                super();
            }
        });
        return view1;
    }

    private Context context;
    private JSONArray data;
    private Fragment parentFragment;



}
