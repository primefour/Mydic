// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v4.app.*;
import android.view.*;
import android.widget.GridView;
import android.widget.ListView;
import com.flurry.android.FlurryAgent;

// Referenced classes of package com.mirror.base.main.more_menu:
//            AdapterMoreMenu

public class MoreMenuFragment extends Fragment
{

    public MoreMenuFragment()
    {
    }

    private void initListeners()
    {
    }

    private void initVars()
    {
        adapterMoreMenu = new AdapterMoreMenu(getActivity(), ((KogiActivity)getActivity()).getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_MORE), this);
    }

    private void initViews()
    {
        lvMoreMenu = (ListView)getActivity().findViewById(com.mirror.base.R.id.lvMoreMenu);
        View view = LayoutInflater.from(getActivity()).inflate(com.mirror.base.R.layout.footer_for_list, null);
        try
        {
            lvMoreMenu.addFooterView(view);
            lvMoreMenu.setAdapter(adapterMoreMenu);
        }
        catch(NullPointerException nullpointerexception)
        {
            gvMoreMenu = (GridView)getActivity().findViewById(com.mirror.base.R.id.gvMoreMenu);
            gvMoreMenu.setAdapter(adapterMoreMenu);
        }
        if(getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            FlurryAgent.onPageView();
    }

    public void onActivityCreated(Bundle bundle)
    {
        super.onActivityCreated(bundle);
        initViews();
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        initVars();
    }

    public View onCreateView(LayoutInflater layoutinflater, ViewGroup viewgroup, Bundle bundle)
    {
        if(viewgroup == null)
            return null;
        else
            return layoutinflater.inflate(com.mirror.base.R.layout.more_menu_fragment, viewgroup, false);
    }

    public void onStart()
    {
        super.onStart();
        initListeners();
    }

    AdapterMoreMenu adapterMoreMenu;
    GridView gvMoreMenu;
    ListView lvMoreMenu;
}
