// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.more_menu.ws;

import android.content.Context;
import com.mirror.base.main.my_mirror_page.ws.CommandGetNews;
import org.json.JSONArray;
import org.json.JSONObject;

public class WSHoroscopes
{

    public WSHoroscopes(Context context1)
    {
        context = context1;
    }

    public JSONArray getHoroscopes(JSONArray jsonarray)
    {
        CommandGetNews commandgetnews = new CommandGetNews(context);
        JSONArray jsonarray1 = new JSONArray();
        int i = 0;
        while(i < jsonarray.length()) 
        {
            try
            {
                JSONObject jsonobject = jsonarray.getJSONObject(i);
                commandgetnews.setUrl((new JSONObject()).put("url", jsonobject.getString("url")));
                commandgetnews.execute();
                jsonarray1.put(((JSONObject)commandgetnews.getResult()).getJSONArray("news").getJSONObject(0));
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
            i++;
        }
        return jsonarray1;
    }

    private Context context;
}
