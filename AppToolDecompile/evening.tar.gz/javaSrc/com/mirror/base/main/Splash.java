// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.*;
import android.support.v4.app.KogiActivity;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.widget.ImageView;
import com.facebook.AppEventsLogger;
import com.flurry.android.FlurryAgent;
import com.kogi.bitmapfun.*;
import com.kogi.imagetest.im.ImageService;
import com.mirror.base.constants.Constants;
import com.mirror.base.main.ws.WSSplash;
import com.mirror.base.tracking.TrackingHelper;
import java.util.*;
import org.apache.http.message.BasicNameValuePair;
import org.json.*;

// Referenced classes of package com.mirror.base.main:
//            MirrorNewsApp, MainFragmentActivity

public class Splash extends KogiActivity
{
    class PollingTask extends AsyncTask
    {

        protected volatile Object doInBackground(Object aobj[])
        {
            return doInBackground((JSONObject[])aobj);
        }

        protected transient JSONObject doInBackground(JSONObject ajsonobject[])
        {
            JSONObject jsonobject;
            try
            {
                jsonobject = new JSONObject();
                JSONObject jsonobject1 = wsSplash.getSponsorship();
                Log.i(getSponsorship, (new StringBuilder()).append("Sponsorship doInBackground response: ").append(jsonobject1.toString()).toString());
                ((MirrorNewsApp)getApplication()).getImageService().getHandler(jsonobject1.optJSONArray("splash").optString(0));
                jsonobject.put("Sponsorship", jsonobject1);
            }
            catch(Exception exception)
            {
                bDownloadSpon = false;
                exception.printStackTrace();
                Log.i(getSponsorship, (new StringBuilder()).append("Sponsorship doInBackground Exception: ").append(exception).toString());
                return null;
            }
            return jsonobject;
        }

        protected volatile void onPostExecute(Object obj)
        {
            onPostExecute((JSONObject)obj);
        }

        protected void onPostExecute(JSONObject jsonobject)
        {
            super.onPostExecute(jsonobject);
            if(jsonobject != null)
                Log.i(getSponsorship, (new StringBuilder()).append("Sponsorship onPostExecute result: ").append(jsonobject.toString()).toString());
            else
                Log.i(getSponsorship, "Sponsorship onPostExecute result IS NULL: ");
            if(bDownloadSpon)
                startTime = System.currentTimeMillis();
            bDownloadSpon = false;
            try
            {
                Log.i(getSponsorship, (new StringBuilder()).append("Sponsorship onPostExecute setSponsorship: ").append(jsonobject.toString()).toString());
                setSponsorship((JSONObject)jsonobject.get("Sponsorship"));
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
            (new SplashLoad()).execute(new JSONObject[0]);
        }

        JSONObject jResponse;
        final Splash this$0;

        PollingTask()
        {
            this$0 = Splash.this;
            super();
            jResponse = new JSONObject();
        }
    }

    class SplashLoad extends AsyncTask
    {

        protected volatile Object doInBackground(Object aobj[])
        {
            return doInBackground((JSONObject[])aobj);
        }

        protected transient JSONObject doInBackground(JSONObject ajsonobject[])
        {
            (new Timer()).schedule(new TimerTask() {

                public void run()
                {
                    cancelable = true;
                    if(!finished)
                        publishProgress(new JSONObject[0]);
                }

                final SplashLoad this$1;

            
            {
                this$1 = SplashLoad.this;
                super();
            }
            }, getResources().getInteger(com.mirror.base.R.integer.splash_wait_time_milis));
            try
            {
                jConfFile = wsSplash.getConfFile();
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
            try
            {
                jConfFileMC = wsSplash.getConfFileMatchCentre();
            }
            catch(Exception exception1)
            {
                exception1.printStackTrace();
            }
            while(bDownloadSpon && System.currentTimeMillis() - startTime < (long)getResources().getInteger(com.mirror.base.R.integer.splash_wait_time_milis)) 
            {
                Log.e(
// JavaClassFileOutputException: get_constant: invalid tag

        protected volatile void onPostExecute(Object obj)
        {
            onPostExecute((JSONObject)obj);
        }

        protected void onPostExecute(JSONObject jsonobject)
        {
            finished = true;
            onPostExecute(jsonobject);
            if(dialog != null && dialog.isShowing())
                dialog.dismiss();
            JSONArray jsonarray;
            jsonarray = jConfFile.getJSONArray("tabs");
            if(!getBooleanParameter(MirrorNewsApp.PARAMETERS.BOOL_HASPREFERENCES, false))
                setParameter(MirrorNewsApp.PARAMETERS.JA_MY_MIRROR, jsonarray.getJSONObject(0).getJSONArray("sections"));
            setParameter(MirrorNewsApp.PARAMETERS.JA_MY_MIRROR_SELECTION, jsonarray.getJSONObject(1).getJSONArray("sections"));
_L3:
            setParameter(MirrorNewsApp.PARAMETERS.JA_MY_NEWS, jsonarray.getJSONObject(2).getJSONArray("sections"));
_L4:
            setParameter(MirrorNewsApp.PARAMETERS.JA_MY_FOOTBALL, jsonarray.getJSONObject(3).getJSONArray("sections"));
_L5:
            setParameter(MirrorNewsApp.PARAMETERS.JA_3AM, jsonarray.getJSONObject(4).getJSONArray("sections"));
_L6:
            setParameter(MirrorNewsApp.PARAMETERS.JA_MORE, jsonarray.getJSONObject(5).getJSONArray("sections"));
_L7:
            Intent intent;
            JSONObject jsonobject1;
            intent = new Intent(Splash.this, com/mirror/base/main/MainFragmentActivity);
            jsonobject1 = jConfFileMC;
            if(jsonobject1 == null) goto _L2; else goto _L1
_L1:
            ((MirrorNewsApp)getApplicationContext()).updateConfig(jConfFileMC);
_L8:
            JSONException jsonexception1;
            try
            {
                startActivity(intent);
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
            finish();
            return;
            jsonexception1;
            jsonexception1.printStackTrace();
              goto _L3
            JSONException jsonexception2;
            jsonexception2;
            jsonexception2.printStackTrace();
              goto _L4
            JSONException jsonexception3;
            jsonexception3;
            jsonexception3.printStackTrace();
              goto _L5
            JSONException jsonexception4;
            jsonexception4;
            jsonexception4.printStackTrace();
              goto _L6
            JSONException jsonexception5;
            jsonexception5;
            jsonexception5.printStackTrace();
              goto _L7
            JSONException jsonexception7;
            jsonexception7;
            JSONArray jsonarray2 = jsonarray.getJSONObject(3).getJSONArray("sections");
            int j = 0;
_L13:
            JSONObject jsonobject3;
            boolean flag1;
            if(j >= jsonarray2.length())
                break MISSING_BLOCK_LABEL_416;
            jsonobject3 = jsonarray2.getJSONObject(j);
            if(!jsonobject3.getString("name").toLowerCase().equals(getResources().getString(com.mirror.base.R.string.match_centre_name).toLowerCase()))
                break MISSING_BLOCK_LABEL_581;
            flag1 = jsonobject3.has("section");
            if(!flag1)
                break MISSING_BLOCK_LABEL_416;
            ((MirrorNewsApp)getApplicationContext()).updateConfig2(jsonobject3.getJSONArray("section"));
_L9:
            jsonexception7.printStackTrace();
              goto _L8
            JSONException jsonexception8;
            jsonexception8;
            Log.e(
// JavaClassFileOutputException: get_constant: invalid tag

        protected volatile void onProgressUpdate(Object aobj[])
        {
            onProgressUpdate((JSONObject[])aobj);
        }

        protected transient void onProgressUpdate(JSONObject ajsonobject[])
        {
            onProgressUpdate(ajsonobject);
            if(finished)
                break MISSING_BLOCK_LABEL_52;
            dialog = ProgressDialog.show(Splash.this, getResources().getString(com.mirror.base.R.string.splash_title_wait), getResources().getString(com.mirror.base.R.string.splash_body_wait));
            return;
            Exception exception;
            exception;
            exception.printStackTrace();
            return;
        }

        private boolean finished;
        final Splash this$0;



        SplashLoad()
        {
            this$0 = Splash.this;
            super();
            finished = false;
        }
    }


    public Splash()
    {
        cancelable = false;
        jConfFile = new JSONObject();
        jConfFileMC = new JSONObject();
        bDownloadSpon = true;
    }

    protected void initData()
    {
        startTime = System.currentTimeMillis();
        try
        {
            Log.i(TAG, "Sponsorship initData : ");
            PollingTask pollingtask = new PollingTask();
            JSONObject ajsonobject[] = new JSONObject[1];
            ajsonobject[0] = new JSONObject();
            pollingtask.execute(ajsonobject);
            return;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    protected void initListeners()
    {
    }

    protected void initUI()
    {
    }

    protected void initVars()
    {
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        display.getMetrics(displaymetrics);
        int i = displaymetrics.widthPixels;
        int j = displaymetrics.heightPixels;
        Constants.SCREEN_WIDTH = i;
        Constants.SCREEN_HEIGHT = j;
        com.kogi.bitmapfun.ImageCache.ImageCacheParams imagecacheparams = new ImageCacheParams("images");
        imagecacheparams.memCacheSize = (i * j * Utils.getMemoryClass(this)) / 10;
        imagecacheparams.compressFormat = android.graphics.Bitmap.CompressFormat.PNG;
        mImageWorker = new ImageFetcher(this, i, j);
        mImageWorker.setImageFadeIn(true);
        ArrayList arraylist = new ArrayList();
        arraylist.add(new BasicNameValuePair("Content-Type", "application/x-www-form-urlencoded"));
        mImageWorker.setHeaders(arraylist);
        mImageWorker.setImageCache(ImageCache.findOrCreateCache(this, imagecacheparams));
        setParameter(MirrorNewsApp.PARAMETERS.INT_CACHE_SIZE, (1024 * (1024 * Utils.getMemoryClass(this))) / 10);
        ((MirrorNewsApp)getApplicationContext()).setCacheSize(getIntegerParameter(MirrorNewsApp.PARAMETERS.INT_CACHE_SIZE, 0x400000));
        wsSplash = new WSSplash(this);
    }

    protected void initViews(Bundle bundle)
    {
        ivSplashSponsorship = (ImageView)findViewById(com.mirror.base.R.id.iVSplashSponsorship);
    }

    protected void onCreate(Bundle bundle)
    {
        onCreate(bundle);
        setContentView(com.mirror.base.R.layout.splash_activity);
        TrackingHelper.configureAppMeasurement(this);
    }

    protected void onPause()
    {
        onPause();
    }

    protected void onResume()
    {
        onResume();
        AppEventsLogger.activateApp(this, getString(com.mirror.base.R.string.facebook_app_id));
    }

    protected void onStart()
    {
        onStart();
        if(getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            FlurryAgent.onStartSession(this, getResources().getString(com.mirror.base.R.string.flurry_key));
        TrackingHelper.configureAppMeasurement(this);
        Hashtable hashtable = new Hashtable();
        Hashtable hashtable1 = new Hashtable();
        String s = getString(com.mirror.base.R.string.omniture_products);
        String s1 = getString(com.mirror.base.R.string.omniture_appstate_splash);
        String s2 = getString(com.mirror.base.R.string.omniture_app_launch_events);
        String s3 = getString(com.mirror.base.R.string.omniture_hire1_splash);
        hashtable.put(Integer.valueOf(1), "");
        hashtable.put(Integer.valueOf(2), "");
        hashtable.put(Integer.valueOf(5), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_owner_site)));
        hashtable.put(Integer.valueOf(15), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_not_an_article)));
        hashtable.put(Integer.valueOf(16), getString(com.mirror.base.R.string.omniture_prop16));
        hashtable.put(Integer.valueOf(19), "");
        hashtable.put(Integer.valueOf(21), getString(com.mirror.base.R.string.omniture_prop21));
        hashtable.put(Integer.valueOf(27), "");
        hashtable.put(Integer.valueOf(30), getString(com.mirror.base.R.string.omniture_prop30_splash));
        hashtable.put(Integer.valueOf(31), "");
        hashtable.put(Integer.valueOf(32), "");
        hashtable.put(Integer.valueOf(35), "");
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        display.getMetrics(displaymetrics);
        hashtable.put(Integer.valueOf(36), TrackingHelper.SCStrip2((new StringBuilder()).append(displaymetrics.widthPixels).append("x").append(displaymetrics.heightPixels).toString()));
        hashtable.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
        hashtable.put(Integer.valueOf(41), hashtable.get(Integer.valueOf(2)));
        hashtable.put(Integer.valueOf(42), TrackingHelper.SCStrip2(TrackingHelper.checkInternetType(this)));
        hashtable.put(Integer.valueOf(49), TrackingHelper.SCStrip2(TrackingHelper.getVisitorID()));
        hashtable.put(Integer.valueOf(50), "");
        String s4 = TrackingHelper.CalculateDate(this);
        hashtable.put(Integer.valueOf(51), TrackingHelper.SCStrip2(s4));
        hashtable.put(Integer.valueOf(52), getString(com.mirror.base.R.string.omniture_prop52));
        hashtable.put(Integer.valueOf(53), getString(com.mirror.base.R.string.omniture_prop53));
        hashtable.put(Integer.valueOf(64), TrackingHelper.SCStrip2(getString(com.mirror.base.R.string.omniture_mobile)));
        hashtable.put(Integer.valueOf(72), getString(com.mirror.base.R.string.omniture_landing_page));
        hashtable.put(Integer.valueOf(75), TrackingHelper.SCStrip2((new StringBuilder()).append("mobile_").append(Build.MANUFACTURER).append("_").append(Build.MODEL).append(getString(com.mirror.base.R.string.omniture_prop75_sufix)).toString()));
        hashtable1.put(Integer.valueOf(9), hashtable.get(Integer.valueOf(16)));
        hashtable1.put(Integer.valueOf(10), hashtable.get(Integer.valueOf(21)));
        hashtable1.put(Integer.valueOf(11), hashtable.get(Integer.valueOf(5)));
        hashtable1.put(Integer.valueOf(12), hashtable.get(Integer.valueOf(35)));
        hashtable1.put(Integer.valueOf(14), hashtable.get(Integer.valueOf(15)));
        hashtable1.put(Integer.valueOf(40), hashtable.get(Integer.valueOf(1)));
        hashtable1.put(Integer.valueOf(42), "");
        hashtable1.put(Integer.valueOf(43), hashtable.get(Integer.valueOf(30)));
        hashtable1.put(Integer.valueOf(45), hashtable.get(Integer.valueOf(19)));
        hashtable1.put(Integer.valueOf(47), hashtable.get(Integer.valueOf(51)));
        hashtable1.put(Integer.valueOf(48), hashtable.get(Integer.valueOf(52)));
        hashtable1.put(Integer.valueOf(49), hashtable.get(Integer.valueOf(53)));
        hashtable1.put(Integer.valueOf(50), getString(com.mirror.base.R.string.omniture_evar50_splash));
        hashtable1.put(Integer.valueOf(51), hashtable.get(Integer.valueOf(49)));
        hashtable1.put(Integer.valueOf(57), hashtable.get(Integer.valueOf(51)));
        hashtable1.put(Integer.valueOf(59), "");
        hashtable1.put(Integer.valueOf(61), hashtable.get(Integer.valueOf(75)));
        hashtable1.put(Integer.valueOf(64), hashtable.get(Integer.valueOf(64)));
        TrackingHelper.logEvent(hashtable, hashtable1, s2, s, s1, s3, false);
    }

    protected void onStop()
    {
        onStop();
        if(getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
            FlurryAgent.onEndSession(this);
    }

    public void setSponsorship(JSONObject jsonobject)
    {
        try
        {
            setParameter(MirrorNewsApp.PARAMETERS.JO_SPORSONSHIP, jsonobject);
            Log.i(TAG, (new StringBuilder()).append("Sponsorship setSponsorship jsoSponsorship: ").append(jsonobject.toString()).toString());
        }
        catch(Error error)
        {
            error.printStackTrace();
            Log.i(TAG, (new StringBuilder()).append("Sponsorship setSponsorship jsoSponsorship JSONException: ").append(jsonobject.toString()).toString());
        }
        try
        {
            String s = jsonobject.getJSONArray("splash").getString(0);
            if(!s.equals(""))
                mImageWorker.loadImage(s, ivSplashSponsorship);
            return;
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
    }

    protected void updateUI()
    {
    }

    private boolean bDownloadSpon;
    public boolean cancelable;
    public ProgressDialog dialog;
    private ImageView ivSplashSponsorship;
    public JSONObject jConfFile;
    public JSONObject jConfFileMC;
    private ImageWorker mImageWorker;
    private long startTime;
    private WSSplash wsSplash;







/*
    static boolean access$302(Splash splash, boolean flag)
    {
        splash.bDownloadSpon = flag;
        return flag;
    }

*/



/*
    static long access$402(Splash splash, long l)
    {
        splash.startTime = l;
        return l;
    }

*/





}
