// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.news_section_page;

import android.content.res.Resources;
import android.support.v4.app.*;
import android.view.*;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.flurry.android.FlurryAgent;
import com.mirror.base.main.MainFragmentActivity;
import com.mirror.base.main.more_menu.MoreMenuActivity;
import com.mirror.base.main.more_menu.MoreMenuNewsFragment;
import com.mirror.base.main.sports_page.SportsPageFragment;
import com.mirror.base.main.three_am_page.ThreeAMPageFragment;
import java.util.HashMap;
import java.util.Map;
import org.json.*;

// Referenced classes of package com.mirror.base.main.news_section_page:
//            NewsSectionPageFragment, ViewHolder

public class AdapterDropDown extends BaseAdapter
{

    public AdapterDropDown(Fragment fragment)
    {
        selectedPos = -1;
        parentFragment = fragment;
        if(!fragment.getClass().getSimpleName().equals(com/mirror/base/main/news_section_page/NewsSectionPageFragment.getSimpleName())) goto _L2; else goto _L1
_L1:
        data = ((KogiActivity)fragment.getActivity()).getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_MY_NEWS);
_L4:
        mInflater = (LayoutInflater)fragment.getActivity().getSystemService("layout_inflater");
        return;
_L2:
        if(fragment.getClass().getSimpleName().equals(com/mirror/base/main/sports_page/SportsPageFragment.getSimpleName()))
            data = ((KogiActivity)fragment.getActivity()).getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_MY_FOOTBALL);
        else
        if(fragment.getClass().getSimpleName().equals(com/mirror/base/main/three_am_page/ThreeAMPageFragment.getSimpleName()))
            data = ((KogiActivity)fragment.getActivity()).getJSONArrayParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_3AM);
        else
        if(fragment.getClass().getSimpleName().equals(com/mirror/base/main/more_menu/MoreMenuNewsFragment.getSimpleName()))
            data = ((MoreMenuNewsFragment)fragment).getData();
        if(true) goto _L4; else goto _L3
_L3:
    }

    private String capitalizeFirstLetter(String s)
    {
        boolean flag = true;
        char ac[] = s.toCharArray();
        int i = 0;
        while(i < ac.length) 
        {
            if(Character.isLetter(ac[i]))
            {
                if(flag)
                    ac[i] = Character.toUpperCase(ac[i]);
                flag = false;
            } else
            {
                flag = Character.isWhitespace(ac[i]);
            }
            i++;
        }
        return new String(ac);
    }

    public int getCount()
    {
        return data.length();
    }

    public String getDropdownTitle(int i)
    {
        return ((ViewHolder)getView(i, null, null).getTag()).text.getText().toString().toLowerCase().trim();
    }

    public Object getItem(int i)
    {
        return null;
    }

    public long getItemId(int i)
    {
        return 0L;
    }

    public View getView(final int position, View view, ViewGroup viewgroup)
    {
        ViewHolder viewholder = new ViewHolder();
        if(view == null)
        {
            view = mInflater.inflate(com.mirror.base.R.layout.dropdown_item, null);
            viewholder.text = (TextView)view.findViewById(com.mirror.base.R.id.stvDropdownMenuItemText);
            view.setTag(viewholder);
        } else
        {
            viewholder = (ViewHolder)view.getTag();
        }
        if(selectedPos == -1)
            selectedPos = 0;
        if(position == selectedPos && selectedPos != -1)
            viewholder.text.setBackgroundResource(com.mirror.base.R.drawable.dropdown_selected);
        else
            viewholder.text.setBackgroundResource(com.mirror.base.R.drawable.grey_item_dropdown);
        try
        {
            String s = data.getJSONObject(position).getString("name");
            viewholder.text.setText(s);
            view.setOnTouchListener(new android.view.View.OnTouchListener() {

                public boolean onTouch(View view1, MotionEvent motionevent)
                {
                    ViewHolder viewholder1 = (ViewHolder)view1.getTag();
                    if(motionevent.getAction() != 3 && motionevent.getAction() != 1) goto _L2; else goto _L1
_L1:
                    if(position == selectedPos && selectedPos != -1)
                        viewholder1.text.setBackgroundResource(com.mirror.base.R.drawable.dropdown_selected);
                    else
                        viewholder1.text.setBackgroundResource(com.mirror.base.R.drawable.grey_item_dropdown);
_L4:
                    return false;
_L2:
                    if(position != selectedPos || selectedPos == -1)
                        viewholder1.text.setBackgroundResource(com.mirror.base.R.drawable.grey_item_feedback);
                    if(true) goto _L4; else goto _L3
_L3:
                }

                final AdapterDropDown this$0;
                final int val$position;

            
            {
                this$0 = AdapterDropDown.this;
                position = i;
                super();
            }
            });
            view.setOnClickListener(new android.view.View.OnClickListener() {

                public void onClick(View view1)
                {
                    String as[];
                    ViewHolder viewholder1 = (ViewHolder)view1.getTag();
                    if(parentFragment.getResources().getBoolean(com.mirror.base.R.bool.flurry_active))
                        FlurryAgent.onPageView();
                    boolean flag3;
                    HashMap hashmap3;
                    if(position == selectedPos && selectedPos != -1)
                        viewholder1.text.setBackgroundResource(com.mirror.base.R.drawable.dropdown_selected);
                    else
                        viewholder1.text.setBackgroundResource(com.mirror.base.R.drawable.grey_item_dropdown);
                    selectedPos = position;
                    if(!parentFragment.getClass().getSimpleName().equals(com/mirror/base/main/news_section_page/NewsSectionPageFragment.getSimpleName())) goto _L2; else goto _L1
_L1:
                    ((NewsSectionPageFragment)parentFragment).hideDropDownMenus();
                    ((NewsSectionPageFragment)parentFragment).showProgressDialog();
                    ((NewsSectionPageFragment)parentFragment).updateNews(data.getJSONObject(position).getString("name").toString(), position);
                    flag3 = parentFragment.getResources().getBoolean(com.mirror.base.R.bool.flurry_active);
                    if(!flag3)
                        break MISSING_BLOCK_LABEL_248;
                    hashmap3 = new HashMap();
                    hashmap3.put("Parameter", data.getJSONObject(position).getString("name").toString());
                    FlurryAgent.logEvent(parentFragment.getString(com.mirror.base.R.string.flurry_event_news), hashmap3);
_L8:
                    as = new String[3];
                    JSONException jsonexception1;
                    boolean flag;
                    HashMap hashmap;
                    Exception exception;
                    boolean flag1;
                    HashMap hashmap1;
                    Exception exception1;
                    boolean flag2;
                    HashMap hashmap2;
                    Exception exception2;
                    Exception exception3;
                    if(parentFragment instanceof NewsSectionPageFragment)
                        as[0] = ((MainFragmentActivity)parentFragment.getActivity()).getSLIDE_MAIN_TITLES()[1].toLowerCase().trim();
                    else
                    if(parentFragment instanceof SportsPageFragment)
                        as[0] = parentFragment.getString(com.mirror.base.R.string.omniture_app_section_sport);
                    else
                    if(parentFragment instanceof ThreeAMPageFragment)
                        as[0] = parentFragment.getString(com.mirror.base.R.string.omniture_app_section_3am);
                    else
                    if(parentFragment instanceof MoreMenuNewsFragment)
                        as[0] = ((MoreMenuActivity)parentFragment.getActivity()).getTittle().toLowerCase().trim();
                    as[1] = viewholder1.text.getText().toString().toLowerCase().trim();
                    as[2] = "section";
                    if(!(parentFragment.getActivity() instanceof MainFragmentActivity)) goto _L4; else goto _L3
_L3:
                    ((MainFragmentActivity)parentFragment.getActivity()).trackEvent(as);
_L6:
                    return;
                    exception3;
                    try
                    {
                        exception3.printStackTrace();
                    }
                    // Misplaced declaration of an exception variable
                    catch(JSONException jsonexception1)
                    {
                        jsonexception1.printStackTrace();
                    }
                    continue; /* Loop/switch isn't completed */
_L2:
                    if(!parentFragment.getClass().getSimpleName().equals(com/mirror/base/main/sports_page/SportsPageFragment.getSimpleName()))
                        break MISSING_BLOCK_LABEL_651;
                    ((SportsPageFragment)parentFragment).hideDropDownMenus();
                    if(data.getJSONObject(position).getString("name").toString().toLowerCase().equals(parentFragment.getString(com.mirror.base.R.string.match_centre_name).toLowerCase()))
                    {
                        ((SportsPageFragment)parentFragment).setMatchCentre();
                        continue; /* Loop/switch isn't completed */
                    }
                    ((SportsPageFragment)parentFragment).setMatchCentreOff();
                    ((SportsPageFragment)parentFragment).showProgressDialog();
                    ((SportsPageFragment)parentFragment).updateNews(data.getJSONObject(position).getString("name").toString(), position);
                    flag2 = parentFragment.getResources().getBoolean(com.mirror.base.R.bool.flurry_active);
                    if(!flag2)
                        continue; /* Loop/switch isn't completed */
                    hashmap2 = new HashMap();
                    hashmap2.put("Parameter", data.getJSONObject(position).getString("name").toString());
                    FlurryAgent.logEvent(parentFragment.getString(com.mirror.base.R.string.flurry_event_football), hashmap2);
                    continue; /* Loop/switch isn't completed */
                    exception2;
                    exception2.printStackTrace();
                    continue; /* Loop/switch isn't completed */
                    if(!parentFragment.getClass().getSimpleName().equals(com/mirror/base/main/three_am_page/ThreeAMPageFragment.getSimpleName()))
                        break MISSING_BLOCK_LABEL_838;
                    ((ThreeAMPageFragment)parentFragment).hideDropDownMenus();
                    ((ThreeAMPageFragment)parentFragment).showProgressDialog();
                    ((ThreeAMPageFragment)parentFragment).updateNews(data.getJSONObject(position).getString("name").toString(), position);
                    flag1 = parentFragment.getResources().getBoolean(com.mirror.base.R.bool.flurry_active);
                    if(!flag1)
                        continue; /* Loop/switch isn't completed */
                    hashmap1 = new HashMap();
                    hashmap1.put("Parameter", data.getJSONObject(position).getString("name").toString());
                    FlurryAgent.logEvent(parentFragment.getActivity().getString(com.mirror.base.R.string.flurry_event_3am), hashmap1);
                    continue; /* Loop/switch isn't completed */
                    exception1;
                    exception1.printStackTrace();
                    continue; /* Loop/switch isn't completed */
                    if(!parentFragment.getClass().getSimpleName().equals(com/mirror/base/main/more_menu/MoreMenuNewsFragment.getSimpleName()))
                        continue; /* Loop/switch isn't completed */
                    ((MoreMenuNewsFragment)parentFragment).hideDropDownMenus();
                    ((MoreMenuNewsFragment)parentFragment).showProgressDialog();
                    ((MoreMenuNewsFragment)parentFragment).updateNews(data.getJSONObject(position).getString("name").toString(), position);
                    flag = parentFragment.getResources().getBoolean(com.mirror.base.R.bool.flurry_active);
                    if(!flag)
                        continue; /* Loop/switch isn't completed */
                    hashmap = new HashMap();
                    hashmap.put("Parameter", data.getJSONObject(position).getString("name").toString());
                    FlurryAgent.logEvent(((MoreMenuNewsFragment)parentFragment).getCurrentParentSection(), hashmap);
                    continue; /* Loop/switch isn't completed */
                    exception;
                    exception.printStackTrace();
                    continue; /* Loop/switch isn't completed */
_L4:
                    if(!(parentFragment.getActivity() instanceof MoreMenuActivity)) goto _L6; else goto _L5
_L5:
                    ((MoreMenuActivity)parentFragment.getActivity()).trackEvent(as[0], as[1]);
                    return;
                    if(true) goto _L8; else goto _L7
_L7:
                }

                final AdapterDropDown this$0;
                final int val$position;

            
            {
                this$0 = AdapterDropDown.this;
                position = i;
                super();
            }
            });
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
            return view;
        }
        return view;
    }

    private JSONArray data;
    private LayoutInflater mInflater;
    private Fragment parentFragment;
    private int selectedPos;



/*
    static int access$002(AdapterDropDown adapterdropdown, int i)
    {
        adapterdropdown.selectedPos = i;
        return i;
    }

*/


}
