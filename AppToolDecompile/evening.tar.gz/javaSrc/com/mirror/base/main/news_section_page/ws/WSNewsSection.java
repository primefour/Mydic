// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.news_section_page.ws;

import android.content.Context;
import com.mirror.base.main.my_mirror_page.ws.CommandGetNews;
import org.json.JSONArray;
import org.json.JSONObject;

public class WSNewsSection
{

    public WSNewsSection(Context context1)
    {
        context = context1;
    }

    public JSONArray getNewsSectionNews(String s)
    {
        CommandGetNews commandgetnews = new CommandGetNews(context);
        JSONArray jsonarray = new JSONArray();
        JSONArray jsonarray1;
        try
        {
            commandgetnews.setUrl((new JSONObject()).put("url", s));
            commandgetnews.execute();
            jsonarray1 = ((JSONObject)commandgetnews.getResult()).getJSONArray("news");
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
            return jsonarray;
        }
        return jsonarray1;
    }

    private Context context;
}
