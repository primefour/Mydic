// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.news_section_page;

import android.widget.TextView;

public class ViewHolder
{

    public ViewHolder()
    {
    }

    public TextView text;
}
