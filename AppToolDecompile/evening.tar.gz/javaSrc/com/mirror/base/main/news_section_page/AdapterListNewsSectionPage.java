// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main.news_section_page;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.KogiActivity;
import android.text.Html;
import android.util.Log;
import android.view.*;
import android.widget.*;
import com.kogi.bitmapfun.ImageWorker;
import com.mirror.base.article_page.NewsDetailActivity;
import com.mirror.base.main.MainFragmentActivity;
import com.mirror.base.main.more_menu.MoreMenuActivity;
import com.mirror.base.main.my_mirror_page.ViewHolderMyMirror;
import com.mirror.base.main.sports_page.SportsPageFragment;
import com.mirror.base.main.three_am_page.ThreeAMPageFragment;
import org.json.*;

// Referenced classes of package com.mirror.base.main.news_section_page:
//            NewsSectionPageFragment

public class AdapterListNewsSectionPage extends BaseAdapter
{

    public AdapterListNewsSectionPage(Fragment fragment, JSONArray jsonarray, ImageWorker imageworker)
    {
        parentFragment = fragment;
        context = fragment.getActivity();
        mImageWorker = imageworker;
        if(jsonarray != null)
            data = jsonarray;
        else
            data = new JSONArray();
        if(fragment instanceof NewsSectionPageFragment)
        {
            sectionTitle = ((NewsSectionPageFragment)fragment).getCurrentSection();
            return;
        }
        if(fragment instanceof ThreeAMPageFragment)
        {
            sectionTitle = ((ThreeAMPageFragment)fragment).getCurrentSection();
            return;
        }
        if(fragment instanceof SportsPageFragment)
        {
            sectionTitle = ((SportsPageFragment)fragment).getCurrentSection();
            return;
        } else
        {
            sectionTitle = "";
            return;
        }
    }

    public int getCount()
    {
        return data.length();
    }

    public Object getItem(int i)
    {
        return null;
    }

    public long getItemId(int i)
    {
        return 0L;
    }

    public int getItemViewType(int i)
    {
        return i != 0 ? 1 : 0;
    }

    public View getView(final int position, View view, ViewGroup viewgroup)
    {
        if(view != null) goto _L2; else goto _L1
_L1:
        ViewHolderMyMirror viewholdermymirror;
        int i;
        i = getItemViewType(position);
        viewholdermymirror = null;
        i;
        JVM INSTR tableswitch 0 1: default 40
    //                   0 128
    //                   1 191;
           goto _L3 _L4 _L5
_L3:
        boolean flag;
        try
        {
            viewholdermymirror.name.setText(Html.fromHtml(data.getJSONObject(position).getString("title")));
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
        flag = data.getJSONObject(position).has("media:thumbnail");
        if(!flag)
            break MISSING_BLOCK_LABEL_308;
        String s = data.getJSONObject(position).getString("media:thumbnail");
        mImageWorker.loadImage(s, viewholdermymirror.image);
_L6:
        view.setOnClickListener(new android.view.View.OnClickListener() {

            public void onClick(View view1)
            {
                Intent intent;
                if(parentFragment instanceof SportsPageFragment)
                    ((KogiActivity)context).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.ST_CURRENT_FLURRY_SECTION, ((SportsPageFragment)parentFragment).getFlurrySection());
                else
                if(parentFragment instanceof NewsSectionPageFragment)
                    ((KogiActivity)context).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.ST_CURRENT_FLURRY_SECTION, ((NewsSectionPageFragment)parentFragment).getFlurrySection());
                else
                if(parentFragment instanceof ThreeAMPageFragment)
                    ((KogiActivity)context).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.ST_CURRENT_FLURRY_SECTION, ((ThreeAMPageFragment)parentFragment).getFlurrySection());
                else
                    Log.e("WARNING, WARNING", (new StringBuilder()).append("CASE NOT VALIDATED YET").append(parentFragment.getClass().getSimpleName()).toString());
                intent = new Intent(context, com/mirror/base/article_page/NewsDetailActivity);
                intent.setFlags(0x30000000);
                intent.putExtra("news_selected", position);
                ((KogiActivity)context).setParameter(com.mirror.base.main.MirrorNewsApp.PARAMETERS.JA_NEWS_DATA, data);
                if(sectionTitle.equals(""))
                    intent.putExtra("newsDetailsTitle", context.getString(com.mirror.base.R.string.news_news_title));
                else
                    intent.putExtra("newsDetailsTitle", sectionTitle);
                intent.putExtra("fatherActivity", parentFragment.getClass().getSimpleName());
                if(context instanceof MainFragmentActivity)
                    ((MainFragmentActivity)context).hideDropDownMenus();
                else
                    ((MoreMenuActivity)context).hideDropDownMenus();
                context.startActivity(intent);
            }

            final AdapterListNewsSectionPage this$0;
            final int val$position;

            
            {
                this$0 = AdapterListNewsSectionPage.this;
                position = i;
                super();
            }
        });
        return view;
_L4:
        view = LayoutInflater.from(context).inflate(com.mirror.base.R.layout.my_mirror_page_list_headline, null);
        viewholdermymirror = new ViewHolderMyMirror();
        viewholdermymirror.name = (TextView)view.findViewById(com.mirror.base.R.id.tVMyMirrorHeadlineTitle);
        viewholdermymirror.image = (ImageView)view.findViewById(com.mirror.base.R.id.iVMyMirrorHeadlineImage);
        view.setTag(viewholdermymirror);
          goto _L3
_L5:
        view = LayoutInflater.from(context).inflate(com.mirror.base.R.layout.my_mirror_page_list_item, null);
        viewholdermymirror = new ViewHolderMyMirror();
        viewholdermymirror.name = (TextView)view.findViewById(com.mirror.base.R.id.tVMyMirrorChildText);
        viewholdermymirror.image = (ImageView)view.findViewById(com.mirror.base.R.id.iVMyMirrorChildImage);
        view.setTag(viewholdermymirror);
          goto _L3
_L2:
        viewholdermymirror = (ViewHolderMyMirror)view.getTag();
          goto _L3
        Throwable throwable;
        throwable;
        try
        {
            viewholdermymirror.image.setImageResource(com.mirror.base.R.drawable.placeholder_big);
        }
        catch(JSONException jsonexception1)
        {
            viewholdermymirror.image.setImageResource(com.mirror.base.R.drawable.placeholder_big);
        }
          goto _L6
        viewholdermymirror.image.setImageResource(com.mirror.base.R.drawable.placeholder_big);
          goto _L6
    }

    public int getViewTypeCount()
    {
        return 2;
    }

    public void setData(JSONArray jsonarray)
    {
        data = jsonarray;
        notifyDataSetChanged();
    }

    public void setSectionTitle(String s)
    {
        sectionTitle = s;
    }

    private final int TYPE_HEADLINE = 0;
    private final int TYPE_ITEM = 1;
    private final int VIEW_TYPE_COUNT = 2;
    private Context context;
    private JSONArray data;
    private ImageWorker mImageWorker;
    private Fragment parentFragment;
    private String sectionTitle;




}
