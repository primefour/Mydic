// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package com.mirror.base.main;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Resources;
import android.support.v4.app.KogiApplication;
import android.util.Log;
import com.kogi.imagetest.im.ImageService;
import java.util.ArrayList;
import org.apache.http.client.CookieStore;
import org.apache.http.impl.client.BasicCookieStore;
import org.json.*;

public class MirrorNewsApp extends KogiApplication
{
    public static final class COMMAND extends Enum
    {

        public static COMMAND valueOf(String s)
        {
            return (COMMAND)Enum.valueOf(com/mirror/base/main/MirrorNewsApp$COMMAND, s);
        }

        public static COMMAND[] values()
        {
            return (COMMAND[])$VALUES.clone();
        }

        private static final COMMAND $VALUES[];
        public static final COMMAND ASYNC_MATCH_CENTRE_COMPETITION;
        public static final COMMAND ASYNC_MATCH_CENTRE_MATCH;
        public static final COMMAND BRIGHTCOVE;
        public static final COMMAND BRING_ME_MORE_ABOUT_NEWS;
        public static final COMMAND COMMENTS_FB_DO_ITEM_SCORE;
        public static final COMMAND COMMENTS_FB_DO_REPORT_ABUSE;
        public static final COMMAND COMMENTS_FB_RETURNING;
        public static final COMMAND COMMENTS_FB_WRITE_COMMENT;
        public static final COMMAND COMMENTS_LOAD_MORE;
        public static final COMMAND COMMENTS_ORDERED;
        public static final COMMAND COMMENTS_SCORE_REVIEW;
        public static final COMMAND GET_HOROSCOPES;
        public static final COMMAND GET_MY_MIRROR_NEWS;
        public static final COMMAND MORE_NEW_TWITTER;
        public static final COMMAND REPORT_ABUSE;
        public static final COMMAND WRITE_COMMAND;

        static 
        {
            GET_HOROSCOPES = new COMMAND("GET_HOROSCOPES", 0);
            BRING_ME_MORE_ABOUT_NEWS = new COMMAND("BRING_ME_MORE_ABOUT_NEWS", 1);
            MORE_NEW_TWITTER = new COMMAND("MORE_NEW_TWITTER", 2);
            GET_MY_MIRROR_NEWS = new COMMAND("GET_MY_MIRROR_NEWS", 3);
            BRIGHTCOVE = new COMMAND("BRIGHTCOVE", 4);
            WRITE_COMMAND = new COMMAND("WRITE_COMMAND", 5);
            COMMENTS_ORDERED = new COMMAND("COMMENTS_ORDERED", 6);
            COMMENTS_SCORE_REVIEW = new COMMAND("COMMENTS_SCORE_REVIEW", 7);
            REPORT_ABUSE = new COMMAND("REPORT_ABUSE", 8);
            COMMENTS_FB_RETURNING = new COMMAND("COMMENTS_FB_RETURNING", 9);
            COMMENTS_FB_WRITE_COMMENT = new COMMAND("COMMENTS_FB_WRITE_COMMENT", 10);
            COMMENTS_FB_DO_ITEM_SCORE = new COMMAND("COMMENTS_FB_DO_ITEM_SCORE", 11);
            COMMENTS_FB_DO_REPORT_ABUSE = new COMMAND("COMMENTS_FB_DO_REPORT_ABUSE", 12);
            COMMENTS_LOAD_MORE = new COMMAND("COMMENTS_LOAD_MORE", 13);
            ASYNC_MATCH_CENTRE_COMPETITION = new COMMAND("ASYNC_MATCH_CENTRE_COMPETITION", 14);
            ASYNC_MATCH_CENTRE_MATCH = new COMMAND("ASYNC_MATCH_CENTRE_MATCH", 15);
            COMMAND acommand[] = new COMMAND[16];
            acommand[0] = GET_HOROSCOPES;
            acommand[1] = BRING_ME_MORE_ABOUT_NEWS;
            acommand[2] = MORE_NEW_TWITTER;
            acommand[3] = GET_MY_MIRROR_NEWS;
            acommand[4] = BRIGHTCOVE;
            acommand[5] = WRITE_COMMAND;
            acommand[6] = COMMENTS_ORDERED;
            acommand[7] = COMMENTS_SCORE_REVIEW;
            acommand[8] = REPORT_ABUSE;
            acommand[9] = COMMENTS_FB_RETURNING;
            acommand[10] = COMMENTS_FB_WRITE_COMMENT;
            acommand[11] = COMMENTS_FB_DO_ITEM_SCORE;
            acommand[12] = COMMENTS_FB_DO_REPORT_ABUSE;
            acommand[13] = COMMENTS_LOAD_MORE;
            acommand[14] = ASYNC_MATCH_CENTRE_COMPETITION;
            acommand[15] = ASYNC_MATCH_CENTRE_MATCH;
            $VALUES = acommand;
        }

        private COMMAND(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class LOADERS extends Enum
    {

        public static LOADERS valueOf(String s)
        {
            return (LOADERS)Enum.valueOf(com/mirror/base/main/MirrorNewsApp$LOADERS, s);
        }

        public static LOADERS[] values()
        {
            return (LOADERS[])$VALUES.clone();
        }

        private static final LOADERS $VALUES[];
        public static final LOADERS COMMENTS_LOADER;
        public static final LOADERS DATA_LOADER;

        static 
        {
            COMMENTS_LOADER = new LOADERS("COMMENTS_LOADER", 0);
            DATA_LOADER = new LOADERS("DATA_LOADER", 1);
            LOADERS aloaders[] = new LOADERS[2];
            aloaders[0] = COMMENTS_LOADER;
            aloaders[1] = DATA_LOADER;
            $VALUES = aloaders;
        }

        private LOADERS(String s, int i)
        {
            super(s, i);
        }
    }

    public static final class PARAMETERS extends Enum
    {

        public static PARAMETERS valueOf(String s)
        {
            return (PARAMETERS)Enum.valueOf(com/mirror/base/main/MirrorNewsApp$PARAMETERS, s);
        }

        public static PARAMETERS[] values()
        {
            return (PARAMETERS[])$VALUES.clone();
        }

        private static final PARAMETERS $VALUES[];
        public static final PARAMETERS BOOL_FIRS_TIME;
        public static final PARAMETERS BOOL_HASPREFERENCES;
        public static final PARAMETERS BOOL_IS_AD_SHOWING_ARTICLE;
        public static final PARAMETERS BOOL_IS_AD_SHOWING_MAIN;
        public static final PARAMETERS BOOL_IS_AD_SHOWING_SECOND;
        public static final PARAMETERS BOOL_IS_NEWS_AD_SHOWING;
        public static final PARAMETERS BOOL_NEED_TO_REFRESH_DRAGANDDROPLIST;
        public static final PARAMETERS INT_CACHE_SIZE;
        public static final PARAMETERS INT_MAX_ARTICLES;
        public static final PARAMETERS INT_RATE_TIME;
        public static final PARAMETERS JA_3AM;
        public static final PARAMETERS JA_MORE;
        public static final PARAMETERS JA_MYCLUB;
        public static final PARAMETERS JA_MY_FOOTBALL;
        public static final PARAMETERS JA_MY_MIRROR;
        public static final PARAMETERS JA_MY_MIRROR_SELECTION;
        public static final PARAMETERS JA_MY_MIRROR_USER_SECTIONS;
        public static final PARAMETERS JA_MY_NEWS;
        public static final PARAMETERS JA_NEWS_DATA;
        public static final PARAMETERS JA_TEMP_SAVED_INSTANCE;
        public static final PARAMETERS JO_FB_DATA;
        public static final PARAMETERS JO_SPORSONSHIP;
        public static final PARAMETERS ST_CURRENT_FLURRY_SECTION;
        public static final PARAMETERS ST_LEAGUE_ID;
        public static final PARAMETERS ST_OMNITURE_ID;

        static 
        {
            JO_SPORSONSHIP = new PARAMETERS("JO_SPORSONSHIP", 0);
            BOOL_HASPREFERENCES = new PARAMETERS("BOOL_HASPREFERENCES", 1);
            JA_MY_MIRROR = new PARAMETERS("JA_MY_MIRROR", 2);
            JA_MY_MIRROR_SELECTION = new PARAMETERS("JA_MY_MIRROR_SELECTION", 3);
            JA_MY_MIRROR_USER_SECTIONS = new PARAMETERS("JA_MY_MIRROR_USER_SECTIONS", 4);
            JA_MY_NEWS = new PARAMETERS("JA_MY_NEWS", 5);
            JA_MY_FOOTBALL = new PARAMETERS("JA_MY_FOOTBALL", 6);
            JA_3AM = new PARAMETERS("JA_3AM", 7);
            JA_MORE = new PARAMETERS("JA_MORE", 8);
            INT_MAX_ARTICLES = new PARAMETERS("INT_MAX_ARTICLES", 9);
            BOOL_NEED_TO_REFRESH_DRAGANDDROPLIST = new PARAMETERS("BOOL_NEED_TO_REFRESH_DRAGANDDROPLIST", 10);
            BOOL_IS_NEWS_AD_SHOWING = new PARAMETERS("BOOL_IS_NEWS_AD_SHOWING", 11);
            BOOL_FIRS_TIME = new PARAMETERS("BOOL_FIRS_TIME", 12);
            INT_RATE_TIME = new PARAMETERS("INT_RATE_TIME", 13);
            BOOL_IS_AD_SHOWING_MAIN = new PARAMETERS("BOOL_IS_AD_SHOWING_MAIN", 14);
            BOOL_IS_AD_SHOWING_SECOND = new PARAMETERS("BOOL_IS_AD_SHOWING_SECOND", 15);
            BOOL_IS_AD_SHOWING_ARTICLE = new PARAMETERS("BOOL_IS_AD_SHOWING_ARTICLE", 16);
            INT_CACHE_SIZE = new PARAMETERS("INT_CACHE_SIZE", 17);
            JA_NEWS_DATA = new PARAMETERS("JA_NEWS_DATA", 18);
            JA_TEMP_SAVED_INSTANCE = new PARAMETERS("JA_TEMP_SAVED_INSTANCE", 19);
            ST_CURRENT_FLURRY_SECTION = new PARAMETERS("ST_CURRENT_FLURRY_SECTION", 20);
            ST_LEAGUE_ID = new PARAMETERS("ST_LEAGUE_ID", 21);
            JA_MYCLUB = new PARAMETERS("JA_MYCLUB", 22);
            ST_OMNITURE_ID = new PARAMETERS("ST_OMNITURE_ID", 23);
            JO_FB_DATA = new PARAMETERS("JO_FB_DATA", 24);
            PARAMETERS aparameters[] = new PARAMETERS[25];
            aparameters[0] = JO_SPORSONSHIP;
            aparameters[1] = BOOL_HASPREFERENCES;
            aparameters[2] = JA_MY_MIRROR;
            aparameters[3] = JA_MY_MIRROR_SELECTION;
            aparameters[4] = JA_MY_MIRROR_USER_SECTIONS;
            aparameters[5] = JA_MY_NEWS;
            aparameters[6] = JA_MY_FOOTBALL;
            aparameters[7] = JA_3AM;
            aparameters[8] = JA_MORE;
            aparameters[9] = INT_MAX_ARTICLES;
            aparameters[10] = BOOL_NEED_TO_REFRESH_DRAGANDDROPLIST;
            aparameters[11] = BOOL_IS_NEWS_AD_SHOWING;
            aparameters[12] = BOOL_FIRS_TIME;
            aparameters[13] = INT_RATE_TIME;
            aparameters[14] = BOOL_IS_AD_SHOWING_MAIN;
            aparameters[15] = BOOL_IS_AD_SHOWING_SECOND;
            aparameters[16] = BOOL_IS_AD_SHOWING_ARTICLE;
            aparameters[17] = INT_CACHE_SIZE;
            aparameters[18] = JA_NEWS_DATA;
            aparameters[19] = JA_TEMP_SAVED_INSTANCE;
            aparameters[20] = ST_CURRENT_FLURRY_SECTION;
            aparameters[21] = ST_LEAGUE_ID;
            aparameters[22] = JA_MYCLUB;
            aparameters[23] = ST_OMNITURE_ID;
            aparameters[24] = JO_FB_DATA;
            $VALUES = aparameters;
        }

        private PARAMETERS(String s, int i)
        {
            super(s, i);
        }
    }


    public MirrorNewsApp()
    {
        imageService = new ImageService(this);
    }

    public CookieStore getCookieStore()
    {
        return cookieStore;
    }

    public ImageService getImageService()
    {
        return imageService;
    }

    public String getNamebyClub(String s)
    {
        JSONArray jsonarray;
        int i;
        String s1;
        try
        {
            jsonarray = getJSONArrayParameter(PARAMETERS.JA_MYCLUB);
            i = -1 + jsonarray.length();
        }
        catch(JSONException jsonexception)
        {
            Log.w(TAG, (new StringBuilder()).append("There is not shot name for ").append(s).toString());
            Log.w(TAG, (new StringBuilder()).append("There is not shot name for ").append(s).toString());
            return "";
        }
_L2:
        if(i < 0)
            break MISSING_BLOCK_LABEL_106;
        JSONObject jsonobject = jsonarray.getJSONObject(i);
        if(jsonobject.has("id") && jsonobject.getString("id").equals(s) || jsonobject.has("team_uID") && jsonobject.getString("team_uID").equals(s))
            if(jsonobject.has("short_name"))
                return jsonobject.getString("short_name");
            else
                return jsonobject.getString("name");
        break MISSING_BLOCK_LABEL_202;
        s1 = (new JSONObject(getStringParameter(getResources().getString(com.mirror.base.R.string.parameter_jsotherclubs), (new JSONObject()).toString()))).getString(s);
        return s1;
        i--;
        if(true) goto _L2; else goto _L1
_L1:
    }

    protected void initParameters()
    {
        setParameter(PARAMETERS.BOOL_IS_AD_SHOWING_MAIN, false);
        setParameter(PARAMETERS.BOOL_IS_AD_SHOWING_SECOND, false);
        setParameter(PARAMETERS.BOOL_IS_AD_SHOWING_ARTICLE, false);
        setParameter(PARAMETERS.JO_FB_DATA, new JSONObject());
        cookieStore = new BasicCookieStore();
    }

    public void onCreate()
    {
        super.onCreate();
    }

    public void putOtherName(String s, String s1)
        throws JSONException
    {
        JSONObject jsonobject = new JSONObject(getStringParameter(getResources().getString(com.mirror.base.R.string.parameter_jsotherclubs), (new JSONObject()).toString()));
        jsonobject.put(s, s1);
        setParameter(getResources().getString(com.mirror.base.R.string.parameter_jsotherclubs), jsonobject.toString());
    }

    public void setImageService(ImageService imageservice)
    {
        imageService = imageservice;
    }

    public void showNoInternetMessage(Context context)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setTitle("You're now offline.");
        builder.setMessage("You can still read articles you've already downloaded, but please connect to the internet to see all the images and videos.");
        builder.setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialoginterface, int i)
            {
                dialoginterface.dismiss();
            }

            final MirrorNewsApp this$0;

            
            {
                this$0 = MirrorNewsApp.this;
                super();
            }
        });
        builder.create().show();
    }

    public void updateConfig(JSONObject jsonobject)
        throws JSONException
    {
        JSONArray jsonarray;
        int i;
        if(!jsonobject.getString("version").equals("1.0"))
            break MISSING_BLOCK_LABEL_518;
        jsonarray = jsonobject.getJSONArray("tabs");
        i = 0;
_L6:
        JSONObject jsonobject1;
        if(i >= jsonarray.length())
            break MISSING_BLOCK_LABEL_518;
        jsonobject1 = jsonarray.getJSONObject(i);
        jsonobject1.getInt("order");
        JVM INSTR tableswitch 1 7: default 88
    //                   1 94
    //                   2 88
    //                   3 88
    //                   4 88
    //                   5 88
    //                   6 328
    //                   7 423;
           goto _L1 _L2 _L1 _L1 _L1 _L1 _L3 _L4
_L4:
        break MISSING_BLOCK_LABEL_423;
_L1:
        break; /* Loop/switch isn't completed */
_L2:
        break; /* Loop/switch isn't completed */
_L7:
        i++;
        if(true) goto _L6; else goto _L5
_L5:
        JSONArray jsonarray5 = new JSONArray();
        JSONArray jsonarray6 = jsonobject1.getJSONArray("sections");
        JSONArray jsonarray7 = new JSONArray();
        int i1 = 0;
        do
        {
            int j1 = jsonarray6.length();
            if(i1 >= j1)
                break;
            JSONObject jsonobject2 = jsonarray6.getJSONObject(i1);
            JSONObject jsonobject3 = new JSONObject();
            jsonobject3.put("leagueName", jsonobject2.get("League"));
            jsonobject3.put("leagueId", jsonobject2.get("LeagueID"));
            JSONArray jsonarray8 = new JSONArray();
            int k1 = 0;
            do
            {
                int l1 = jsonobject2.getJSONArray("sections").length();
                if(k1 >= l1)
                    break;
                JSONObject jsonobject4 = jsonobject2.getJSONArray("sections").getJSONObject(k1);
                JSONObject jsonobject5 = new JSONObject();
                jsonobject5.put("id", jsonobject4.get("id"));
                jsonobject5.put("name", jsonobject4.get("name"));
                jsonarray7.put(jsonobject5);
                jsonarray8.put(jsonobject5);
                k1++;
            } while(true);
            jsonobject3.put("leagueClubs", jsonarray8);
            jsonarray5.put(jsonobject3);
            i1++;
        } while(true);
        setParameter(PARAMETERS.JA_MYCLUB, jsonarray7);
          goto _L7
_L3:
        setParameter(getResources().getString(com.mirror.base.R.string.parameter_season), jsonobject1.getString("season"));
        setParameter(getResources().getString(com.mirror.base.R.string.parameter_jsleagues), jsonobject1.getJSONArray("leagues").toString());
        JSONArray jsonarray4 = jsonobject1.getJSONArray("competitions");
        ArrayList arraylist = new ArrayList();
        int l = 0;
        while(l < jsonarray4.length()) 
        {
            arraylist.add(jsonarray4.getString(l));
            l++;
        }
          goto _L7
        JSONArray jsonarray1 = getJSONArrayParameter(PARAMETERS.JA_MYCLUB);
        JSONArray jsonarray2 = jsonobject1.getJSONArray("leagues");
        for(int j = 0; j < jsonarray2.length(); j++)
        {
            JSONArray jsonarray3 = jsonarray2.getJSONObject(j).getJSONArray("sections");
            for(int k = 0; k < jsonarray3.length(); k++)
                jsonarray1.put(jsonarray3.getJSONObject(k));

        }

        setParameter(PARAMETERS.JA_MYCLUB, jsonarray1);
          goto _L7
    }

    public void updateConfig2(JSONArray jsonarray)
        throws JSONException
    {
        setParameter(getResources().getString(com.mirror.base.R.string.parameter_season), jsonarray.getJSONObject(0).getString("season"));
        setParameter(getResources().getString(com.mirror.base.R.string.parameter_jsleagues), jsonarray.getJSONObject(0).getJSONArray("leagues").toString());
        JSONArray jsonarray1 = jsonarray.getJSONObject(0).getJSONArray("competitions");
        ArrayList arraylist = new ArrayList();
        for(int i = 0; i < jsonarray1.length(); i++)
            arraylist.add(jsonarray1.getString(i));

        JSONArray jsonarray2 = getJSONArrayParameter(PARAMETERS.JA_MYCLUB);
        JSONArray jsonarray3 = jsonarray.getJSONObject(1).getJSONArray("leagues");
        for(int j = 0; j < jsonarray3.length(); j++)
        {
            JSONArray jsonarray4 = jsonarray3.getJSONObject(j).getJSONArray("sections");
            for(int k = 0; k < jsonarray4.length(); k++)
                jsonarray2.put(jsonarray4.getJSONObject(k));

        }

        setParameter(PARAMETERS.JA_MYCLUB, jsonarray2);
    }

    private CookieStore cookieStore;
    private ImageService imageService;
}
