// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package oauth.signpost;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;
import oauth.signpost.exception.OAuthNotAuthorizedException;
import oauth.signpost.http.HttpParameters;
import oauth.signpost.http.HttpRequest;
import oauth.signpost.http.HttpResponse;

// Referenced classes of package oauth.signpost:
//            OAuthProvider, OAuthConsumer, OAuth, OAuthProviderListener

public abstract class AbstractOAuthProvider
    implements OAuthProvider
{

    public AbstractOAuthProvider(String s, String s1, String s2)
    {
        requestTokenEndpointUrl = s;
        accessTokenEndpointUrl = s1;
        authorizationWebsiteUrl = s2;
        responseParameters = new HttpParameters();
        defaultHeaders = new HashMap();
    }

    protected void closeConnection(HttpRequest httprequest, HttpResponse httpresponse)
        throws Exception
    {
    }

    protected abstract HttpRequest createRequest(String s)
        throws Exception;

    public String getAccessTokenEndpointUrl()
    {
        return accessTokenEndpointUrl;
    }

    public String getAuthorizationWebsiteUrl()
    {
        return authorizationWebsiteUrl;
    }

    public Map getRequestHeaders()
    {
        return defaultHeaders;
    }

    public String getRequestTokenEndpointUrl()
    {
        return requestTokenEndpointUrl;
    }

    protected String getResponseParameter(String s)
    {
        return responseParameters.getFirst(s);
    }

    public HttpParameters getResponseParameters()
    {
        return responseParameters;
    }

    protected void handleUnexpectedResponse(int i, HttpResponse httpresponse)
        throws Exception
    {
        if(httpresponse == null)
            return;
        BufferedReader bufferedreader = new BufferedReader(new InputStreamReader(httpresponse.getContent()));
        StringBuilder stringbuilder = new StringBuilder();
        for(String s = bufferedreader.readLine(); s != null; s = bufferedreader.readLine())
            stringbuilder.append(s);

        switch(i)
        {
        default:
            throw new OAuthCommunicationException((new StringBuilder()).append("Service provider responded in error: ").append(i).append(" (").append(httpresponse.getReasonPhrase()).append(")").toString(), stringbuilder.toString());

        case 401: 
            throw new OAuthNotAuthorizedException(stringbuilder.toString());
        }
    }

    public boolean isOAuth10a()
    {
        return isOAuth10a;
    }

    public void removeListener(OAuthProviderListener oauthproviderlistener)
    {
        listener = null;
    }

    public void retrieveAccessToken(OAuthConsumer oauthconsumer, String s)
        throws OAuthMessageSignerException, OAuthNotAuthorizedException, OAuthExpectationFailedException, OAuthCommunicationException
    {
        if(oauthconsumer.getToken() == null || oauthconsumer.getTokenSecret() == null)
            throw new OAuthExpectationFailedException("Authorized request token or token secret not set. Did you retrieve an authorized request token before?");
        if(isOAuth10a && s != null)
        {
            retrieveToken(oauthconsumer, accessTokenEndpointUrl, new String[] {
                "oauth_verifier", s
            });
            return;
        } else
        {
            retrieveToken(oauthconsumer, accessTokenEndpointUrl, new String[0]);
            return;
        }
    }

    public String retrieveRequestToken(OAuthConsumer oauthconsumer, String s)
        throws OAuthMessageSignerException, OAuthNotAuthorizedException, OAuthExpectationFailedException, OAuthCommunicationException
    {
        oauthconsumer.setTokenWithSecret(null, null);
        retrieveToken(oauthconsumer, requestTokenEndpointUrl, new String[] {
            "oauth_callback", s
        });
        String s1 = responseParameters.getFirst("oauth_callback_confirmed");
        responseParameters.remove("oauth_callback_confirmed");
        isOAuth10a = Boolean.TRUE.toString().equals(s1);
        if(isOAuth10a)
        {
            String s3 = authorizationWebsiteUrl;
            String as1[] = new String[2];
            as1[0] = "oauth_token";
            as1[1] = oauthconsumer.getToken();
            return OAuth.addQueryParameters(s3, as1);
        } else
        {
            String s2 = authorizationWebsiteUrl;
            String as[] = new String[4];
            as[0] = "oauth_token";
            as[1] = oauthconsumer.getToken();
            as[2] = "oauth_callback";
            as[3] = s;
            return OAuth.addQueryParameters(s2, as);
        }
    }

    protected transient void retrieveToken(OAuthConsumer oauthconsumer, String s, String as[])
        throws OAuthMessageSignerException, OAuthCommunicationException, OAuthNotAuthorizedException, OAuthExpectationFailedException
    {
        Map map;
        HttpRequest httprequest;
        HttpResponse httpresponse;
        map = getRequestHeaders();
        if(oauthconsumer.getConsumerKey() == null || oauthconsumer.getConsumerSecret() == null)
            throw new OAuthExpectationFailedException("Consumer key or secret not set");
        httprequest = null;
        httpresponse = null;
        Iterator iterator;
        httprequest = createRequest(s);
        iterator = map.keySet().iterator();
_L1:
        boolean flag = iterator.hasNext();
        httpresponse = null;
        if(!flag)
            break MISSING_BLOCK_LABEL_132;
        String s1 = (String)iterator.next();
        httprequest.setHeader(s1, (String)map.get(s1));
          goto _L1
        OAuthNotAuthorizedException oauthnotauthorizedexception;
        oauthnotauthorizedexception;
        throw oauthnotauthorizedexception;
        Exception exception1;
        exception1;
        Exception exception;
        OAuthExpectationFailedException oauthexpectationfailedexception;
        OAuthProviderListener oauthproviderlistener;
        OAuthProviderListener oauthproviderlistener1;
        int i;
        OAuthProviderListener oauthproviderlistener2;
        boolean flag1;
        boolean flag2;
        HttpParameters httpparameters;
        String s2;
        String s3;
        Exception exception3;
        Exception exception4;
        HttpParameters httpparameters1;
        try
        {
            closeConnection(httprequest, httpresponse);
        }
        catch(Exception exception2)
        {
            throw new OAuthCommunicationException(exception2);
        }
        throw exception1;
        if(as == null)
            break MISSING_BLOCK_LABEL_160;
        httpparameters1 = new HttpParameters();
        httpparameters1.putAll(as, true);
        oauthconsumer.setAdditionalParameters(httpparameters1);
        oauthproviderlistener = listener;
        httpresponse = null;
        if(oauthproviderlistener == null)
            break MISSING_BLOCK_LABEL_185;
        listener.prepareRequest(httprequest);
        oauthconsumer.sign(httprequest);
        oauthproviderlistener1 = listener;
        httpresponse = null;
        if(oauthproviderlistener1 == null)
            break MISSING_BLOCK_LABEL_219;
        listener.prepareSubmission(httprequest);
        httpresponse = sendRequest(httprequest);
        i = httpresponse.getStatusCode();
        oauthproviderlistener2 = listener;
        flag1 = false;
        if(oauthproviderlistener2 == null)
            break MISSING_BLOCK_LABEL_269;
        flag2 = listener.onResponseReceived(httprequest, httpresponse);
        flag1 = flag2;
        if(flag1)
            try
            {
                closeConnection(httprequest, httpresponse);
                return;
            }
            // Misplaced declaration of an exception variable
            catch(Exception exception4)
            {
                throw new OAuthCommunicationException(exception4);
            }
        if(i < 300)
            break MISSING_BLOCK_LABEL_311;
        handleUnexpectedResponse(i, httpresponse);
        httpparameters = OAuth.decodeForm(httpresponse.getContent());
        s2 = httpparameters.getFirst("oauth_token");
        s3 = httpparameters.getFirst("oauth_token_secret");
        httpparameters.remove("oauth_token");
        httpparameters.remove("oauth_token_secret");
        setResponseParameters(httpparameters);
        if(s2 != null && s3 != null)
            break MISSING_BLOCK_LABEL_391;
        throw new OAuthExpectationFailedException("Request token or token secret not set in server reply. The service provider you use is probably buggy.");
        oauthexpectationfailedexception;
        throw oauthexpectationfailedexception;
        oauthconsumer.setTokenWithSecret(s2, s3);
        try
        {
            closeConnection(httprequest, httpresponse);
            return;
        }
        // Misplaced declaration of an exception variable
        catch(Exception exception3)
        {
            throw new OAuthCommunicationException(exception3);
        }
        exception;
        throw new OAuthCommunicationException(exception);
    }

    protected abstract HttpResponse sendRequest(HttpRequest httprequest)
        throws Exception;

    public void setListener(OAuthProviderListener oauthproviderlistener)
    {
        listener = oauthproviderlistener;
    }

    public void setOAuth10a(boolean flag)
    {
        isOAuth10a = flag;
    }

    public void setRequestHeader(String s, String s1)
    {
        defaultHeaders.put(s, s1);
    }

    public void setResponseParameters(HttpParameters httpparameters)
    {
        responseParameters = httpparameters;
    }

    private static final long serialVersionUID = 1L;
    private String accessTokenEndpointUrl;
    private String authorizationWebsiteUrl;
    private Map defaultHeaders;
    private boolean isOAuth10a;
    private transient OAuthProviderListener listener;
    private String requestTokenEndpointUrl;
    private HttpParameters responseParameters;
}
