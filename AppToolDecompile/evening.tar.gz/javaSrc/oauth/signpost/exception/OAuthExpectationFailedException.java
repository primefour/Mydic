// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package oauth.signpost.exception;


// Referenced classes of package oauth.signpost.exception:
//            OAuthException

public class OAuthExpectationFailedException extends OAuthException
{

    public OAuthExpectationFailedException(String s)
    {
        super(s);
    }
}
