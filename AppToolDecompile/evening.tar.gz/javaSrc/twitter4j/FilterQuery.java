// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import twitter4j.internal.http.HttpParameter;
import twitter4j.internal.util.z_T4JInternalStringUtil;

public final class FilterQuery
    implements Serializable
{

    public FilterQuery()
    {
        count = 0;
        follow = null;
        track = null;
        locations = (double[][])null;
    }

    public FilterQuery(int i, long al[])
    {
        this();
        count = i;
        follow = al;
    }

    public FilterQuery(int i, long al[], String as[])
    {
        this();
        count = i;
        follow = al;
        track = as;
    }

    public FilterQuery(int i, long al[], String as[], double ad[][])
    {
        count = i;
        follow = al;
        track = as;
        locations = ad;
    }

    public FilterQuery(long al[])
    {
        this();
        count = 0;
        follow = al;
    }

    private String toLocationsString(double ad[][])
    {
        StringBuffer stringbuffer = new StringBuffer(2 * (20 * ad.length));
        int i = ad.length;
        for(int j = 0; j < i; j++)
        {
            double ad1[] = ad[j];
            if(stringbuffer.length() != 0)
                stringbuffer.append(",");
            stringbuffer.append(ad1[0]);
            stringbuffer.append(",");
            stringbuffer.append(ad1[1]);
        }

        return stringbuffer.toString();
    }

    HttpParameter[] asHttpParameterArray()
    {
        ArrayList arraylist = new ArrayList();
        arraylist.add(new HttpParameter("count", count));
        if(follow != null && follow.length > 0)
            arraylist.add(new HttpParameter("follow", z_T4JInternalStringUtil.join(follow)));
        if(track != null && track.length > 0)
            arraylist.add(new HttpParameter("track", z_T4JInternalStringUtil.join(track)));
        if(locations != null && locations.length > 0)
            arraylist.add(new HttpParameter("locations", toLocationsString(locations)));
        if(includeEntities)
            arraylist.add(new HttpParameter("include_entities", true));
        return (HttpParameter[])arraylist.toArray(new HttpParameter[arraylist.size()]);
    }

    public FilterQuery count(int i)
    {
        count = i;
        return this;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            FilterQuery filterquery = (FilterQuery)obj;
            if(count != filterquery.count)
                return false;
            if(!Arrays.equals(follow, filterquery.follow))
                return false;
            if(!Arrays.equals(track, filterquery.track))
                return false;
        }
        return true;
    }

    public FilterQuery follow(long al[])
    {
        follow = al;
        return this;
    }

    public int hashCode()
    {
        int i = 31 * count;
        int j;
        int k;
        String as[];
        int l;
        if(follow != null)
            j = Arrays.hashCode(follow);
        else
            j = 0;
        k = 31 * (i + j);
        as = track;
        l = 0;
        if(as != null)
            l = Arrays.hashCode(track);
        return k + l;
    }

    public FilterQuery locations(double ad[][])
    {
        locations = ad;
        return this;
    }

    public FilterQuery setIncludeEntities(boolean flag)
    {
        includeEntities = flag;
        return this;
    }

    public String toString()
    {
        StringBuffer stringbuffer = (new StringBuffer()).append("FilterQuery{count=").append(count).append(", follow=").append(Arrays.toString(follow)).append(", track=");
        java.util.List list;
        StringBuffer stringbuffer1;
        double ad[][];
        java.util.List list1;
        if(track == null)
            list = null;
        else
            list = Arrays.asList(track);
        stringbuffer1 = stringbuffer.append(list).append(", locations=");
        ad = locations;
        list1 = null;
        if(ad != null)
            list1 = Arrays.asList(locations);
        return stringbuffer1.append(list1).append(", includeEntities=").append(includeEntities).append('}').toString();
    }

    public FilterQuery track(String as[])
    {
        track = as;
        return this;
    }

    private static final long serialVersionUID = 0x5fb19dc48ce2331L;
    private int count;
    private long follow[];
    private boolean includeEntities;
    private double locations[][];
    private String track[];
}
