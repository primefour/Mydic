// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.json;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import twitter4j.*;
import twitter4j.internal.org.json.*;

// Referenced classes of package twitter4j.json:
//            JSONObjectType

public final class DataObjectFactory
{

    private DataObjectFactory()
    {
        throw new AssertionError("not intended to be instantiated.");
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    static void clearThreadLocalMap()
    {
        ((Map)rawJsonMap.get()).clear();
    }

    public static AccountTotals createAccountTotals(String s)
        throws TwitterException
    {
        AccountTotals accounttotals;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            accounttotals = (AccountTotals)accountTotalsConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return accounttotals;
    }

    public static Category createCategory(String s)
        throws TwitterException
    {
        Category category;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            category = (Category)categoryConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return category;
    }

    public static DirectMessage createDirectMessage(String s)
        throws TwitterException
    {
        DirectMessage directmessage;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            directmessage = (DirectMessage)directMessageConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return directmessage;
    }

    public static IDs createIDs(String s)
        throws TwitterException
    {
        IDs ids;
        try
        {
            ids = (IDs)IDsConstructor.newInstance(new Object[] {
                s
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        return ids;
    }

    public static Location createLocation(String s)
        throws TwitterException
    {
        Location location;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            location = (Location)locationConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return location;
    }

    public static Object createObject(String s)
        throws TwitterException
    {
        JSONObject jsonobject;
label0:
        {
            JSONObjectType jsonobjecttype;
            JSONObjectType jsonobjecttype1;
            try
            {
                jsonobject = new JSONObject(s);
                jsonobjecttype = JSONObjectType.determine(jsonobject);
                if(JSONObjectType.SENDER == jsonobjecttype)
                {
                    Constructor constructor2 = directMessageConstructor;
                    Object aobj2[] = new Object[1];
                    aobj2[0] = jsonobject.getJSONObject("direct_message");
                    return registerJSONObject(constructor2.newInstance(aobj2), jsonobject);
                }
                if(JSONObjectType.STATUS == jsonobjecttype)
                    return registerJSONObject(statusConstructor.newInstance(new Object[] {
                        jsonobject
                    }), jsonobject);
                if(JSONObjectType.DIRECT_MESSAGE == jsonobjecttype)
                {
                    Constructor constructor1 = directMessageConstructor;
                    Object aobj1[] = new Object[1];
                    aobj1[0] = jsonobject.getJSONObject("direct_message");
                    return registerJSONObject(constructor1.newInstance(aobj1), jsonobject);
                }
                if(JSONObjectType.DELETE == jsonobjecttype)
                {
                    Constructor constructor = statusDeletionNoticeConstructor;
                    Object aobj[] = new Object[1];
                    aobj[0] = jsonobject.getJSONObject("delete").getJSONObject("status");
                    return registerJSONObject(constructor.newInstance(aobj), jsonobject);
                }
                if(JSONObjectType.LIMIT == jsonobjecttype)
                    break label0;
                jsonobjecttype1 = JSONObjectType.SCRUB_GEO;
            }
            catch(InstantiationException instantiationexception)
            {
                throw new TwitterException(instantiationexception);
            }
            catch(IllegalAccessException illegalaccessexception)
            {
                throw new AssertionError(illegalaccessexception);
            }
            catch(InvocationTargetException invocationtargetexception)
            {
                throw new TwitterException(invocationtargetexception);
            }
            catch(JSONException jsonexception)
            {
                throw new TwitterException(jsonexception);
            }
            if(jsonobjecttype1 == jsonobjecttype)
                return jsonobject;
        }
        return jsonobject;
    }

    public static Place createPlace(String s)
        throws TwitterException
    {
        Place place;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            place = (Place)placeConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return place;
    }

    public static RateLimitStatus createRateLimitStatus(String s)
        throws TwitterException
    {
        RateLimitStatus ratelimitstatus;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            ratelimitstatus = (RateLimitStatus)rateLimitStatusConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return ratelimitstatus;
    }

    public static RelatedResults createRelatedResults(String s)
        throws TwitterException
    {
        RelatedResults relatedresults;
        try
        {
            JSONArray jsonarray = new JSONArray(s);
            relatedresults = (RelatedResults)relatedResultsConstructor.newInstance(new Object[] {
                jsonarray
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return relatedresults;
    }

    public static Relationship createRelationship(String s)
        throws TwitterException
    {
        Relationship relationship;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            relationship = (Relationship)relationshipConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return relationship;
    }

    public static SavedSearch createSavedSearch(String s)
        throws TwitterException
    {
        SavedSearch savedsearch;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            savedsearch = (SavedSearch)savedSearchConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return savedsearch;
    }

    public static Status createStatus(String s)
        throws TwitterException
    {
        Status status;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            status = (Status)statusConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return status;
    }

    public static Trend createTrend(String s)
        throws TwitterException
    {
        Trend trend;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            trend = (Trend)trendConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return trend;
    }

    public static Trends createTrends(String s)
        throws TwitterException
    {
        Trends trends;
        try
        {
            trends = (Trends)trendsConstructor.newInstance(new Object[] {
                s
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new TwitterException(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
        return trends;
    }

    public static Tweet createTweet(String s)
        throws TwitterException
    {
        Tweet tweet;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            tweet = (Tweet)tweetConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return tweet;
    }

    public static User createUser(String s)
        throws TwitterException
    {
        User user;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            user = (User)userConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return user;
    }

    public static UserList createUserList(String s)
        throws TwitterException
    {
        UserList userlist;
        try
        {
            JSONObject jsonobject = new JSONObject(s);
            userlist = (UserList)userListConstructor.newInstance(new Object[] {
                jsonobject
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new TwitterException(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new TwitterException(invocationtargetexception);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        return userlist;
    }

    public static String getRawJSON(Object obj)
    {
        Object obj1 = ((Map)rawJsonMap.get()).get(obj);
        if(obj1 instanceof String)
            return (String)obj1;
        if(obj1 != null)
            return obj1.toString();
        else
            return null;
    }

    static Object registerJSONObject(Object obj, Object obj1)
    {
        ((Map)rawJsonMap.get()).put(obj, obj1);
        return obj;
    }

    private static final Constructor IDsConstructor;
    private static final Constructor accountTotalsConstructor;
    private static final Constructor categoryConstructor;
    static Class class$java$lang$String;
    static Class class$twitter4j$internal$org$json$JSONArray;
    static Class class$twitter4j$internal$org$json$JSONObject;
    private static final Constructor directMessageConstructor;
    private static final Constructor locationConstructor;
    private static final Constructor placeConstructor;
    private static final Constructor rateLimitStatusConstructor;
    private static final ThreadLocal rawJsonMap;
    private static final Constructor relatedResultsConstructor;
    private static final Constructor relationshipConstructor;
    private static final Constructor savedSearchConstructor;
    private static final Constructor statusConstructor;
    private static final Constructor statusDeletionNoticeConstructor;
    private static final Constructor trendConstructor;
    private static final Constructor trendsConstructor;
    private static final Constructor tweetConstructor;
    private static final Constructor userConstructor;
    private static final Constructor userListConstructor;

    static 
    {
        Class class1;
        Class aclass[];
        class1 = Class.forName("twitter4j.internal.json.StatusJSONImpl");
        aclass = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L2; else goto _L1
_L1:
        Class class2;
        class2 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class2;
_L33:
        Class class3;
        Class aclass1[];
        aclass[0] = class2;
        statusConstructor = class1.getDeclaredConstructor(aclass);
        statusConstructor.setAccessible(true);
        class3 = Class.forName("twitter4j.internal.json.UserJSONImpl");
        aclass1 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L4; else goto _L3
_L3:
        Class class4;
        class4 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class4;
_L34:
        Class class5;
        Class aclass2[];
        aclass1[0] = class4;
        userConstructor = class3.getDeclaredConstructor(aclass1);
        userConstructor.setAccessible(true);
        class5 = Class.forName("twitter4j.internal.json.TweetJSONImpl");
        aclass2 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L6; else goto _L5
_L5:
        Class class6;
        class6 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class6;
_L35:
        Class class7;
        Class aclass3[];
        aclass2[0] = class6;
        tweetConstructor = class5.getDeclaredConstructor(aclass2);
        tweetConstructor.setAccessible(true);
        class7 = Class.forName("twitter4j.internal.json.RelationshipJSONImpl");
        aclass3 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L8; else goto _L7
_L7:
        Class class8;
        class8 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class8;
_L36:
        Class class9;
        Class aclass4[];
        aclass3[0] = class8;
        relationshipConstructor = class7.getDeclaredConstructor(aclass3);
        relationshipConstructor.setAccessible(true);
        class9 = Class.forName("twitter4j.internal.json.PlaceJSONImpl");
        aclass4 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L10; else goto _L9
_L9:
        Class class10;
        class10 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class10;
_L37:
        Class class11;
        Class aclass5[];
        aclass4[0] = class10;
        placeConstructor = class9.getDeclaredConstructor(aclass4);
        placeConstructor.setAccessible(true);
        class11 = Class.forName("twitter4j.internal.json.SavedSearchJSONImpl");
        aclass5 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L12; else goto _L11
_L11:
        Class class12;
        class12 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class12;
_L38:
        Class class13;
        Class aclass6[];
        aclass5[0] = class12;
        savedSearchConstructor = class11.getDeclaredConstructor(aclass5);
        savedSearchConstructor.setAccessible(true);
        class13 = Class.forName("twitter4j.internal.json.TrendJSONImpl");
        aclass6 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L14; else goto _L13
_L13:
        Class class14;
        class14 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class14;
_L39:
        Class class15;
        Class aclass7[];
        aclass6[0] = class14;
        trendConstructor = class13.getDeclaredConstructor(aclass6);
        trendConstructor.setAccessible(true);
        class15 = Class.forName("twitter4j.internal.json.TrendsJSONImpl");
        aclass7 = new Class[1];
        if(class$java$lang$String != null) goto _L16; else goto _L15
_L15:
        Class class16;
        class16 = _mthclass$("java.lang.String");
        class$java$lang$String = class16;
_L40:
        Class class17;
        Class aclass8[];
        aclass7[0] = class16;
        trendsConstructor = class15.getDeclaredConstructor(aclass7);
        trendsConstructor.setAccessible(true);
        class17 = Class.forName("twitter4j.internal.json.IDsJSONImpl");
        aclass8 = new Class[1];
        if(class$java$lang$String != null) goto _L18; else goto _L17
_L17:
        Class class18;
        class18 = _mthclass$("java.lang.String");
        class$java$lang$String = class18;
_L41:
        Class class19;
        Class aclass9[];
        aclass8[0] = class18;
        IDsConstructor = class17.getDeclaredConstructor(aclass8);
        IDsConstructor.setAccessible(true);
        class19 = Class.forName("twitter4j.internal.json.RateLimitStatusJSONImpl");
        aclass9 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L20; else goto _L19
_L19:
        Class class20;
        class20 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class20;
_L42:
        Class class21;
        Class aclass10[];
        aclass9[0] = class20;
        rateLimitStatusConstructor = class19.getDeclaredConstructor(aclass9);
        rateLimitStatusConstructor.setAccessible(true);
        class21 = Class.forName("twitter4j.internal.json.CategoryJSONImpl");
        aclass10 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L22; else goto _L21
_L21:
        Class class22;
        class22 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class22;
_L43:
        Class class23;
        Class aclass11[];
        aclass10[0] = class22;
        categoryConstructor = class21.getDeclaredConstructor(aclass10);
        categoryConstructor.setAccessible(true);
        class23 = Class.forName("twitter4j.internal.json.DirectMessageJSONImpl");
        aclass11 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L24; else goto _L23
_L23:
        Class class24;
        class24 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class24;
_L44:
        Class class25;
        Class aclass12[];
        aclass11[0] = class24;
        directMessageConstructor = class23.getDeclaredConstructor(aclass11);
        directMessageConstructor.setAccessible(true);
        class25 = Class.forName("twitter4j.internal.json.LocationJSONImpl");
        aclass12 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L26; else goto _L25
_L25:
        Class class26;
        class26 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class26;
_L45:
        Class class27;
        Class aclass13[];
        aclass12[0] = class26;
        locationConstructor = class25.getDeclaredConstructor(aclass12);
        locationConstructor.setAccessible(true);
        class27 = Class.forName("twitter4j.internal.json.UserListJSONImpl");
        aclass13 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L28; else goto _L27
_L27:
        Class class28;
        class28 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class28;
_L46:
        Class class29;
        Class aclass14[];
        aclass13[0] = class28;
        userListConstructor = class27.getDeclaredConstructor(aclass13);
        userListConstructor.setAccessible(true);
        class29 = Class.forName("twitter4j.internal.json.RelatedResultsJSONImpl");
        aclass14 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONArray != null) goto _L30; else goto _L29
_L29:
        Class class30;
        class30 = _mthclass$("twitter4j.internal.org.json.JSONArray");
        class$twitter4j$internal$org$json$JSONArray = class30;
_L47:
        Class class31;
        Class aclass15[];
        aclass14[0] = class30;
        relatedResultsConstructor = class29.getDeclaredConstructor(aclass14);
        relatedResultsConstructor.setAccessible(true);
        class31 = Class.forName("twitter4j.StatusDeletionNoticeImpl");
        aclass15 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null) goto _L32; else goto _L31
_L31:
        Class class32;
        class32 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class32;
_L48:
        Class class33;
        Class aclass16[];
        Class class34;
        aclass15[0] = class32;
        statusDeletionNoticeConstructor = class31.getDeclaredConstructor(aclass15);
        statusDeletionNoticeConstructor.setAccessible(true);
        class33 = Class.forName("twitter4j.internal.json.AccountTotalsJSONImpl");
        aclass16 = new Class[1];
        if(class$twitter4j$internal$org$json$JSONObject != null)
            break MISSING_BLOCK_LABEL_1052;
        class34 = _mthclass$("twitter4j.internal.org.json.JSONObject");
        class$twitter4j$internal$org$json$JSONObject = class34;
_L49:
        aclass16[0] = class34;
        accountTotalsConstructor = class33.getDeclaredConstructor(aclass16);
        accountTotalsConstructor.setAccessible(true);
        rawJsonMap = new ThreadLocal() {

            protected Object initialValue()
            {
                return initialValue();
            }

            protected Map initialValue()
            {
                return new HashMap();
            }

        };
        return;
_L2:
        try
        {
            class2 = class$twitter4j$internal$org$json$JSONObject;
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new ExceptionInInitializerError(nosuchmethodexception);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw new ExceptionInInitializerError(classnotfoundexception);
        }
          goto _L33
_L4:
        class4 = class$twitter4j$internal$org$json$JSONObject;
          goto _L34
_L6:
        class6 = class$twitter4j$internal$org$json$JSONObject;
          goto _L35
_L8:
        class8 = class$twitter4j$internal$org$json$JSONObject;
          goto _L36
_L10:
        class10 = class$twitter4j$internal$org$json$JSONObject;
          goto _L37
_L12:
        class12 = class$twitter4j$internal$org$json$JSONObject;
          goto _L38
_L14:
        class14 = class$twitter4j$internal$org$json$JSONObject;
          goto _L39
_L16:
        class16 = class$java$lang$String;
          goto _L40
_L18:
        class18 = class$java$lang$String;
          goto _L41
_L20:
        class20 = class$twitter4j$internal$org$json$JSONObject;
          goto _L42
_L22:
        class22 = class$twitter4j$internal$org$json$JSONObject;
          goto _L43
_L24:
        class24 = class$twitter4j$internal$org$json$JSONObject;
          goto _L44
_L26:
        class26 = class$twitter4j$internal$org$json$JSONObject;
          goto _L45
_L28:
        class28 = class$twitter4j$internal$org$json$JSONObject;
          goto _L46
_L30:
        class30 = class$twitter4j$internal$org$json$JSONArray;
          goto _L47
_L32:
        class32 = class$twitter4j$internal$org$json$JSONObject;
          goto _L48
        class34 = class$twitter4j$internal$org$json$JSONObject;
          goto _L49
    }
}
