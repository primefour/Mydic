// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;

public class GeoLocation
    implements Serializable
{

    GeoLocation()
    {
    }

    public GeoLocation(double d, double d1)
    {
        latitude = d;
        longitude = d1;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof GeoLocation))
                return false;
            GeoLocation geolocation = (GeoLocation)obj;
            if(Double.compare(geolocation.getLatitude(), latitude) != 0)
                return false;
            if(Double.compare(geolocation.getLongitude(), longitude) != 0)
                return false;
        }
        return true;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public int hashCode()
    {
        long l;
        int i;
        long l1;
        if(latitude != 0.0D)
            l = Double.doubleToLongBits(latitude);
        else
            l = 0L;
        i = (int)(l ^ l >>> 32);
        if(longitude != 0.0D)
            l1 = Double.doubleToLongBits(longitude);
        else
            l1 = 0L;
        return i * 31 + (int)(l1 ^ l1 >>> 32);
    }

    public String toString()
    {
        return "GeoLocation{latitude=" + latitude + ", longitude=" + longitude + '}';
    }

    private static final long serialVersionUID = 0xbcb9fb5a874f20f1L;
    protected double latitude;
    protected double longitude;
}
