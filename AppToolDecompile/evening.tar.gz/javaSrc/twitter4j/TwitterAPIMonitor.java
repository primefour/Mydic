// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.lang.management.ManagementFactory;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.management.*;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationContext;
import twitter4j.internal.logging.Logger;
import twitter4j.management.APIStatistics;
import twitter4j.management.APIStatisticsMBean;
import twitter4j.management.APIStatisticsOpenMBean;

public class TwitterAPIMonitor
{

    private TwitterAPIMonitor()
    {
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public static TwitterAPIMonitor getInstance()
    {
        return SINGLETON;
    }

    public APIStatisticsMBean getStatistics()
    {
        return STATISTICS;
    }

    void methodCalled(String s, long l, boolean flag)
    {
        Matcher matcher = pattern.matcher(s);
        if(matcher.matches() && matcher.groupCount() > 0)
        {
            String s1 = matcher.group();
            STATISTICS.methodCalled(s1, l, flag);
        }
    }

    private static final TwitterAPIMonitor SINGLETON;
    static Class class$twitter4j$TwitterAPIMonitor;
    private static final Logger logger;
    private static final Pattern pattern;
    private final APIStatistics STATISTICS = new APIStatistics(100);

    static 
    {
        boolean flag;
        MBeanServer mbeanserver;
        APIStatistics apistatistics;
        Class class1;
        String s;
        if(class$twitter4j$TwitterAPIMonitor == null)
        {
            class1 = _mthclass$("twitter4j.TwitterAPIMonitor");
            class$twitter4j$TwitterAPIMonitor = class1;
        } else
        {
            class1 = class$twitter4j$TwitterAPIMonitor;
        }
        logger = Logger.getLogger(class1);
        pattern = Pattern.compile("https?:\\/\\/[^\\/]+\\/([a-zA-Z_\\.]*).*");
        SINGLETON = new TwitterAPIMonitor();
        s = System.getProperty("java.specification.version");
        flag = false;
        if(s == null)
            break MISSING_BLOCK_LABEL_69;
        if(1.5D > Double.parseDouble(s))
            flag = true;
        else
            flag = false;
        try
        {
            if(ConfigurationContext.getInstance().isDalvik())
                System.setProperty("http.keepAlive", "false");
        }
        catch(SecurityException securityexception)
        {
            flag = true;
        }
        mbeanserver = ManagementFactory.getPlatformMBeanServer();
        apistatistics = new APIStatistics(100);
        if(flag)
        {
            ObjectName objectname;
            try
            {
                mbeanserver.registerMBean(apistatistics, new ObjectName("twitter4j.mbean:type=APIStatistics"));
            }
            catch(InstanceAlreadyExistsException instancealreadyexistsexception)
            {
                instancealreadyexistsexception.printStackTrace();
                logger.error(instancealreadyexistsexception.getMessage());
            }
            catch(MBeanRegistrationException mbeanregistrationexception)
            {
                mbeanregistrationexception.printStackTrace();
                logger.error(mbeanregistrationexception.getMessage());
            }
            catch(NotCompliantMBeanException notcompliantmbeanexception)
            {
                notcompliantmbeanexception.printStackTrace();
                logger.error(notcompliantmbeanexception.getMessage());
            }
            catch(MalformedObjectNameException malformedobjectnameexception)
            {
                malformedobjectnameexception.printStackTrace();
                logger.error(malformedobjectnameexception.getMessage());
            }
            break MISSING_BLOCK_LABEL_249;
        }
        objectname = new ObjectName("twitter4j.mbean:type=APIStatisticsOpenMBean");
        mbeanserver.registerMBean(new APIStatisticsOpenMBean(apistatistics), objectname);
    }
}
