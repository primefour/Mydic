// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.PrintStream;

public final class Version
{

    private Version()
    {
        throw new AssertionError();
    }

    public static String getVersion()
    {
        return "2.2.6-SNAPSHOT(build: 404bccc2082954dc0d12612322791a37f3daa917)";
    }

    public static void main(String args[])
    {
        System.out.println("Twitter4J 2.2.6-SNAPSHOT(build: 404bccc2082954dc0d12612322791a37f3daa917)");
    }

    private static final String TITLE = "Twitter4J";
    private static final String VERSION = "2.2.6-SNAPSHOT(build: 404bccc2082954dc0d12612322791a37f3daa917)";
}
