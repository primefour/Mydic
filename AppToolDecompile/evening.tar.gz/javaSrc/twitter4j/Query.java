// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import twitter4j.internal.http.HttpParameter;

// Referenced classes of package twitter4j:
//            GeoLocation

public final class Query
    implements Serializable
{

    public Query()
    {
        query = null;
        lang = null;
        locale = null;
        maxId = -1L;
        rpp = -1;
        page = -1;
        since = null;
        sinceId = -1L;
        geocode = null;
        until = null;
        resultType = null;
    }

    public Query(String s)
    {
        query = null;
        lang = null;
        locale = null;
        maxId = -1L;
        rpp = -1;
        page = -1;
        since = null;
        sinceId = -1L;
        geocode = null;
        until = null;
        resultType = null;
        query = s;
    }

    private void appendParameter(String s, long l, List list)
    {
        if(0L <= l)
            list.add(new HttpParameter(s, String.valueOf(l)));
    }

    private void appendParameter(String s, String s1, List list)
    {
        if(s1 != null)
            list.add(new HttpParameter(s, s1));
    }

    HttpParameter[] asHttpParameterArray(HttpParameter httpparameter)
    {
        ArrayList arraylist = new ArrayList();
        appendParameter("q", query, arraylist);
        appendParameter("lang", lang, arraylist);
        appendParameter("locale", locale, arraylist);
        appendParameter("max_id", maxId, arraylist);
        appendParameter("rpp", rpp, arraylist);
        appendParameter("page", page, arraylist);
        appendParameter("since", since, arraylist);
        appendParameter("since_id", sinceId, arraylist);
        appendParameter("geocode", geocode, arraylist);
        appendParameter("until", until, arraylist);
        appendParameter("result_type", resultType, arraylist);
        arraylist.add(WITH_TWITTER_USER_ID);
        arraylist.add(httpparameter);
        return (HttpParameter[])arraylist.toArray(new HttpParameter[arraylist.size()]);
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            Query query1 = (Query)obj;
            if(maxId != query1.maxId)
                return false;
            if(page != query1.page)
                return false;
            if(rpp != query1.rpp)
                return false;
            if(sinceId != query1.sinceId)
                return false;
            if(geocode == null ? query1.geocode != null : !geocode.equals(query1.geocode))
                return false;
            if(lang == null ? query1.lang != null : !lang.equals(query1.lang))
                return false;
            if(locale == null ? query1.locale != null : !locale.equals(query1.locale))
                return false;
            if(query == null ? query1.query != null : !query.equals(query1.query))
                return false;
            if(since == null ? query1.since != null : !since.equals(query1.since))
                return false;
            if(until == null ? query1.until != null : !until.equals(query1.until))
                return false;
            if(resultType == null ? query1.resultType != null : !resultType.equals(query1.resultType))
                return false;
        }
        return true;
    }

    public Query geoCode(GeoLocation geolocation, double d, String s)
    {
        setGeoCode(geolocation, d, s);
        return this;
    }

    public String getGeocode()
    {
        return geocode;
    }

    public String getLang()
    {
        return lang;
    }

    public String getLocale()
    {
        return locale;
    }

    public long getMaxId()
    {
        return maxId;
    }

    public int getPage()
    {
        return page;
    }

    public String getQuery()
    {
        return query;
    }

    public String getResultType()
    {
        return resultType;
    }

    public int getRpp()
    {
        return rpp;
    }

    public String getSince()
    {
        return since;
    }

    public long getSinceId()
    {
        return sinceId;
    }

    public String getUntil()
    {
        return until;
    }

    public int hashCode()
    {
        int i;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        String s;
        int i3;
        if(query != null)
            i = query.hashCode();
        else
            i = 0;
        j = i * 31;
        if(lang != null)
            k = lang.hashCode();
        else
            k = 0;
        l = 31 * (j + k);
        if(locale != null)
            i1 = locale.hashCode();
        else
            i1 = 0;
        j1 = 31 * (31 * (31 * (31 * (l + i1) + (int)(maxId ^ maxId >>> 32)) + rpp) + page);
        if(since != null)
            k1 = since.hashCode();
        else
            k1 = 0;
        l1 = 31 * (31 * (j1 + k1) + (int)(sinceId ^ sinceId >>> 32));
        if(geocode != null)
            i2 = geocode.hashCode();
        else
            i2 = 0;
        j2 = 31 * (l1 + i2);
        if(until != null)
            k2 = until.hashCode();
        else
            k2 = 0;
        l2 = 31 * (j2 + k2);
        s = resultType;
        i3 = 0;
        if(s != null)
            i3 = resultType.hashCode();
        return l2 + i3;
    }

    public Query lang(String s)
    {
        setLang(s);
        return this;
    }

    public Query locale(String s)
    {
        setLocale(s);
        return this;
    }

    public Query maxId(long l)
    {
        setMaxId(l);
        return this;
    }

    public Query page(int i)
    {
        setPage(i);
        return this;
    }

    public Query query(String s)
    {
        setQuery(s);
        return this;
    }

    public Query resultType(String s)
    {
        setResultType(s);
        return this;
    }

    public Query rpp(int i)
    {
        setRpp(i);
        return this;
    }

    public void setGeoCode(GeoLocation geolocation, double d, String s)
    {
        geocode = geolocation.getLatitude() + "," + geolocation.getLongitude() + "," + d + s;
    }

    public void setLang(String s)
    {
        lang = s;
    }

    public void setLocale(String s)
    {
        locale = s;
    }

    public void setMaxId(long l)
    {
        maxId = l;
    }

    public void setPage(int i)
    {
        page = i;
    }

    public void setQuery(String s)
    {
        query = s;
    }

    public void setResultType(String s)
    {
        resultType = s;
    }

    public void setRpp(int i)
    {
        rpp = i;
    }

    public void setSince(String s)
    {
        since = s;
    }

    public void setSinceId(long l)
    {
        sinceId = l;
    }

    public void setUntil(String s)
    {
        until = s;
    }

    public Query since(String s)
    {
        setSince(s);
        return this;
    }

    public Query sinceId(long l)
    {
        setSinceId(l);
        return this;
    }

    public String toString()
    {
        return "Query{query='" + query + '\'' + ", lang='" + lang + '\'' + ", locale='" + locale + '\'' + ", maxId=" + maxId + ", rpp=" + rpp + ", page=" + page + ", since='" + since + '\'' + ", sinceId=" + sinceId + ", geocode='" + geocode + '\'' + ", until='" + until + '\'' + ", resultType='" + resultType + '\'' + '}';
    }

    public Query until(String s)
    {
        setUntil(s);
        return this;
    }

    public static final String KILOMETERS = "km";
    public static final String MILES = "mi";
    public static final String MIXED = "mixed";
    public static final String POPULAR = "popular";
    public static final String RECENT = "recent";
    private static HttpParameter WITH_TWITTER_USER_ID = new HttpParameter("with_twitter_user_id", "true");
    private static final long serialVersionUID = 0x8f7915acca2960c0L;
    private String geocode;
    private String lang;
    private String locale;
    private long maxId;
    private int page;
    private String query;
    private String resultType;
    private int rpp;
    private String since;
    private long sinceId;
    private String until;

}
