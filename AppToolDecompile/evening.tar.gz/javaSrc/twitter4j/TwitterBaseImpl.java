// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.*;
import java.util.*;
import twitter4j.auth.AccessToken;
import twitter4j.auth.Authorization;
import twitter4j.auth.AuthorizationFactory;
import twitter4j.auth.BasicAuthorization;
import twitter4j.auth.NullAuthorization;
import twitter4j.auth.OAuthAuthorization;
import twitter4j.auth.OAuthSupport;
import twitter4j.auth.RequestToken;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpClientWrapper;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.http.HttpResponseEvent;
import twitter4j.internal.http.HttpResponseListener;
import twitter4j.internal.http.XAuthAuthorization;
import twitter4j.internal.json.z_T4JInternalFactory;
import twitter4j.internal.json.z_T4JInternalJSONImplFactory;

// Referenced classes of package twitter4j:
//            RateLimitStatusListener, TwitterException, User, RateLimitStatusEvent

abstract class TwitterBaseImpl
    implements Serializable, OAuthSupport, HttpResponseListener
{

    TwitterBaseImpl(Configuration configuration, Authorization authorization)
    {
        screenName = null;
        id = 0L;
        rateLimitStatusListeners = new ArrayList(0);
        conf = configuration;
        auth = authorization;
        init();
    }

    private OAuthSupport getOAuth()
    {
        if(!(auth instanceof OAuthSupport))
            throw new IllegalStateException("OAuth consumer key/secret combination not supplied");
        else
            return (OAuthSupport)auth;
    }

    private void init()
    {
        if(auth == null)
        {
            String s = conf.getOAuthConsumerKey();
            String s1 = conf.getOAuthConsumerSecret();
            if(s != null && s1 != null)
            {
                OAuthAuthorization oauthauthorization = new OAuthAuthorization(conf);
                String s2 = conf.getOAuthAccessToken();
                String s3 = conf.getOAuthAccessTokenSecret();
                if(s2 != null && s3 != null)
                    oauthauthorization.setOAuthAccessToken(new AccessToken(s2, s3));
                auth = oauthauthorization;
            } else
            {
                auth = NullAuthorization.getInstance();
            }
        }
        http = new HttpClientWrapper(conf);
        http.setHttpResponseListener(this);
        setFactory();
    }

    private void readObject(ObjectInputStream objectinputstream)
        throws IOException, ClassNotFoundException
    {
        conf = (Configuration)objectinputstream.readObject();
        auth = (Authorization)objectinputstream.readObject();
        rateLimitStatusListeners = (List)objectinputstream.readObject();
        http = new HttpClientWrapper(conf);
        http.setHttpResponseListener(this);
        setFactory();
    }

    private void writeObject(ObjectOutputStream objectoutputstream)
        throws IOException
    {
        objectoutputstream.writeObject(conf);
        objectoutputstream.writeObject(auth);
        ArrayList arraylist = new ArrayList(0);
        Iterator iterator = rateLimitStatusListeners.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            RateLimitStatusListener ratelimitstatuslistener = (RateLimitStatusListener)iterator.next();
            if(ratelimitstatuslistener instanceof Serializable)
                arraylist.add(ratelimitstatuslistener);
        } while(true);
        objectoutputstream.writeObject(arraylist);
    }

    public void addRateLimitStatusListener(RateLimitStatusListener ratelimitstatuslistener)
    {
        rateLimitStatusListeners.add(ratelimitstatuslistener);
    }

    protected final void ensureAuthorizationEnabled()
    {
        if(!auth.isEnabled())
            throw new IllegalStateException("Authentication credentials are missing. See http://twitter4j.org/configuration.html for the detail.");
        else
            return;
    }

    protected final void ensureOAuthEnabled()
    {
        if(!(auth instanceof OAuthAuthorization))
            throw new IllegalStateException("OAuth required. Authentication credentials are missing. See http://twitter4j.org/configuration.html for the detail.");
        else
            return;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof TwitterBaseImpl))
                return false;
            TwitterBaseImpl twitterbaseimpl = (TwitterBaseImpl)obj;
            if(auth == null ? twitterbaseimpl.auth != null : !auth.equals(twitterbaseimpl.auth))
                return false;
            if(!conf.equals(twitterbaseimpl.conf))
                return false;
            if(http == null ? twitterbaseimpl.http != null : !http.equals(twitterbaseimpl.http))
                return false;
            if(!rateLimitStatusListeners.equals(twitterbaseimpl.rateLimitStatusListeners))
                return false;
        }
        return true;
    }

    protected User fillInIDAndScreenName()
        throws TwitterException
    {
        ensureAuthorizationEnabled();
        User user = factory.createUser(http.get(conf.getRestBaseURL() + "account/verify_credentials.json?include_entities=" + conf.isIncludeEntitiesEnabled(), auth));
        screenName = user.getScreenName();
        id = user.getId();
        return user;
    }

    public final Authorization getAuthorization()
    {
        return auth;
    }

    public Configuration getConfiguration()
    {
        return conf;
    }

    public long getId()
        throws TwitterException, IllegalStateException
    {
        if(!auth.isEnabled())
            throw new IllegalStateException("Neither user ID/password combination nor OAuth consumer key/secret combination supplied");
        if(0L == id)
            fillInIDAndScreenName();
        return id;
    }

    public AccessToken getOAuthAccessToken()
        throws TwitterException
    {
        this;
        JVM INSTR monitorenter ;
        Authorization authorization = getAuthorization();
        if(!(authorization instanceof BasicAuthorization)) goto _L2; else goto _L1
_L1:
        BasicAuthorization basicauthorization;
        Authorization authorization1;
        basicauthorization = (BasicAuthorization)authorization;
        authorization1 = AuthorizationFactory.getInstance(conf);
        if(!(authorization1 instanceof OAuthAuthorization)) goto _L4; else goto _L3
_L3:
        AccessToken accesstoken1;
        auth = authorization1;
        accesstoken1 = ((OAuthAuthorization)authorization1).getOAuthAccessToken(basicauthorization.getUserId(), basicauthorization.getPassword());
_L5:
        screenName = accesstoken1.getScreenName();
        id = accesstoken1.getUserId();
        this;
        JVM INSTR monitorexit ;
        return accesstoken1;
_L4:
        throw new IllegalStateException("consumer key / secret combination not supplied.");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
_L2:
label0:
        {
            if(!(authorization instanceof XAuthAuthorization))
                break label0;
            XAuthAuthorization xauthauthorization = (XAuthAuthorization)authorization;
            auth = xauthauthorization;
            OAuthAuthorization oauthauthorization = new OAuthAuthorization(conf);
            oauthauthorization.setOAuthConsumer(xauthauthorization.getConsumerKey(), xauthauthorization.getConsumerSecret());
            accesstoken1 = oauthauthorization.getOAuthAccessToken(xauthauthorization.getUserId(), xauthauthorization.getPassword());
        }
          goto _L5
        AccessToken accesstoken = getOAuth().getOAuthAccessToken();
        accesstoken1 = accesstoken;
          goto _L5
    }

    public AccessToken getOAuthAccessToken(String s)
        throws TwitterException
    {
        this;
        JVM INSTR monitorenter ;
        AccessToken accesstoken;
        accesstoken = getOAuth().getOAuthAccessToken(s);
        screenName = accesstoken.getScreenName();
        this;
        JVM INSTR monitorexit ;
        return accesstoken;
        Exception exception;
        exception;
        throw exception;
    }

    public AccessToken getOAuthAccessToken(String s, String s1)
        throws TwitterException
    {
        this;
        JVM INSTR monitorenter ;
        AccessToken accesstoken = getOAuth().getOAuthAccessToken(s, s1);
        this;
        JVM INSTR monitorexit ;
        return accesstoken;
        Exception exception;
        exception;
        throw exception;
    }

    public AccessToken getOAuthAccessToken(RequestToken requesttoken)
        throws TwitterException
    {
        this;
        JVM INSTR monitorenter ;
        AccessToken accesstoken;
        accesstoken = getOAuth().getOAuthAccessToken(requesttoken);
        screenName = accesstoken.getScreenName();
        this;
        JVM INSTR monitorexit ;
        return accesstoken;
        Exception exception;
        exception;
        throw exception;
    }

    public AccessToken getOAuthAccessToken(RequestToken requesttoken, String s)
        throws TwitterException
    {
        this;
        JVM INSTR monitorenter ;
        AccessToken accesstoken = getOAuth().getOAuthAccessToken(requesttoken, s);
        this;
        JVM INSTR monitorexit ;
        return accesstoken;
        Exception exception;
        exception;
        throw exception;
    }

    public RequestToken getOAuthRequestToken()
        throws TwitterException
    {
        return getOAuthRequestToken(null);
    }

    public RequestToken getOAuthRequestToken(String s)
        throws TwitterException
    {
        return getOAuth().getOAuthRequestToken(s);
    }

    public RequestToken getOAuthRequestToken(String s, String s1)
        throws TwitterException
    {
        return getOAuth().getOAuthRequestToken(s, s1);
    }

    public String getScreenName()
        throws TwitterException, IllegalStateException
    {
        if(!auth.isEnabled())
            throw new IllegalStateException("Neither user ID/password combination nor OAuth consumer key/secret combination supplied");
        if(screenName == null)
        {
            if(auth instanceof BasicAuthorization)
            {
                screenName = ((BasicAuthorization)auth).getUserId();
                if(-1 != screenName.indexOf("@"))
                    screenName = null;
            }
            if(screenName == null)
                fillInIDAndScreenName();
        }
        return screenName;
    }

    public int hashCode()
    {
        int i = 31 * conf.hashCode();
        int j;
        int k;
        Authorization authorization;
        int l;
        if(http != null)
            j = http.hashCode();
        else
            j = 0;
        k = 31 * (31 * (i + j) + rateLimitStatusListeners.hashCode());
        authorization = auth;
        l = 0;
        if(authorization != null)
            l = auth.hashCode();
        return k + l;
    }

    public void httpResponseReceived(HttpResponseEvent httpresponseevent)
    {
        if(rateLimitStatusListeners.size() != 0)
        {
            HttpResponse httpresponse = httpresponseevent.getResponse();
            TwitterException twitterexception = httpresponseevent.getTwitterException();
            RateLimitStatus ratelimitstatus;
            int i;
            if(twitterexception != null)
            {
                ratelimitstatus = twitterexception.getRateLimitStatus();
                i = twitterexception.getStatusCode();
            } else
            {
                ratelimitstatus = z_T4JInternalJSONImplFactory.createRateLimitStatusFromResponseHeader(httpresponse);
                i = httpresponse.getStatusCode();
            }
            if(ratelimitstatus != null)
            {
                RateLimitStatusEvent ratelimitstatusevent = new RateLimitStatusEvent(this, ratelimitstatus, httpresponseevent.isAuthenticated());
                if(i == 420 || i == 503)
                {
                    RateLimitStatusListener ratelimitstatuslistener;
                    for(Iterator iterator = rateLimitStatusListeners.iterator(); iterator.hasNext(); ratelimitstatuslistener.onRateLimitReached(ratelimitstatusevent))
                    {
                        ratelimitstatuslistener = (RateLimitStatusListener)iterator.next();
                        ratelimitstatuslistener.onRateLimitStatus(ratelimitstatusevent);
                    }

                } else
                {
                    for(Iterator iterator1 = rateLimitStatusListeners.iterator(); iterator1.hasNext(); ((RateLimitStatusListener)iterator1.next()).onRateLimitStatus(ratelimitstatusevent));
                }
            }
        }
    }

    protected void setFactory()
    {
        factory = new z_T4JInternalJSONImplFactory(conf);
    }

    public void setOAuthAccessToken(AccessToken accesstoken)
    {
        this;
        JVM INSTR monitorenter ;
        getOAuth().setOAuthAccessToken(accesstoken);
        this;
        JVM INSTR monitorexit ;
        return;
        Exception exception;
        exception;
        throw exception;
    }

    public void setOAuthConsumer(String s, String s1)
    {
        this;
        JVM INSTR monitorenter ;
        if(s != null)
            break MISSING_BLOCK_LABEL_24;
        throw new NullPointerException("consumer key is null");
        Exception exception;
        exception;
        this;
        JVM INSTR monitorexit ;
        throw exception;
        if(s1 != null)
            break MISSING_BLOCK_LABEL_39;
        throw new NullPointerException("consumer secret is null");
        if(!(auth instanceof NullAuthorization)) goto _L2; else goto _L1
_L1:
        OAuthAuthorization oauthauthorization = new OAuthAuthorization(conf);
        oauthauthorization.setOAuthConsumer(s, s1);
        auth = oauthauthorization;
_L3:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(!(auth instanceof BasicAuthorization))
            continue; /* Loop/switch isn't completed */
        XAuthAuthorization xauthauthorization = new XAuthAuthorization((BasicAuthorization)auth);
        xauthauthorization.setOAuthConsumer(s, s1);
        auth = xauthauthorization;
          goto _L3
        if(!(auth instanceof OAuthAuthorization)) goto _L3; else goto _L4
_L4:
        throw new IllegalStateException("consumer key/secret pair already set.");
    }

    public void shutdown()
    {
        if(http != null)
            http.shutdown();
    }

    public String toString()
    {
        return "TwitterBase{conf=" + conf + ", http=" + http + ", rateLimitStatusListeners=" + rateLimitStatusListeners + ", auth=" + auth + '}';
    }

    private static final long serialVersionUID = 0xcb186dfe36c9c194L;
    protected Authorization auth;
    protected Configuration conf;
    protected z_T4JInternalFactory factory;
    protected transient HttpClientWrapper http;
    protected transient long id;
    private List rateLimitStatusListeners;
    protected transient String screenName;
}
