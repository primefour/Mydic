// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.api;

import twitter4j.*;

public interface SavedSearchesMethods
{

    public abstract SavedSearch createSavedSearch(String s)
        throws TwitterException;

    public abstract SavedSearch destroySavedSearch(int i)
        throws TwitterException;

    public abstract ResponseList getSavedSearches()
        throws TwitterException;

    public abstract SavedSearch showSavedSearch(int i)
        throws TwitterException;
}
