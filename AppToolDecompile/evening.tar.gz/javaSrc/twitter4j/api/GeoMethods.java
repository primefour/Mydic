// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.api;

import twitter4j.*;

public interface GeoMethods
{

    public abstract Place createPlace(String s, String s1, String s2, GeoLocation geolocation, String s3)
        throws TwitterException;

    public abstract Place getGeoDetails(String s)
        throws TwitterException;

    public abstract SimilarPlaces getSimilarPlaces(GeoLocation geolocation, String s, String s1, String s2)
        throws TwitterException;

    public abstract ResponseList reverseGeoCode(GeoQuery geoquery)
        throws TwitterException;

    public abstract ResponseList searchPlaces(GeoQuery geoquery)
        throws TwitterException;
}
