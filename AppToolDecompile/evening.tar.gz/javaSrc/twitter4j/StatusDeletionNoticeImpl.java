// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;
import twitter4j.internal.org.json.JSONObject;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j:
//            StatusDeletionNotice

class StatusDeletionNoticeImpl
    implements StatusDeletionNotice, Serializable
{

    StatusDeletionNoticeImpl(JSONObject jsonobject)
    {
        statusId = z_T4JInternalParseUtil.getLong("id", jsonobject);
        userId = z_T4JInternalParseUtil.getLong("user_id", jsonobject);
    }

    public int compareTo(Object obj)
    {
        return compareTo((StatusDeletionNotice)obj);
    }

    public int compareTo(StatusDeletionNotice statusdeletionnotice)
    {
        long l = statusId - statusdeletionnotice.getStatusId();
        if(l < 0xffffffff80000000L)
            return 0x80000000;
        if(l > 0x7fffffffL)
            return 0x7fffffff;
        else
            return (int)l;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            StatusDeletionNoticeImpl statusdeletionnoticeimpl = (StatusDeletionNoticeImpl)obj;
            if(statusId != statusdeletionnoticeimpl.statusId)
                return false;
            if(userId != statusdeletionnoticeimpl.userId)
                return false;
        }
        return true;
    }

    public long getStatusId()
    {
        return statusId;
    }

    public long getUserId()
    {
        return userId;
    }

    public int hashCode()
    {
        return 31 * (int)(statusId ^ statusId >>> 32) + (int)(userId ^ userId >>> 32);
    }

    public String toString()
    {
        return "StatusDeletionNoticeImpl{statusId=" + statusId + ", userId=" + userId + '}';
    }

    private static final long serialVersionUID = 0x17ea8725e4ab20deL;
    private long statusId;
    private long userId;
}
