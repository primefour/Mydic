// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.auth;

import twitter4j.conf.Configuration;

// Referenced classes of package twitter4j.auth:
//            OAuthAuthorization, AccessToken, NullAuthorization, BasicAuthorization, 
//            Authorization

public final class AuthorizationFactory
{

    public AuthorizationFactory()
    {
    }

    public static Authorization getInstance(Configuration configuration)
    {
        String s;
        String s1;
        s = configuration.getOAuthConsumerKey();
        s1 = configuration.getOAuthConsumerSecret();
        if(s == null || s1 == null) goto _L2; else goto _L1
_L1:
        Object obj;
        OAuthAuthorization oauthauthorization = new OAuthAuthorization(configuration);
        String s4 = configuration.getOAuthAccessToken();
        String s5 = configuration.getOAuthAccessTokenSecret();
        if(s4 != null && s5 != null)
            oauthauthorization.setOAuthAccessToken(new AccessToken(s4, s5));
        obj = oauthauthorization;
_L4:
        if(obj == null)
            obj = NullAuthorization.getInstance();
        return ((Authorization) (obj));
_L2:
        String s2 = configuration.getUser();
        String s3 = configuration.getPassword();
        obj = null;
        if(s2 != null)
        {
            obj = null;
            if(s3 != null)
                obj = new BasicAuthorization(s2, s3);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }
}
