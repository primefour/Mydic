// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.auth;

import java.io.Serializable;
import twitter4j.TwitterException;
import twitter4j.internal.http.HttpResponse;

// Referenced classes of package twitter4j.auth:
//            OAuthToken

public class AccessToken extends OAuthToken
    implements Serializable
{

    AccessToken(String s)
    {
        super(s);
        screenName = getParameter("screen_name");
        String s1 = getParameter("user_id");
        if(s1 != null)
            userId = Long.parseLong(s1);
    }

    public AccessToken(String s, String s1)
    {
        super(s, s1);
        String s2;
        try
        {
            s2 = s.substring(0, s.indexOf("-"));
        }
        catch(IndexOutOfBoundsException indexoutofboundsexception)
        {
            throw new IllegalArgumentException("Invalid access token format.");
        }
        if(s2 != null)
            userId = Long.parseLong(s2);
    }

    AccessToken(HttpResponse httpresponse)
        throws TwitterException
    {
        this(httpresponse.asString());
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            if(!super.equals(obj))
                return false;
            AccessToken accesstoken = (AccessToken)obj;
            if(userId != accesstoken.userId)
                return false;
            if(screenName == null ? accesstoken.screenName != null : !screenName.equals(accesstoken.screenName))
                return false;
        }
        return true;
    }

    public String getParameter(String s)
    {
        return super.getParameter(s);
    }

    public String getScreenName()
    {
        return screenName;
    }

    public String getToken()
    {
        return super.getToken();
    }

    public String getTokenSecret()
    {
        return super.getTokenSecret();
    }

    public long getUserId()
    {
        return userId;
    }

    public int hashCode()
    {
        int i = 31 * super.hashCode();
        int j;
        if(screenName != null)
            j = screenName.hashCode();
        else
            j = 0;
        return 31 * (i + j) + (int)(userId ^ userId >>> 32);
    }

    public String toString()
    {
        return "AccessToken{screenName='" + screenName + '\'' + ", userId=" + userId + '}';
    }

    private static final long serialVersionUID = 0x8c3247a79636c1cdL;
    private String screenName;
    private long userId;
}
