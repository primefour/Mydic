// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.util.Date;

// Referenced classes of package twitter4j:
//            GeoLocation, Place

public interface Twt
{

    public abstract Date getCreatedAt();

    public abstract GeoLocation getGeoLocation();

    public abstract long getId();

    public abstract long getInReplyToStatusId();

    public abstract Place getPlace();

    public abstract String getSource();

    public abstract String getText();
}
