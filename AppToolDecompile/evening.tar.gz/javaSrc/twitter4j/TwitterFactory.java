// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import twitter4j.auth.AccessToken;
import twitter4j.auth.Authorization;
import twitter4j.auth.AuthorizationFactory;
import twitter4j.auth.OAuthAuthorization;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationContext;

// Referenced classes of package twitter4j:
//            Twitter

public final class TwitterFactory
    implements Serializable
{

    public TwitterFactory()
    {
        this(ConfigurationContext.getInstance());
    }

    public TwitterFactory(String s)
    {
        this(ConfigurationContext.getInstance(s));
    }

    public TwitterFactory(Configuration configuration)
    {
        if(configuration == null)
        {
            throw new NullPointerException("configuration cannot be null");
        } else
        {
            conf = configuration;
            return;
        }
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public static Twitter getSingleton()
    {
        return SINGLETON;
    }

    public Twitter getInstance()
    {
        return getInstance(AuthorizationFactory.getInstance(conf));
    }

    public Twitter getInstance(AccessToken accesstoken)
    {
        String s = conf.getOAuthConsumerKey();
        String s1 = conf.getOAuthConsumerSecret();
        if(s == null && s1 == null)
        {
            throw new IllegalStateException("Consumer key and Consumer secret not supplied.");
        } else
        {
            OAuthAuthorization oauthauthorization = new OAuthAuthorization(conf);
            oauthauthorization.setOAuthAccessToken(accesstoken);
            return getInstance(((Authorization) (oauthauthorization)));
        }
    }

    public Twitter getInstance(Authorization authorization)
    {
        Twitter twitter;
        try
        {
            Constructor constructor = TWITTER_CONSTRUCTOR;
            Object aobj[] = new Object[2];
            aobj[0] = conf;
            aobj[1] = authorization;
            twitter = (Twitter)constructor.newInstance(aobj);
        }
        catch(InstantiationException instantiationexception)
        {
            throw new AssertionError(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
        return twitter;
    }

    static final Authorization DEFAULT_AUTHORIZATION;
    private static final Twitter SINGLETON;
    private static final Constructor TWITTER_CONSTRUCTOR;
    static Class class$twitter4j$auth$Authorization;
    static Class class$twitter4j$conf$Configuration;
    private static final long serialVersionUID = 0x481470a850d0e763L;
    private final Configuration conf;

    static 
    {
        String s;
        DEFAULT_AUTHORIZATION = AuthorizationFactory.getInstance(ConfigurationContext.getInstance());
        boolean flag = ConfigurationContext.getInstance().isGAE();
        s = null;
        if(!flag)
            break MISSING_BLOCK_LABEL_33;
        Class.forName("twitter4j.AppEngineTwitterImpl");
        s = "twitter4j.AppEngineTwitterImpl";
_L6:
        if(s == null)
            s = "twitter4j.TwitterImpl";
        Class class1;
        Class aclass[];
        class1 = Class.forName(s);
        aclass = new Class[2];
        if(class$twitter4j$conf$Configuration != null) goto _L2; else goto _L1
_L1:
        Class class2;
        class2 = _mthclass$("twitter4j.conf.Configuration");
        class$twitter4j$conf$Configuration = class2;
_L3:
        Class class3;
        aclass[0] = class2;
        if(class$twitter4j$auth$Authorization != null)
            break MISSING_BLOCK_LABEL_161;
        class3 = _mthclass$("twitter4j.auth.Authorization");
        class$twitter4j$auth$Authorization = class3;
_L4:
        Constructor constructor;
        aclass[1] = class3;
        constructor = class1.getDeclaredConstructor(aclass);
        TWITTER_CONSTRUCTOR = constructor;
        ClassNotFoundException classnotfoundexception;
        NoSuchMethodException nosuchmethodexception;
        try
        {
            Constructor constructor1 = TWITTER_CONSTRUCTOR;
            Object aobj[] = new Object[2];
            aobj[0] = ConfigurationContext.getInstance();
            aobj[1] = DEFAULT_AUTHORIZATION;
            SINGLETON = (Twitter)constructor1.newInstance(aobj);
            return;
        }
        catch(InstantiationException instantiationexception)
        {
            throw new AssertionError(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
_L2:
        try
        {
            class2 = class$twitter4j$conf$Configuration;
        }
        // Misplaced declaration of an exception variable
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new AssertionError(nosuchmethodexception);
        }
        // Misplaced declaration of an exception variable
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw new AssertionError(classnotfoundexception);
        }
          goto _L3
        class3 = class$twitter4j$auth$Authorization;
          goto _L4
        ClassNotFoundException classnotfoundexception1;
        classnotfoundexception1;
        s = null;
        if(true) goto _L6; else goto _L5
_L5:
    }
}
