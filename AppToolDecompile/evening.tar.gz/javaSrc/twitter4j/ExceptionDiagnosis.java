// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;

final class ExceptionDiagnosis
    implements Serializable
{

    ExceptionDiagnosis(Throwable throwable)
    {
        this(throwable, new String[0]);
    }

    ExceptionDiagnosis(Throwable throwable, String as[])
    {
        hexString = "";
        th = throwable;
        StackTraceElement astacktraceelement[] = throwable.getStackTrace();
        stackLineHash = 0;
        lineNumberHash = 0;
        int i = -1 + astacktraceelement.length;
label0:
        do
        {
            if(i >= 0)
            {
                StackTraceElement stacktraceelement = astacktraceelement[i];
                int j = as.length;
                int k = 0;
                do
                {
label1:
                    {
                        if(k < j)
                        {
                            String s = as[k];
                            if(!stacktraceelement.getClassName().startsWith(s))
                                break label1;
                            stackLineHash = stacktraceelement.getClassName().hashCode() + stacktraceelement.getMethodName().hashCode() + 31 * stackLineHash;
                            lineNumberHash = 31 * lineNumberHash + stacktraceelement.getLineNumber();
                        }
                        i--;
                        continue label0;
                    }
                    k++;
                } while(true);
            }
            hexString = hexString + toHexString(stackLineHash) + "-" + toHexString(lineNumberHash);
            if(throwable.getCause() != null)
                hexString = hexString + " " + (new ExceptionDiagnosis(throwable.getCause(), as)).asHexString();
            return;
        } while(true);
    }

    private String toHexString(int i)
    {
        String s = "0000000" + Integer.toHexString(i);
        return s.substring(-8 + s.length(), s.length());
    }

    String asHexString()
    {
        return hexString;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            ExceptionDiagnosis exceptiondiagnosis = (ExceptionDiagnosis)obj;
            if(lineNumberHash != exceptiondiagnosis.lineNumberHash)
                return false;
            if(stackLineHash != exceptiondiagnosis.stackLineHash)
                return false;
        }
        return true;
    }

    int getLineNumberHash()
    {
        return lineNumberHash;
    }

    String getLineNumberHashAsHex()
    {
        return toHexString(lineNumberHash);
    }

    int getStackLineHash()
    {
        return stackLineHash;
    }

    String getStackLineHashAsHex()
    {
        return toHexString(stackLineHash);
    }

    public int hashCode()
    {
        return 31 * stackLineHash + lineNumberHash;
    }

    public String toString()
    {
        return "ExceptionDiagnosis{stackLineHash=" + stackLineHash + ", lineNumberHash=" + lineNumberHash + '}';
    }

    private static final long serialVersionUID = 0x64cc93f854f97a4L;
    String hexString;
    int lineNumberHash;
    int stackLineHash;
    Throwable th;
}
