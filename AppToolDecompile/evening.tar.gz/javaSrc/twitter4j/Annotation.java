// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j;

import java.io.Serializable;
import java.util.*;
import twitter4j.internal.org.json.JSONException;
import twitter4j.internal.org.json.JSONObject;

public class Annotation
    implements Comparable, Serializable
{

    public Annotation(String s)
    {
        type = null;
        attributes = null;
        setType(s);
        setAttributes(null);
    }

    public Annotation(String s, Map map)
    {
        type = null;
        attributes = null;
        setType(s);
        setAttributes(map);
    }

    Annotation(JSONObject jsonobject)
    {
        Iterator iterator;
        boolean flag;
        Object obj;
        String s;
        type = null;
        attributes = null;
        iterator = jsonobject.keys();
        flag = iterator.hasNext();
        obj = null;
        s = null;
        if(!flag) goto _L2; else goto _L1
_L1:
        s = (String)iterator.next();
        if(!iterator.hasNext()) goto _L4; else goto _L3
_L3:
        type = null;
_L2:
        setType(s);
        setAttributes(((Map) (obj)));
        return;
_L4:
        JSONObject jsonobject1;
        LinkedHashMap linkedhashmap;
        jsonobject1 = jsonobject.getJSONObject(s);
        linkedhashmap = new LinkedHashMap();
        String s1;
        for(Iterator iterator1 = jsonobject1.keys(); iterator1.hasNext(); linkedhashmap.put(s1, jsonobject1.getString(s1)))
            s1 = (String)iterator1.next();

          goto _L5
        JSONException jsonexception1;
        jsonexception1;
_L6:
        obj = null;
        s = null;
          goto _L2
_L5:
        obj = linkedhashmap;
          goto _L2
        JSONException jsonexception;
        jsonexception;
          goto _L6
    }

    private SortedSet sortedNames()
    {
        TreeSet treeset = new TreeSet();
        treeset.addAll(getAttributes().keySet());
        return treeset;
    }

    public void addAttribute(String s, String s1)
    {
        attributes.put(s, s1);
    }

    JSONObject asJSONObject()
    {
        JSONObject jsonobject = new JSONObject();
        try
        {
            jsonobject.put(type, attributes);
        }
        catch(JSONException jsonexception)
        {
            return jsonobject;
        }
        return jsonobject;
    }

    String asParameterValue()
    {
        return asJSONObject().toString();
    }

    public Annotation attribute(String s, String s1)
    {
        addAttribute(s, s1);
        return this;
    }

    public Annotation attributes(Map map)
    {
        setAttributes(map);
        return this;
    }

    public int compareTo(Object obj)
    {
        return compareTo((Annotation)obj);
    }

    public int compareTo(Annotation annotation)
    {
        if(annotation != null) goto _L2; else goto _L1
_L1:
        int i = 1;
_L4:
        return i;
_L2:
        if(this == annotation)
            return 0;
        i = getType().compareTo(annotation.getType());
        if(i == 0)
        {
            i = size().compareTo(annotation.size());
            if(i == 0)
            {
                Iterator iterator = sortedNames().iterator();
                Iterator iterator1 = annotation.sortedNames().iterator();
label0:
                do
                {
label1:
                    {
                        if(!iterator.hasNext())
                            break label1;
                        String s = (String)iterator.next();
                        String s1 = (String)iterator1.next();
                        i = s.compareTo(s1);
                        if(i != 0)
                            continue;
                        int j = ((String)getAttributes().get(s)).compareTo((String)annotation.getAttributes().get(s1));
                        if(j != 0)
                            return j;
                    }
                } while(true);
            }
        }
        if(true) goto _L4; else goto _L3
_L3:
        return 0;
    }

    public boolean equals(Object obj)
    {
        boolean flag = true;
        if(obj != null)
        {
            if(this == obj)
                return flag;
            if(obj instanceof Annotation)
            {
                Annotation annotation = (Annotation)obj;
                if(!getType().equals(annotation.getType()) || !getAttributes().equals(annotation.getAttributes()))
                    flag = false;
                return flag;
            }
        }
        return false;
    }

    public Map getAttributes()
    {
        return attributes;
    }

    public String getType()
    {
        return type;
    }

    public int hashCode()
    {
        return 31 * type.hashCode() + attributes.hashCode();
    }

    public boolean isEmpty()
    {
        return attributes.isEmpty();
    }

    public void setAttributes(Map map)
    {
        if(map == null)
            map = new LinkedHashMap();
        attributes = map;
    }

    public void setType(String s)
    {
        if(s == null)
            s = "";
        type = s;
    }

    public Integer size()
    {
        return new Integer(attributes.size());
    }

    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer("Annotation{type='");
        stringbuffer.append(type).append("', attributes={");
        Iterator iterator = attributes.keySet().iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            String s = (String)iterator.next();
            String s1 = (String)attributes.get(s);
            stringbuffer.append('\'').append(s).append("'='").append(s1).append('\'');
            if(iterator.hasNext())
                stringbuffer.append(", ");
        } while(true);
        stringbuffer.append("}}");
        return stringbuffer.toString();
    }

    public Annotation type(String s)
    {
        setType(s);
        return this;
    }

    private static final long serialVersionUID = 0xa594bcd4354c38aeL;
    private Map attributes;
    private String type;
}
