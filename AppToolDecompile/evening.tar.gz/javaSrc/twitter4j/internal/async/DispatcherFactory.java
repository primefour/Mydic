// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.async;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationContext;

// Referenced classes of package twitter4j.internal.async:
//            Dispatcher

public final class DispatcherFactory
{

    public DispatcherFactory()
    {
        this(ConfigurationContext.getInstance());
    }

    public DispatcherFactory(Configuration configuration)
    {
        dispatcherImpl = configuration.getDispatcherImpl();
        conf = configuration;
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public Dispatcher getInstance()
    {
        try
        {
            Class class1 = Class.forName(dispatcherImpl);
            Class aclass[] = new Class[1];
            Class class2;
            Constructor constructor;
            Object aobj[];
            if(class$twitter4j$conf$Configuration == null)
            {
                class2 = _mthclass$("twitter4j.conf.Configuration");
                class$twitter4j$conf$Configuration = class2;
            } else
            {
                class2 = class$twitter4j$conf$Configuration;
            }
            aclass[0] = class2;
            constructor = class1.getConstructor(aclass);
            aobj = new Object[1];
            aobj[0] = conf;
            return (Dispatcher)constructor.newInstance(aobj);
        }
        catch(InstantiationException instantiationexception)
        {
            throw new AssertionError(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw new AssertionError(classnotfoundexception);
        }
        catch(ClassCastException classcastexception)
        {
            throw new AssertionError(classcastexception);
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new AssertionError(nosuchmethodexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
    }

    static Class class$twitter4j$conf$Configuration;
    private Configuration conf;
    private String dispatcherImpl;
}
