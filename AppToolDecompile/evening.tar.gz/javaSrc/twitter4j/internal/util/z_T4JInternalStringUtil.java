// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.util;

import java.util.ArrayList;
import java.util.List;

public class z_T4JInternalStringUtil
{

    private z_T4JInternalStringUtil()
    {
        throw new AssertionError();
    }

    public static String join(int ai[])
    {
        StringBuffer stringbuffer = new StringBuffer(11 * ai.length);
        int i = ai.length;
        for(int j = 0; j < i; j++)
        {
            int k = ai[j];
            if(stringbuffer.length() != 0)
                stringbuffer.append(",");
            stringbuffer.append(k);
        }

        return stringbuffer.toString();
    }

    public static String join(long al[])
    {
        StringBuffer stringbuffer = new StringBuffer(11 * al.length);
        int i = al.length;
        for(int j = 0; j < i; j++)
        {
            long l = al[j];
            if(stringbuffer.length() != 0)
                stringbuffer.append(",");
            stringbuffer.append(l);
        }

        return stringbuffer.toString();
    }

    public static String join(String as[])
    {
        StringBuffer stringbuffer = new StringBuffer(11 * as.length);
        int i = as.length;
        for(int j = 0; j < i; j++)
        {
            String s = as[j];
            if(stringbuffer.length() != 0)
                stringbuffer.append(",");
            stringbuffer.append(s);
        }

        return stringbuffer.toString();
    }

    public static String maskString(String s)
    {
        StringBuffer stringbuffer = new StringBuffer(s.length());
        for(int i = 0; i < s.length(); i++)
            stringbuffer.append("*");

        return stringbuffer.toString();
    }

    public static String[] split(String s, String s1)
    {
        int i = s.indexOf(s1);
        if(i == -1)
            return (new String[] {
                s
            });
        ArrayList arraylist = new ArrayList();
        int j = 0;
        for(; i != -1; i = s.indexOf(s1, j))
        {
            arraylist.add(s.substring(j, i));
            j = i + s1.length();
        }

        if(j != s.length())
            arraylist.add(s.substring(j));
        return (String[])arraylist.toArray(new String[arraylist.size()]);
    }
}
