// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.util;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import twitter4j.TwitterException;
import twitter4j.internal.http.HTMLEntity;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.JSONException;
import twitter4j.internal.org.json.JSONObject;

public final class z_T4JInternalParseUtil
{

    private z_T4JInternalParseUtil()
    {
        throw new AssertionError();
    }

    public static boolean getBoolean(String s, JSONObject jsonobject)
    {
        String s1 = getRawString(s, jsonobject);
        if(s1 == null || "null".equals(s1))
            return false;
        else
            return Boolean.valueOf(s1).booleanValue();
    }

    public static Date getDate(String s, String s1)
        throws TwitterException
    {
        SimpleDateFormat simpledateformat = (SimpleDateFormat)((Map)formatMap.get()).get(s1);
        if(simpledateformat == null)
        {
            simpledateformat = new SimpleDateFormat(s1, Locale.ENGLISH);
            simpledateformat.setTimeZone(TimeZone.getTimeZone("GMT"));
            ((Map)formatMap.get()).put(s1, simpledateformat);
        }
        Date date;
        try
        {
            date = simpledateformat.parse(s);
        }
        catch(ParseException parseexception)
        {
            throw new TwitterException("Unexpected date format(" + s + ") returned from twitter.com", parseexception);
        }
        return date;
    }

    public static Date getDate(String s, JSONObject jsonobject)
        throws TwitterException
    {
        return getDate(s, jsonobject, "EEE MMM d HH:mm:ss z yyyy");
    }

    public static Date getDate(String s, JSONObject jsonobject, String s1)
        throws TwitterException
    {
        String s2 = getUnescapedString(s, jsonobject);
        if("null".equals(s2) || s2 == null)
            return null;
        else
            return getDate(s2, s1);
    }

    public static double getDouble(String s, JSONObject jsonobject)
    {
        String s1 = getRawString(s, jsonobject);
        if(s1 == null || "".equals(s1) || "null".equals(s1))
            return -1D;
        else
            return Double.valueOf(s1).doubleValue();
    }

    public static int getInt(String s)
    {
        if(s == null || "".equals(s) || "null".equals(s))
            return -1;
        int i;
        try
        {
            i = Integer.valueOf(s).intValue();
        }
        catch(NumberFormatException numberformatexception)
        {
            return -1;
        }
        return i;
    }

    public static int getInt(String s, JSONObject jsonobject)
    {
        return getInt(getRawString(s, jsonobject));
    }

    public static long getLong(String s)
    {
        if(s == null || "".equals(s) || "null".equals(s))
            return -1L;
        if(s.endsWith("+"))
            return 1L + Long.valueOf(s.substring(0, -1 + s.length())).longValue();
        else
            return Long.valueOf(s).longValue();
    }

    public static long getLong(String s, JSONObject jsonobject)
    {
        return getLong(getRawString(s, jsonobject));
    }

    public static String getRawString(String s, JSONObject jsonobject)
    {
        if(jsonobject.isNull(s))
            return null;
        String s1;
        try
        {
            s1 = jsonobject.getString(s);
        }
        catch(JSONException jsonexception)
        {
            return null;
        }
        return s1;
    }

    public static String getURLDecodedString(String s, JSONObject jsonobject)
    {
        String s1 = getRawString(s, jsonobject);
        if(s1 != null)
        {
            String s2;
            try
            {
                s2 = URLDecoder.decode(s1, "UTF-8");
            }
            catch(UnsupportedEncodingException unsupportedencodingexception)
            {
                return s1;
            }
            s1 = s2;
        }
        return s1;
    }

    public static String getUnescapedString(String s, JSONObject jsonobject)
    {
        return HTMLEntity.unescape(getRawString(s, jsonobject));
    }

    public static Date parseTrendsDate(String s)
        throws TwitterException
    {
        switch(s.length())
        {
        default:
            return getDate(s, "EEE, d MMM yyyy HH:mm:ss z");

        case 10: // '\n'
            return new Date(1000L * Long.parseLong(s));

        case 20: // '\024'
            return getDate(s, "yyyy-MM-dd'T'HH:mm:ss'Z'");
        }
    }

    public static int toAccessLevel(HttpResponse httpresponse)
    {
        if(httpresponse == null)
            return -1;
        String s = httpresponse.getResponseHeader("X-Access-Level");
        if(s == null)
            return 0;
        switch(s.length())
        {
        default:
            return 0;

        case 4: // '\004'
            return 1;

        case 10: // '\n'
            return 2;

        case 25: // '\031'
            return 3;

        case 26: // '\032'
            return 3;
        }
    }

    private static ThreadLocal formatMap = new ThreadLocal() {

        protected Object initialValue()
        {
            return initialValue();
        }

        protected Map initialValue()
        {
            return new HashMap();
        }

    };

}
