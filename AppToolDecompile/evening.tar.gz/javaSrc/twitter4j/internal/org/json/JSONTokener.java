// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.org.json;

import java.io.*;

// Referenced classes of package twitter4j.internal.org.json:
//            JSONException, JSONObject, JSONArray

public class JSONTokener
{

    public JSONTokener(InputStream inputstream)
        throws JSONException
    {
        this(((Reader) (new InputStreamReader(inputstream))));
    }

    public JSONTokener(Reader reader1)
    {
        if(!reader1.markSupported())
            reader1 = new BufferedReader(reader1);
        reader = reader1;
        eof = false;
        usePrevious = false;
        previous = '\0';
        index = 0;
        character = 1;
        line = 1;
    }

    public JSONTokener(String s)
    {
        this(((Reader) (new StringReader(s))));
    }

    public static int dehexchar(char c)
    {
        if(c >= '0' && c <= '9')
            return c - 48;
        if(c >= 'A' && c <= 'F')
            return c - 55;
        if(c >= 'a' && c <= 'f')
            return c - 87;
        else
            return -1;
    }

    public void back()
        throws JSONException
    {
        if(usePrevious || index <= 0)
        {
            throw new JSONException("Stepping back two steps is not supported");
        } else
        {
            index = -1 + index;
            character = -1 + character;
            usePrevious = true;
            eof = false;
            return;
        }
    }

    public boolean end()
    {
        return eof && !usePrevious;
    }

    public boolean more()
        throws JSONException
    {
        next();
        if(end())
        {
            return false;
        } else
        {
            back();
            return true;
        }
    }

    public char next()
        throws JSONException
    {
        int j;
        if(usePrevious)
        {
            usePrevious = false;
            j = previous;
        } else
        {
            int i;
            try
            {
                i = reader.read();
            }
            catch(IOException ioexception)
            {
                throw new JSONException(ioexception);
            }
            j = i;
            if(j <= 0)
            {
                eof = true;
                j = 0;
            }
        }
        index = 1 + index;
        if(previous == '\r')
        {
            line = 1 + line;
            int k = 0;
            if(j != 10)
                k = 1;
            character = k;
        } else
        if(j == 10)
        {
            line = 1 + line;
            character = 0;
        } else
        {
            character = 1 + character;
        }
        previous = (char)j;
        return previous;
    }

    public char next(char c)
        throws JSONException
    {
        char c1 = next();
        if(c1 != c)
            throw syntaxError("Expected '" + c + "' and instead saw '" + c1 + "'");
        else
            return c1;
    }

    public String next(int i)
        throws JSONException
    {
        if(i == 0)
            return "";
        char ac[] = new char[i];
        for(int j = 0; j < i; j++)
        {
            ac[j] = next();
            if(end())
                throw syntaxError("Substring bounds error");
        }

        return new String(ac);
    }

    public char nextClean()
        throws JSONException
    {
        char c;
        do
            c = next();
        while(c != 0 && c <= ' ');
        return c;
    }

    public String nextString(char c)
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        do
        {
            char c1 = next();
            switch(c1)
            {
            default:
                if(c1 == c)
                    return stringbuffer.toString();
                break;

            case 0: // '\0'
            case 10: // '\n'
            case 13: // '\r'
                throw syntaxError("Unterminated string");

            case 92: // '\\'
                char c2 = next();
                switch(c2)
                {
                default:
                    throw syntaxError("Illegal escape.");

                case 98: // 'b'
                    stringbuffer.append('\b');
                    break;

                case 116: // 't'
                    stringbuffer.append('\t');
                    break;

                case 110: // 'n'
                    stringbuffer.append('\n');
                    break;

                case 102: // 'f'
                    stringbuffer.append('\f');
                    break;

                case 114: // 'r'
                    stringbuffer.append('\r');
                    break;

                case 117: // 'u'
                    stringbuffer.append((char)Integer.parseInt(next(4), 16));
                    break;

                case 34: // '"'
                case 39: // '\''
                case 47: // '/'
                case 92: // '\\'
                    stringbuffer.append(c2);
                    break;
                }
                continue;
            }
            stringbuffer.append(c1);
        } while(true);
    }

    public String nextTo(char c)
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        do
        {
            char c1 = next();
            if(c1 == c || c1 == 0 || c1 == '\n' || c1 == '\r')
            {
                if(c1 != 0)
                    back();
                return stringbuffer.toString().trim();
            }
            stringbuffer.append(c1);
        } while(true);
    }

    public String nextTo(String s)
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        do
        {
            char c = next();
            if(s.indexOf(c) >= 0 || c == 0 || c == '\n' || c == '\r')
            {
                if(c != 0)
                    back();
                return stringbuffer.toString().trim();
            }
            stringbuffer.append(c);
        } while(true);
    }

    public Object nextValue()
        throws JSONException
    {
        char c = nextClean();
        StringBuffer stringbuffer;
        switch(c)
        {
        default:
            stringbuffer = new StringBuffer();
            for(; c >= ' ' && ",:]}/\\\"[{;=#".indexOf(c) < 0; c = next())
                stringbuffer.append(c);

            break;

        case 34: // '"'
        case 39: // '\''
            return nextString(c);

        case 123: // '{'
            back();
            return new JSONObject(this);

        case 91: // '['
            back();
            return new JSONArray(this);
        }
        back();
        String s = stringbuffer.toString().trim();
        if(s.equals(""))
            throw syntaxError("Missing value");
        else
            return JSONObject.stringToValue(s);
    }

    public char skipTo(char c)
        throws JSONException
    {
        int i;
        int j;
        int k;
        i = index;
        j = character;
        k = line;
        reader.mark(0x7fffffff);
_L1:
        char c1 = next();
        if(c1 == 0)
        {
            try
            {
                reader.reset();
                index = i;
                character = j;
                line = k;
            }
            catch(IOException ioexception)
            {
                throw new JSONException(ioexception);
            }
            return c1;
        }
        if(c1 == c)
        {
            back();
            return c1;
        }
          goto _L1
    }

    public JSONException syntaxError(String s)
    {
        return new JSONException(s + toString());
    }

    public String toString()
    {
        return " at " + index + " [character " + character + " line " + line + "]";
    }

    private int character;
    private boolean eof;
    private int index;
    private int line;
    private char previous;
    private Reader reader;
    private boolean usePrevious;
}
