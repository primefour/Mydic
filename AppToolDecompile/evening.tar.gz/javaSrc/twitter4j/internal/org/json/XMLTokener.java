// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.org.json;

import java.util.HashMap;

// Referenced classes of package twitter4j.internal.org.json:
//            JSONTokener, XML, JSONException

public class XMLTokener extends JSONTokener
{

    public XMLTokener(String s)
    {
        super(s);
    }

    public String nextCDATA()
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        int i;
        do
        {
            char c = next();
            if(end())
                throw syntaxError("Unclosed CDATA");
            stringbuffer.append(c);
            i = -3 + stringbuffer.length();
        } while(i < 0 || stringbuffer.charAt(i) != ']' || stringbuffer.charAt(i + 1) != ']' || stringbuffer.charAt(i + 2) != '>');
        stringbuffer.setLength(i);
        return stringbuffer.toString();
    }

    public Object nextContent()
        throws JSONException
    {
        char c;
        do
            c = next();
        while(Character.isWhitespace(c));
        if(c == 0)
            return null;
        if(c == '<')
            return XML.LT;
        StringBuffer stringbuffer = new StringBuffer();
        do
        {
            if(c == '<' || c == 0)
            {
                back();
                return stringbuffer.toString().trim();
            }
            if(c == '&')
                stringbuffer.append(nextEntity(c));
            else
                stringbuffer.append(c);
            c = next();
        } while(true);
    }

    public Object nextEntity(char c)
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        char c1;
        do
        {
            c1 = next();
            if(!Character.isLetterOrDigit(c1) && c1 != '#')
                break;
            stringbuffer.append(Character.toLowerCase(c1));
        } while(true);
        if(c1 == ';')
        {
            String s = stringbuffer.toString();
            Object obj = entity.get(s);
            if(obj != null)
                return obj;
            else
                return c + s + ";";
        } else
        {
            throw syntaxError("Missing ';' in XML entity: &" + stringbuffer);
        }
    }

    public Object nextMeta()
        throws JSONException
    {
        char c;
        do
            c = next();
        while(Character.isWhitespace(c));
        c;
        JVM INSTR lookupswitch 9: default 96
    //                   0: 112
    //                   33: 135
    //                   34: 143
    //                   39: 143
    //                   47: 127
    //                   60: 119
    //                   61: 131
    //                   62: 123
    //                   63: 139;
           goto _L1 _L2 _L3 _L4 _L4 _L5 _L6 _L7 _L8 _L9
_L1:
        char c2;
        c2 = next();
        if(Character.isWhitespace(c2))
            return Boolean.TRUE;
        break; /* Loop/switch isn't completed */
_L2:
        throw syntaxError("Misshaped meta tag");
_L6:
        return XML.LT;
_L8:
        return XML.GT;
_L5:
        return XML.SLASH;
_L7:
        return XML.EQ;
_L3:
        return XML.BANG;
_L9:
        return XML.QUEST;
_L4:
        char c1;
        do
        {
            c1 = next();
            if(c1 == 0)
                throw syntaxError("Unterminated string");
        } while(c1 != c);
        return Boolean.TRUE;
        switch(c2)
        {
        case 0: // '\0'
        case 33: // '!'
        case 34: // '"'
        case 39: // '\''
        case 47: // '/'
        case 60: // '<'
        case 61: // '='
        case 62: // '>'
        case 63: // '?'
            back();
            return Boolean.TRUE;
        }
        if(true) goto _L1; else goto _L10
_L10:
    }

    public Object nextToken()
        throws JSONException
    {
        char c;
        do
            c = next();
        while(Character.isWhitespace(c));
        switch(c)
        {
        default:
            StringBuffer stringbuffer1 = new StringBuffer();
            do
            {
                stringbuffer1.append(c);
                c = next();
                char c1;
                StringBuffer stringbuffer;
                char c2;
                if(Character.isWhitespace(c))
                    return stringbuffer1.toString();
                switch(c)
                {
                case 0: // '\0'
                    return stringbuffer1.toString();

                case 33: // '!'
                case 47: // '/'
                case 61: // '='
                case 62: // '>'
                case 63: // '?'
                case 91: // '['
                case 93: // ']'
                    back();
                    return stringbuffer1.toString();

                case 34: // '"'
                case 39: // '\''
                case 60: // '<'
                    throw syntaxError("Bad character in a name");
                }
            } while(true);

        case 0: // '\0'
            throw syntaxError("Misshaped element");

        case 60: // '<'
            throw syntaxError("Misplaced '<'");

        case 62: // '>'
            return XML.GT;

        case 47: // '/'
            return XML.SLASH;

        case 61: // '='
            return XML.EQ;

        case 33: // '!'
            return XML.BANG;

        case 63: // '?'
            return XML.QUEST;

        case 34: // '"'
        case 39: // '\''
            c1 = c;
            stringbuffer = new StringBuffer();
            do
            {
                c2 = next();
                if(c2 == 0)
                    throw syntaxError("Unterminated string");
                if(c2 == c1)
                    return stringbuffer.toString();
                if(c2 == '&')
                    stringbuffer.append(nextEntity(c2));
                else
                    stringbuffer.append(c2);
            } while(true);
        }
    }

    public boolean skipPast(String s)
        throws JSONException
    {
        int i;
        char ac[];
        int k;
        char c;
        i = s.length();
        ac = new char[i];
        int j = 0;
        do
        {
            k = 0;
            if(j >= i)
                break;
            char c1 = next();
            if(c1 == 0)
                return false;
            ac[j] = c1;
            j++;
        } while(true);
_L3:
        int l = k;
        boolean flag = true;
        int i1 = 0;
label0:
        do
        {
label1:
            {
                if(i1 < i)
                {
                    if(ac[l] == s.charAt(i1))
                        break label1;
                    flag = false;
                }
                if(flag)
                    return true;
                break label0;
            }
            if(++l >= i)
                l -= i;
            i1++;
        } while(true);
        c = next();
        if(c == 0)
            return false;
        if(true) goto _L2; else goto _L1
_L2:
        ac[k] = c;
        if(++k >= i)
            k -= i;
        if(true) goto _L3; else goto _L1
_L1:
    }

    public static final HashMap entity;

    static 
    {
        entity = new HashMap(8);
        entity.put("amp", XML.AMP);
        entity.put("apos", XML.APOS);
        entity.put("gt", XML.GT);
        entity.put("lt", XML.LT);
        entity.put("quot", XML.QUOT);
    }
}
