// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.org.json;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.*;
import java.util.*;

// Referenced classes of package twitter4j.internal.org.json:
//            JSONException, JSONTokener, JSONString, JSONArray

public class JSONObject
{
    private static final class Null
    {

        protected final Object clone()
        {
            return this;
        }

        public boolean equals(Object obj)
        {
            return obj == null || obj == this;
        }

        public String toString()
        {
            return "null";
        }

        private Null()
        {
        }

    }


    public JSONObject()
    {
        map = new HashMap();
    }

    public JSONObject(Object obj)
    {
        this();
        populateMap(obj);
    }

    public JSONObject(Object obj, String as[])
    {
        this();
        Class class1 = obj.getClass();
        int i = 0;
        while(i < as.length) 
        {
            String s = as[i];
            try
            {
                putOpt(s, class1.getField(s).get(obj));
            }
            catch(Exception exception) { }
            i++;
        }
    }

    public JSONObject(String s)
        throws JSONException
    {
        this(new JSONTokener(s));
    }

    public JSONObject(String s, Locale locale)
        throws JSONException
    {
        this();
        ResourceBundle resourcebundle = ResourceBundle.getBundle(s, locale, Thread.currentThread().getContextClassLoader());
        Enumeration enumeration = resourcebundle.getKeys();
        do
        {
            if(!enumeration.hasMoreElements())
                break;
            Object obj = enumeration.nextElement();
            if(obj instanceof String)
            {
                String as[] = ((String)obj).split("\\.");
                int i = -1 + as.length;
                JSONObject jsonobject = this;
                for(int j = 0; j < i; j++)
                {
                    String s1 = as[j];
                    JSONObject jsonobject1 = jsonobject.optJSONObject(s1);
                    if(jsonobject1 == null)
                    {
                        jsonobject1 = new JSONObject();
                        jsonobject.put(s1, jsonobject1);
                    }
                    jsonobject = jsonobject1;
                }

                jsonobject.put(as[i], resourcebundle.getString((String)obj));
            }
        } while(true);
    }

    public JSONObject(Map map1)
    {
        map = new HashMap();
        if(map1 != null)
        {
            Iterator iterator = map1.entrySet().iterator();
            do
            {
                if(!iterator.hasNext())
                    break;
                java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
                Object obj = entry.getValue();
                if(obj != null)
                    map.put(entry.getKey(), wrap(obj));
            } while(true);
        }
    }

    public JSONObject(JSONObject jsonobject, String as[])
    {
        this();
        int i = 0;
        while(i < as.length) 
        {
            try
            {
                putOnce(as[i], jsonobject.opt(as[i]));
            }
            catch(Exception exception) { }
            i++;
        }
    }

    public JSONObject(JSONTokener jsontokener)
        throws JSONException
    {
        this();
        if(jsontokener.nextClean() != '{')
            throw jsontokener.syntaxError("A JSONObject text must begin with '{' found:" + jsontokener.nextClean());
          goto _L1
_L11:
        jsontokener.back();
_L1:
        jsontokener.nextClean();
        JVM INSTR lookupswitch 2: default 76
    //                   0: 167
    //                   125: 196;
           goto _L2 _L3 _L4
_L2:
        String s;
        char c;
        jsontokener.back();
        s = jsontokener.nextValue().toString();
        c = jsontokener.nextClean();
        if(c != '=') goto _L6; else goto _L5
_L5:
        if(jsontokener.next() != '>')
            jsontokener.back();
_L10:
        putOnce(s, jsontokener.nextValue());
        jsontokener.nextClean();
        JVM INSTR lookupswitch 3: default 160
    //                   44: 187
    //                   59: 187
    //                   125: 196;
           goto _L7 _L8 _L8 _L4
_L7:
        throw jsontokener.syntaxError("Expected a ',' or '}'");
_L3:
        throw jsontokener.syntaxError("A JSONObject text must end with '}'");
_L6:
        if(c == ':') goto _L10; else goto _L9
_L9:
        throw jsontokener.syntaxError("Expected a ':' after a key");
_L8:
        if(jsontokener.nextClean() != '}') goto _L11; else goto _L4
_L4:
    }

    public static String doubleToString(double d)
    {
        String s;
        if(Double.isInfinite(d) || Double.isNaN(d))
        {
            s = "null";
        } else
        {
            s = Double.toString(d);
            if(s.indexOf('.') > 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0)
            {
                for(; s.endsWith("0"); s = s.substring(0, -1 + s.length()));
                if(s.endsWith("."))
                    return s.substring(0, -1 + s.length());
            }
        }
        return s;
    }

    public static String[] getNames(Object obj)
    {
        String as[] = null;
        if(obj != null) goto _L2; else goto _L1
_L1:
        return as;
_L2:
        Field afield[] = obj.getClass().getFields();
        int i = afield.length;
        as = null;
        if(i != 0)
        {
            as = new String[i];
            int j = 0;
            while(j < i) 
            {
                as[j] = afield[j].getName();
                j++;
            }
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    public static String[] getNames(JSONObject jsonobject)
    {
        int i = jsonobject.length();
        String as[];
        if(i == 0)
        {
            as = null;
        } else
        {
            Iterator iterator = jsonobject.keys();
            as = new String[i];
            int j = 0;
            while(iterator.hasNext()) 
            {
                as[j] = (String)iterator.next();
                j++;
            }
        }
        return as;
    }

    public static String numberToString(Number number)
        throws JSONException
    {
        if(number == null)
            throw new JSONException("Null pointer");
        testValidity(number);
        String s = number.toString();
        if(s.indexOf('.') > 0 && s.indexOf('e') < 0 && s.indexOf('E') < 0)
        {
            for(; s.endsWith("0"); s = s.substring(0, -1 + s.length()));
            if(s.endsWith("."))
                s = s.substring(0, -1 + s.length());
        }
        return s;
    }

    private void populateMap(Object obj)
    {
        String s;
        String s1;
        Class class1 = obj.getClass();
        ClassLoader classloader = class1.getClassLoader();
        boolean flag = false;
        if(classloader != null)
            flag = true;
        Method amethod[];
        int i;
        Method method;
        Object obj1;
        if(flag)
            amethod = class1.getMethods();
        else
            amethod = class1.getDeclaredMethods();
        i = 0;
        if(i >= amethod.length) goto _L2; else goto _L1
_L1:
        method = amethod[i];
        if(!Modifier.isPublic(method.getModifiers())) goto _L4; else goto _L3
_L3:
        s = method.getName();
        s1 = "";
        if(!s.startsWith("get")) goto _L6; else goto _L5
_L5:
        if(s.equals("getClass") || s.equals("getDeclaringClass"))
            break MISSING_BLOCK_LABEL_294;
          goto _L7
_L14:
        if(s1.length() <= 0 || !Character.isUpperCase(s1.charAt(0)) || method.getParameterTypes().length != 0) goto _L4; else goto _L8
_L8:
        if(s1.length() != 1) goto _L10; else goto _L9
_L9:
        s1 = s1.toLowerCase();
_L12:
        obj1 = method.invoke(obj, (Object[])null);
        String s2;
        if(obj1 != null)
            try
            {
                map.put(s1, wrap(obj1));
            }
            catch(Exception exception) { }
_L4:
        i++;
        break MISSING_BLOCK_LABEL_34;
_L7:
        s1 = s.substring(3);
        continue; /* Loop/switch isn't completed */
_L6:
        if(s.startsWith("is"))
            s1 = s.substring(2);
        continue; /* Loop/switch isn't completed */
_L10:
        if(Character.isUpperCase(s1.charAt(1))) goto _L12; else goto _L11
_L11:
        s2 = s1.substring(0, 1).toLowerCase() + s1.substring(1);
        s1 = s2;
          goto _L12
_L2:
        return;
        s1 = "";
        if(true) goto _L14; else goto _L13
_L13:
    }

    public static String quote(String s)
    {
        StringBuffer stringbuffer;
label0:
        {
label1:
            {
label2:
                {
label3:
                    {
label4:
                        {
label5:
                            {
label6:
                                {
                                    if(s == null || s.length() == 0)
                                        return "\"\"";
                                    char c = '\0';
                                    int i = s.length();
                                    stringbuffer = new StringBuffer(i + 4);
                                    stringbuffer.append('"');
                                    int j = 0;
label7:
                                    do
                                    {
                                        {
                                            if(j >= i)
                                                break label0;
                                            int k = c;
                                            c = s.charAt(j);
                                            switch(c)
                                            {
                                            default:
                                                if(c < ' ' || c >= '\200' && c < '\240' || c >= '\u2000' && c < '\u2100')
                                                {
                                                    String s1 = "000" + Integer.toHexString(c);
                                                    stringbuffer.append("\\u").append(s1.substring(-4 + s1.length()));
                                                } else
                                                {
                                                    stringbuffer.append(c);
                                                }
                                                break;

                                            case 8: // '\b'
                                                break label5;

                                            case 9: // '\t'
                                                break label4;

                                            case 10: // '\n'
                                                break label3;

                                            case 12: // '\f'
                                                break label2;

                                            case 13: // '\r'
                                                break label1;

                                            case 34: // '"'
                                            case 92: // '\\'
                                                break label7;

                                            case 47: // '/'
                                                break label6;
                                            }
                                        }
                                        j++;
                                    } while(true);
                                    stringbuffer.append('\\');
                                    stringbuffer.append(c);
                                    break MISSING_BLOCK_LABEL_219;
                                }
                                if(k == 60)
                                    stringbuffer.append('\\');
                                stringbuffer.append(c);
                                break MISSING_BLOCK_LABEL_219;
                            }
                            stringbuffer.append("\\b");
                            break MISSING_BLOCK_LABEL_219;
                        }
                        stringbuffer.append("\\t");
                        break MISSING_BLOCK_LABEL_219;
                    }
                    stringbuffer.append("\\n");
                    break MISSING_BLOCK_LABEL_219;
                }
                stringbuffer.append("\\f");
                break MISSING_BLOCK_LABEL_219;
            }
            stringbuffer.append("\\r");
            break MISSING_BLOCK_LABEL_219;
        }
        stringbuffer.append('"');
        return stringbuffer.toString();
    }

    public static Object stringToValue(String s)
    {
        if(!s.equals("")) goto _L2; else goto _L1
_L1:
        return s;
_L2:
        char c;
        if(s.equalsIgnoreCase("true"))
            return Boolean.TRUE;
        if(s.equalsIgnoreCase("false"))
            return Boolean.FALSE;
        if(s.equalsIgnoreCase("null"))
            return NULL;
        c = s.charAt(0);
        if((c < '0' || c > '9') && c != '.' && c != '-' && c != '+') goto _L1; else goto _L3
_L3:
        if(c != '0' || s.length() <= 2 || s.charAt(1) != 'x' && s.charAt(1) != 'X')
            break MISSING_BLOCK_LABEL_147;
        Integer integer1 = new Integer(Integer.parseInt(s.substring(2), 16));
        return integer1;
        Exception exception1;
        exception1;
label0:
        {
            Long long1;
            Integer integer;
            try
            {
                if(s.indexOf('.') > -1 || s.indexOf('e') > -1 || s.indexOf('E') > -1)
                    return Double.valueOf(s);
                long1 = new Long(s);
                if(long1.longValue() != (long)long1.intValue())
                    break label0;
                integer = new Integer(long1.intValue());
            }
            catch(Exception exception)
            {
                return s;
            }
            return integer;
        }
        return long1;
    }

    public static void testValidity(Object obj)
        throws JSONException
    {
        if(obj != null)
            if(obj instanceof Double)
            {
                if(((Double)obj).isInfinite() || ((Double)obj).isNaN())
                    throw new JSONException("JSON does not allow non-finite numbers.");
            } else
            if((obj instanceof Float) && (((Float)obj).isInfinite() || ((Float)obj).isNaN()))
                throw new JSONException("JSON does not allow non-finite numbers.");
    }

    public static String valueToString(Object obj)
        throws JSONException
    {
        if(obj == null || obj.equals(null))
            return "null";
        if(obj instanceof JSONString)
        {
            String s;
            try
            {
                s = ((JSONString)obj).toJSONString();
            }
            catch(Exception exception)
            {
                throw new JSONException(exception);
            }
            if(s instanceof String)
                return (String)s;
            else
                throw new JSONException("Bad value from toJSONString: " + s);
        }
        if(obj instanceof Number)
            return numberToString((Number)obj);
        if((obj instanceof Boolean) || (obj instanceof JSONObject) || (obj instanceof JSONArray))
            return obj.toString();
        if(obj instanceof Map)
            return (new JSONObject((Map)obj)).toString();
        if(obj instanceof Collection)
            return (new JSONArray((Collection)obj)).toString();
        if(obj.getClass().isArray())
            return (new JSONArray(obj)).toString();
        else
            return quote(obj.toString());
    }

    static String valueToString(Object obj, int i, int j)
        throws JSONException
    {
        if(obj == null || obj.equals(null))
            return "null";
        String s1;
        if(!(obj instanceof JSONString))
            break MISSING_BLOCK_LABEL_52;
        String s = ((JSONString)obj).toJSONString();
        if(!(s instanceof String))
            break MISSING_BLOCK_LABEL_52;
        s1 = (String)s;
        return s1;
        Exception exception;
        exception;
        if(obj instanceof Number)
            return numberToString((Number)obj);
        if(obj instanceof Boolean)
            return obj.toString();
        if(obj instanceof JSONObject)
            return ((JSONObject)obj).toString(i, j);
        if(obj instanceof JSONArray)
            return ((JSONArray)obj).toString(i, j);
        if(obj instanceof Map)
            return (new JSONObject((Map)obj)).toString(i, j);
        if(obj instanceof Collection)
            return (new JSONArray((Collection)obj)).toString(i, j);
        if(obj.getClass().isArray())
            return (new JSONArray(obj)).toString(i, j);
        else
            return quote(obj.toString());
    }

    public static Object wrap(Object obj)
    {
        if(obj != null)
            break MISSING_BLOCK_LABEL_8;
        return NULL;
        if((obj instanceof JSONObject) || (obj instanceof JSONArray) || NULL.equals(obj) || (obj instanceof JSONString) || (obj instanceof Byte) || (obj instanceof Character) || (obj instanceof Short) || (obj instanceof Integer) || (obj instanceof Long) || (obj instanceof Boolean) || (obj instanceof Float) || (obj instanceof Double) || (obj instanceof String)) goto _L2; else goto _L1
_L1:
        Package package1;
        if(obj instanceof Collection)
            return new JSONArray((Collection)obj);
        if(obj.getClass().isArray())
            return new JSONArray(obj);
        if(obj instanceof Map)
            return new JSONObject((Map)obj);
        package1 = obj.getClass().getPackage();
        if(package1 == null)
            break MISSING_BLOCK_LABEL_229;
        String s = package1.getName();
_L3:
        JSONObject jsonobject;
        if(s.startsWith("java.") || s.startsWith("javax.") || obj.getClass().getClassLoader() == null)
            return obj.toString();
        jsonobject = new JSONObject(obj);
        return jsonobject;
        Exception exception;
        exception;
        obj = null;
_L2:
        return obj;
        s = "";
          goto _L3
    }

    public JSONObject accumulate(String s, Object obj)
        throws JSONException
    {
        testValidity(obj);
        Object obj1 = opt(s);
        if(obj1 == null)
        {
            if(obj instanceof JSONArray)
                obj = (new JSONArray()).put(obj);
            put(s, obj);
            return this;
        }
        if(obj1 instanceof JSONArray)
        {
            ((JSONArray)obj1).put(obj);
            return this;
        } else
        {
            put(s, (new JSONArray()).put(obj1).put(obj));
            return this;
        }
    }

    public JSONObject append(String s, Object obj)
        throws JSONException
    {
        testValidity(obj);
        Object obj1 = opt(s);
        if(obj1 == null)
        {
            put(s, (new JSONArray()).put(obj));
            return this;
        }
        if(obj1 instanceof JSONArray)
        {
            put(s, ((JSONArray)obj1).put(obj));
            return this;
        } else
        {
            throw new JSONException("JSONObject[" + s + "] is not a JSONArray.");
        }
    }

    public Object get(String s)
        throws JSONException
    {
        if(s == null)
            throw new JSONException("Null key.");
        Object obj = opt(s);
        if(obj == null)
            throw new JSONException("JSONObject[" + quote(s) + "] not found.");
        else
            return obj;
    }

    public boolean getBoolean(String s)
        throws JSONException
    {
        Object obj = get(s);
        if(obj.equals(Boolean.FALSE) || (obj instanceof String) && ((String)obj).equalsIgnoreCase("false"))
            return false;
        if(obj.equals(Boolean.TRUE) || (obj instanceof String) && ((String)obj).equalsIgnoreCase("true"))
            return true;
        else
            throw new JSONException("JSONObject[" + quote(s) + "] is not a Boolean.");
    }

    public double getDouble(String s)
        throws JSONException
    {
        Object obj = get(s);
        double d;
        try
        {
            if(obj instanceof Number)
                return ((Number)obj).doubleValue();
            d = Double.parseDouble((String)obj);
        }
        catch(Exception exception)
        {
            throw new JSONException("JSONObject[" + quote(s) + "] is not a number.");
        }
        return d;
    }

    public int getInt(String s)
        throws JSONException
    {
        Object obj = get(s);
        int i;
        try
        {
            if(obj instanceof Number)
                return ((Number)obj).intValue();
            i = Integer.parseInt((String)obj);
        }
        catch(Exception exception)
        {
            throw new JSONException("JSONObject[" + quote(s) + "] is not an int.");
        }
        return i;
    }

    public JSONArray getJSONArray(String s)
        throws JSONException
    {
        Object obj = get(s);
        if(obj instanceof JSONArray)
            return (JSONArray)obj;
        else
            throw new JSONException("JSONObject[" + quote(s) + "] is not a JSONArray.");
    }

    public JSONObject getJSONObject(String s)
        throws JSONException
    {
        Object obj = get(s);
        if(obj instanceof JSONObject)
            return (JSONObject)obj;
        else
            throw new JSONException("JSONObject[" + quote(s) + "] is not a JSONObject.");
    }

    public long getLong(String s)
        throws JSONException
    {
        Object obj = get(s);
        long l;
        try
        {
            if(obj instanceof Number)
                return ((Number)obj).longValue();
            l = Long.parseLong((String)obj);
        }
        catch(Exception exception)
        {
            throw new JSONException("JSONObject[" + quote(s) + "] is not a long.");
        }
        return l;
    }

    public String getString(String s)
        throws JSONException
    {
        Object obj = get(s);
        if(obj == NULL)
            return null;
        else
            return obj.toString();
    }

    public boolean has(String s)
    {
        return map.containsKey(s);
    }

    public JSONObject increment(String s)
        throws JSONException
    {
        Object obj = opt(s);
        if(obj == null)
        {
            put(s, 1);
            return this;
        }
        if(obj instanceof Integer)
        {
            put(s, 1 + ((Integer)obj).intValue());
            return this;
        }
        if(obj instanceof Long)
        {
            put(s, 1L + ((Long)obj).longValue());
            return this;
        }
        if(obj instanceof Double)
        {
            put(s, 1.0D + ((Double)obj).doubleValue());
            return this;
        }
        if(obj instanceof Float)
        {
            put(s, 1.0F + ((Float)obj).floatValue());
            return this;
        } else
        {
            throw new JSONException("Unable to increment [" + quote(s) + "].");
        }
    }

    public boolean isNull(String s)
    {
        return NULL.equals(opt(s));
    }

    public Iterator keys()
    {
        return map.keySet().iterator();
    }

    public int length()
    {
        return map.size();
    }

    public JSONArray names()
    {
        JSONArray jsonarray = new JSONArray();
        for(Iterator iterator = keys(); iterator.hasNext(); jsonarray.put(iterator.next()));
        if(jsonarray.length() == 0)
            jsonarray = null;
        return jsonarray;
    }

    public Object opt(String s)
    {
        if(s == null)
            return null;
        else
            return map.get(s);
    }

    public boolean optBoolean(String s)
    {
        return optBoolean(s, false);
    }

    public boolean optBoolean(String s, boolean flag)
    {
        boolean flag1;
        try
        {
            flag1 = getBoolean(s);
        }
        catch(Exception exception)
        {
            return flag;
        }
        return flag1;
    }

    public double optDouble(String s)
    {
        return optDouble(s, (0.0D / 0.0D));
    }

    public double optDouble(String s, double d)
    {
        double d1;
        try
        {
            d1 = getDouble(s);
        }
        catch(Exception exception)
        {
            return d;
        }
        return d1;
    }

    public int optInt(String s)
    {
        return optInt(s, 0);
    }

    public int optInt(String s, int i)
    {
        int j;
        try
        {
            j = getInt(s);
        }
        catch(Exception exception)
        {
            return i;
        }
        return j;
    }

    public JSONArray optJSONArray(String s)
    {
        Object obj = opt(s);
        if(obj instanceof JSONArray)
            return (JSONArray)obj;
        else
            return null;
    }

    public JSONObject optJSONObject(String s)
    {
        Object obj = opt(s);
        if(obj instanceof JSONObject)
            return (JSONObject)obj;
        else
            return null;
    }

    public long optLong(String s)
    {
        return optLong(s, 0L);
    }

    public long optLong(String s, long l)
    {
        long l1;
        try
        {
            l1 = getLong(s);
        }
        catch(Exception exception)
        {
            return l;
        }
        return l1;
    }

    public String optString(String s)
    {
        return optString(s, "");
    }

    public String optString(String s, String s1)
    {
        Object obj = opt(s);
        if(NULL.equals(obj))
            return s1;
        else
            return obj.toString();
    }

    public JSONObject put(String s, double d)
        throws JSONException
    {
        put(s, new Double(d));
        return this;
    }

    public JSONObject put(String s, int i)
        throws JSONException
    {
        put(s, new Integer(i));
        return this;
    }

    public JSONObject put(String s, long l)
        throws JSONException
    {
        put(s, new Long(l));
        return this;
    }

    public JSONObject put(String s, Object obj)
        throws JSONException
    {
        if(s == null)
            throw new JSONException("Null key.");
        if(obj != null)
        {
            testValidity(obj);
            map.put(s, obj);
            return this;
        } else
        {
            remove(s);
            return this;
        }
    }

    public JSONObject put(String s, Collection collection)
        throws JSONException
    {
        put(s, new JSONArray(collection));
        return this;
    }

    public JSONObject put(String s, Map map1)
        throws JSONException
    {
        put(s, new JSONObject(map1));
        return this;
    }

    public JSONObject put(String s, boolean flag)
        throws JSONException
    {
        Boolean boolean1;
        if(flag)
            boolean1 = Boolean.TRUE;
        else
            boolean1 = Boolean.FALSE;
        put(s, boolean1);
        return this;
    }

    public JSONObject putOnce(String s, Object obj)
        throws JSONException
    {
        if(s != null && obj != null)
        {
            if(opt(s) != null)
                throw new JSONException("Duplicate key \"" + s + "\"");
            put(s, obj);
        }
        return this;
    }

    public JSONObject putOpt(String s, Object obj)
        throws JSONException
    {
        if(s != null && obj != null)
            put(s, obj);
        return this;
    }

    public Object remove(String s)
    {
        return map.remove(s);
    }

    public Iterator sortedKeys()
    {
        return (new TreeSet(map.keySet())).iterator();
    }

    public JSONArray toJSONArray(JSONArray jsonarray)
        throws JSONException
    {
        JSONArray jsonarray1;
        if(jsonarray == null || jsonarray.length() == 0)
        {
            jsonarray1 = null;
        } else
        {
            jsonarray1 = new JSONArray();
            int i = 0;
            while(i < jsonarray.length()) 
            {
                jsonarray1.put(opt(jsonarray.getString(i)));
                i++;
            }
        }
        return jsonarray1;
    }

    public String toString()
    {
        StringBuffer stringbuffer;
        String s;
        try
        {
            Iterator iterator = keys();
            stringbuffer = new StringBuffer("{");
            Object obj;
            for(; iterator.hasNext(); stringbuffer.append(valueToString(map.get(obj))))
            {
                if(stringbuffer.length() > 1)
                    stringbuffer.append(',');
                obj = iterator.next();
                stringbuffer.append(quote(obj.toString()));
                stringbuffer.append(':');
            }

        }
        catch(Exception exception)
        {
            return null;
        }
        stringbuffer.append('}');
        s = stringbuffer.toString();
        return s;
    }

    public String toString(int i)
        throws JSONException
    {
        return toString(i, 0);
    }

    String toString(int i, int j)
        throws JSONException
    {
        int k;
        Iterator iterator;
        int l;
        StringBuffer stringbuffer;
        k = length();
        if(k == 0)
            return "{}";
        iterator = sortedKeys();
        l = j + i;
        stringbuffer = new StringBuffer("{");
        if(k != 1) goto _L2; else goto _L1
_L1:
        Object obj1 = iterator.next();
        stringbuffer.append(quote(obj1.toString()));
        stringbuffer.append(": ");
        stringbuffer.append(valueToString(map.get(obj1), i, j));
_L6:
        stringbuffer.append('}');
        return stringbuffer.toString();
_L4:
        Object obj;
        stringbuffer.append(quote(obj.toString()));
        stringbuffer.append(": ");
        stringbuffer.append(valueToString(map.get(obj), i, l));
_L2:
        if(!iterator.hasNext())
            break; /* Loop/switch isn't completed */
        obj = iterator.next();
        int j1;
        if(stringbuffer.length() > 1)
            stringbuffer.append(",\n");
        else
            stringbuffer.append('\n');
        j1 = 0;
        while(j1 < l) 
        {
            stringbuffer.append(' ');
            j1++;
        }
        if(true) goto _L4; else goto _L3
_L3:
        if(stringbuffer.length() > 1)
        {
            stringbuffer.append('\n');
            int i1 = 0;
            while(i1 < j) 
            {
                stringbuffer.append(' ');
                i1++;
            }
        }
        if(true) goto _L6; else goto _L5
_L5:
    }

    public Writer write(Writer writer)
        throws JSONException
    {
        boolean flag = false;
        Iterator iterator;
        iterator = keys();
        writer.write(123);
_L3:
        if(!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        if(!flag)
            break MISSING_BLOCK_LABEL_34;
        writer.write(44);
        Object obj1;
        Object obj = iterator.next();
        writer.write(quote(obj.toString()));
        writer.write(58);
        obj1 = map.get(obj);
        if(obj1 instanceof JSONObject)
        {
            ((JSONObject)obj1).write(writer);
            break MISSING_BLOCK_LABEL_146;
        }
        IOException ioexception;
        if(obj1 instanceof JSONArray)
        {
            ((JSONArray)obj1).write(writer);
            break MISSING_BLOCK_LABEL_146;
        }
        try
        {
            writer.write(valueToString(obj1));
        }
        // Misplaced declaration of an exception variable
        catch(IOException ioexception)
        {
            throw new JSONException(ioexception);
        }
        break MISSING_BLOCK_LABEL_146;
_L2:
        writer.write(125);
        return writer;
        flag = true;
          goto _L3
    }

    public static final Object NULL = new Null();
    private Map map;

}
