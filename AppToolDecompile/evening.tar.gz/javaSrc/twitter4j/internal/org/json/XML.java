// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.org.json;

import java.util.Iterator;

// Referenced classes of package twitter4j.internal.org.json:
//            JSONException, XMLTokener, JSONObject, JSONArray

public class XML
{

    public XML()
    {
    }

    public static String escape(String s)
    {
        StringBuffer stringbuffer;
        int i;
        int j;
        stringbuffer = new StringBuffer();
        i = 0;
        j = s.length();
_L7:
        char c;
        if(i >= j)
            break MISSING_BLOCK_LABEL_125;
        c = s.charAt(i);
        c;
        JVM INSTR lookupswitch 4: default 72
    //                   34: 115
    //                   38: 85
    //                   60: 95
    //                   62: 105;
           goto _L1 _L2 _L3 _L4 _L5
_L2:
        break MISSING_BLOCK_LABEL_115;
_L3:
        break; /* Loop/switch isn't completed */
_L1:
        stringbuffer.append(c);
_L8:
        i++;
        if(true) goto _L7; else goto _L6
_L6:
        stringbuffer.append("&amp;");
          goto _L8
_L4:
        stringbuffer.append("&lt;");
          goto _L8
_L5:
        stringbuffer.append("&gt;");
          goto _L8
        stringbuffer.append("&quot;");
          goto _L8
        return stringbuffer.toString();
    }

    public static void noSpace(String s)
        throws JSONException
    {
        int i = s.length();
        if(i == 0)
            throw new JSONException("Empty string.");
        for(int j = 0; j < i; j++)
            if(Character.isWhitespace(s.charAt(j)))
                throw new JSONException("'" + s + "' contains a space character.");

    }

    private static boolean parse(XMLTokener xmltokener, JSONObject jsonobject, String s)
        throws JSONException
    {
        Object obj = xmltokener.nextToken();
        if(obj != BANG) goto _L2; else goto _L1
_L1:
        char c = xmltokener.next();
        if(c != '-') goto _L4; else goto _L3
_L3:
        if(xmltokener.next() != '-') goto _L6; else goto _L5
_L5:
        xmltokener.skipPast("-->");
_L8:
        return false;
_L6:
        xmltokener.back();
        break MISSING_BLOCK_LABEL_47;
_L4:
        if(c == '[')
        {
            if(xmltokener.nextToken().equals("CDATA") && xmltokener.next() == '[')
            {
                String s4 = xmltokener.nextCDATA();
                if(s4.length() > 0)
                {
                    jsonobject.accumulate("content", s4);
                    return false;
                }
            } else
            {
                throw xmltokener.syntaxError("Expected 'CDATA['");
            }
            continue; /* Loop/switch isn't completed */
        }
        int i = 1;
        do
        {
            Object obj6 = xmltokener.nextMeta();
            if(obj6 == null)
                throw xmltokener.syntaxError("Missing '>' after '<!'.");
            if(obj6 == LT)
                i++;
            else
            if(obj6 == GT)
                i--;
        } while(i > 0);
        return false;
_L2:
        if(obj == QUEST)
        {
            xmltokener.skipPast("?>");
            return false;
        }
        if(obj == SLASH)
        {
            Object obj5 = xmltokener.nextToken();
            if(s == null)
                throw xmltokener.syntaxError("Mismatched close tag " + obj5);
            if(!obj5.equals(s))
                throw xmltokener.syntaxError("Mismatched " + s + " and " + obj5);
            if(xmltokener.nextToken() != GT)
                throw xmltokener.syntaxError("Misshaped close tag");
            else
                return true;
        }
        if(obj instanceof Character)
            throw xmltokener.syntaxError("Misshaped tag");
        String s1 = (String)obj;
        Object obj1 = null;
        JSONObject jsonobject1 = new JSONObject();
        do
        {
label0:
            {
                Object obj2;
                Object obj3;
                String s2;
                String s3;
                if(obj1 == null)
                    obj2 = xmltokener.nextToken();
                else
                    obj2 = obj1;
                if(!(obj2 instanceof String))
                    break label0;
                s3 = (String)obj2;
                obj1 = xmltokener.nextToken();
                if(obj1 == EQ)
                {
                    Object obj4 = xmltokener.nextToken();
                    if(!(obj4 instanceof String))
                        throw xmltokener.syntaxError("Missing value");
                    jsonobject1.accumulate(s3, stringToValue((String)obj4));
                    obj1 = null;
                } else
                {
                    jsonobject1.accumulate(s3, "");
                }
            }
        } while(true);
        if(obj2 == SLASH)
        {
            if(xmltokener.nextToken() != GT)
                throw xmltokener.syntaxError("Misshaped tag");
            if(jsonobject1.length() > 0)
            {
                jsonobject.accumulate(s1, jsonobject1);
                return false;
            } else
            {
                jsonobject.accumulate(s1, "");
                return false;
            }
        }
        if(obj2 == GT)
        {
label1:
            do
                do
                {
                    obj3 = xmltokener.nextContent();
                    if(obj3 == null)
                    {
                        if(s1 != null)
                            throw xmltokener.syntaxError("Unclosed tag " + s1);
                        continue; /* Loop/switch isn't completed */
                    }
                    if(!(obj3 instanceof String))
                        continue label1;
                    s2 = (String)obj3;
                    if(s2.length() > 0)
                        jsonobject1.accumulate("content", stringToValue(s2));
                } while(true);
            while(obj3 != LT || !parse(xmltokener, jsonobject1, s1));
            if(jsonobject1.length() == 0)
            {
                jsonobject.accumulate(s1, "");
                return false;
            }
            if(jsonobject1.length() == 1 && jsonobject1.opt("content") != null)
            {
                jsonobject.accumulate(s1, jsonobject1.opt("content"));
                return false;
            } else
            {
                jsonobject.accumulate(s1, jsonobject1);
                return false;
            }
        }
        throw xmltokener.syntaxError("Misshaped tag");
        if(true) goto _L8; else goto _L7
_L7:
    }

    public static Object stringToValue(String s)
    {
        byte byte0 = 1;
        if(!s.equals("")) goto _L2; else goto _L1
_L1:
        return s;
_L2:
        char c;
        boolean flag;
        if(s.equalsIgnoreCase("true"))
            return Boolean.TRUE;
        if(s.equalsIgnoreCase("false"))
            return Boolean.FALSE;
        if(s.equalsIgnoreCase("null"))
            return JSONObject.NULL;
        Long long1;
        Integer integer;
        try
        {
            c = s.charAt(0);
        }
        catch(Exception exception)
        {
            return s;
        }
        flag = false;
        if(c != '-') goto _L4; else goto _L3
_L3:
        c = s.charAt(1);
        flag = true;
          goto _L4
_L9:
        if(s.charAt(byte0) == '0') goto _L1; else goto _L5
_L5:
        if(c < '0' || c > '9') goto _L1; else goto _L6
_L6:
        if(s.indexOf('.') >= 0)
            return Double.valueOf(s);
        if(s.indexOf('e') >= 0 || s.indexOf('E') >= 0) goto _L1; else goto _L7
_L7:
        long1 = new Long(s);
        if(long1.longValue() != (long)long1.intValue())
            break MISSING_BLOCK_LABEL_175;
        integer = new Integer(long1.intValue());
        return integer;
        return long1;
_L4:
        if(c != '0') goto _L5; else goto _L8
_L8:
        if(flag)
            byte0 = 2;
          goto _L9
    }

    public static JSONObject toJSONObject(String s)
        throws JSONException
    {
        JSONObject jsonobject = new JSONObject();
        for(XMLTokener xmltokener = new XMLTokener(s); xmltokener.more() && xmltokener.skipPast("<"); parse(xmltokener, jsonobject, null));
        return jsonobject;
    }

    public static String toString(Object obj)
        throws JSONException
    {
        return toString(obj, null);
    }

    public static String toString(Object obj, String s)
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        if(obj instanceof JSONObject)
        {
            if(s != null)
            {
                stringbuffer.append('<');
                stringbuffer.append(s);
                stringbuffer.append('>');
            }
            JSONObject jsonobject = (JSONObject)obj;
            for(Iterator iterator = jsonobject.keys(); iterator.hasNext();)
            {
                String s3 = iterator.next().toString();
                Object obj2 = jsonobject.opt(s3);
                if(obj2 == null)
                    obj2 = "";
                if(obj2 instanceof String)
                {
                    String _tmp = (String)obj2;
                }
                if(s3.equals("content"))
                {
                    if(obj2 instanceof JSONArray)
                    {
                        JSONArray jsonarray2 = (JSONArray)obj2;
                        int i1 = jsonarray2.length();
                        int j1 = 0;
                        while(j1 < i1) 
                        {
                            if(j1 > 0)
                                stringbuffer.append('\n');
                            stringbuffer.append(escape(jsonarray2.get(j1).toString()));
                            j1++;
                        }
                    } else
                    {
                        stringbuffer.append(escape(obj2.toString()));
                    }
                } else
                if(obj2 instanceof JSONArray)
                {
                    JSONArray jsonarray1 = (JSONArray)obj2;
                    int k = jsonarray1.length();
                    int l = 0;
                    while(l < k) 
                    {
                        Object obj3 = jsonarray1.get(l);
                        if(obj3 instanceof JSONArray)
                        {
                            stringbuffer.append('<');
                            stringbuffer.append(s3);
                            stringbuffer.append('>');
                            stringbuffer.append(toString(obj3));
                            stringbuffer.append("</");
                            stringbuffer.append(s3);
                            stringbuffer.append('>');
                        } else
                        {
                            stringbuffer.append(toString(obj3, s3));
                        }
                        l++;
                    }
                } else
                if(obj2.equals(""))
                {
                    stringbuffer.append('<');
                    stringbuffer.append(s3);
                    stringbuffer.append("/>");
                } else
                {
                    stringbuffer.append(toString(obj2, s3));
                }
            }

            if(s != null)
            {
                stringbuffer.append("</");
                stringbuffer.append(s);
                stringbuffer.append('>');
            }
            return stringbuffer.toString();
        }
        if(obj instanceof JSONArray)
        {
            JSONArray jsonarray = (JSONArray)obj;
            int i = jsonarray.length();
            int j = 0;
            while(j < i) 
            {
                Object obj1 = jsonarray.opt(j);
                String s2;
                if(s == null)
                    s2 = "array";
                else
                    s2 = s;
                stringbuffer.append(toString(obj1, s2));
                j++;
            }
            return stringbuffer.toString();
        }
        String s1;
        if(obj == null)
            s1 = "null";
        else
            s1 = escape(obj.toString());
        if(s == null)
            return "\"" + s1 + "\"";
        if(s1.length() == 0)
            return "<" + s + "/>";
        else
            return "<" + s + ">" + s1 + "</" + s + ">";
    }

    public static final Character AMP = new Character('&');
    public static final Character APOS = new Character('\'');
    public static final Character BANG = new Character('!');
    public static final Character EQ = new Character('=');
    public static final Character GT = new Character('>');
    public static final Character LT = new Character('<');
    public static final Character QUEST = new Character('?');
    public static final Character QUOT = new Character('"');
    public static final Character SLASH = new Character('/');

}
