// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.org.json;

import java.io.IOException;
import java.io.Writer;
import java.lang.reflect.Array;
import java.util.*;

// Referenced classes of package twitter4j.internal.org.json:
//            JSONException, JSONObject, JSONTokener

public class JSONArray
{

    public JSONArray()
    {
        myArrayList = new ArrayList();
    }

    public JSONArray(Object obj)
        throws JSONException
    {
        this();
        if(obj.getClass().isArray())
        {
            int i = Array.getLength(obj);
            for(int j = 0; j < i; j++)
                put(JSONObject.wrap(Array.get(obj, j)));

        } else
        {
            throw new JSONException("JSONArray initial value should be a string or collection or array.");
        }
    }

    public JSONArray(String s)
        throws JSONException
    {
        this(new JSONTokener(s));
    }

    public JSONArray(Collection collection)
    {
        myArrayList = new ArrayList();
        if(collection != null)
        {
            Object obj;
            for(Iterator iterator = collection.iterator(); iterator.hasNext(); myArrayList.add(JSONObject.wrap(obj)))
                obj = iterator.next();

        }
    }

    public JSONArray(JSONTokener jsontokener)
        throws JSONException
    {
        this();
        if(jsontokener.nextClean() != '[')
            throw jsontokener.syntaxError("A JSONArray text must start with '['");
        if(jsontokener.nextClean() == ']') goto _L2; else goto _L1
_L1:
        jsontokener.back();
_L7:
        if(jsontokener.nextClean() == ',')
        {
            jsontokener.back();
            myArrayList.add(JSONObject.NULL);
        } else
        {
            jsontokener.back();
            myArrayList.add(jsontokener.nextValue());
        }
        jsontokener.nextClean();
        JVM INSTR lookupswitch 3: default 96
    //                   44: 122
    //                   59: 122
    //                   93: 131;
           goto _L3 _L4 _L4 _L2
_L3:
        throw jsontokener.syntaxError("Expected a ',' or ']'");
_L4:
        if(jsontokener.nextClean() != ']') goto _L5; else goto _L2
_L2:
        return;
_L5:
        jsontokener.back();
        if(true) goto _L7; else goto _L6
_L6:
    }

    public Object get(int i)
        throws JSONException
    {
        Object obj = opt(i);
        if(obj == null)
            throw new JSONException("JSONArray[" + i + "] not found.");
        else
            return obj;
    }

    public boolean getBoolean(int i)
        throws JSONException
    {
        Object obj = get(i);
        if(obj.equals(Boolean.FALSE) || (obj instanceof String) && ((String)obj).equalsIgnoreCase("false"))
            return false;
        if(obj.equals(Boolean.TRUE) || (obj instanceof String) && ((String)obj).equalsIgnoreCase("true"))
            return true;
        else
            throw new JSONException("JSONArray[" + i + "] is not a boolean.");
    }

    public double getDouble(int i)
        throws JSONException
    {
        Object obj = get(i);
        double d;
        try
        {
            if(obj instanceof Number)
                return ((Number)obj).doubleValue();
            d = Double.parseDouble((String)obj);
        }
        catch(Exception exception)
        {
            throw new JSONException("JSONArray[" + i + "] is not a number.");
        }
        return d;
    }

    public int getInt(int i)
        throws JSONException
    {
        Object obj = get(i);
        int j;
        try
        {
            if(obj instanceof Number)
                return ((Number)obj).intValue();
            j = Integer.parseInt((String)obj);
        }
        catch(Exception exception)
        {
            throw new JSONException("JSONArray[" + i + "] is not a number.");
        }
        return j;
    }

    public JSONArray getJSONArray(int i)
        throws JSONException
    {
        Object obj = get(i);
        if(obj instanceof JSONArray)
            return (JSONArray)obj;
        else
            throw new JSONException("JSONArray[" + i + "] is not a JSONArray.");
    }

    public JSONObject getJSONObject(int i)
        throws JSONException
    {
        Object obj = get(i);
        if(obj instanceof JSONObject)
            return (JSONObject)obj;
        else
            throw new JSONException("JSONArray[" + i + "] is not a JSONObject.");
    }

    public long getLong(int i)
        throws JSONException
    {
        Object obj = get(i);
        long l;
        try
        {
            if(obj instanceof Number)
                return ((Number)obj).longValue();
            l = Long.parseLong((String)obj);
        }
        catch(Exception exception)
        {
            throw new JSONException("JSONArray[" + i + "] is not a number.");
        }
        return l;
    }

    public String getString(int i)
        throws JSONException
    {
        Object obj = get(i);
        if(obj == JSONObject.NULL)
            return null;
        else
            return obj.toString();
    }

    public boolean isNull(int i)
    {
        return JSONObject.NULL.equals(opt(i));
    }

    public String join(String s)
        throws JSONException
    {
        int i = length();
        StringBuffer stringbuffer = new StringBuffer();
        for(int j = 0; j < i; j++)
        {
            if(j > 0)
                stringbuffer.append(s);
            stringbuffer.append(JSONObject.valueToString(myArrayList.get(j)));
        }

        return stringbuffer.toString();
    }

    public int length()
    {
        return myArrayList.size();
    }

    public Object opt(int i)
    {
        if(i < 0 || i >= length())
            return null;
        else
            return myArrayList.get(i);
    }

    public boolean optBoolean(int i)
    {
        return optBoolean(i, false);
    }

    public boolean optBoolean(int i, boolean flag)
    {
        boolean flag1;
        try
        {
            flag1 = getBoolean(i);
        }
        catch(Exception exception)
        {
            return flag;
        }
        return flag1;
    }

    public double optDouble(int i)
    {
        return optDouble(i, (0.0D / 0.0D));
    }

    public double optDouble(int i, double d)
    {
        double d1;
        try
        {
            d1 = getDouble(i);
        }
        catch(Exception exception)
        {
            return d;
        }
        return d1;
    }

    public int optInt(int i)
    {
        return optInt(i, 0);
    }

    public int optInt(int i, int j)
    {
        int k;
        try
        {
            k = getInt(i);
        }
        catch(Exception exception)
        {
            return j;
        }
        return k;
    }

    public JSONArray optJSONArray(int i)
    {
        Object obj = opt(i);
        if(obj instanceof JSONArray)
            return (JSONArray)obj;
        else
            return null;
    }

    public JSONObject optJSONObject(int i)
    {
        Object obj = opt(i);
        if(obj instanceof JSONObject)
            return (JSONObject)obj;
        else
            return null;
    }

    public long optLong(int i)
    {
        return optLong(i, 0L);
    }

    public long optLong(int i, long l)
    {
        long l1;
        try
        {
            l1 = getLong(i);
        }
        catch(Exception exception)
        {
            return l;
        }
        return l1;
    }

    public String optString(int i)
    {
        return optString(i, "");
    }

    public String optString(int i, String s)
    {
        Object obj = opt(i);
        if(obj != null)
            s = obj.toString();
        return s;
    }

    public JSONArray put(double d)
        throws JSONException
    {
        Double double1 = new Double(d);
        JSONObject.testValidity(double1);
        put(double1);
        return this;
    }

    public JSONArray put(int i)
    {
        put(new Integer(i));
        return this;
    }

    public JSONArray put(int i, double d)
        throws JSONException
    {
        put(i, new Double(d));
        return this;
    }

    public JSONArray put(int i, int j)
        throws JSONException
    {
        put(i, new Integer(j));
        return this;
    }

    public JSONArray put(int i, long l)
        throws JSONException
    {
        put(i, new Long(l));
        return this;
    }

    public JSONArray put(int i, Object obj)
        throws JSONException
    {
        JSONObject.testValidity(obj);
        if(i < 0)
            throw new JSONException("JSONArray[" + i + "] not found.");
        if(i < length())
        {
            myArrayList.set(i, obj);
            return this;
        }
        for(; i != length(); put(JSONObject.NULL));
        put(obj);
        return this;
    }

    public JSONArray put(int i, Collection collection)
        throws JSONException
    {
        put(i, new JSONArray(collection));
        return this;
    }

    public JSONArray put(int i, Map map)
        throws JSONException
    {
        put(i, new JSONObject(map));
        return this;
    }

    public JSONArray put(int i, boolean flag)
        throws JSONException
    {
        Boolean boolean1;
        if(flag)
            boolean1 = Boolean.TRUE;
        else
            boolean1 = Boolean.FALSE;
        put(i, boolean1);
        return this;
    }

    public JSONArray put(long l)
    {
        put(new Long(l));
        return this;
    }

    public JSONArray put(Object obj)
    {
        myArrayList.add(obj);
        return this;
    }

    public JSONArray put(Collection collection)
    {
        put(new JSONArray(collection));
        return this;
    }

    public JSONArray put(Map map)
    {
        put(new JSONObject(map));
        return this;
    }

    public JSONArray put(boolean flag)
    {
        Boolean boolean1;
        if(flag)
            boolean1 = Boolean.TRUE;
        else
            boolean1 = Boolean.FALSE;
        put(boolean1);
        return this;
    }

    public Object remove(int i)
    {
        Object obj = opt(i);
        myArrayList.remove(i);
        return obj;
    }

    public JSONObject toJSONObject(JSONArray jsonarray)
        throws JSONException
    {
        JSONObject jsonobject;
        if(jsonarray == null || jsonarray.length() == 0 || length() == 0)
        {
            jsonobject = null;
        } else
        {
            jsonobject = new JSONObject();
            int i = 0;
            while(i < jsonarray.length()) 
            {
                jsonobject.put(jsonarray.getString(i), opt(i));
                i++;
            }
        }
        return jsonobject;
    }

    public String toString()
    {
        String s;
        try
        {
            s = '[' + join(",") + ']';
        }
        catch(Exception exception)
        {
            return null;
        }
        return s;
    }

    public String toString(int i)
        throws JSONException
    {
        return toString(i, 0);
    }

    String toString(int i, int j)
        throws JSONException
    {
        int k = length();
        if(k == 0)
            return "[]";
        StringBuffer stringbuffer = new StringBuffer("[");
        if(k == 1)
        {
            stringbuffer.append(JSONObject.valueToString(myArrayList.get(0), i, j));
        } else
        {
            int l = j + i;
            stringbuffer.append('\n');
            for(int i1 = 0; i1 < k; i1++)
            {
                if(i1 > 0)
                    stringbuffer.append(",\n");
                for(int k1 = 0; k1 < l; k1++)
                    stringbuffer.append(' ');

                stringbuffer.append(JSONObject.valueToString(myArrayList.get(i1), i, l));
            }

            stringbuffer.append('\n');
            int j1 = 0;
            while(j1 < j) 
            {
                stringbuffer.append(' ');
                j1++;
            }
        }
        stringbuffer.append(']');
        return stringbuffer.toString();
    }

    public Writer write(Writer writer)
        throws JSONException
    {
        boolean flag;
        int j;
        Object obj;
        flag = false;
        int i;
        try
        {
            i = length();
            writer.write(91);
        }
        catch(IOException ioexception)
        {
            throw new JSONException(ioexception);
        }
        j = 0;
_L2:
        if(j >= i)
            break MISSING_BLOCK_LABEL_109;
        if(!flag)
            break MISSING_BLOCK_LABEL_34;
        writer.write(44);
        obj = myArrayList.get(j);
        if(obj instanceof JSONObject)
        {
            ((JSONObject)obj).write(writer);
            break MISSING_BLOCK_LABEL_117;
        }
        if(obj instanceof JSONArray)
        {
            ((JSONArray)obj).write(writer);
            break MISSING_BLOCK_LABEL_117;
        }
        writer.write(JSONObject.valueToString(obj));
        break MISSING_BLOCK_LABEL_117;
        writer.write(93);
        return writer;
        flag = true;
        j++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private ArrayList myArrayList;
}
