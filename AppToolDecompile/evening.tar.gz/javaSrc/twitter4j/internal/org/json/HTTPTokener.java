// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.org.json;


// Referenced classes of package twitter4j.internal.org.json:
//            JSONTokener, JSONException

public class HTTPTokener extends JSONTokener
{

    public HTTPTokener(String s)
    {
        super(s);
    }

    public String nextToken()
        throws JSONException
    {
        StringBuffer stringbuffer = new StringBuffer();
        char c;
        do
            c = next();
        while(Character.isWhitespace(c));
        if(c == '"' || c == '\'')
        {
            char c1 = c;
            do
            {
                char c2 = next();
                if(c2 < ' ')
                    throw syntaxError("Unterminated string.");
                if(c2 == c1)
                    return stringbuffer.toString();
                stringbuffer.append(c2);
            } while(true);
        }
        for(; c != 0 && !Character.isWhitespace(c); c = next())
            stringbuffer.append(c);

        return stringbuffer.toString();
    }
}
