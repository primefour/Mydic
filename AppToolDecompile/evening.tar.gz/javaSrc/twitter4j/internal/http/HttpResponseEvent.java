// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;

import twitter4j.TwitterException;
import twitter4j.auth.Authorization;

// Referenced classes of package twitter4j.internal.http:
//            HttpRequest, HttpResponse

public final class HttpResponseEvent
{

    HttpResponseEvent(HttpRequest httprequest, HttpResponse httpresponse, TwitterException twitterexception)
    {
        request = httprequest;
        response = httpresponse;
        twitterException = twitterexception;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            HttpResponseEvent httpresponseevent = (HttpResponseEvent)obj;
            if(request == null ? httpresponseevent.request != null : !request.equals(httpresponseevent.request))
                return false;
            if(response == null ? httpresponseevent.response != null : !response.equals(httpresponseevent.response))
                return false;
        }
        return true;
    }

    public HttpRequest getRequest()
    {
        return request;
    }

    public HttpResponse getResponse()
    {
        return response;
    }

    public TwitterException getTwitterException()
    {
        return twitterException;
    }

    public int hashCode()
    {
        int i;
        int j;
        HttpResponse httpresponse;
        int k;
        if(request != null)
            i = request.hashCode();
        else
            i = 0;
        j = i * 31;
        httpresponse = response;
        k = 0;
        if(httpresponse != null)
            k = response.hashCode();
        return j + k;
    }

    public boolean isAuthenticated()
    {
        return request.getAuthorization().isEnabled();
    }

    public String toString()
    {
        return "HttpResponseEvent{request=" + request + ", response=" + response + '}';
    }

    private HttpRequest request;
    private HttpResponse response;
    private TwitterException twitterException;
}
