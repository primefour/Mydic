// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;

import java.io.*;
import java.util.Map;
import twitter4j.TwitterException;
import twitter4j.conf.ConfigurationContext;
import twitter4j.internal.logging.Logger;
import twitter4j.internal.org.json.*;

// Referenced classes of package twitter4j.internal.http:
//            HttpClientConfiguration

public abstract class HttpResponse
{

    HttpResponse()
    {
        responseAsString = null;
        streamConsumed = false;
        json = null;
        jsonArray = null;
        CONF = ConfigurationContext.getInstance();
    }

    public HttpResponse(HttpClientConfiguration httpclientconfiguration)
    {
        responseAsString = null;
        streamConsumed = false;
        json = null;
        jsonArray = null;
        CONF = httpclientconfiguration;
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    private void disconnectForcibly()
    {
        try
        {
            disconnect();
            return;
        }
        catch(Exception exception)
        {
            return;
        }
    }

    public JSONArray asJSONArray()
        throws TwitterException
    {
        if(jsonArray != null) goto _L2; else goto _L1
_L1:
        Reader reader = null;
        String s = responseAsString;
        reader = null;
        if(s != null) goto _L4; else goto _L3
_L3:
        reader = asReader();
        jsonArray = new JSONArray(new JSONTokener(reader));
_L7:
        if(!CONF.isPrettyDebugEnabled()) goto _L6; else goto _L5
_L5:
        logger.debug(jsonArray.toString(1));
_L10:
        Exception exception;
        JSONException jsonexception;
        Logger logger1;
        String s1;
        String s2;
        if(reader != null)
            try
            {
                reader.close();
            }
            catch(IOException ioexception1) { }
        disconnectForcibly();
_L2:
        return jsonArray;
_L4:
        jsonArray = new JSONArray(responseAsString);
        reader = null;
          goto _L7
        jsonexception;
        if(logger.isDebugEnabled())
            throw new TwitterException(jsonexception.getMessage() + ":" + responseAsString, jsonexception);
        break MISSING_BLOCK_LABEL_219;
        exception;
        if(reader != null)
            try
            {
                reader.close();
            }
            catch(IOException ioexception) { }
        disconnectForcibly();
        throw exception;
_L6:
        logger1 = logger;
        if(responseAsString == null) goto _L9; else goto _L8
_L8:
        s2 = responseAsString;
_L11:
        logger1.debug(s2);
          goto _L10
_L9:
        s1 = jsonArray.toString();
        s2 = s1;
          goto _L11
        throw new TwitterException(jsonexception.getMessage(), jsonexception);
          goto _L7
    }

    public JSONObject asJSONObject()
        throws TwitterException
    {
        if(json != null) goto _L2; else goto _L1
_L1:
        Reader reader = null;
        String s = responseAsString;
        reader = null;
        if(s != null) goto _L4; else goto _L3
_L3:
        reader = asReader();
        json = new JSONObject(new JSONTokener(reader));
_L7:
        if(!CONF.isPrettyDebugEnabled()) goto _L6; else goto _L5
_L5:
        logger.debug(json.toString(1));
_L10:
        Exception exception;
        JSONException jsonexception;
        Logger logger1;
        String s1;
        String s2;
        if(reader != null)
            try
            {
                reader.close();
            }
            catch(IOException ioexception1) { }
        disconnectForcibly();
_L2:
        return json;
_L4:
        json = new JSONObject(responseAsString);
        reader = null;
          goto _L7
        jsonexception;
        if(responseAsString == null)
            throw new TwitterException(jsonexception.getMessage(), jsonexception);
        break MISSING_BLOCK_LABEL_192;
        exception;
        if(reader != null)
            try
            {
                reader.close();
            }
            catch(IOException ioexception) { }
        disconnectForcibly();
        throw exception;
_L6:
        logger1 = logger;
        if(responseAsString == null) goto _L9; else goto _L8
_L8:
        s2 = responseAsString;
_L11:
        logger1.debug(s2);
          goto _L10
_L9:
        s1 = json.toString();
        s2 = s1;
          goto _L11
        throw new TwitterException(jsonexception.getMessage() + ":" + responseAsString, jsonexception);
          goto _L7
    }

    public Reader asReader()
    {
        BufferedReader bufferedreader;
        try
        {
            bufferedreader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            return new InputStreamReader(is);
        }
        return bufferedreader;
    }

    public InputStream asStream()
    {
        if(streamConsumed)
            throw new IllegalStateException("Stream has already been consumed.");
        else
            return is;
    }

    public String asString()
        throws TwitterException
    {
        if(responseAsString != null) goto _L2; else goto _L1
_L1:
        BufferedReader bufferedreader;
        InputStream inputstream;
        bufferedreader = null;
        inputstream = null;
        InputStream inputstream1 = asStream();
        IOException ioexception;
        Exception exception;
        BufferedReader bufferedreader1;
        inputstream = inputstream1;
        if(inputstream == null)
        {
            StringBuffer stringbuffer;
            String s;
            if(inputstream != null)
                try
                {
                    inputstream.close();
                }
                catch(IOException ioexception6) { }
            if(false)
                try
                {
                    null.close();
                }
                catch(IOException ioexception5) { }
            disconnectForcibly();
            return null;
        }
        bufferedreader1 = new BufferedReader(new InputStreamReader(inputstream, "UTF-8"));
        stringbuffer = new StringBuffer();
_L5:
        s = bufferedreader1.readLine();
        if(s == null) goto _L4; else goto _L3
_L3:
        stringbuffer.append(s).append("\n");
          goto _L5
        ioexception;
        bufferedreader = bufferedreader1;
_L9:
        throw new TwitterException(ioexception.getMessage(), ioexception);
        exception;
_L7:
        IOException ioexception3;
        IOException ioexception4;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            catch(IOException ioexception2) { }
        if(bufferedreader != null)
            try
            {
                bufferedreader.close();
            }
            catch(IOException ioexception1) { }
        disconnectForcibly();
        throw exception;
_L4:
        responseAsString = stringbuffer.toString();
        logger.debug(responseAsString);
        inputstream.close();
        streamConsumed = true;
        if(inputstream != null)
            try
            {
                inputstream.close();
            }
            // Misplaced declaration of an exception variable
            catch(IOException ioexception4) { }
        if(bufferedreader1 != null)
            try
            {
                bufferedreader1.close();
            }
            // Misplaced declaration of an exception variable
            catch(IOException ioexception3) { }
        disconnectForcibly();
_L2:
        return responseAsString;
        exception;
        bufferedreader = bufferedreader1;
        if(true) goto _L7; else goto _L6
_L6:
        ioexception;
        bufferedreader = null;
        if(true) goto _L9; else goto _L8
_L8:
    }

    public abstract void disconnect()
        throws IOException;

    public abstract String getResponseHeader(String s);

    public abstract Map getResponseHeaderFields();

    public int getStatusCode()
    {
        return statusCode;
    }

    public String toString()
    {
        return "HttpResponse{statusCode=" + statusCode + ", responseAsString='" + responseAsString + '\'' + ", is=" + is + ", streamConsumed=" + streamConsumed + '}';
    }

    static Class class$twitter4j$internal$http$HttpResponseImpl;
    private static final Logger logger;
    protected final HttpClientConfiguration CONF;
    protected InputStream is;
    private JSONObject json;
    private JSONArray jsonArray;
    protected String responseAsString;
    protected int statusCode;
    private boolean streamConsumed;

    static 
    {
        Class class1;
        if(class$twitter4j$internal$http$HttpResponseImpl == null)
        {
            class1 = _mthclass$("twitter4j.internal.http.HttpResponseImpl");
            class$twitter4j$internal$http$HttpResponseImpl = class1;
        } else
        {
            class1 = class$twitter4j$internal$http$HttpResponseImpl;
        }
        logger = Logger.getLogger(class1);
    }
}
