// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;

import java.io.*;
import java.net.*;
import java.util.*;
import twitter4j.TwitterException;
import twitter4j.auth.Authorization;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationContext;
import twitter4j.internal.logging.Logger;
import twitter4j.internal.util.z_T4JInternalStringUtil;

// Referenced classes of package twitter4j.internal.http:
//            HttpClientBase, HttpClient, HttpResponseCode, HttpClientConfiguration, 
//            HttpRequest, RequestMethod, HttpParameter, HttpResponseImpl, 
//            HttpResponse

public class HttpClientImpl extends HttpClientBase
    implements HttpClient, HttpResponseCode, Serializable
{

    public HttpClientImpl()
    {
        super(ConfigurationContext.getInstance());
    }

    public HttpClientImpl(HttpClientConfiguration httpclientconfiguration)
    {
        super(httpclientconfiguration);
        if(isProxyConfigured() && isJDK14orEarlier)
            logger.warn("HTTP Proxy is not supported on JDK1.4 or earlier. Try twitter4j-httpclient-supoprt artifact");
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public static String encode(String s)
    {
        String s1;
        try
        {
            s1 = URLEncoder.encode(s, "UTF-8");
        }
        catch(UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new AssertionError("will never happen");
        }
        return s1;
    }

    private HttpURLConnection getConnection(String s)
        throws IOException
    {
        HttpURLConnection httpurlconnection;
        if(isProxyConfigured() && !isJDK14orEarlier)
        {
            if(CONF.getHttpProxyUser() != null && !CONF.getHttpProxyUser().equals(""))
            {
                if(logger.isDebugEnabled())
                {
                    logger.debug("Proxy AuthUser: " + CONF.getHttpProxyUser());
                    logger.debug("Proxy AuthPassword: " + z_T4JInternalStringUtil.maskString(CONF.getHttpProxyPassword()));
                }
                Authenticator.setDefault(new Authenticator() {

                    protected PasswordAuthentication getPasswordAuthentication()
                    {
                        if(getRequestorType().equals(java.net.Authenticator.RequestorType.PROXY))
                            return new PasswordAuthentication(CONF.getHttpProxyUser(), CONF.getHttpProxyPassword().toCharArray());
                        else
                            return null;
                    }

                    private final HttpClientImpl this$0;

            
            {
                this$0 = HttpClientImpl.this;
                super();
            }
                });
            }
            Proxy proxy = new Proxy(java.net.Proxy.Type.HTTP, InetSocketAddress.createUnresolved(CONF.getHttpProxyHost(), CONF.getHttpProxyPort()));
            if(logger.isDebugEnabled())
                logger.debug("Opening proxied connection(" + CONF.getHttpProxyHost() + ":" + CONF.getHttpProxyPort() + ")");
            httpurlconnection = (HttpURLConnection)(new URL(s)).openConnection(proxy);
        } else
        {
            httpurlconnection = (HttpURLConnection)(new URL(s)).openConnection();
        }
        if(CONF.getHttpConnectionTimeout() > 0 && !isJDK14orEarlier)
            httpurlconnection.setConnectTimeout(CONF.getHttpConnectionTimeout());
        if(CONF.getHttpReadTimeout() > 0 && !isJDK14orEarlier)
            httpurlconnection.setReadTimeout(CONF.getHttpReadTimeout());
        httpurlconnection.setInstanceFollowRedirects(false);
        return httpurlconnection;
    }

    public static HttpClient getInstance(HttpClientConfiguration httpclientconfiguration)
    {
        Object obj = (HttpClient)instanceMap.get(httpclientconfiguration);
        if(obj == null)
        {
            obj = new HttpClientImpl(httpclientconfiguration);
            instanceMap.put(httpclientconfiguration, obj);
        }
        return ((HttpClient) (obj));
    }

    private void setHeaders(HttpRequest httprequest, HttpURLConnection httpurlconnection)
    {
        if(logger.isDebugEnabled())
        {
            logger.debug("Request: ");
            logger.debug(httprequest.getMethod().name() + " ", httprequest.getURL());
        }
        if(httprequest.getAuthorization() != null)
        {
            String s1 = httprequest.getAuthorization().getAuthorizationHeader(httprequest);
            if(s1 != null)
            {
                if(logger.isDebugEnabled())
                    logger.debug("Authorization: ", z_T4JInternalStringUtil.maskString(s1));
                httpurlconnection.addRequestProperty("Authorization", s1);
            }
        }
        if(httprequest.getRequestHeaders() != null)
        {
            String s;
            for(Iterator iterator = httprequest.getRequestHeaders().keySet().iterator(); iterator.hasNext(); logger.debug(s + ": " + (String)httprequest.getRequestHeaders().get(s)))
            {
                s = (String)iterator.next();
                httpurlconnection.addRequestProperty(s, (String)httprequest.getRequestHeaders().get(s));
            }

        }
    }

    public HttpResponse get(String s)
        throws TwitterException
    {
        return request(new HttpRequest(RequestMethod.GET, s, null, null, null));
    }

    public HttpResponse post(String s, HttpParameter ahttpparameter[])
        throws TwitterException
    {
        return request(new HttpRequest(RequestMethod.POST, s, ahttpparameter, null, null));
    }

    public HttpResponse request(HttpRequest httprequest)
        throws TwitterException
    {
        int i;
        int j;
        Object obj;
        i = 1 + CONF.getHttpRetryCount();
        j = 0;
        obj = null;
_L31:
        if(j >= i) goto _L2; else goto _L1
_L1:
        int k;
        OutputStream outputstream;
        k = -1;
        outputstream = null;
        HttpURLConnection httpurlconnection;
        RequestMethod requestmethod;
        RequestMethod requestmethod1;
        httpurlconnection = getConnection(httprequest.getURL());
        httpurlconnection.setDoInput(true);
        setHeaders(httprequest, httpurlconnection);
        httpurlconnection.setRequestMethod(httprequest.getMethod().name());
        requestmethod = httprequest.getMethod();
        requestmethod1 = RequestMethod.POST;
        outputstream = null;
        if(requestmethod != requestmethod1) goto _L4; else goto _L3
_L3:
        boolean flag = HttpParameter.containsFile(httprequest.getParameters());
        outputstream = null;
        if(!flag) goto _L6; else goto _L5
_L5:
        String s1;
        DataOutputStream dataoutputstream;
        HttpParameter ahttpparameter[];
        int i1;
        String s = "----Twitter4J-upload" + System.currentTimeMillis();
        httpurlconnection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + s);
        s1 = "--" + s;
        httpurlconnection.setDoOutput(true);
        outputstream = httpurlconnection.getOutputStream();
        dataoutputstream = new DataOutputStream(outputstream);
        ahttpparameter = httprequest.getParameters();
        i1 = ahttpparameter.length;
        int j1 = 0;
_L33:
        if(j1 >= i1) goto _L8; else goto _L7
_L7:
        HttpParameter httpparameter = ahttpparameter[j1];
        if(!httpparameter.isFile()) goto _L10; else goto _L9
_L9:
        write(dataoutputstream, s1 + "\r\n");
        write(dataoutputstream, "Content-Disposition: form-data; name=\"" + httpparameter.getName() + "\"; filename=\"" + httpparameter.getFile().getName() + "\"\r\n");
        write(dataoutputstream, "Content-Type: " + httpparameter.getContentType() + "\r\n\r\n");
        if(!httpparameter.hasFileBody()) goto _L12; else goto _L11
_L11:
        Object obj2 = httpparameter.getFileBody();
_L16:
        BufferedInputStream bufferedinputstream = new BufferedInputStream(((java.io.InputStream) (obj2)));
_L15:
        int k1 = bufferedinputstream.read();
        if(k1 == -1) goto _L14; else goto _L13
_L13:
        dataoutputstream.write(k1);
          goto _L15
        Exception exception;
        exception;
        Object obj1 = obj;
_L26:
        IOException ioexception;
        int l;
        TwitterException twitterexception;
        int l1;
        Exception exception3;
        Map map;
        Iterator iterator;
        String s2;
        Iterator iterator1;
        String s3;
        try
        {
            outputstream.close();
        }
        catch(Exception exception1) { }
        throw exception;
_L12:
        obj2 = new FileInputStream(httpparameter.getFile());
          goto _L16
_L14:
        write(dataoutputstream, "\r\n");
        bufferedinputstream.close();
          goto _L17
_L10:
        write(dataoutputstream, s1 + "\r\n");
        write(dataoutputstream, "Content-Disposition: form-data; name=\"" + httpparameter.getName() + "\"\r\n");
        write(dataoutputstream, "Content-Type: text/plain; charset=UTF-8\r\n\r\n");
        logger.debug(httpparameter.getValue());
        dataoutputstream.write(httpparameter.getValue().getBytes("UTF-8"));
        write(dataoutputstream, "\r\n");
          goto _L17
_L8:
        write(dataoutputstream, s1 + "--\r\n");
        write(dataoutputstream, "\r\n");
_L27:
        outputstream.flush();
        outputstream.close();
_L4:
        HttpClientConfiguration httpclientconfiguration = CONF;
        obj1 = new HttpResponseImpl(httpurlconnection, httpclientconfiguration);
        k = httpurlconnection.getResponseCode();
        if(!logger.isDebugEnabled()) goto _L19; else goto _L18
_L18:
        logger.debug("Response: ");
        map = httpurlconnection.getHeaderFields();
        iterator = map.keySet().iterator();
_L22:
        if(!iterator.hasNext()) goto _L19; else goto _L20
_L20:
        s2 = (String)iterator.next();
        iterator1 = ((List)map.get(s2)).iterator();
_L25:
        if(!iterator1.hasNext()) goto _L22; else goto _L21
_L21:
        s3 = (String)iterator1.next();
        if(s2 == null) goto _L24; else goto _L23
_L23:
        logger.debug(s2 + ": " + s3);
          goto _L25
        exception;
          goto _L26
_L6:
        httpurlconnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
        String s4 = HttpParameter.encodeParameters(httprequest.getParameters());
        logger.debug("Post Params: ", s4);
        byte abyte0[] = s4.getBytes("UTF-8");
        httpurlconnection.setRequestProperty("Content-Length", Integer.toString(abyte0.length));
        httpurlconnection.setDoOutput(true);
        outputstream = httpurlconnection.getOutputStream();
        outputstream.write(abyte0);
          goto _L27
_L24:
        logger.debug(s3);
          goto _L25
_L34:
        if(k == 420 || k == 400 || k < 500) goto _L29; else goto _L28
_L28:
        l1 = CONF.getHttpRetryCount();
        if(j != l1) goto _L30; else goto _L29
_L29:
        TwitterException twitterexception1 = new TwitterException(((HttpResponse) (obj1)).asString(), ((HttpResponse) (obj1)));
        throw twitterexception1;
_L35:
        outputstream.close();
        return ((HttpResponse) (obj1));
_L30:
        try
        {
            outputstream.close();
        }
        catch(Exception exception2) { }
        // Misplaced declaration of an exception variable
        catch(IOException ioexception)
        {
            l = CONF.getHttpRetryCount();
            if(j == l)
            {
                twitterexception = new TwitterException(ioexception.getMessage(), ioexception, k);
                throw twitterexception;
            }
        }
        if(!logger.isDebugEnabled() || obj1 == null)
            break MISSING_BLOCK_LABEL_1000;
        ((HttpResponse) (obj1)).asString();
        logger.debug("Sleeping " + CONF.getHttpRetryIntervalSeconds() + " seconds until the next retry.");
        Thread.sleep(1000 * CONF.getHttpRetryIntervalSeconds());
_L32:
        j++;
        obj = obj1;
          goto _L31
        exception3;
        return ((HttpResponse) (obj1));
        InterruptedException interruptedexception;
        interruptedexception;
          goto _L32
_L2:
        return ((HttpResponse) (obj));
_L17:
        j1++;
          goto _L33
_L19:
        if(k >= 200 && (k == 302 || 300 > k)) goto _L35; else goto _L34
    }

    static Class class$twitter4j$internal$http$HttpClientImpl;
    private static final Map instanceMap;
    private static boolean isJDK14orEarlier = false;
    private static final Logger logger;
    private static final long serialVersionUID = 0x859c02532b19cd01L;

    static 
    {
        boolean flag;
        Class class1;
        String s;
        if(class$twitter4j$internal$http$HttpClientImpl == null)
        {
            class1 = _mthclass$("twitter4j.internal.http.HttpClientImpl");
            class$twitter4j$internal$http$HttpClientImpl = class1;
        } else
        {
            class1 = class$twitter4j$internal$http$HttpClientImpl;
        }
        logger = Logger.getLogger(class1);
        isJDK14orEarlier = false;
        s = System.getProperty("java.specification.version");
        if(s == null)
            break MISSING_BLOCK_LABEL_54;
        if(1.5D > Double.parseDouble(s))
            flag = true;
        else
            flag = false;
        isJDK14orEarlier = flag;
        if(ConfigurationContext.getInstance().isDalvik())
        {
            isJDK14orEarlier = false;
            System.setProperty("http.keepAlive", "false");
        }
_L2:
        instanceMap = new HashMap(1);
        return;
        SecurityException securityexception;
        securityexception;
        isJDK14orEarlier = true;
        if(true) goto _L2; else goto _L1
_L1:
    }
}
