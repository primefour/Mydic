// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;


// Referenced classes of package twitter4j.internal.http:
//            HttpResponseEvent

public interface HttpResponseListener
{

    public abstract void httpResponseReceived(HttpResponseEvent httpresponseevent);
}
