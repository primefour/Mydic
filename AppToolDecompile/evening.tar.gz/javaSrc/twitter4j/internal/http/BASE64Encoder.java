// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;


public final class BASE64Encoder
{

    private BASE64Encoder()
    {
    }

    public static String encode(byte abyte0[])
    {
        StringBuffer stringbuffer;
        int i;
        char c;
        int j;
        stringbuffer = new StringBuffer(3 + (int)(1.3400000000000001D * (double)abyte0.length));
        i = 0;
        c = '\0';
        j = 0;
_L10:
        if(j >= abyte0.length)
            break; /* Loop/switch isn't completed */
        i %= 8;
_L7:
        if(i >= 8)
            break MISSING_BLOCK_LABEL_216;
        i;
        JVM INSTR tableswitch 0 6: default 88
    //                   0 104
    //                   1 88
    //                   2 120
    //                   3 88
    //                   4 133
    //                   5 88
    //                   6 175;
           goto _L1 _L2 _L1 _L3 _L1 _L4 _L1 _L5
_L5:
        break MISSING_BLOCK_LABEL_175;
_L1:
        break; /* Loop/switch isn't completed */
_L2:
        break; /* Loop/switch isn't completed */
_L8:
        stringbuffer.append(encodeTable[c]);
        i += 6;
        if(true) goto _L7; else goto _L6
_L6:
        c = (char)((char)(abyte0[j] & lead6byte) >>> 2);
          goto _L8
_L3:
        c = (char)(abyte0[j] & last6byte);
          goto _L8
_L4:
        c = (char)((char)(abyte0[j] & last4byte) << 2);
        if(j + 1 < abyte0.length)
            c |= (abyte0[j + 1] & lead2byte) >>> 6;
          goto _L8
        c = (char)((char)(abyte0[j] & last2byte) << 4);
        if(j + 1 < abyte0.length)
            c |= (abyte0[j + 1] & lead4byte) >>> 4;
          goto _L8
        j++;
        if(true) goto _L10; else goto _L9
_L9:
        if(stringbuffer.length() % 4 != 0)
        {
            for(int k = 4 - stringbuffer.length() % 4; k > 0; k--)
                stringbuffer.append("=");

        }
        return stringbuffer.toString();
    }

    private static final char encodeTable[] = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
        'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
        'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 
        'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
        'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
        '8', '9', '+', '/'
    };
    private static final char last2byte = (char)Integer.parseInt("00000011", 2);
    private static final char last4byte = (char)Integer.parseInt("00001111", 2);
    private static final char last6byte = (char)Integer.parseInt("00111111", 2);
    private static final char lead2byte = (char)Integer.parseInt("11000000", 2);
    private static final char lead4byte = (char)Integer.parseInt("11110000", 2);
    private static final char lead6byte = (char)Integer.parseInt("11111100", 2);

}
