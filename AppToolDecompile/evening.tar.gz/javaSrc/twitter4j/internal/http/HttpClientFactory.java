// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

// Referenced classes of package twitter4j.internal.http:
//            HttpClient, HttpClientConfiguration

public final class HttpClientFactory
{

    public HttpClientFactory()
    {
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public static HttpClient getInstance(HttpClientConfiguration httpclientconfiguration)
    {
        HttpClient httpclient;
        try
        {
            httpclient = (HttpClient)HTTP_CLIENT_CONSTRUCTOR.newInstance(new Object[] {
                httpclientconfiguration
            });
        }
        catch(InstantiationException instantiationexception)
        {
            throw new AssertionError(instantiationexception);
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
        return httpclient;
    }

    private static final Constructor HTTP_CLIENT_CONSTRUCTOR;
    private static final String HTTP_CLIENT_IMPLEMENTATION = "twitter4j.http.httpClient";
    static Class class$twitter4j$internal$http$HttpClientConfiguration;

    static 
    {
        String s;
        Class class1;
        s = System.getProperty("twitter4j.http.httpClient");
        class1 = null;
        if(s == null)
            break MISSING_BLOCK_LABEL_21;
        Class class5 = Class.forName(s);
        class1 = class5;
_L2:
        if(class1 != null)
            break MISSING_BLOCK_LABEL_35;
        Class class4 = Class.forName("twitter4j.internal.http.alternative.HttpClientImpl");
        class1 = class4;
_L3:
        Class class2;
        if(class1 == null)
        {
            Class aclass[];
            Class class3;
            try
            {
                class3 = Class.forName("twitter4j.internal.http.HttpClientImpl");
            }
            catch(ClassNotFoundException classnotfoundexception)
            {
                throw new AssertionError(classnotfoundexception);
            }
            class1 = class3;
        }
        aclass = new Class[1];
        if(class$twitter4j$internal$http$HttpClientConfiguration != null)
            break MISSING_BLOCK_LABEL_98;
        class2 = _mthclass$("twitter4j.internal.http.HttpClientConfiguration");
        class$twitter4j$internal$http$HttpClientConfiguration = class2;
_L1:
        aclass[0] = class2;
        HTTP_CLIENT_CONSTRUCTOR = class1.getConstructor(aclass);
        return;
        try
        {
            class2 = class$twitter4j$internal$http$HttpClientConfiguration;
        }
        catch(NoSuchMethodException nosuchmethodexception)
        {
            throw new AssertionError(nosuchmethodexception);
        }
          goto _L1
        ClassNotFoundException classnotfoundexception2;
        classnotfoundexception2;
        class1 = null;
          goto _L2
        ClassNotFoundException classnotfoundexception1;
        classnotfoundexception1;
          goto _L3
    }
}
