// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.http;

import java.io.*;
import twitter4j.internal.logging.Logger;

// Referenced classes of package twitter4j.internal.http:
//            HttpClientConfiguration

public class HttpClientBase
    implements Serializable
{

    public HttpClientBase(HttpClientConfiguration httpclientconfiguration)
    {
        CONF = httpclientconfiguration;
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof HttpClientBase))
                return false;
            HttpClientBase httpclientbase = (HttpClientBase)obj;
            if(!CONF.equals(httpclientbase.CONF))
                return false;
        }
        return true;
    }

    public int hashCode()
    {
        return CONF.hashCode();
    }

    protected boolean isProxyConfigured()
    {
        return CONF.getHttpProxyHost() != null && !CONF.getHttpProxyHost().equals("");
    }

    public void shutdown()
    {
    }

    public String toString()
    {
        return "HttpClientBase{CONF=" + CONF + '}';
    }

    public void write(DataOutputStream dataoutputstream, String s)
        throws IOException
    {
        dataoutputstream.writeBytes(s);
        logger.debug(s);
    }

    static Class class$twitter4j$internal$http$HttpClientBase;
    private static final Logger logger;
    protected final HttpClientConfiguration CONF;

    static 
    {
        Class class1;
        if(class$twitter4j$internal$http$HttpClientBase == null)
        {
            class1 = _mthclass$("twitter4j.internal.http.HttpClientBase");
            class$twitter4j$internal$http$HttpClientBase = class1;
        } else
        {
            class1 = class$twitter4j$internal$http$HttpClientBase;
        }
        logger = Logger.getLogger(class1);
    }
}
