// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.util.Date;
import twitter4j.RateLimitStatus;
import twitter4j.TwitterException;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.JSONObject;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            DataObjectFactoryUtil

final class RateLimitStatusJSONImpl
    implements RateLimitStatus, Serializable
{

    private RateLimitStatusJSONImpl(int i, int j, int k, Date date)
    {
        hourlyLimit = i;
        remainingHits = j;
        resetTime = date;
        resetTimeInSeconds = k;
        secondsUntilReset = (int)((date.getTime() - System.currentTimeMillis()) / 1000L);
    }

    RateLimitStatusJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        JSONObject jsonobject = httpresponse.asJSONObject();
        init(jsonobject);
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
        }
    }

    RateLimitStatusJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        init(jsonobject);
    }

    static RateLimitStatus createFeatureSpecificRateLimitStatusFromResponseHeader(HttpResponse httpresponse)
    {
        String s;
        if(httpresponse != null)
            if((s = httpresponse.getResponseHeader("X-FeatureRateLimit-Limit")) != null)
            {
                int i = Integer.parseInt(s);
                String s1 = httpresponse.getResponseHeader("X-FeatureRateLimit-Remaining");
                if(s1 != null)
                {
                    int j = Integer.parseInt(s1);
                    String s2 = httpresponse.getResponseHeader("X-FeatureRateLimit-Reset");
                    if(s2 != null)
                    {
                        long l = Long.parseLong(s2);
                        return new RateLimitStatusJSONImpl(i, j, (int)(l / 1000L), new Date(l * 1000L));
                    }
                }
            }
        return null;
    }

    static RateLimitStatus createFromResponseHeader(HttpResponse httpresponse)
    {
        String s;
        if(httpresponse != null)
            if((s = httpresponse.getResponseHeader("X-RateLimit-Limit")) != null)
            {
                int i = Integer.parseInt(s);
                String s1 = httpresponse.getResponseHeader("X-RateLimit-Remaining");
                if(s1 != null)
                {
                    int j = Integer.parseInt(s1);
                    String s2 = httpresponse.getResponseHeader("X-RateLimit-Reset");
                    if(s2 != null)
                    {
                        long l = Long.parseLong(s2);
                        return new RateLimitStatusJSONImpl(i, j, (int)(l / 1000L), new Date(l * 1000L));
                    }
                }
            }
        return null;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof RateLimitStatusJSONImpl))
                return false;
            RateLimitStatusJSONImpl ratelimitstatusjsonimpl = (RateLimitStatusJSONImpl)obj;
            if(hourlyLimit != ratelimitstatusjsonimpl.hourlyLimit)
                return false;
            if(remainingHits != ratelimitstatusjsonimpl.remainingHits)
                return false;
            if(resetTimeInSeconds != ratelimitstatusjsonimpl.resetTimeInSeconds)
                return false;
            if(secondsUntilReset != ratelimitstatusjsonimpl.secondsUntilReset)
                return false;
            if(resetTime == null ? ratelimitstatusjsonimpl.resetTime != null : !resetTime.equals(ratelimitstatusjsonimpl.resetTime))
                return false;
        }
        return true;
    }

    public int getHourlyLimit()
    {
        return hourlyLimit;
    }

    public int getRemainingHits()
    {
        return remainingHits;
    }

    public Date getResetTime()
    {
        return resetTime;
    }

    public int getResetTimeInSeconds()
    {
        return resetTimeInSeconds;
    }

    public int getSecondsUntilReset()
    {
        return secondsUntilReset;
    }

    public int hashCode()
    {
        int i = 31 * (31 * (31 * (31 * remainingHits + hourlyLimit) + resetTimeInSeconds) + secondsUntilReset);
        int j;
        if(resetTime != null)
            j = resetTime.hashCode();
        else
            j = 0;
        return i + j;
    }

    void init(JSONObject jsonobject)
        throws TwitterException
    {
        hourlyLimit = z_T4JInternalParseUtil.getInt("hourly_limit", jsonobject);
        remainingHits = z_T4JInternalParseUtil.getInt("remaining_hits", jsonobject);
        resetTime = z_T4JInternalParseUtil.getDate("reset_time", jsonobject, "EEE MMM d HH:mm:ss Z yyyy");
        resetTimeInSeconds = z_T4JInternalParseUtil.getInt("reset_time_in_seconds", jsonobject);
        secondsUntilReset = (int)((resetTime.getTime() - System.currentTimeMillis()) / 1000L);
    }

    public String toString()
    {
        return "RateLimitStatusJSONImpl{remainingHits=" + remainingHits + ", hourlyLimit=" + hourlyLimit + ", resetTimeInSeconds=" + resetTimeInSeconds + ", secondsUntilReset=" + secondsUntilReset + ", resetTime=" + resetTime + '}';
    }

    private static final long serialVersionUID = 0xb8d1e8292f717f6L;
    private int hourlyLimit;
    private int remainingHits;
    private Date resetTime;
    private int resetTimeInSeconds;
    private int secondsUntilReset;
}
