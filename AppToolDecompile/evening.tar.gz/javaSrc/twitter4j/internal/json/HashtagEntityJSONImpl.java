// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import twitter4j.HashtagEntity;
import twitter4j.TwitterException;
import twitter4j.internal.org.json.*;

class HashtagEntityJSONImpl
    implements HashtagEntity
{

    HashtagEntityJSONImpl()
    {
        start = -1;
        end = -1;
    }

    HashtagEntityJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        start = -1;
        end = -1;
        init(jsonobject);
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        try
        {
            JSONArray jsonarray = jsonobject.getJSONArray("indices");
            start = jsonarray.getInt(0);
            end = jsonarray.getInt(1);
            if(!jsonobject.isNull("text"))
                text = jsonobject.getString("text");
            return;
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            HashtagEntityJSONImpl hashtagentityjsonimpl = (HashtagEntityJSONImpl)obj;
            if(end != hashtagentityjsonimpl.end)
                return false;
            if(start != hashtagentityjsonimpl.start)
                return false;
            if(text == null ? hashtagentityjsonimpl.text != null : !text.equals(hashtagentityjsonimpl.text))
                return false;
        }
        return true;
    }

    public int getEnd()
    {
        return end;
    }

    public int getStart()
    {
        return start;
    }

    public String getText()
    {
        return text;
    }

    public int hashCode()
    {
        int i = 31 * (31 * start + end);
        int j;
        if(text != null)
            j = text.hashCode();
        else
            j = 0;
        return i + j;
    }

    public String toString()
    {
        return "HashtagEntityJSONImpl{start=" + start + ", end=" + end + ", text='" + text + '\'' + '}';
    }

    private static final long serialVersionUID = 0x3877f7012d9cd490L;
    private int end;
    private int start;
    private String text;
}
