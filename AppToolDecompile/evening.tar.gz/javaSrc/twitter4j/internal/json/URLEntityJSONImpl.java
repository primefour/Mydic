// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.net.MalformedURLException;
import java.net.URL;
import twitter4j.TwitterException;
import twitter4j.URLEntity;
import twitter4j.internal.org.json.*;

final class URLEntityJSONImpl
    implements URLEntity
{

    URLEntityJSONImpl()
    {
        start = -1;
        end = -1;
    }

    URLEntityJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        start = -1;
        end = -1;
        init(jsonobject);
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        JSONArray jsonarray = jsonobject.getJSONArray("indices");
        start = jsonarray.getInt(0);
        end = jsonarray.getInt(1);
        JSONException jsonexception;
        boolean flag;
        try
        {
            url = new URL(jsonobject.getString("url"));
        }
        catch(MalformedURLException malformedurlexception) { }
        flag = jsonobject.isNull("expanded_url");
        if(flag)
            break MISSING_BLOCK_LABEL_72;
        try
        {
            expandedURL = new URL(jsonobject.getString("expanded_url"));
        }
        catch(MalformedURLException malformedurlexception1) { }
        if(!jsonobject.isNull("display_url"))
            displayURL = jsonobject.getString("display_url");
        return;
        jsonexception;
        throw new TwitterException(jsonexception);
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            URLEntityJSONImpl urlentityjsonimpl = (URLEntityJSONImpl)obj;
            if(end != urlentityjsonimpl.end)
                return false;
            if(start != urlentityjsonimpl.start)
                return false;
            if(displayURL == null ? urlentityjsonimpl.displayURL != null : !displayURL.equals(urlentityjsonimpl.displayURL))
                return false;
            if(expandedURL == null ? urlentityjsonimpl.expandedURL != null : !expandedURL.equals(urlentityjsonimpl.expandedURL))
                return false;
            if(url == null ? urlentityjsonimpl.url != null : !url.equals(urlentityjsonimpl.url))
                return false;
        }
        return true;
    }

    public String getDisplayURL()
    {
        return displayURL;
    }

    public int getEnd()
    {
        return end;
    }

    public URL getExpandedURL()
    {
        return expandedURL;
    }

    public int getStart()
    {
        return start;
    }

    public URL getURL()
    {
        return url;
    }

    public int hashCode()
    {
        int i = 31 * (31 * start + end);
        int j;
        int k;
        int l;
        int i1;
        String s;
        int j1;
        if(url != null)
            j = url.hashCode();
        else
            j = 0;
        k = 31 * (i + j);
        if(expandedURL != null)
            l = expandedURL.hashCode();
        else
            l = 0;
        i1 = 31 * (k + l);
        s = displayURL;
        j1 = 0;
        if(s != null)
            j1 = displayURL.hashCode();
        return i1 + j1;
    }

    public String toString()
    {
        return "URLEntityJSONImpl{start=" + start + ", end=" + end + ", url=" + url + ", expandedURL=" + expandedURL + ", displayURL=" + displayURL + '}';
    }

    private static final long serialVersionUID = 0x102b94bf50a65174L;
    private String displayURL;
    private int end;
    private URL expandedURL;
    private int start;
    private URL url;
}
