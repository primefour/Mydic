// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.util.Date;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, ResponseListImpl, UserJSONImpl

final class DirectMessageJSONImpl extends TwitterResponseImpl
    implements DirectMessage, Serializable
{

    DirectMessageJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        JSONObject jsonobject = httpresponse.asJSONObject();
        init(jsonobject);
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
        }
    }

    DirectMessageJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        init(jsonobject);
    }

    static ResponseList createDirectMessageList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        int j;
        JSONArray jsonarray;
        int i;
        ResponseListImpl responselistimpl;
        JSONObject jsonobject;
        DirectMessageJSONImpl directmessagejsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            jsonarray = httpresponse.asJSONArray();
            i = jsonarray.length();
            responselistimpl = new ResponseListImpl(i, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
_L2:
        if(j >= i)
            break MISSING_BLOCK_LABEL_97;
        jsonobject = jsonarray.getJSONObject(j);
        directmessagejsonimpl = new DirectMessageJSONImpl(jsonobject);
        responselistimpl.add(directmessagejsonimpl);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(directmessagejsonimpl, jsonobject);
        break MISSING_BLOCK_LABEL_130;
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
        j++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        id = z_T4JInternalParseUtil.getLong("id", jsonobject);
        text = z_T4JInternalParseUtil.getUnescapedString("text", jsonobject);
        senderId = z_T4JInternalParseUtil.getLong("sender_id", jsonobject);
        recipientId = z_T4JInternalParseUtil.getLong("recipient_id", jsonobject);
        createdAt = z_T4JInternalParseUtil.getDate("created_at", jsonobject);
        senderScreenName = z_T4JInternalParseUtil.getUnescapedString("sender_screen_name", jsonobject);
        recipientScreenName = z_T4JInternalParseUtil.getUnescapedString("recipient_screen_name", jsonobject);
        try
        {
            sender = new UserJSONImpl(jsonobject.getJSONObject("sender"));
            recipient = new UserJSONImpl(jsonobject.getJSONObject("recipient"));
            return;
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
    }

    public boolean equals(Object obj)
    {
        boolean flag = true;
        if(obj == null)
            flag = false;
        else
        if(this != obj && (!(obj instanceof DirectMessage) || ((DirectMessage)obj).getId() != id))
            return false;
        return flag;
    }

    public Date getCreatedAt()
    {
        return createdAt;
    }

    public long getId()
    {
        return id;
    }

    public User getRecipient()
    {
        return recipient;
    }

    public long getRecipientId()
    {
        return recipientId;
    }

    public String getRecipientScreenName()
    {
        return recipientScreenName;
    }

    public User getSender()
    {
        return sender;
    }

    public long getSenderId()
    {
        return senderId;
    }

    public String getSenderScreenName()
    {
        return senderScreenName;
    }

    public String getText()
    {
        return text;
    }

    public int hashCode()
    {
        return (int)id;
    }

    public String toString()
    {
        return "DirectMessageJSONImpl{id=" + id + ", text='" + text + '\'' + ", sender_id=" + senderId + ", recipient_id=" + recipientId + ", created_at=" + createdAt + ", sender_screen_name='" + senderScreenName + '\'' + ", recipient_screen_name='" + recipientScreenName + '\'' + ", sender=" + sender + ", recipient=" + recipient + '}';
    }

    private static final long serialVersionUID = 0x9d68b11f622cb5f7L;
    private Date createdAt;
    private long id;
    private User recipient;
    private long recipientId;
    private String recipientScreenName;
    private User sender;
    private long senderId;
    private String senderScreenName;
    private String text;
}
