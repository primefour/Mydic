// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.logging.Logger;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, ResponseListImpl, UserJSONImpl, 
//            z_T4JInternalJSONImplFactory, PlaceJSONImpl, UserMentionEntityJSONImpl, URLEntityJSONImpl, 
//            HashtagEntityJSONImpl, MediaEntityJSONImpl

final class StatusJSONImpl extends TwitterResponseImpl
    implements Status, Serializable
{

    StatusJSONImpl()
    {
        geoLocation = null;
        place = null;
        contributors = null;
        annotations = null;
        user = null;
    }

    StatusJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        geoLocation = null;
        place = null;
        contributors = null;
        annotations = null;
        user = null;
        JSONObject jsonobject = httpresponse.asJSONObject();
        init(jsonobject);
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
        }
    }

    StatusJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        geoLocation = null;
        place = null;
        contributors = null;
        annotations = null;
        user = null;
        init(jsonobject);
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    static ResponseList createStatusList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        JSONArray jsonarray;
        int i;
        ResponseListImpl responselistimpl;
        int j;
        JSONObject jsonobject;
        StatusJSONImpl statusjsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            jsonarray = httpresponse.asJSONArray();
            i = jsonarray.length();
            responselistimpl = new ResponseListImpl(i, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
        if(j >= i)
            break; /* Loop/switch isn't completed */
        jsonobject = jsonarray.getJSONObject(j);
        statusjsonimpl = new StatusJSONImpl(jsonobject);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(statusjsonimpl, jsonobject);
        responselistimpl.add(statusjsonimpl);
        j++;
        if(true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_40;
_L1:
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        id = z_T4JInternalParseUtil.getLong("id", jsonobject);
        text = z_T4JInternalParseUtil.getUnescapedString("text", jsonobject);
        source = z_T4JInternalParseUtil.getUnescapedString("source", jsonobject);
        createdAt = z_T4JInternalParseUtil.getDate("created_at", jsonobject);
        isTruncated = z_T4JInternalParseUtil.getBoolean("truncated", jsonobject);
        inReplyToStatusId = z_T4JInternalParseUtil.getLong("in_reply_to_status_id", jsonobject);
        inReplyToUserId = z_T4JInternalParseUtil.getLong("in_reply_to_user_id", jsonobject);
        isFavorited = z_T4JInternalParseUtil.getBoolean("favorited", jsonobject);
        inReplyToScreenName = z_T4JInternalParseUtil.getUnescapedString("in_reply_to_screen_name", jsonobject);
        retweetCount = z_T4JInternalParseUtil.getLong("retweet_count", jsonobject);
        JSONArray jsonarray4;
        int i2;
        try
        {
            if(!jsonobject.isNull("user"))
                user = new UserJSONImpl(jsonobject.getJSONObject("user"));
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        geoLocation = z_T4JInternalJSONImplFactory.createGeoLocation(jsonobject);
        if(!jsonobject.isNull("place"))
            try
            {
                place = new PlaceJSONImpl(jsonobject.getJSONObject("place"));
            }
            catch(JSONException jsonexception6)
            {
                jsonexception6.printStackTrace();
                logger.warn("failed to parse place:" + jsonobject);
            }
        if(!jsonobject.isNull("retweeted_status"))
            try
            {
                retweetedStatus = new StatusJSONImpl(jsonobject.getJSONObject("retweeted_status"));
            }
            catch(JSONException jsonexception5)
            {
                jsonexception5.printStackTrace();
                logger.warn("failed to parse retweeted_status:" + jsonobject);
            }
        if(jsonobject.isNull("contributors")) goto _L2; else goto _L1
_L1:
        jsonarray4 = jsonobject.getJSONArray("contributors");
        contributorsIDs = new long[jsonarray4.length()];
        i2 = 0;
_L4:
        if(i2 >= jsonarray4.length())
            break; /* Loop/switch isn't completed */
        contributorsIDs[i2] = Long.parseLong(jsonarray4.getString(i2));
        i2++;
        if(true) goto _L4; else goto _L3
        NumberFormatException numberformatexception;
        numberformatexception;
        numberformatexception.printStackTrace();
        logger.warn("failed to parse contributors:" + jsonobject);
_L3:
        if(jsonobject.isNull("entities")) goto _L6; else goto _L5
_L5:
        JSONObject jsonobject1 = jsonobject.getJSONObject("entities");
        if(jsonobject1.isNull("user_mentions")) goto _L8; else goto _L7
_L7:
        JSONArray jsonarray3;
        int k1;
        jsonarray3 = jsonobject1.getJSONArray("user_mentions");
        k1 = jsonarray3.length();
        userMentionEntities = new UserMentionEntity[k1];
        int l1 = 0;
        while(l1 < k1) 
        {
            JSONArray jsonarray;
            int i;
            int j;
            JSONArray jsonarray1;
            int k;
            int l;
            JSONArray jsonarray2;
            int i1;
            int j1;
            JSONException jsonexception4;
            try
            {
                userMentionEntities[l1] = new UserMentionEntityJSONImpl(jsonarray3.getJSONObject(l1));
            }
            catch(JSONException jsonexception3)
            {
                throw new TwitterException(jsonexception3);
            }
            l1++;
        }
          goto _L8
        jsonexception4;
        jsonexception4.printStackTrace();
        logger.warn("failed to parse contributors:" + jsonobject);
          goto _L3
_L2:
        contributors = null;
          goto _L3
_L8:
        if(jsonobject1.isNull("urls")) goto _L10; else goto _L9
_L9:
        jsonarray2 = jsonobject1.getJSONArray("urls");
        i1 = jsonarray2.length();
        urlEntities = new URLEntity[i1];
        j1 = 0;
_L11:
        if(j1 >= i1)
            break; /* Loop/switch isn't completed */
        urlEntities[j1] = new URLEntityJSONImpl(jsonarray2.getJSONObject(j1));
        j1++;
        if(true) goto _L11; else goto _L10
_L10:
        if(jsonobject1.isNull("hashtags")) goto _L13; else goto _L12
_L12:
        jsonarray1 = jsonobject1.getJSONArray("hashtags");
        k = jsonarray1.length();
        hashtagEntities = new HashtagEntity[k];
        l = 0;
_L14:
        if(l >= k)
            break; /* Loop/switch isn't completed */
        hashtagEntities[l] = new HashtagEntityJSONImpl(jsonarray1.getJSONObject(l));
        l++;
        if(true) goto _L14; else goto _L13
_L13:
        if(jsonobject1.isNull("media")) goto _L6; else goto _L15
_L15:
        jsonarray = jsonobject1.getJSONArray("media");
        i = jsonarray.length();
        mediaEntities = new MediaEntity[i];
        j = 0;
_L16:
        if(j >= i)
            break; /* Loop/switch isn't completed */
        mediaEntities[j] = new MediaEntityJSONImpl(jsonarray.getJSONObject(j));
        j++;
        if(true) goto _L16; else goto _L6
_L6:
        JSONException jsonexception1;
        if(!jsonobject.isNull("annotations"))
            try
            {
                annotations = new Annotations(jsonobject.getJSONArray("annotations"));
            }
            catch(JSONException jsonexception2) { }
        if(jsonobject.isNull("current_user_retweet"))
            break MISSING_BLOCK_LABEL_797;
        myRetweetedStatus = new StatusJSONImpl(jsonobject.getJSONObject("current_user_retweet"));
        wasRetweetedByMe = true;
        return;
        jsonexception1;
        jsonexception1.printStackTrace();
        logger.warn("failed to parse current_user_retweet:" + jsonobject);
        return;
    }

    public int compareTo(Object obj)
    {
        return compareTo((Status)obj);
    }

    public int compareTo(Status status)
    {
        long l = id - status.getId();
        if(l < 0xffffffff80000000L)
            return 0x80000000;
        if(l > 0x7fffffffL)
            return 0x7fffffff;
        else
            return (int)l;
    }

    public boolean equals(Object obj)
    {
        boolean flag = true;
        if(obj == null)
            flag = false;
        else
        if(this != obj && (!(obj instanceof Status) || ((Status)obj).getId() != id))
            return false;
        return flag;
    }

    public Annotations getAnnotations()
    {
        return annotations;
    }

    public long[] getContributors()
    {
        if(contributors != null)
        {
            contributorsIDs = new long[contributors.length];
            int i = 0;
            do
            {
                if(i >= contributors.length)
                    break;
                try
                {
                    contributorsIDs[i] = Long.parseLong(contributors[i]);
                }
                catch(NumberFormatException numberformatexception)
                {
                    numberformatexception.printStackTrace();
                    logger.warn("failed to parse contributors:" + numberformatexception);
                }
                i++;
            } while(true);
            contributors = null;
        }
        return contributorsIDs;
    }

    public Date getCreatedAt()
    {
        return createdAt;
    }

    public GeoLocation getGeoLocation()
    {
        return geoLocation;
    }

    public HashtagEntity[] getHashtagEntities()
    {
        return hashtagEntities;
    }

    public long getId()
    {
        return id;
    }

    public String getInReplyToScreenName()
    {
        return inReplyToScreenName;
    }

    public long getInReplyToStatusId()
    {
        return inReplyToStatusId;
    }

    public long getInReplyToUserId()
    {
        return inReplyToUserId;
    }

    public MediaEntity[] getMediaEntities()
    {
        return mediaEntities;
    }

    public Place getPlace()
    {
        return place;
    }

    public long getRetweetCount()
    {
        return retweetCount;
    }

    public Status getRetweetedStatus()
    {
        return retweetedStatus;
    }

    public String getSource()
    {
        return source;
    }

    public String getText()
    {
        return text;
    }

    public URLEntity[] getURLEntities()
    {
        return urlEntities;
    }

    public User getUser()
    {
        return user;
    }

    public UserMentionEntity[] getUserMentionEntities()
    {
        return userMentionEntities;
    }

    public int hashCode()
    {
        return (int)id;
    }

    public boolean isFavorited()
    {
        return isFavorited;
    }

    public boolean isRetweet()
    {
        return retweetedStatus != null;
    }

    public boolean isRetweetedByMe()
    {
        return wasRetweetedByMe;
    }

    public boolean isTruncated()
    {
        return isTruncated;
    }

    public String toString()
    {
        StringBuffer stringbuffer = (new StringBuffer()).append("StatusJSONImpl{createdAt=").append(createdAt).append(", id=").append(id).append(", text='").append(text).append('\'').append(", source='").append(source).append('\'').append(", isTruncated=").append(isTruncated).append(", inReplyToStatusId=").append(inReplyToStatusId).append(", inReplyToUserId=").append(inReplyToUserId).append(", isFavorited=").append(isFavorited).append(", inReplyToScreenName='").append(inReplyToScreenName).append('\'').append(", geoLocation=").append(geoLocation).append(", place=").append(place).append(", retweetCount=").append(retweetCount).append(", wasRetweetedByMe=").append(wasRetweetedByMe).append(", contributors=");
        java.util.List list;
        StringBuffer stringbuffer1;
        java.util.List list1;
        StringBuffer stringbuffer2;
        java.util.List list2;
        StringBuffer stringbuffer3;
        HashtagEntity ahashtagentity[];
        java.util.List list3;
        if(contributorsIDs == null)
        {
            list = null;
        } else
        {
            long al[][] = new long[1][];
            al[0] = contributorsIDs;
            list = Arrays.asList(al);
        }
        stringbuffer1 = stringbuffer.append(list).append(", annotations=").append(annotations).append(", retweetedStatus=").append(retweetedStatus).append(", userMentionEntities=");
        if(userMentionEntities == null)
            list1 = null;
        else
            list1 = Arrays.asList(userMentionEntities);
        stringbuffer2 = stringbuffer1.append(list1).append(", urlEntities=");
        if(urlEntities == null)
            list2 = null;
        else
            list2 = Arrays.asList(urlEntities);
        stringbuffer3 = stringbuffer2.append(list2).append(", hashtagEntities=");
        ahashtagentity = hashtagEntities;
        list3 = null;
        if(ahashtagentity != null)
            list3 = Arrays.asList(hashtagEntities);
        return stringbuffer3.append(list3).append(", user=").append(user).append('}').toString();
    }

    static Class class$twitter4j$internal$json$StatusJSONImpl;
    private static final Logger logger;
    private static final long serialVersionUID = 0x68c214e4e0c8cc29L;
    private Annotations annotations;
    private String contributors[];
    private long contributorsIDs[];
    private Date createdAt;
    private GeoLocation geoLocation;
    private HashtagEntity hashtagEntities[];
    private long id;
    private String inReplyToScreenName;
    private long inReplyToStatusId;
    private long inReplyToUserId;
    private boolean isFavorited;
    private boolean isTruncated;
    private MediaEntity mediaEntities[];
    private Status myRetweetedStatus;
    private Place place;
    private long retweetCount;
    private Status retweetedStatus;
    private String source;
    private String text;
    private URLEntity urlEntities[];
    private User user;
    private UserMentionEntity userMentionEntities[];
    private boolean wasRetweetedByMe;

    static 
    {
        Class class1;
        if(class$twitter4j$internal$json$StatusJSONImpl == null)
        {
            class1 = _mthclass$("twitter4j.internal.json.StatusJSONImpl");
            class$twitter4j$internal$json$StatusJSONImpl = class1;
        } else
        {
            class1 = class$twitter4j$internal$json$StatusJSONImpl;
        }
        logger = Logger.getLogger(class1);
    }
}
