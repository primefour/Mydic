// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.net.URI;
import java.net.URISyntaxException;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, PagableResponseListImpl, ResponseListImpl, 
//            UserJSONImpl

class UserListJSONImpl extends TwitterResponseImpl
    implements UserList, Serializable
{

    UserListJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.clearThreadLocalMap();
        JSONObject jsonobject = httpresponse.asJSONObject();
        init(jsonobject);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
    }

    UserListJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        init(jsonobject);
    }

    static PagableResponseList createPagableUserListList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        int j;
        JSONObject jsonobject;
        JSONArray jsonarray;
        int i;
        PagableResponseListImpl pagableresponselistimpl;
        JSONObject jsonobject1;
        UserListJSONImpl userlistjsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            jsonobject = httpresponse.asJSONObject();
            jsonarray = jsonobject.getJSONArray("lists");
            i = jsonarray.length();
            pagableresponselistimpl = new PagableResponseListImpl(i, jsonobject, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
_L2:
        if(j >= i)
            break MISSING_BLOCK_LABEL_108;
        jsonobject1 = jsonarray.getJSONObject(j);
        userlistjsonimpl = new UserListJSONImpl(jsonobject1);
        pagableresponselistimpl.add(userlistjsonimpl);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(userlistjsonimpl, jsonobject1);
        break MISSING_BLOCK_LABEL_141;
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(pagableresponselistimpl, jsonobject);
        return pagableresponselistimpl;
        j++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    static ResponseList createUserListList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        int j;
        JSONArray jsonarray;
        int i;
        ResponseListImpl responselistimpl;
        JSONObject jsonobject;
        UserListJSONImpl userlistjsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            jsonarray = httpresponse.asJSONArray();
            i = jsonarray.length();
            responselistimpl = new ResponseListImpl(i, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
_L2:
        if(j >= i)
            break MISSING_BLOCK_LABEL_97;
        jsonobject = jsonarray.getJSONObject(j);
        userlistjsonimpl = new UserListJSONImpl(jsonobject);
        responselistimpl.add(userlistjsonimpl);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(userlistjsonimpl, jsonobject);
        break MISSING_BLOCK_LABEL_130;
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
        j++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        id = z_T4JInternalParseUtil.getInt("id", jsonobject);
        name = z_T4JInternalParseUtil.getRawString("name", jsonobject);
        fullName = z_T4JInternalParseUtil.getRawString("full_name", jsonobject);
        slug = z_T4JInternalParseUtil.getRawString("slug", jsonobject);
        description = z_T4JInternalParseUtil.getRawString("description", jsonobject);
        subscriberCount = z_T4JInternalParseUtil.getInt("subscriber_count", jsonobject);
        memberCount = z_T4JInternalParseUtil.getInt("member_count", jsonobject);
        uri = z_T4JInternalParseUtil.getRawString("uri", jsonobject);
        mode = "public".equals(z_T4JInternalParseUtil.getRawString("mode", jsonobject));
        following = z_T4JInternalParseUtil.getBoolean("following", jsonobject);
        try
        {
            if(!jsonobject.isNull("user"))
                user = new UserJSONImpl(jsonobject.getJSONObject("user"));
            return;
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + jsonobject.toString(), jsonexception);
        }
    }

    public int compareTo(Object obj)
    {
        return compareTo((UserList)obj);
    }

    public int compareTo(UserList userlist)
    {
        return id - userlist.getId();
    }

    public boolean equals(Object obj)
    {
        boolean flag = true;
        if(obj == null)
            flag = false;
        else
        if(this != obj && (!(obj instanceof UserList) || ((UserList)obj).getId() != id))
            return false;
        return flag;
    }

    public String getDescription()
    {
        return description;
    }

    public String getFullName()
    {
        return fullName;
    }

    public int getId()
    {
        return id;
    }

    public int getMemberCount()
    {
        return memberCount;
    }

    public String getName()
    {
        return name;
    }

    public String getSlug()
    {
        return slug;
    }

    public int getSubscriberCount()
    {
        return subscriberCount;
    }

    public URI getURI()
    {
        URI uri1;
        try
        {
            uri1 = new URI(uri);
        }
        catch(URISyntaxException urisyntaxexception)
        {
            return null;
        }
        return uri1;
    }

    public User getUser()
    {
        return user;
    }

    public int hashCode()
    {
        return id;
    }

    public boolean isFollowing()
    {
        return following;
    }

    public boolean isPublic()
    {
        return mode;
    }

    public String toString()
    {
        return "UserListJSONImpl{id=" + id + ", name='" + name + '\'' + ", fullName='" + fullName + '\'' + ", slug='" + slug + '\'' + ", description='" + description + '\'' + ", subscriberCount=" + subscriberCount + ", memberCount=" + memberCount + ", uri='" + uri + '\'' + ", mode=" + mode + ", user=" + user + ", following=" + following + '}';
    }

    private static final long serialVersionUID = 0xa7eedbb8d7ed08daL;
    private String description;
    private boolean following;
    private String fullName;
    private int id;
    private int memberCount;
    private boolean mode;
    private String name;
    private String slug;
    private int subscriberCount;
    private String uri;
    private User user;
}
