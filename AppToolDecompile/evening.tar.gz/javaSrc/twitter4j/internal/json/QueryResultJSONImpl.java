// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            DataObjectFactoryUtil, TweetJSONImpl

final class QueryResultJSONImpl
    implements QueryResult, Serializable
{

    QueryResultJSONImpl(Query query1)
    {
        sinceId = query1.getSinceId();
        resultsPerPage = query1.getRpp();
        page = query1.getPage();
        tweets = new ArrayList(0);
    }

    QueryResultJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
_L2:
        if(i >= jsonarray.length())
            break MISSING_BLOCK_LABEL_215;
        JSONObject jsonobject1 = jsonarray.getJSONObject(i);
        tweets.add(new TweetJSONImpl(jsonobject1, configuration));
        i++;
        continue; /* Loop/switch isn't completed */
        return;
        super();
        JSONObject jsonobject = httpresponse.asJSONObject();
        JSONArray jsonarray;
        int i;
        try
        {
            sinceId = z_T4JInternalParseUtil.getLong("since_id", jsonobject);
            maxId = z_T4JInternalParseUtil.getLong("max_id", jsonobject);
            refreshUrl = z_T4JInternalParseUtil.getUnescapedString("refresh_url", jsonobject);
            resultsPerPage = z_T4JInternalParseUtil.getInt("results_per_page", jsonobject);
            warning = z_T4JInternalParseUtil.getRawString("warning", jsonobject);
            completedIn = z_T4JInternalParseUtil.getDouble("completed_in", jsonobject);
            page = z_T4JInternalParseUtil.getInt("page", jsonobject);
            query = z_T4JInternalParseUtil.getURLDecodedString("query", jsonobject);
            jsonarray = jsonobject.getJSONArray("results");
            tweets = new ArrayList(jsonarray.length());
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + jsonobject.toString(), jsonexception);
        }
        i = 0;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            QueryResult queryresult = (QueryResult)obj;
            if(Double.compare(queryresult.getCompletedIn(), completedIn) != 0)
                return false;
            if(maxId != queryresult.getMaxId())
                return false;
            if(page != queryresult.getPage())
                return false;
            if(resultsPerPage != queryresult.getResultsPerPage())
                return false;
            if(sinceId != queryresult.getSinceId())
                return false;
            if(!query.equals(queryresult.getQuery()))
                return false;
            if(refreshUrl == null ? queryresult.getRefreshUrl() != null : !refreshUrl.equals(queryresult.getRefreshUrl()))
                return false;
            if(tweets == null ? queryresult.getTweets() != null : !tweets.equals(queryresult.getTweets()))
                return false;
            if(warning == null ? queryresult.getWarning() != null : !warning.equals(queryresult.getWarning()))
                return false;
        }
        return true;
    }

    public double getCompletedIn()
    {
        return completedIn;
    }

    public long getMaxId()
    {
        return maxId;
    }

    public int getPage()
    {
        return page;
    }

    public String getQuery()
    {
        return query;
    }

    public String getRefreshUrl()
    {
        return refreshUrl;
    }

    public int getResultsPerPage()
    {
        return resultsPerPage;
    }

    public long getSinceId()
    {
        return sinceId;
    }

    public List getTweets()
    {
        return tweets;
    }

    public String getWarning()
    {
        return warning;
    }

    public int hashCode()
    {
        int i = 31 * (31 * (int)(sinceId ^ sinceId >>> 32) + (int)(maxId ^ maxId >>> 32));
        int j;
        int k;
        int l;
        int i1;
        long l1;
        int j1;
        List list;
        int k1;
        if(refreshUrl != null)
            j = refreshUrl.hashCode();
        else
            j = 0;
        k = 31 * (31 * (i + j) + resultsPerPage);
        if(warning != null)
            l = warning.hashCode();
        else
            l = 0;
        i1 = k + l;
        if(completedIn != 0.0D)
            l1 = Double.doubleToLongBits(completedIn);
        else
            l1 = 0L;
        j1 = 31 * (31 * (31 * (i1 * 31 + (int)(l1 ^ l1 >>> 32)) + page) + query.hashCode());
        list = tweets;
        k1 = 0;
        if(list != null)
            k1 = tweets.hashCode();
        return j1 + k1;
    }

    public String toString()
    {
        return "QueryResultJSONImpl{sinceId=" + sinceId + ", maxId=" + maxId + ", refreshUrl='" + refreshUrl + '\'' + ", resultsPerPage=" + resultsPerPage + ", warning='" + warning + '\'' + ", completedIn=" + completedIn + ", page=" + page + ", query='" + query + '\'' + ", tweets=" + tweets + '}';
    }

    private static final long serialVersionUID = 0x82477b4a917043daL;
    private double completedIn;
    private long maxId;
    private int page;
    private String query;
    private String refreshUrl;
    private int resultsPerPage;
    private long sinceId;
    private List tweets;
    private String warning;
}
