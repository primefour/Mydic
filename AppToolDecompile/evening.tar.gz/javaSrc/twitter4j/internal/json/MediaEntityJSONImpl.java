// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import twitter4j.MediaEntity;
import twitter4j.TwitterException;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

public class MediaEntityJSONImpl
    implements MediaEntity
{
    static class Size
        implements twitter4j.MediaEntity.Size
    {

        public boolean equals(Object obj)
        {
            if(this != obj)
            {
                if(!(obj instanceof Size))
                    return false;
                Size size = (Size)obj;
                if(height != size.height)
                    return false;
                if(resize != size.resize)
                    return false;
                if(width != size.width)
                    return false;
            }
            return true;
        }

        public int getHeight()
        {
            return height;
        }

        public int getResize()
        {
            return resize;
        }

        public int getWidth()
        {
            return width;
        }

        public int hashCode()
        {
            return 31 * (31 * width + height) + resize;
        }

        public String toString()
        {
            return "Size{width=" + width + ", height=" + height + ", resize=" + resize + '}';
        }

        private static final long serialVersionUID = 0x787c23aefe30ba2dL;
        int height;
        int resize;
        int width;

        Size(JSONObject jsonobject)
            throws JSONException
        {
            width = jsonobject.getInt("w");
            height = jsonobject.getInt("h");
            int i;
            if("fit".equals(jsonobject.getString("resize")))
                i = 100;
            else
                i = 101;
            resize = i;
        }
    }


    MediaEntityJSONImpl()
    {
        start = -1;
        end = -1;
    }

    public MediaEntityJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        start = -1;
        end = -1;
        JSONArray jsonarray = jsonobject.getJSONArray("indices");
        start = jsonarray.getInt(0);
        end = jsonarray.getInt(1);
        id = z_T4JInternalParseUtil.getLong("id", jsonobject);
        JSONException jsonexception;
        boolean flag;
        boolean flag1;
        boolean flag2;
        JSONObject jsonobject1;
        try
        {
            url = new URL(jsonobject.getString("url"));
        }
        catch(MalformedURLException malformedurlexception) { }
        flag = jsonobject.isNull("expanded_url");
        if(flag)
            break MISSING_BLOCK_LABEL_96;
        try
        {
            expandedURL = new URL(jsonobject.getString("expanded_url"));
        }
        catch(MalformedURLException malformedurlexception3) { }
        flag1 = jsonobject.isNull("media_url");
        if(flag1)
            break MISSING_BLOCK_LABEL_126;
        try
        {
            mediaURL = new URL(jsonobject.getString("media_url"));
        }
        catch(MalformedURLException malformedurlexception2) { }
        flag2 = jsonobject.isNull("media_url_https");
        if(flag2)
            break MISSING_BLOCK_LABEL_156;
        try
        {
            mediaURLHttps = new URL(jsonobject.getString("media_url_https"));
        }
        catch(MalformedURLException malformedurlexception1) { }
        if(!jsonobject.isNull("display_url"))
            displayURL = jsonobject.getString("display_url");
        jsonobject1 = jsonobject.getJSONObject("sizes");
        sizes = new HashMap(4);
        sizes.put(twitter4j.MediaEntity.Size.LARGE, new Size(jsonobject1.getJSONObject("large")));
        sizes.put(twitter4j.MediaEntity.Size.MEDIUM, new Size(jsonobject1.getJSONObject("medium")));
        sizes.put(twitter4j.MediaEntity.Size.SMALL, new Size(jsonobject1.getJSONObject("small")));
        sizes.put(twitter4j.MediaEntity.Size.THUMB, new Size(jsonobject1.getJSONObject("thumb")));
        return;
        jsonexception;
        throw new TwitterException(jsonexception);
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof MediaEntityJSONImpl))
                return false;
            MediaEntityJSONImpl mediaentityjsonimpl = (MediaEntityJSONImpl)obj;
            if(id != mediaentityjsonimpl.id)
                return false;
        }
        return true;
    }

    public String getDisplayURL()
    {
        return displayURL;
    }

    public int getEnd()
    {
        return end;
    }

    public URL getExpandedURL()
    {
        return expandedURL;
    }

    public long getId()
    {
        return id;
    }

    public URL getMediaURL()
    {
        return mediaURL;
    }

    public URL getMediaURLHttps()
    {
        return mediaURLHttps;
    }

    public Map getSizes()
    {
        return sizes;
    }

    public int getStart()
    {
        return start;
    }

    public URL getURL()
    {
        return url;
    }

    public int hashCode()
    {
        return (int)(id ^ id >>> 32);
    }

    public String toString()
    {
        return "MediaEntityJSONImpl{id=" + id + ", start=" + start + ", end=" + end + ", url=" + url + ", mediaURL=" + mediaURL + ", mediaURLHttps=" + mediaURLHttps + ", expandedURL=" + expandedURL + ", displayURL='" + displayURL + '\'' + ", sizes=" + sizes + '}';
    }

    private static final long serialVersionUID = 0xb7e28b202efe003fL;
    private String displayURL;
    private int end;
    private URL expandedURL;
    private long id;
    private URL mediaURL;
    private URL mediaURLHttps;
    private Map sizes;
    private int start;
    private URL url;
}
