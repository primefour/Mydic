// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import twitter4j.TwitterException;
import twitter4j.UserMentionEntity;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

class UserMentionEntityJSONImpl
    implements UserMentionEntity
{

    UserMentionEntityJSONImpl()
    {
        start = -1;
        end = -1;
    }

    UserMentionEntityJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        start = -1;
        end = -1;
        init(jsonobject);
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        try
        {
            JSONArray jsonarray = jsonobject.getJSONArray("indices");
            start = jsonarray.getInt(0);
            end = jsonarray.getInt(1);
            if(!jsonobject.isNull("name"))
                name = jsonobject.getString("name");
            if(!jsonobject.isNull("screen_name"))
                screenName = jsonobject.getString("screen_name");
            id = z_T4JInternalParseUtil.getLong("id", jsonobject);
            return;
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            UserMentionEntityJSONImpl usermentionentityjsonimpl = (UserMentionEntityJSONImpl)obj;
            if(end != usermentionentityjsonimpl.end)
                return false;
            if(id != usermentionentityjsonimpl.id)
                return false;
            if(start != usermentionentityjsonimpl.start)
                return false;
            if(name == null ? usermentionentityjsonimpl.name != null : !name.equals(usermentionentityjsonimpl.name))
                return false;
            if(screenName == null ? usermentionentityjsonimpl.screenName != null : !screenName.equals(usermentionentityjsonimpl.screenName))
                return false;
        }
        return true;
    }

    public int getEnd()
    {
        return end;
    }

    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public String getScreenName()
    {
        return screenName;
    }

    public int getStart()
    {
        return start;
    }

    public int hashCode()
    {
        int i = 31 * (31 * start + end);
        int j;
        int k;
        String s;
        int l;
        if(name != null)
            j = name.hashCode();
        else
            j = 0;
        k = 31 * (i + j);
        s = screenName;
        l = 0;
        if(s != null)
            l = screenName.hashCode();
        return 31 * (k + l) + (int)(id ^ id >>> 32);
    }

    public String toString()
    {
        return "UserMentionEntityJSONImpl{start=" + start + ", end=" + end + ", name='" + name + '\'' + ", screenName='" + screenName + '\'' + ", id=" + id + '}';
    }

    private static final long serialVersionUID = 0x5b5263422916aeb6L;
    private int end;
    private long id;
    private String name;
    private String screenName;
    private int start;
}
