// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, ResponseListImpl

class RelationshipJSONImpl extends TwitterResponseImpl
    implements Relationship, Serializable
{

    RelationshipJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        this(httpresponse, httpresponse.asJSONObject());
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, httpresponse.asJSONObject());
        }
    }

    RelationshipJSONImpl(HttpResponse httpresponse, JSONObject jsonobject)
        throws TwitterException
    {
        super(httpresponse);
        try
        {
            JSONObject jsonobject1 = jsonobject.getJSONObject("relationship");
            JSONObject jsonobject2 = jsonobject1.getJSONObject("source");
            JSONObject jsonobject3 = jsonobject1.getJSONObject("target");
            sourceUserId = z_T4JInternalParseUtil.getLong("id", jsonobject2);
            targetUserId = z_T4JInternalParseUtil.getLong("id", jsonobject3);
            sourceUserScreenName = z_T4JInternalParseUtil.getUnescapedString("screen_name", jsonobject2);
            targetUserScreenName = z_T4JInternalParseUtil.getUnescapedString("screen_name", jsonobject3);
            sourceBlockingTarget = z_T4JInternalParseUtil.getBoolean("blocking", jsonobject2);
            sourceFollowingTarget = z_T4JInternalParseUtil.getBoolean("following", jsonobject2);
            sourceFollowedByTarget = z_T4JInternalParseUtil.getBoolean("followed_by", jsonobject2);
            sourceNotificationsEnabled = z_T4JInternalParseUtil.getBoolean("notifications_enabled", jsonobject2);
            return;
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + jsonobject.toString(), jsonexception);
        }
    }

    RelationshipJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        this(null, jsonobject);
    }

    static ResponseList createRelationshipList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        JSONArray jsonarray;
        int i;
        ResponseListImpl responselistimpl;
        int j;
        JSONObject jsonobject;
        RelationshipJSONImpl relationshipjsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            jsonarray = httpresponse.asJSONArray();
            i = jsonarray.length();
            responselistimpl = new ResponseListImpl(i, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
        if(j >= i)
            break; /* Loop/switch isn't completed */
        jsonobject = jsonarray.getJSONObject(j);
        relationshipjsonimpl = new RelationshipJSONImpl(jsonobject);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(relationshipjsonimpl, jsonobject);
        responselistimpl.add(relationshipjsonimpl);
        j++;
        if(true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_40;
_L1:
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof Relationship))
                return false;
            Relationship relationship = (Relationship)obj;
            if(sourceUserId != relationship.getSourceUserId())
                return false;
            if(targetUserId != relationship.getTargetUserId())
                return false;
            if(!sourceUserScreenName.equals(relationship.getSourceUserScreenName()))
                return false;
            if(!targetUserScreenName.equals(relationship.getTargetUserScreenName()))
                return false;
        }
        return true;
    }

    public long getSourceUserId()
    {
        return sourceUserId;
    }

    public String getSourceUserScreenName()
    {
        return sourceUserScreenName;
    }

    public long getTargetUserId()
    {
        return targetUserId;
    }

    public String getTargetUserScreenName()
    {
        return targetUserScreenName;
    }

    public int hashCode()
    {
        int i = 1;
        int j = 31 * (int)(targetUserId ^ targetUserId >>> 32);
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        String s;
        int l2;
        if(targetUserScreenName != null)
            k = targetUserScreenName.hashCode();
        else
            k = 0;
        l = 31 * (j + k);
        if(sourceBlockingTarget)
            i1 = i;
        else
            i1 = 0;
        j1 = 31 * (l + i1);
        if(sourceNotificationsEnabled)
            k1 = i;
        else
            k1 = 0;
        l1 = 31 * (j1 + k1);
        if(sourceFollowingTarget)
            i2 = i;
        else
            i2 = 0;
        j2 = 31 * (l1 + i2);
        if(!sourceFollowedByTarget)
            i = 0;
        k2 = 31 * (31 * (j2 + i) + (int)(sourceUserId ^ sourceUserId >>> 32));
        s = sourceUserScreenName;
        l2 = 0;
        if(s != null)
            l2 = sourceUserScreenName.hashCode();
        return k2 + l2;
    }

    public boolean isSourceBlockingTarget()
    {
        return sourceBlockingTarget;
    }

    public boolean isSourceFollowedByTarget()
    {
        return sourceFollowedByTarget;
    }

    public boolean isSourceFollowingTarget()
    {
        return sourceFollowingTarget;
    }

    public boolean isSourceNotificationsEnabled()
    {
        return sourceNotificationsEnabled;
    }

    public boolean isTargetFollowedBySource()
    {
        return sourceFollowingTarget;
    }

    public boolean isTargetFollowingSource()
    {
        return sourceFollowedByTarget;
    }

    public String toString()
    {
        return "RelationshipJSONImpl{sourceUserId=" + sourceUserId + ", targetUserId=" + targetUserId + ", sourceUserScreenName='" + sourceUserScreenName + '\'' + ", targetUserScreenName='" + targetUserScreenName + '\'' + ", sourceFollowingTarget=" + sourceFollowingTarget + ", sourceFollowedByTarget=" + sourceFollowedByTarget + ", sourceNotificationsEnabled=" + sourceNotificationsEnabled + '}';
    }

    private static final long serialVersionUID = 0x6b34ca39712b59e8L;
    private final boolean sourceBlockingTarget;
    private final boolean sourceFollowedByTarget;
    private final boolean sourceFollowingTarget;
    private final boolean sourceNotificationsEnabled;
    private final long sourceUserId;
    private final String sourceUserScreenName;
    private final long targetUserId;
    private final String targetUserScreenName;
}
