// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import twitter4j.ResponseList;
import twitter4j.TwitterException;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;

// Referenced classes of package twitter4j.internal.json:
//            DataObjectFactoryUtil, ResponseListImpl

public class LanguageJSONImpl
    implements twitter4j.api.HelpMethods.Language
{

    LanguageJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        init(jsonobject);
    }

    static ResponseList createLanguageList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        return createLanguageList(httpresponse.asJSONArray(), httpresponse, configuration);
    }

    static ResponseList createLanguageList(JSONArray jsonarray, HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        int j;
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.clearThreadLocalMap();
        int i;
        ResponseListImpl responselistimpl;
        JSONObject jsonobject;
        LanguageJSONImpl languagejsonimpl;
        try
        {
            i = jsonarray.length();
            responselistimpl = new ResponseListImpl(i, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
_L2:
        if(j >= i)
            break MISSING_BLOCK_LABEL_89;
        jsonobject = jsonarray.getJSONObject(j);
        languagejsonimpl = new LanguageJSONImpl(jsonobject);
        responselistimpl.add(languagejsonimpl);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(languagejsonimpl, jsonobject);
        break MISSING_BLOCK_LABEL_123;
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
        j++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        try
        {
            name = jsonobject.getString("name");
            code = jsonobject.getString("code");
            status = jsonobject.getString("status");
            return;
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + jsonobject.toString(), jsonexception);
        }
    }

    public String getCode()
    {
        return code;
    }

    public String getName()
    {
        return name;
    }

    public String getStatus()
    {
        return status;
    }

    private String code;
    private String name;
    private String status;
}
