// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.util.Date;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, ResponseListImpl

final class SavedSearchJSONImpl extends TwitterResponseImpl
    implements SavedSearch
{

    SavedSearchJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.clearThreadLocalMap();
        JSONObject jsonobject = httpresponse.asJSONObject();
        init(jsonobject);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
    }

    SavedSearchJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        init(jsonobject);
    }

    static ResponseList createSavedSearchList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        int i;
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.clearThreadLocalMap();
        JSONArray jsonarray = httpresponse.asJSONArray();
        ResponseListImpl responselistimpl;
        JSONObject jsonobject;
        SavedSearchJSONImpl savedsearchjsonimpl;
        try
        {
            responselistimpl = new ResponseListImpl(jsonarray.length(), httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + httpresponse.asString(), jsonexception);
        }
        i = 0;
_L2:
        if(i < jsonarray.length())
        {
            jsonobject = jsonarray.getJSONObject(i);
            savedsearchjsonimpl = new SavedSearchJSONImpl(jsonobject);
            responselistimpl.add(savedsearchjsonimpl);
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.registerJSONObject(savedsearchjsonimpl, jsonobject);
            break MISSING_BLOCK_LABEL_149;
        }
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
        i++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void init(JSONObject jsonobject)
        throws TwitterException
    {
        createdAt = z_T4JInternalParseUtil.getDate("created_at", jsonobject, "EEE MMM dd HH:mm:ss z yyyy");
        query = z_T4JInternalParseUtil.getUnescapedString("query", jsonobject);
        position = z_T4JInternalParseUtil.getInt("position", jsonobject);
        name = z_T4JInternalParseUtil.getUnescapedString("name", jsonobject);
        id = z_T4JInternalParseUtil.getInt("id", jsonobject);
    }

    public int compareTo(Object obj)
    {
        return compareTo((SavedSearch)obj);
    }

    public int compareTo(SavedSearch savedsearch)
    {
        return id - savedsearch.getId();
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof SavedSearch))
                return false;
            SavedSearch savedsearch = (SavedSearch)obj;
            if(id != savedsearch.getId())
                return false;
        }
        return true;
    }

    public Date getCreatedAt()
    {
        return createdAt;
    }

    public int getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public int getPosition()
    {
        return position;
    }

    public String getQuery()
    {
        return query;
    }

    public int hashCode()
    {
        return 31 * (31 * (31 * (31 * createdAt.hashCode() + query.hashCode()) + position) + name.hashCode()) + id;
    }

    public String toString()
    {
        return "SavedSearchJSONImpl{createdAt=" + createdAt + ", query='" + query + '\'' + ", position=" + position + ", name='" + name + '\'' + ", id=" + id + '}';
    }

    private static final long serialVersionUID = 0x2acbedd301ef9884L;
    private Date createdAt;
    private int id;
    private String name;
    private int position;
    private String query;
}
