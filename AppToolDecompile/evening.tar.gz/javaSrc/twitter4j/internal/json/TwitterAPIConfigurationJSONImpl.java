// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.util.*;
import twitter4j.TwitterAPIConfiguration;
import twitter4j.TwitterException;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil

class TwitterAPIConfigurationJSONImpl extends TwitterResponseImpl
    implements TwitterAPIConfiguration
{

    TwitterAPIConfigurationJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        JSONObject jsonobject;
        JSONObject jsonobject1;
        JSONObject jsonobject2;
        jsonobject = httpresponse.asJSONObject();
        photoSizeLimit = z_T4JInternalParseUtil.getInt("photo_size_limit", jsonobject);
        shortURLLength = z_T4JInternalParseUtil.getInt("short_url_length", jsonobject);
        shortURLLengthHttps = z_T4JInternalParseUtil.getInt("short_url_length_https", jsonobject);
        charactersReservedPerMedia = z_T4JInternalParseUtil.getInt("characters_reserved_per_media", jsonobject);
        jsonobject1 = jsonobject.getJSONObject("photo_sizes");
        photoSizes = new HashMap(4);
        photoSizes.put(twitter4j.MediaEntity.Size.LARGE, new MediaEntityJSONImpl.Size(jsonobject1.getJSONObject("large")));
        if(!jsonobject1.isNull("med"))
            break MISSING_BLOCK_LABEL_273;
        jsonobject2 = jsonobject1.getJSONObject("medium");
_L1:
        JSONArray jsonarray;
        photoSizes.put(twitter4j.MediaEntity.Size.MEDIUM, new MediaEntityJSONImpl.Size(jsonobject2));
        photoSizes.put(twitter4j.MediaEntity.Size.SMALL, new MediaEntityJSONImpl.Size(jsonobject1.getJSONObject("small")));
        photoSizes.put(twitter4j.MediaEntity.Size.THUMB, new MediaEntityJSONImpl.Size(jsonobject1.getJSONObject("thumb")));
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, httpresponse.asJSONObject());
        }
        jsonarray = jsonobject.getJSONArray("non_username_paths");
        nonUsernamePaths = new String[jsonarray.length()];
        int i = 0;
        do
        {
            try
            {
                if(i >= jsonarray.length())
                    break;
                nonUsernamePaths[i] = jsonarray.getString(i);
            }
            catch(JSONException jsonexception)
            {
                throw new TwitterException(jsonexception);
            }
            i++;
        } while(true);
        break MISSING_BLOCK_LABEL_285;
        jsonobject2 = jsonobject1.getJSONObject("med");
          goto _L1
        maxMediaPerUpload = z_T4JInternalParseUtil.getInt("max_media_per_upload", jsonobject);
        return;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof TwitterAPIConfigurationJSONImpl))
                return false;
            TwitterAPIConfigurationJSONImpl twitterapiconfigurationjsonimpl = (TwitterAPIConfigurationJSONImpl)obj;
            if(charactersReservedPerMedia != twitterapiconfigurationjsonimpl.charactersReservedPerMedia)
                return false;
            if(maxMediaPerUpload != twitterapiconfigurationjsonimpl.maxMediaPerUpload)
                return false;
            if(photoSizeLimit != twitterapiconfigurationjsonimpl.photoSizeLimit)
                return false;
            if(shortURLLength != twitterapiconfigurationjsonimpl.shortURLLength)
                return false;
            if(shortURLLengthHttps != twitterapiconfigurationjsonimpl.shortURLLengthHttps)
                return false;
            if(!Arrays.equals(nonUsernamePaths, twitterapiconfigurationjsonimpl.nonUsernamePaths))
                return false;
            if(photoSizes == null ? twitterapiconfigurationjsonimpl.photoSizes != null : !photoSizes.equals(twitterapiconfigurationjsonimpl.photoSizes))
                return false;
        }
        return true;
    }

    public int getCharactersReservedPerMedia()
    {
        return charactersReservedPerMedia;
    }

    public int getMaxMediaPerUpload()
    {
        return maxMediaPerUpload;
    }

    public String[] getNonUsernamePaths()
    {
        return nonUsernamePaths;
    }

    public int getPhotoSizeLimit()
    {
        return photoSizeLimit;
    }

    public Map getPhotoSizes()
    {
        return photoSizes;
    }

    public int getShortURLLength()
    {
        return shortURLLength;
    }

    public int getShortURLLengthHttps()
    {
        return shortURLLengthHttps;
    }

    public int hashCode()
    {
        int i = 31 * (31 * (31 * (31 * photoSizeLimit + shortURLLength) + shortURLLengthHttps) + charactersReservedPerMedia);
        int j;
        int k;
        String as[];
        int l;
        if(photoSizes != null)
            j = photoSizes.hashCode();
        else
            j = 0;
        k = 31 * (i + j);
        as = nonUsernamePaths;
        l = 0;
        if(as != null)
            l = Arrays.hashCode(nonUsernamePaths);
        return 31 * (k + l) + maxMediaPerUpload;
    }

    public String toString()
    {
        StringBuffer stringbuffer = (new StringBuffer()).append("TwitterAPIConfigurationJSONImpl{photoSizeLimit=").append(photoSizeLimit).append(", shortURLLength=").append(shortURLLength).append(", shortURLLengthHttps=").append(shortURLLengthHttps).append(", charactersReservedPerMedia=").append(charactersReservedPerMedia).append(", photoSizes=").append(photoSizes).append(", nonUsernamePaths=");
        java.util.List list;
        if(nonUsernamePaths == null)
            list = null;
        else
            list = Arrays.asList(nonUsernamePaths);
        return stringbuffer.append(list).append(", maxMediaPerUpload=").append(maxMediaPerUpload).append('}').toString();
    }

    private static final long serialVersionUID = 0x504d099b9651fb89L;
    private int charactersReservedPerMedia;
    private int maxMediaPerUpload;
    private String nonUsernamePaths[];
    private int photoSizeLimit;
    private Map photoSizes;
    private int shortURLLength;
    private int shortURLLengthHttps;
}
