// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            DataObjectFactoryUtil, ResponseListImpl

class FriendshipJSONImpl
    implements Friendship
{

    FriendshipJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        int i;
        following = false;
        followedBy = false;
        JSONArray jsonarray;
        String s;
        try
        {
            id = z_T4JInternalParseUtil.getLong("id", jsonobject);
            name = jsonobject.getString("name");
            screenName = jsonobject.getString("screen_name");
            jsonarray = jsonobject.getJSONArray("connections");
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + jsonobject.toString(), jsonexception);
        }
        i = 0;
_L2:
        if(i >= jsonarray.length())
            break MISSING_BLOCK_LABEL_146;
        s = jsonarray.getString(i);
        if("following".equals(s))
        {
            following = true;
            break MISSING_BLOCK_LABEL_147;
        }
        if("followed_by".equals(s))
            followedBy = true;
        break MISSING_BLOCK_LABEL_147;
        return;
        i++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    static ResponseList createFriendshipList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        JSONArray jsonarray;
        int i;
        ResponseListImpl responselistimpl;
        int j;
        JSONObject jsonobject;
        FriendshipJSONImpl friendshipjsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            jsonarray = httpresponse.asJSONArray();
            i = jsonarray.length();
            responselistimpl = new ResponseListImpl(i, httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        catch(TwitterException twitterexception)
        {
            throw twitterexception;
        }
        j = 0;
        if(j >= i)
            break; /* Loop/switch isn't completed */
        jsonobject = jsonarray.getJSONObject(j);
        friendshipjsonimpl = new FriendshipJSONImpl(jsonobject);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(friendshipjsonimpl, jsonobject);
        responselistimpl.add(friendshipjsonimpl);
        j++;
        if(true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_40;
_L1:
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            FriendshipJSONImpl friendshipjsonimpl = (FriendshipJSONImpl)obj;
            if(followedBy != friendshipjsonimpl.followedBy)
                return false;
            if(following != friendshipjsonimpl.following)
                return false;
            if(id != friendshipjsonimpl.id)
                return false;
            if(!name.equals(friendshipjsonimpl.name))
                return false;
            if(!screenName.equals(friendshipjsonimpl.screenName))
                return false;
        }
        return true;
    }

    public long getId()
    {
        return id;
    }

    public String getName()
    {
        return name;
    }

    public String getScreenName()
    {
        return screenName;
    }

    public int hashCode()
    {
        int i = 1;
        int j = 31 * (int)(id ^ id >>> 32);
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        if(name != null)
            k = name.hashCode();
        else
            k = 0;
        l = 31 * (j + k);
        if(screenName != null)
            i1 = screenName.hashCode();
        else
            i1 = 0;
        j1 = 31 * (l + i1);
        if(following)
            k1 = i;
        else
            k1 = 0;
        l1 = 31 * (j1 + k1);
        if(!followedBy)
            i = 0;
        return l1 + i;
    }

    public boolean isFollowedBy()
    {
        return followedBy;
    }

    public boolean isFollowing()
    {
        return following;
    }

    public String toString()
    {
        return "FriendshipJSONImpl{id=" + id + ", name='" + name + '\'' + ", screenName='" + screenName + '\'' + ", following=" + following + ", followedBy=" + followedBy + '}';
    }

    private static final long serialVersionUID = 0x6b329ebb34802aedL;
    private boolean followedBy;
    private boolean following;
    private final long id;
    private final String name;
    private final String screenName;
}
