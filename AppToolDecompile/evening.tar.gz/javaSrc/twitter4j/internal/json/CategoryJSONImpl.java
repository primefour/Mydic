// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            DataObjectFactoryUtil, ResponseListImpl

final class CategoryJSONImpl
    implements Category, Serializable
{

    CategoryJSONImpl(JSONObject jsonobject)
        throws JSONException
    {
        init(jsonobject);
    }

    static ResponseList createCategoriesList(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        return createCategoriesList(httpresponse.asJSONArray(), httpresponse, configuration);
    }

    static ResponseList createCategoriesList(JSONArray jsonarray, HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        int i;
        ResponseListImpl responselistimpl;
        JSONObject jsonobject;
        CategoryJSONImpl categoryjsonimpl;
        try
        {
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.clearThreadLocalMap();
            responselistimpl = new ResponseListImpl(jsonarray.length(), httpresponse);
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        i = 0;
_L2:
        if(i < jsonarray.length())
        {
            jsonobject = jsonarray.getJSONObject(i);
            categoryjsonimpl = new CategoryJSONImpl(jsonobject);
            responselistimpl.add(categoryjsonimpl);
            if(configuration.isJSONStoreEnabled())
                DataObjectFactoryUtil.registerJSONObject(categoryjsonimpl, jsonobject);
            break MISSING_BLOCK_LABEL_116;
        }
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(responselistimpl, jsonarray);
        return responselistimpl;
        i++;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(obj == null || getClass() != obj.getClass())
                return false;
            CategoryJSONImpl categoryjsonimpl = (CategoryJSONImpl)obj;
            if(size != categoryjsonimpl.size)
                return false;
            if(name == null ? categoryjsonimpl.name != null : !name.equals(categoryjsonimpl.name))
                return false;
            if(slug == null ? categoryjsonimpl.slug != null : !slug.equals(categoryjsonimpl.slug))
                return false;
        }
        return true;
    }

    public String getName()
    {
        return name;
    }

    public int getSize()
    {
        return size;
    }

    public String getSlug()
    {
        return slug;
    }

    public int hashCode()
    {
        int i;
        int j;
        String s;
        int k;
        if(name != null)
            i = name.hashCode();
        else
            i = 0;
        j = i * 31;
        s = slug;
        k = 0;
        if(s != null)
            k = slug.hashCode();
        return 31 * (j + k) + size;
    }

    void init(JSONObject jsonobject)
        throws JSONException
    {
        name = jsonobject.getString("name");
        slug = jsonobject.getString("slug");
        size = z_T4JInternalParseUtil.getInt("size", jsonobject);
    }

    public String toString()
    {
        return "CategoryJSONImpl{name='" + name + '\'' + ", slug='" + slug + '\'' + ", size=" + size + '}';
    }

    private static final long serialVersionUID = 0xa2f7f72df154090aL;
    private String name;
    private int size;
    private String slug;
}
