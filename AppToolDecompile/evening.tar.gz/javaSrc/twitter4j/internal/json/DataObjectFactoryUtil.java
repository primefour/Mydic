// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class DataObjectFactoryUtil
{

    private DataObjectFactoryUtil()
    {
        throw new AssertionError("not intended to be instantiated.");
    }

    static Class _mthclass$(String s)
    {
        Class class1;
        try
        {
            class1 = Class.forName(s);
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            throw (new NoClassDefFoundError()).initCause(classnotfoundexception);
        }
        return class1;
    }

    public static void clearThreadLocalMap()
    {
        try
        {
            CLEAR_THREAD_LOCAL_MAP.invoke(null, new Object[0]);
            return;
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
    }

    public static Object registerJSONObject(Object obj, Object obj1)
    {
        Object obj2;
        try
        {
            obj2 = REGISTER_JSON_OBJECT.invoke(null, new Object[] {
                obj, obj1
            });
        }
        catch(IllegalAccessException illegalaccessexception)
        {
            throw new AssertionError(illegalaccessexception);
        }
        catch(InvocationTargetException invocationtargetexception)
        {
            throw new AssertionError(invocationtargetexception);
        }
        return obj2;
    }

    private static final Method CLEAR_THREAD_LOCAL_MAP;
    private static final Method REGISTER_JSON_OBJECT;
    static Class class$twitter4j$json$DataObjectFactory;

    static 
    {
        Class class1;
        Method amethod[];
        Method method;
        Method method1;
        int i;
        int j;
        if(class$twitter4j$json$DataObjectFactory == null)
        {
            class1 = _mthclass$("twitter4j.json.DataObjectFactory");
            class$twitter4j$json$DataObjectFactory = class1;
        } else
        {
            class1 = class$twitter4j$json$DataObjectFactory;
        }
        amethod = class1.getDeclaredMethods();
        method = null;
        method1 = null;
        i = amethod.length;
        j = 0;
        while(j < i) 
        {
            Method method2 = amethod[j];
            if(method2.getName().equals("clearThreadLocalMap"))
            {
                method = method2;
                method.setAccessible(true);
            } else
            if(method2.getName().equals("registerJSONObject"))
            {
                method1 = method2;
                method1.setAccessible(true);
            }
            j++;
        }
        if(method == null || method1 == null)
        {
            throw new AssertionError();
        } else
        {
            CLEAR_THREAD_LOCAL_MAP = method;
            REGISTER_JSON_OBJECT = method1;
        }
    }
}
