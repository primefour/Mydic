// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, TimeZoneJSONImpl, LocationJSONImpl

class AccountSettingsJSONImpl extends TwitterResponseImpl
    implements AccountSettings, Serializable
{

    AccountSettingsJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        this(httpresponse, httpresponse.asJSONObject());
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, httpresponse.asJSONObject());
        }
    }

    private AccountSettingsJSONImpl(HttpResponse httpresponse, JSONObject jsonobject)
        throws TwitterException
    {
        super(httpresponse);
        JSONObject jsonobject1 = jsonobject.getJSONObject("sleep_time");
        SLEEP_TIME_ENABLED = z_T4JInternalParseUtil.getBoolean("enabled", jsonobject1);
        SLEEP_START_TIME = jsonobject1.getString("start_time");
        SLEEP_END_TIME = jsonobject1.getString("end_time");
        if(!jsonobject.isNull("trend_location")) goto _L2; else goto _L1
_L1:
        TREND_LOCATION = new Location[0];
_L6:
        GEO_ENABLED = z_T4JInternalParseUtil.getBoolean("geo_enabled", jsonobject);
        LANGUAGE = jsonobject.getString("language");
        ALWAYS_USE_HTTPS = z_T4JInternalParseUtil.getBoolean("always_use_https", jsonobject);
        DISCOVERABLE_BY_EMAIL = z_T4JInternalParseUtil.getBoolean("discoverable_by_email", jsonobject);
        TIMEZONE = new TimeZoneJSONImpl(jsonobject.getJSONObject("time_zone"));
        return;
_L2:
        JSONArray jsonarray;
        int i;
        try
        {
            jsonarray = jsonobject.getJSONArray("trend_location");
            TREND_LOCATION = new Location[jsonarray.length()];
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        i = 0;
        if(i >= jsonarray.length())
            continue; /* Loop/switch isn't completed */
        TREND_LOCATION[i] = new LocationJSONImpl(jsonarray.getJSONObject(i));
        i++;
        if(true) goto _L4; else goto _L3
_L3:
        break MISSING_BLOCK_LABEL_177;
_L4:
        break MISSING_BLOCK_LABEL_144;
        if(true) goto _L6; else goto _L5
_L5:
    }

    AccountSettingsJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        this(null, jsonobject);
    }

    public String getLanguage()
    {
        return LANGUAGE;
    }

    public String getSleepEndTime()
    {
        return SLEEP_END_TIME;
    }

    public String getSleepStartTime()
    {
        return SLEEP_START_TIME;
    }

    public TimeZone getTimeZone()
    {
        return TIMEZONE;
    }

    public Location[] getTrendLocations()
    {
        return TREND_LOCATION;
    }

    public boolean isAlwaysUseHttps()
    {
        return ALWAYS_USE_HTTPS;
    }

    public boolean isDiscoverableByEmail()
    {
        return DISCOVERABLE_BY_EMAIL;
    }

    public boolean isGeoEnabled()
    {
        return GEO_ENABLED;
    }

    public boolean isSleepTimeEnabled()
    {
        return SLEEP_TIME_ENABLED;
    }

    private static final long serialVersionUID = 0x6eca9ae824b25838L;
    private final boolean ALWAYS_USE_HTTPS;
    private final boolean DISCOVERABLE_BY_EMAIL;
    private final boolean GEO_ENABLED;
    private final String LANGUAGE;
    private final String SLEEP_END_TIME;
    private final String SLEEP_START_TIME;
    private final boolean SLEEP_TIME_ENABLED;
    private final TimeZone TIMEZONE;
    private final Location TREND_LOCATION[];
}
