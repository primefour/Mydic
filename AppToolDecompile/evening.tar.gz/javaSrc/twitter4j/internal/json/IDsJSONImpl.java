// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.util.Arrays;
import twitter4j.IDs;
import twitter4j.TwitterException;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil

final class IDsJSONImpl extends TwitterResponseImpl
    implements IDs
{

    IDsJSONImpl(String s)
        throws TwitterException
    {
        previousCursor = -1L;
        nextCursor = -1L;
        init(s);
    }

    IDsJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        previousCursor = -1L;
        nextCursor = -1L;
        String s = httpresponse.asString();
        init(s);
        if(configuration.isJSONStoreEnabled())
        {
            DataObjectFactoryUtil.clearThreadLocalMap();
            DataObjectFactoryUtil.registerJSONObject(this, s);
        }
    }

    private void init(String s)
        throws TwitterException
    {
        JSONObject jsonobject;
        JSONArray jsonarray;
        if(!s.startsWith("{"))
            break MISSING_BLOCK_LABEL_139;
        jsonobject = new JSONObject(s);
        jsonarray = jsonobject.getJSONArray("ids");
        ids = new long[jsonarray.length()];
        int i = 0;
_L1:
        int j;
        NumberFormatException numberformatexception;
        try
        {
            j = jsonarray.length();
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
        if(i >= j)
            break MISSING_BLOCK_LABEL_118;
        ids[i] = Long.parseLong(jsonarray.getString(i));
        i++;
          goto _L1
        numberformatexception;
        throw new TwitterException("Twitter API returned malformed response: " + jsonobject, numberformatexception);
        previousCursor = z_T4JInternalParseUtil.getLong("previous_cursor", jsonobject);
        nextCursor = z_T4JInternalParseUtil.getLong("next_cursor", jsonobject);
        return;
        JSONArray jsonarray1;
        jsonarray1 = new JSONArray(s);
        ids = new long[jsonarray1.length()];
        int k = 0;
_L2:
        int l = jsonarray1.length();
        if(k >= l)
            break MISSING_BLOCK_LABEL_232;
        ids[k] = Long.parseLong(jsonarray1.getString(k));
        k++;
          goto _L2
        NumberFormatException numberformatexception1;
        numberformatexception1;
        throw new TwitterException("Twitter API returned malformed response: " + jsonarray1, numberformatexception1);
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof IDs))
                return false;
            IDs ids1 = (IDs)obj;
            if(!Arrays.equals(ids, ids1.getIDs()))
                return false;
        }
        return true;
    }

    public long[] getIDs()
    {
        return ids;
    }

    public long getNextCursor()
    {
        return nextCursor;
    }

    public long getPreviousCursor()
    {
        return previousCursor;
    }

    public boolean hasNext()
    {
        return 0L != nextCursor;
    }

    public boolean hasPrevious()
    {
        return 0L != previousCursor;
    }

    public int hashCode()
    {
        if(ids != null)
            return Arrays.hashCode(ids);
        else
            return 0;
    }

    public String toString()
    {
        return "IDsJSONImpl{ids=" + Arrays.toString(ids) + ", previousCursor=" + previousCursor + ", nextCursor=" + nextCursor + '}';
    }

    private static final long serialVersionUID = 0xa49d493b84decd47L;
    private long ids[];
    private long nextCursor;
    private long previousCursor;
}
