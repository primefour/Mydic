// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.org.json.*;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            z_T4JInternalJSONImplFactory, PlaceJSONImpl, UserMentionEntityJSONImpl, URLEntityJSONImpl, 
//            HashtagEntityJSONImpl, MediaEntityJSONImpl, DataObjectFactoryUtil

final class TweetJSONImpl
    implements Tweet, Serializable
{

    TweetJSONImpl(JSONObject jsonobject)
        throws TwitterException
    {
        toUserId = -1L;
        toUser = null;
        toUserName = null;
        fromUser = null;
        fromUserName = null;
        isoLanguageCode = null;
        inReplyToStatusId = -1L;
        geoLocation = null;
        annotations = null;
        text = z_T4JInternalParseUtil.getUnescapedString("text", jsonobject);
        toUserId = z_T4JInternalParseUtil.getLong("to_user_id", jsonobject);
        toUser = z_T4JInternalParseUtil.getRawString("to_user", jsonobject);
        toUserName = z_T4JInternalParseUtil.getRawString("to_user_name", jsonobject);
        fromUser = z_T4JInternalParseUtil.getRawString("from_user", jsonobject);
        fromUserName = z_T4JInternalParseUtil.getRawString("from_user_name", jsonobject);
        id = z_T4JInternalParseUtil.getLong("id", jsonobject);
        fromUserId = z_T4JInternalParseUtil.getLong("from_user_id", jsonobject);
        isoLanguageCode = z_T4JInternalParseUtil.getRawString("iso_language_code", jsonobject);
        source = z_T4JInternalParseUtil.getUnescapedString("source", jsonobject);
        inReplyToStatusId = z_T4JInternalParseUtil.getLong("in_reply_to_status_id", jsonobject);
        profileImageUrl = z_T4JInternalParseUtil.getUnescapedString("profile_image_url", jsonobject);
        createdAt = z_T4JInternalParseUtil.getDate("created_at", jsonobject, "EEE, dd MMM yyyy HH:mm:ss z");
        location = z_T4JInternalParseUtil.getRawString("location", jsonobject);
        geoLocation = z_T4JInternalJSONImplFactory.createGeoLocation(jsonobject);
        JSONException jsonexception;
        JSONObject jsonobject1;
        JSONArray jsonarray;
        int i;
        int j;
        JSONArray jsonarray1;
        int k;
        int l;
        JSONArray jsonarray2;
        int i1;
        int j1;
        JSONArray jsonarray3;
        int k1;
        int l1;
        if(!jsonobject.isNull("annotations"))
            try
            {
                annotations = new Annotations(jsonobject.getJSONArray("annotations"));
            }
            catch(JSONException jsonexception2) { }
        if(!jsonobject.isNull("place"))
            try
            {
                place = new PlaceJSONImpl(jsonobject.getJSONObject("place"));
            }
            catch(JSONException jsonexception1)
            {
                throw new TwitterException(jsonexception1);
            }
        else
            place = null;
        if(jsonobject.isNull("entities")) goto _L2; else goto _L1
_L1:
        jsonobject1 = jsonobject.getJSONObject("entities");
        if(jsonobject1.isNull("user_mentions"))
            break MISSING_BLOCK_LABEL_361;
        jsonarray3 = jsonobject1.getJSONArray("user_mentions");
        k1 = jsonarray3.length();
        userMentionEntities = new UserMentionEntity[k1];
        l1 = 0;
        while(l1 < k1) 
        {
            try
            {
                userMentionEntities[l1] = new UserMentionEntityJSONImpl(jsonarray3.getJSONObject(l1));
            }
            // Misplaced declaration of an exception variable
            catch(JSONException jsonexception)
            {
                throw new TwitterException(jsonexception);
            }
            l1++;
        }
        if(jsonobject1.isNull("urls")) goto _L4; else goto _L3
_L3:
        jsonarray2 = jsonobject1.getJSONArray("urls");
        i1 = jsonarray2.length();
        urlEntities = new URLEntity[i1];
        j1 = 0;
_L5:
        if(j1 >= i1)
            break; /* Loop/switch isn't completed */
        urlEntities[j1] = new URLEntityJSONImpl(jsonarray2.getJSONObject(j1));
        j1++;
        if(true) goto _L5; else goto _L4
_L4:
        if(jsonobject1.isNull("hashtags")) goto _L7; else goto _L6
_L6:
        jsonarray1 = jsonobject1.getJSONArray("hashtags");
        k = jsonarray1.length();
        hashtagEntities = new HashtagEntity[k];
        l = 0;
_L8:
        if(l >= k)
            break; /* Loop/switch isn't completed */
        hashtagEntities[l] = new HashtagEntityJSONImpl(jsonarray1.getJSONObject(l));
        l++;
        if(true) goto _L8; else goto _L7
_L7:
        if(jsonobject1.isNull("media")) goto _L2; else goto _L9
_L9:
        jsonarray = jsonobject1.getJSONArray("media");
        i = jsonarray.length();
        mediaEntities = new MediaEntity[i];
        j = 0;
_L10:
        if(j >= i)
            break; /* Loop/switch isn't completed */
        mediaEntities[j] = new MediaEntityJSONImpl(jsonarray.getJSONObject(j));
        j++;
        if(true) goto _L10; else goto _L2
_L2:
    }

    TweetJSONImpl(JSONObject jsonobject, Configuration configuration)
        throws TwitterException
    {
        this(jsonobject);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
    }

    public int compareTo(Object obj)
    {
        return compareTo((Tweet)obj);
    }

    public int compareTo(Tweet tweet)
    {
        long l = id - tweet.getId();
        if(l < 0xffffffff80000000L)
            return 0x80000000;
        if(l > 0x7fffffffL)
            return 0x7fffffff;
        else
            return (int)l;
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof Tweet))
                return false;
            Tweet tweet = (Tweet)obj;
            if(id != tweet.getId())
                return false;
        }
        return true;
    }

    public Annotations getAnnotations()
    {
        return annotations;
    }

    public Date getCreatedAt()
    {
        return createdAt;
    }

    public String getFromUser()
    {
        return fromUser;
    }

    public long getFromUserId()
    {
        return fromUserId;
    }

    public String getFromUserName()
    {
        return fromUserName;
    }

    public GeoLocation getGeoLocation()
    {
        return geoLocation;
    }

    public HashtagEntity[] getHashtagEntities()
    {
        return hashtagEntities;
    }

    public long getId()
    {
        return id;
    }

    public long getInReplyToStatusId()
    {
        return inReplyToStatusId;
    }

    public String getIsoLanguageCode()
    {
        return isoLanguageCode;
    }

    public String getLocation()
    {
        return location;
    }

    public MediaEntity[] getMediaEntities()
    {
        return mediaEntities;
    }

    public Place getPlace()
    {
        return place;
    }

    public String getProfileImageUrl()
    {
        return profileImageUrl;
    }

    public String getSource()
    {
        return source;
    }

    public String getText()
    {
        return text;
    }

    public String getToUser()
    {
        return toUser;
    }

    public long getToUserId()
    {
        return toUserId;
    }

    public String getToUserName()
    {
        return toUserName;
    }

    public URLEntity[] getURLEntities()
    {
        return urlEntities;
    }

    public UserMentionEntity[] getUserMentionEntities()
    {
        return userMentionEntities;
    }

    public int hashCode()
    {
        int i;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        int k3;
        int l3;
        int i4;
        int j4;
        int k4;
        int l4;
        int i5;
        int j5;
        int k5;
        int l5;
        int i6;
        int j6;
        int k6;
        int l6;
        int i7;
        int j7;
        int k7;
        int l7;
        MediaEntity amediaentity[];
        int i8;
        if(text != null)
            i = text.hashCode();
        else
            i = 0;
        j = 31 * (i * 31 + (int)(toUserId ^ toUserId >>> 32));
        if(toUser != null)
            k = toUser.hashCode();
        else
            k = 0;
        l = 31 * (j + k);
        if(toUserName != null)
            i1 = toUserName.hashCode();
        else
            i1 = 0;
        j1 = 31 * (l + i1);
        if(fromUser != null)
            k1 = fromUser.hashCode();
        else
            k1 = 0;
        l1 = 31 * (j1 + k1);
        if(fromUserName != null)
            i2 = fromUserName.hashCode();
        else
            i2 = 0;
        j2 = 31 * (31 * (31 * (l1 + i2) + (int)(id ^ id >>> 32)) + (int)(fromUserId ^ fromUserId >>> 32));
        if(isoLanguageCode != null)
            k2 = isoLanguageCode.hashCode();
        else
            k2 = 0;
        l2 = 31 * (j2 + k2);
        if(source != null)
            i3 = source.hashCode();
        else
            i3 = 0;
        j3 = 31 * (31 * (l2 + i3) + (int)(inReplyToStatusId ^ inReplyToStatusId >>> 32));
        if(profileImageUrl != null)
            k3 = profileImageUrl.hashCode();
        else
            k3 = 0;
        l3 = 31 * (j3 + k3);
        if(createdAt != null)
            i4 = createdAt.hashCode();
        else
            i4 = 0;
        j4 = 31 * (l3 + i4);
        if(location != null)
            k4 = location.hashCode();
        else
            k4 = 0;
        l4 = 31 * (j4 + k4);
        if(place != null)
            i5 = place.hashCode();
        else
            i5 = 0;
        j5 = 31 * (l4 + i5);
        if(geoLocation != null)
            k5 = geoLocation.hashCode();
        else
            k5 = 0;
        l5 = 31 * (j5 + k5);
        if(annotations != null)
            i6 = annotations.hashCode();
        else
            i6 = 0;
        j6 = 31 * (l5 + i6);
        if(userMentionEntities != null)
            k6 = Arrays.hashCode(userMentionEntities);
        else
            k6 = 0;
        l6 = 31 * (j6 + k6);
        if(urlEntities != null)
            i7 = Arrays.hashCode(urlEntities);
        else
            i7 = 0;
        j7 = 31 * (l6 + i7);
        if(hashtagEntities != null)
            k7 = Arrays.hashCode(hashtagEntities);
        else
            k7 = 0;
        l7 = 31 * (j7 + k7);
        amediaentity = mediaEntities;
        i8 = 0;
        if(amediaentity != null)
            i8 = Arrays.hashCode(mediaEntities);
        return l7 + i8;
    }

    public String toString()
    {
        StringBuffer stringbuffer = (new StringBuffer()).append("TweetJSONImpl{text='").append(text).append('\'').append(", toUserId=").append(toUserId).append(", toUser='").append(toUser).append('\'').append(", toUserName='").append(toUserName).append('\'').append(", fromUser='").append(fromUser).append('\'').append(", fromUserName='").append(fromUserName).append('\'').append(", id=").append(id).append(", fromUserId=").append(fromUserId).append(", isoLanguageCode='").append(isoLanguageCode).append('\'').append(", source='").append(source).append('\'').append(", inReplyToStatusId=").append(inReplyToStatusId).append(", profileImageUrl='").append(profileImageUrl).append('\'').append(", createdAt=").append(createdAt).append(", location='").append(location).append('\'').append(", place=").append(place).append(", geoLocation=").append(geoLocation).append(", annotations=").append(annotations).append(", userMentionEntities=");
        java.util.List list;
        StringBuffer stringbuffer1;
        java.util.List list1;
        StringBuffer stringbuffer2;
        java.util.List list2;
        StringBuffer stringbuffer3;
        MediaEntity amediaentity[];
        java.util.List list3;
        if(userMentionEntities == null)
            list = null;
        else
            list = Arrays.asList(userMentionEntities);
        stringbuffer1 = stringbuffer.append(list).append(", urlEntities=");
        if(urlEntities == null)
            list1 = null;
        else
            list1 = Arrays.asList(urlEntities);
        stringbuffer2 = stringbuffer1.append(list1).append(", hashtagEntities=");
        if(hashtagEntities == null)
            list2 = null;
        else
            list2 = Arrays.asList(hashtagEntities);
        stringbuffer3 = stringbuffer2.append(list2).append(", mediaEntities=");
        amediaentity = mediaEntities;
        list3 = null;
        if(amediaentity != null)
            list3 = Arrays.asList(mediaEntities);
        return stringbuffer3.append(list3).append('}').toString();
    }

    private static final long serialVersionUID = 0x29e6a7eb8de21fb1L;
    private Annotations annotations;
    private Date createdAt;
    private String fromUser;
    private long fromUserId;
    private String fromUserName;
    private GeoLocation geoLocation;
    private HashtagEntity hashtagEntities[];
    private long id;
    private long inReplyToStatusId;
    private String isoLanguageCode;
    private String location;
    private MediaEntity mediaEntities[];
    private Place place;
    private String profileImageUrl;
    private String source;
    private String text;
    private String toUser;
    private long toUserId;
    private String toUserName;
    private URLEntity urlEntities[];
    private UserMentionEntity userMentionEntities[];
}
