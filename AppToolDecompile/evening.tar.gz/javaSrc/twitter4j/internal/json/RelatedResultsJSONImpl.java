// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.*;

// Referenced classes of package twitter4j.internal.json:
//            TwitterResponseImpl, DataObjectFactoryUtil, ResponseListImpl, StatusJSONImpl

final class RelatedResultsJSONImpl extends TwitterResponseImpl
    implements RelatedResults, Serializable
{

    RelatedResultsJSONImpl(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        super(httpresponse);
        if(configuration.isJSONStoreEnabled())
            DataObjectFactoryUtil.clearThreadLocalMap();
        init(httpresponse.asJSONArray(), httpresponse, configuration.isJSONStoreEnabled());
    }

    RelatedResultsJSONImpl(JSONArray jsonarray)
        throws TwitterException
    {
        init(jsonarray, null, false);
    }

    private void init(JSONArray jsonarray, HttpResponse httpresponse, boolean flag)
        throws TwitterException
    {
        int i;
        tweetsMap = new HashMap(2);
        i = 0;
        int j;
        JSONObject jsonobject;
        String s;
        JSONArray jsonarray1;
        Object obj;
        int k;
        int l;
        JSONObject jsonobject1;
        StatusJSONImpl statusjsonimpl;
        try
        {
            j = jsonarray.length();
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception);
        }
_L4:
        if(i >= j)
            break MISSING_BLOCK_LABEL_257;
        jsonobject = jsonarray.getJSONObject(i);
        if(!"Tweet".equals(jsonobject.getString("resultType")))
            break MISSING_BLOCK_LABEL_258;
        s = jsonobject.getString("groupName");
        if(s.length() == 0 || !s.equals("TweetsWithConversation") && !s.equals("TweetsWithReply") && !s.equals("TweetsFromUser"))
            break MISSING_BLOCK_LABEL_258;
        jsonarray1 = jsonobject.getJSONArray("results");
        obj = (ResponseList)tweetsMap.get(s);
        if(obj != null)
            break MISSING_BLOCK_LABEL_160;
        obj = new ResponseListImpl(jsonarray1.length(), httpresponse);
        tweetsMap.put(s, obj);
        k = 0;
        l = jsonarray1.length();
_L2:
        if(k >= l)
            break; /* Loop/switch isn't completed */
        jsonobject1 = jsonarray1.getJSONObject(k).getJSONObject("value");
        statusjsonimpl = new StatusJSONImpl(jsonobject1);
        if(!flag)
            break MISSING_BLOCK_LABEL_214;
        DataObjectFactoryUtil.registerJSONObject(statusjsonimpl, jsonobject1);
        ((ResponseList) (obj)).add(statusjsonimpl);
        k++;
        if(true) goto _L2; else goto _L1
_L1:
        if(!flag)
            break MISSING_BLOCK_LABEL_258;
        DataObjectFactoryUtil.registerJSONObject(obj, jsonarray1);
        break MISSING_BLOCK_LABEL_258;
        return;
        i++;
        if(true) goto _L4; else goto _L3
_L3:
    }

    public boolean equals(Object obj)
    {
label0:
        {
            if(obj instanceof RelatedResultsJSONImpl)
            {
                RelatedResultsJSONImpl relatedresultsjsonimpl = (RelatedResultsJSONImpl)obj;
                if(tweetsMap != null ? tweetsMap.equals(relatedresultsjsonimpl.tweetsMap) : relatedresultsjsonimpl.tweetsMap == null)
                    break label0;
            }
            return false;
        }
        return true;
    }

    public ResponseList getTweetsFromUser()
    {
        ResponseList responselist = (ResponseList)tweetsMap.get("TweetsFromUser");
        if(responselist != null)
            return responselist;
        else
            return new ResponseListImpl(0, null);
    }

    public ResponseList getTweetsWithConversation()
    {
        ResponseList responselist = (ResponseList)tweetsMap.get("TweetsWithConversation");
        if(responselist != null)
            return responselist;
        else
            return new ResponseListImpl(0, null);
    }

    public ResponseList getTweetsWithReply()
    {
        ResponseList responselist = (ResponseList)tweetsMap.get("TweetsWithReply");
        if(responselist != null)
            return responselist;
        else
            return new ResponseListImpl(0, null);
    }

    public int hashCode()
    {
        return 31 + tweetsMap.hashCode();
    }

    public String toString()
    {
        return "RelatedResultsJSONImpl {tweetsMap=" + tweetsMap + "}";
    }

    private static final String TWEETS_FROM_USER = "TweetsFromUser";
    private static final String TWEETS_WITH_CONVERSATION = "TweetsWithConversation";
    private static final String TWEETS_WITH_REPLY = "TweetsWithReply";
    private static final long serialVersionUID = 0x99114d9b472e63cdL;
    private Map tweetsMap;
}
