// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import java.io.Serializable;
import twitter4j.Trend;
import twitter4j.internal.org.json.JSONObject;
import twitter4j.internal.util.z_T4JInternalParseUtil;

// Referenced classes of package twitter4j.internal.json:
//            DataObjectFactoryUtil

final class TrendJSONImpl
    implements Trend, Serializable
{

    TrendJSONImpl(JSONObject jsonobject)
    {
        this(jsonobject, false);
    }

    TrendJSONImpl(JSONObject jsonobject, boolean flag)
    {
        url = null;
        query = null;
        name = z_T4JInternalParseUtil.getRawString("name", jsonobject);
        url = z_T4JInternalParseUtil.getRawString("url", jsonobject);
        query = z_T4JInternalParseUtil.getRawString("query", jsonobject);
        if(flag)
            DataObjectFactoryUtil.registerJSONObject(this, jsonobject);
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof Trend))
                return false;
            Trend trend = (Trend)obj;
            if(!name.equals(trend.getName()))
                return false;
            if(query == null ? trend.getQuery() != null : !query.equals(trend.getQuery()))
                return false;
            if(url == null ? trend.getUrl() != null : !url.equals(trend.getUrl()))
                return false;
        }
        return true;
    }

    public String getName()
    {
        return name;
    }

    public String getQuery()
    {
        return query;
    }

    public String getUrl()
    {
        return url;
    }

    public int hashCode()
    {
        int i = 31 * name.hashCode();
        int j;
        int k;
        String s;
        int l;
        if(url != null)
            j = url.hashCode();
        else
            j = 0;
        k = 31 * (i + j);
        s = query;
        l = 0;
        if(s != null)
            l = query.hashCode();
        return k + l;
    }

    public String toString()
    {
        return "TrendJSONImpl{name='" + name + '\'' + ", url='" + url + '\'' + ", query='" + query + '\'' + '}';
    }

    private static final long serialVersionUID = 0x1aba5f6b262a250aL;
    private String name;
    private String query;
    private String url;
}
