// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.json;

import twitter4j.*;
import twitter4j.conf.Configuration;
import twitter4j.internal.http.HttpResponse;
import twitter4j.internal.org.json.JSONException;
import twitter4j.internal.org.json.JSONObject;

// Referenced classes of package twitter4j.internal.json:
//            ResponseListImpl, PlaceJSONImpl

public class SimilarPlacesImpl extends ResponseListImpl
    implements SimilarPlaces
{

    SimilarPlacesImpl(ResponseList responselist, HttpResponse httpresponse, String s)
    {
        super(responselist.size(), httpresponse);
        addAll(responselist);
        token = s;
    }

    static SimilarPlaces createSimilarPlaces(HttpResponse httpresponse, Configuration configuration)
        throws TwitterException
    {
        JSONObject jsonobject = null;
        SimilarPlacesImpl similarplacesimpl;
        try
        {
            jsonobject = httpresponse.asJSONObject();
            JSONObject jsonobject1 = jsonobject.getJSONObject("result");
            similarplacesimpl = new SimilarPlacesImpl(PlaceJSONImpl.createPlaceList(jsonobject1.getJSONArray("places"), httpresponse, configuration), httpresponse, jsonobject1.getString("token"));
        }
        catch(JSONException jsonexception)
        {
            throw new TwitterException(jsonexception.getMessage() + ":" + jsonobject.toString(), jsonexception);
        }
        return similarplacesimpl;
    }

    public int getAccessLevel()
    {
        return super.getAccessLevel();
    }

    public RateLimitStatus getFeatureSpecificRateLimitStatus()
    {
        return super.getFeatureSpecificRateLimitStatus();
    }

    public RateLimitStatus getRateLimitStatus()
    {
        return super.getRateLimitStatus();
    }

    public String getToken()
    {
        return token;
    }

    private static final long serialVersionUID = 0x92655a9befea1fc5L;
    private final String token;
}
