// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.internal.logging;


// Referenced classes of package twitter4j.internal.logging:
//            Logger

public abstract class LoggerFactory
{

    public LoggerFactory()
    {
    }

    public abstract Logger getLogger(Class class1);
}
