// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.conf;

import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.*;
import twitter4j.Version;

// Referenced classes of package twitter4j.conf:
//            Configuration

class ConfigurationBase
    implements Configuration, Serializable
{

    protected ConfigurationBase()
    {
        setDebug(false);
        setUser(null);
        setPassword(null);
        setUseSSL(false);
        setPrettyDebugEnabled(false);
        setGZIPEnabled(true);
        setHttpProxyHost(null);
        setHttpProxyUser(null);
        setHttpProxyPassword(null);
        setHttpProxyPort(-1);
        setHttpConnectionTimeout(20000);
        setHttpReadTimeout(0x1d4c0);
        setHttpStreamingReadTimeout(40000);
        setHttpRetryCount(0);
        setHttpRetryIntervalSeconds(5);
        setHttpMaxTotalConnections(20);
        setHttpDefaultMaxPerRoute(2);
        setOAuthConsumerKey(null);
        setOAuthConsumerSecret(null);
        setOAuthAccessToken(null);
        setOAuthAccessTokenSecret(null);
        setAsyncNumThreads(1);
        setClientVersion(Version.getVersion());
        setClientURL("http://twitter4j.org/en/twitter4j-" + Version.getVersion() + ".xml");
        setUserAgent("twitter4j http://twitter4j.org/ /" + Version.getVersion());
        setIncludeRTsEnbled(true);
        setIncludeEntitiesEnbled(true);
        setJSONStoreEnabled(false);
        setMBeanEnabled(false);
        setOAuthRequestTokenURL("http://api.twitter.com/oauth/request_token");
        setOAuthAuthorizationURL("http://api.twitter.com/oauth/authorize");
        setOAuthAccessTokenURL("http://api.twitter.com/oauth/access_token");
        setOAuthAuthenticationURL("http://api.twitter.com/oauth/authenticate");
        setRestBaseURL("http://api.twitter.com/1/");
        setSearchBaseURL("http://search.twitter.com/");
        setStreamBaseURL("https://stream.twitter.com/1/");
        setUserStreamBaseURL("https://userstream.twitter.com/2/");
        setSiteStreamBaseURL("https://sitestream.twitter.com/2b/");
        setUploadBaseURL("http://upload.twitter.com/1/");
        setDispatcherImpl("twitter4j.internal.async.DispatcherImpl");
        setIncludeRTsEnbled(true);
        setUserStreamRepliesAllEnabled(true);
        String s3 = System.getProperty("twitter4j.dalvik", dalvikDetected);
        String s = s3;
_L1:
        IS_DALVIK = Boolean.valueOf(s).booleanValue();
        String s2 = System.getProperty("twitter4j.gae", gaeDetected);
        String s1 = s2;
_L2:
        IS_GAE = Boolean.valueOf(s1).booleanValue();
        setMediaProvider("TWITTER");
        setMediaProviderAPIKey(null);
        setMediaProviderParameters(null);
        return;
        SecurityException securityexception;
        securityexception;
        s = dalvikDetected;
          goto _L1
        SecurityException securityexception1;
        securityexception1;
        s1 = gaeDetected;
          goto _L2
    }

    private static void cacheInstance(ConfigurationBase configurationbase)
    {
        if(!instances.contains(configurationbase))
            instances.add(configurationbase);
    }

    private void fixRestBaseURL()
    {
        if("http://api.twitter.com/1/".equals(fixURL(false, restBaseURL)))
            restBaseURL = fixURL(useSSL, restBaseURL);
        if("http://api.twitter.com/oauth/access_token".equals(fixURL(false, oAuthAccessTokenURL)))
            oAuthAccessTokenURL = fixURL(useSSL, oAuthAccessTokenURL);
        if("http://api.twitter.com/oauth/authenticate".equals(fixURL(false, oAuthAuthenticationURL)))
            oAuthAuthenticationURL = fixURL(useSSL, oAuthAuthenticationURL);
        if("http://api.twitter.com/oauth/authorize".equals(fixURL(false, oAuthAuthorizationURL)))
            oAuthAuthorizationURL = fixURL(useSSL, oAuthAuthorizationURL);
        if("http://api.twitter.com/oauth/request_token".equals(fixURL(false, oAuthRequestTokenURL)))
            oAuthRequestTokenURL = fixURL(useSSL, oAuthRequestTokenURL);
        if("http://search.twitter.com/".equals(fixURL(false, searchBaseURL)))
            searchBaseURL = fixURL(useSSL, searchBaseURL);
    }

    static String fixURL(boolean flag, String s)
    {
        if(s == null)
            return null;
        int i = s.indexOf("://");
        if(-1 == i)
            throw new IllegalArgumentException("url should contain '://'");
        String s1 = s.substring(i + 3);
        if(flag)
            return "https://" + s1;
        else
            return "http://" + s1;
    }

    private void fixUploadBaseURL()
    {
        if("http://upload.twitter.com/1/".equals(fixURL(false, uploadBaseURL)))
            uploadBaseURL = fixURL(useSSL, uploadBaseURL);
    }

    private static ConfigurationBase getInstance(ConfigurationBase configurationbase)
    {
        int i = instances.indexOf(configurationbase);
        if(i == -1)
        {
            instances.add(configurationbase);
            return configurationbase;
        } else
        {
            return (ConfigurationBase)instances.get(i);
        }
    }

    private void initRequestHeaders()
    {
        requestHeaders = new HashMap();
        requestHeaders.put("X-Twitter-Client-Version", getClientVersion());
        requestHeaders.put("X-Twitter-Client-URL", getClientURL());
        requestHeaders.put("X-Twitter-Client", "Twitter4J");
        requestHeaders.put("User-Agent", getUserAgent());
        if(gzipEnabled)
            requestHeaders.put("Accept-Encoding", "gzip");
        if(IS_DALVIK)
            requestHeaders.put("Connection", "close");
    }

    protected void cacheInstance()
    {
        cacheInstance(this);
    }

    public boolean equals(Object obj)
    {
        if(this != obj)
        {
            if(!(obj instanceof ConfigurationBase))
                return false;
            ConfigurationBase configurationbase = (ConfigurationBase)obj;
            if(asyncNumThreads != configurationbase.asyncNumThreads)
                return false;
            if(debug != configurationbase.debug)
                return false;
            if(defaultMaxPerRoute != configurationbase.defaultMaxPerRoute)
                return false;
            if(gzipEnabled != configurationbase.gzipEnabled)
                return false;
            if(httpConnectionTimeout != configurationbase.httpConnectionTimeout)
                return false;
            if(httpProxyPort != configurationbase.httpProxyPort)
                return false;
            if(httpReadTimeout != configurationbase.httpReadTimeout)
                return false;
            if(httpRetryCount != configurationbase.httpRetryCount)
                return false;
            if(httpRetryIntervalSeconds != configurationbase.httpRetryIntervalSeconds)
                return false;
            if(httpStreamingReadTimeout != configurationbase.httpStreamingReadTimeout)
                return false;
            if(includeEntitiesEnabled != configurationbase.includeEntitiesEnabled)
                return false;
            if(includeRTsEnabled != configurationbase.includeRTsEnabled)
                return false;
            if(jsonStoreEnabled != configurationbase.jsonStoreEnabled)
                return false;
            if(maxTotalConnections != configurationbase.maxTotalConnections)
                return false;
            if(mbeanEnabled != configurationbase.mbeanEnabled)
                return false;
            if(prettyDebug != configurationbase.prettyDebug)
                return false;
            if(useSSL != configurationbase.useSSL)
                return false;
            if(userStreamRepliesAllEnabled != configurationbase.userStreamRepliesAllEnabled)
                return false;
            if(clientURL == null ? configurationbase.clientURL != null : !clientURL.equals(configurationbase.clientURL))
                return false;
            if(clientVersion == null ? configurationbase.clientVersion != null : !clientVersion.equals(configurationbase.clientVersion))
                return false;
            if(dispatcherImpl == null ? configurationbase.dispatcherImpl != null : !dispatcherImpl.equals(configurationbase.dispatcherImpl))
                return false;
            if(httpProxyHost == null ? configurationbase.httpProxyHost != null : !httpProxyHost.equals(configurationbase.httpProxyHost))
                return false;
            if(httpProxyPassword == null ? configurationbase.httpProxyPassword != null : !httpProxyPassword.equals(configurationbase.httpProxyPassword))
                return false;
            if(httpProxyUser == null ? configurationbase.httpProxyUser != null : !httpProxyUser.equals(configurationbase.httpProxyUser))
                return false;
            if(mediaProvider == null ? configurationbase.mediaProvider != null : !mediaProvider.equals(configurationbase.mediaProvider))
                return false;
            if(mediaProviderAPIKey == null ? configurationbase.mediaProviderAPIKey != null : !mediaProviderAPIKey.equals(configurationbase.mediaProviderAPIKey))
                return false;
            if(mediaProviderParameters == null ? configurationbase.mediaProviderParameters != null : !mediaProviderParameters.equals(configurationbase.mediaProviderParameters))
                return false;
            if(oAuthAccessToken == null ? configurationbase.oAuthAccessToken != null : !oAuthAccessToken.equals(configurationbase.oAuthAccessToken))
                return false;
            if(oAuthAccessTokenSecret == null ? configurationbase.oAuthAccessTokenSecret != null : !oAuthAccessTokenSecret.equals(configurationbase.oAuthAccessTokenSecret))
                return false;
            if(oAuthAccessTokenURL == null ? configurationbase.oAuthAccessTokenURL != null : !oAuthAccessTokenURL.equals(configurationbase.oAuthAccessTokenURL))
                return false;
            if(oAuthAuthenticationURL == null ? configurationbase.oAuthAuthenticationURL != null : !oAuthAuthenticationURL.equals(configurationbase.oAuthAuthenticationURL))
                return false;
            if(oAuthAuthorizationURL == null ? configurationbase.oAuthAuthorizationURL != null : !oAuthAuthorizationURL.equals(configurationbase.oAuthAuthorizationURL))
                return false;
            if(oAuthConsumerKey == null ? configurationbase.oAuthConsumerKey != null : !oAuthConsumerKey.equals(configurationbase.oAuthConsumerKey))
                return false;
            if(oAuthConsumerSecret == null ? configurationbase.oAuthConsumerSecret != null : !oAuthConsumerSecret.equals(configurationbase.oAuthConsumerSecret))
                return false;
            if(oAuthRequestTokenURL == null ? configurationbase.oAuthRequestTokenURL != null : !oAuthRequestTokenURL.equals(configurationbase.oAuthRequestTokenURL))
                return false;
            if(password == null ? configurationbase.password != null : !password.equals(configurationbase.password))
                return false;
            if(requestHeaders == null ? configurationbase.requestHeaders != null : !requestHeaders.equals(configurationbase.requestHeaders))
                return false;
            if(restBaseURL == null ? configurationbase.restBaseURL != null : !restBaseURL.equals(configurationbase.restBaseURL))
                return false;
            if(searchBaseURL == null ? configurationbase.searchBaseURL != null : !searchBaseURL.equals(configurationbase.searchBaseURL))
                return false;
            if(siteStreamBaseURL == null ? configurationbase.siteStreamBaseURL != null : !siteStreamBaseURL.equals(configurationbase.siteStreamBaseURL))
                return false;
            if(streamBaseURL == null ? configurationbase.streamBaseURL != null : !streamBaseURL.equals(configurationbase.streamBaseURL))
                return false;
            if(uploadBaseURL == null ? configurationbase.uploadBaseURL != null : !uploadBaseURL.equals(configurationbase.uploadBaseURL))
                return false;
            if(user == null ? configurationbase.user != null : !user.equals(configurationbase.user))
                return false;
            if(userAgent == null ? configurationbase.userAgent != null : !userAgent.equals(configurationbase.userAgent))
                return false;
            if(userStreamBaseURL == null ? configurationbase.userStreamBaseURL != null : !userStreamBaseURL.equals(configurationbase.userStreamBaseURL))
                return false;
        }
        return true;
    }

    public final int getAsyncNumThreads()
    {
        return asyncNumThreads;
    }

    public final String getClientURL()
    {
        return clientURL;
    }

    public final String getClientVersion()
    {
        return clientVersion;
    }

    public String getDispatcherImpl()
    {
        return dispatcherImpl;
    }

    public final int getHttpConnectionTimeout()
    {
        return httpConnectionTimeout;
    }

    public final int getHttpDefaultMaxPerRoute()
    {
        return defaultMaxPerRoute;
    }

    public final int getHttpMaxTotalConnections()
    {
        return maxTotalConnections;
    }

    public final String getHttpProxyHost()
    {
        return httpProxyHost;
    }

    public final String getHttpProxyPassword()
    {
        return httpProxyPassword;
    }

    public final int getHttpProxyPort()
    {
        return httpProxyPort;
    }

    public final String getHttpProxyUser()
    {
        return httpProxyUser;
    }

    public final int getHttpReadTimeout()
    {
        return httpReadTimeout;
    }

    public final int getHttpRetryCount()
    {
        return httpRetryCount;
    }

    public final int getHttpRetryIntervalSeconds()
    {
        return httpRetryIntervalSeconds;
    }

    public int getHttpStreamingReadTimeout()
    {
        return httpStreamingReadTimeout;
    }

    public String getMediaProvider()
    {
        return mediaProvider;
    }

    public String getMediaProviderAPIKey()
    {
        return mediaProviderAPIKey;
    }

    public Properties getMediaProviderParameters()
    {
        return mediaProviderParameters;
    }

    public String getOAuthAccessToken()
    {
        return oAuthAccessToken;
    }

    public String getOAuthAccessTokenSecret()
    {
        return oAuthAccessTokenSecret;
    }

    public String getOAuthAccessTokenURL()
    {
        return oAuthAccessTokenURL;
    }

    public String getOAuthAuthenticationURL()
    {
        return oAuthAuthenticationURL;
    }

    public String getOAuthAuthorizationURL()
    {
        return oAuthAuthorizationURL;
    }

    public final String getOAuthConsumerKey()
    {
        return oAuthConsumerKey;
    }

    public final String getOAuthConsumerSecret()
    {
        return oAuthConsumerSecret;
    }

    public String getOAuthRequestTokenURL()
    {
        return oAuthRequestTokenURL;
    }

    public final String getPassword()
    {
        return password;
    }

    public Map getRequestHeaders()
    {
        return requestHeaders;
    }

    public String getRestBaseURL()
    {
        return restBaseURL;
    }

    public String getSearchBaseURL()
    {
        return searchBaseURL;
    }

    public String getSiteStreamBaseURL()
    {
        return siteStreamBaseURL;
    }

    public String getStreamBaseURL()
    {
        return streamBaseURL;
    }

    public String getUploadBaseURL()
    {
        return uploadBaseURL;
    }

    public final String getUser()
    {
        return user;
    }

    public final String getUserAgent()
    {
        return userAgent;
    }

    public String getUserStreamBaseURL()
    {
        return userStreamBaseURL;
    }

    public int hashCode()
    {
        int i = 1;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        int k3;
        int l3;
        int i4;
        int j4;
        int k4;
        int l4;
        int i5;
        int j5;
        int k5;
        int l5;
        int i6;
        int j6;
        int k6;
        int l6;
        int i7;
        int j7;
        int k7;
        int l7;
        int i8;
        int j8;
        int k8;
        int l8;
        int i9;
        int j9;
        int k9;
        int l9;
        int i10;
        int j10;
        int k10;
        int l10;
        int i11;
        int j11;
        int k11;
        int l11;
        int i12;
        int j12;
        int k12;
        int l12;
        int i13;
        int j13;
        int k13;
        int l13;
        int i14;
        int j14;
        int k14;
        int l14;
        int i15;
        int j15;
        int k15;
        int l15;
        int i16;
        int j16;
        int k16;
        int l16;
        int i17;
        int j17;
        int k17;
        int l17;
        int i18;
        int j18;
        Map map;
        int k18;
        if(debug)
            j = i;
        else
            j = 0;
        k = j * 31;
        if(userAgent != null)
            l = userAgent.hashCode();
        else
            l = 0;
        i1 = 31 * (k + l);
        if(user != null)
            j1 = user.hashCode();
        else
            j1 = 0;
        k1 = 31 * (i1 + j1);
        if(password != null)
            l1 = password.hashCode();
        else
            l1 = 0;
        i2 = 31 * (k1 + l1);
        if(useSSL)
            j2 = i;
        else
            j2 = 0;
        k2 = 31 * (i2 + j2);
        if(prettyDebug)
            l2 = i;
        else
            l2 = 0;
        i3 = 31 * (k2 + l2);
        if(gzipEnabled)
            j3 = i;
        else
            j3 = 0;
        k3 = 31 * (i3 + j3);
        if(httpProxyHost != null)
            l3 = httpProxyHost.hashCode();
        else
            l3 = 0;
        i4 = 31 * (k3 + l3);
        if(httpProxyUser != null)
            j4 = httpProxyUser.hashCode();
        else
            j4 = 0;
        k4 = 31 * (i4 + j4);
        if(httpProxyPassword != null)
            l4 = httpProxyPassword.hashCode();
        else
            l4 = 0;
        i5 = 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (k4 + l4) + httpProxyPort) + httpConnectionTimeout) + httpReadTimeout) + httpStreamingReadTimeout) + httpRetryCount) + httpRetryIntervalSeconds) + maxTotalConnections) + defaultMaxPerRoute);
        if(oAuthConsumerKey != null)
            j5 = oAuthConsumerKey.hashCode();
        else
            j5 = 0;
        k5 = 31 * (i5 + j5);
        if(oAuthConsumerSecret != null)
            l5 = oAuthConsumerSecret.hashCode();
        else
            l5 = 0;
        i6 = 31 * (k5 + l5);
        if(oAuthAccessToken != null)
            j6 = oAuthAccessToken.hashCode();
        else
            j6 = 0;
        k6 = 31 * (i6 + j6);
        if(oAuthAccessTokenSecret != null)
            l6 = oAuthAccessTokenSecret.hashCode();
        else
            l6 = 0;
        i7 = 31 * (k6 + l6);
        if(oAuthRequestTokenURL != null)
            j7 = oAuthRequestTokenURL.hashCode();
        else
            j7 = 0;
        k7 = 31 * (i7 + j7);
        if(oAuthAuthorizationURL != null)
            l7 = oAuthAuthorizationURL.hashCode();
        else
            l7 = 0;
        i8 = 31 * (k7 + l7);
        if(oAuthAccessTokenURL != null)
            j8 = oAuthAccessTokenURL.hashCode();
        else
            j8 = 0;
        k8 = 31 * (i8 + j8);
        if(oAuthAuthenticationURL != null)
            l8 = oAuthAuthenticationURL.hashCode();
        else
            l8 = 0;
        i9 = 31 * (k8 + l8);
        if(restBaseURL != null)
            j9 = restBaseURL.hashCode();
        else
            j9 = 0;
        k9 = 31 * (i9 + j9);
        if(searchBaseURL != null)
            l9 = searchBaseURL.hashCode();
        else
            l9 = 0;
        i10 = 31 * (k9 + l9);
        if(streamBaseURL != null)
            j10 = streamBaseURL.hashCode();
        else
            j10 = 0;
        k10 = 31 * (i10 + j10);
        if(userStreamBaseURL != null)
            l10 = userStreamBaseURL.hashCode();
        else
            l10 = 0;
        i11 = 31 * (k10 + l10);
        if(siteStreamBaseURL != null)
            j11 = siteStreamBaseURL.hashCode();
        else
            j11 = 0;
        k11 = 31 * (i11 + j11);
        if(uploadBaseURL != null)
            l11 = uploadBaseURL.hashCode();
        else
            l11 = 0;
        i12 = 31 * (k11 + l11);
        if(dispatcherImpl != null)
            j12 = dispatcherImpl.hashCode();
        else
            j12 = 0;
        k12 = 31 * (31 * (i12 + j12) + asyncNumThreads);
        if(includeRTsEnabled)
            l12 = i;
        else
            l12 = 0;
        i13 = 31 * (k12 + l12);
        if(includeEntitiesEnabled)
            j13 = i;
        else
            j13 = 0;
        k13 = 31 * (i13 + j13);
        if(jsonStoreEnabled)
            l13 = i;
        else
            l13 = 0;
        i14 = 31 * (k13 + l13);
        if(mbeanEnabled)
            j14 = i;
        else
            j14 = 0;
        k14 = 31 * (i14 + j14);
        if(userStreamRepliesAllEnabled)
            l14 = i;
        else
            l14 = 0;
        i15 = 31 * (k14 + l14);
        if(mediaProvider != null)
            j15 = mediaProvider.hashCode();
        else
            j15 = 0;
        k15 = 31 * (i15 + j15);
        if(mediaProviderAPIKey != null)
            l15 = mediaProviderAPIKey.hashCode();
        else
            l15 = 0;
        i16 = 31 * (k15 + l15);
        if(mediaProviderParameters != null)
            j16 = mediaProviderParameters.hashCode();
        else
            j16 = 0;
        k16 = 31 * (i16 + j16);
        if(clientVersion != null)
            l16 = clientVersion.hashCode();
        else
            l16 = 0;
        i17 = 31 * (k16 + l16);
        if(clientURL != null)
            j17 = clientURL.hashCode();
        else
            j17 = 0;
        k17 = 31 * (i17 + j17);
        if(IS_DALVIK)
            l17 = i;
        else
            l17 = 0;
        i18 = 31 * (k17 + l17);
        if(!IS_GAE)
            i = 0;
        j18 = 31 * (i18 + i);
        map = requestHeaders;
        k18 = 0;
        if(map != null)
            k18 = requestHeaders.hashCode();
        return j18 + k18;
    }

    public final boolean isDalvik()
    {
        return IS_DALVIK;
    }

    public final boolean isDebugEnabled()
    {
        return debug;
    }

    public boolean isGAE()
    {
        return IS_GAE;
    }

    public boolean isGZIPEnabled()
    {
        return gzipEnabled;
    }

    public boolean isIncludeEntitiesEnabled()
    {
        return includeEntitiesEnabled;
    }

    public boolean isIncludeRTsEnabled()
    {
        return includeRTsEnabled;
    }

    public boolean isJSONStoreEnabled()
    {
        return jsonStoreEnabled;
    }

    public boolean isMBeanEnabled()
    {
        return mbeanEnabled;
    }

    public boolean isPrettyDebugEnabled()
    {
        return prettyDebug;
    }

    public boolean isUserStreamRepliesAllEnabled()
    {
        return userStreamRepliesAllEnabled;
    }

    protected Object readResolve()
        throws ObjectStreamException
    {
        return getInstance(this);
    }

    protected final void setAsyncNumThreads(int i)
    {
        asyncNumThreads = i;
    }

    protected final void setClientURL(String s)
    {
        clientURL = s;
        initRequestHeaders();
    }

    protected final void setClientVersion(String s)
    {
        clientVersion = s;
        initRequestHeaders();
    }

    protected final void setDebug(boolean flag)
    {
        debug = flag;
    }

    protected final void setDispatcherImpl(String s)
    {
        dispatcherImpl = s;
    }

    protected final void setGZIPEnabled(boolean flag)
    {
        gzipEnabled = flag;
        initRequestHeaders();
    }

    protected final void setHttpConnectionTimeout(int i)
    {
        httpConnectionTimeout = i;
    }

    protected final void setHttpDefaultMaxPerRoute(int i)
    {
        defaultMaxPerRoute = i;
    }

    protected final void setHttpMaxTotalConnections(int i)
    {
        maxTotalConnections = i;
    }

    protected final void setHttpProxyHost(String s)
    {
        httpProxyHost = s;
    }

    protected final void setHttpProxyPassword(String s)
    {
        httpProxyPassword = s;
    }

    protected final void setHttpProxyPort(int i)
    {
        httpProxyPort = i;
    }

    protected final void setHttpProxyUser(String s)
    {
        httpProxyUser = s;
    }

    protected final void setHttpReadTimeout(int i)
    {
        httpReadTimeout = i;
    }

    protected final void setHttpRetryCount(int i)
    {
        httpRetryCount = i;
    }

    protected final void setHttpRetryIntervalSeconds(int i)
    {
        httpRetryIntervalSeconds = i;
    }

    protected final void setHttpStreamingReadTimeout(int i)
    {
        httpStreamingReadTimeout = i;
    }

    protected final void setIncludeEntitiesEnbled(boolean flag)
    {
        includeEntitiesEnabled = flag;
    }

    protected final void setIncludeRTsEnbled(boolean flag)
    {
        includeRTsEnabled = flag;
    }

    protected final void setJSONStoreEnabled(boolean flag)
    {
        jsonStoreEnabled = flag;
    }

    protected final void setMBeanEnabled(boolean flag)
    {
        mbeanEnabled = flag;
    }

    protected final void setMediaProvider(String s)
    {
        mediaProvider = s;
    }

    protected final void setMediaProviderAPIKey(String s)
    {
        mediaProviderAPIKey = s;
    }

    protected final void setMediaProviderParameters(Properties properties)
    {
        mediaProviderParameters = properties;
    }

    protected final void setOAuthAccessToken(String s)
    {
        oAuthAccessToken = s;
    }

    protected final void setOAuthAccessTokenSecret(String s)
    {
        oAuthAccessTokenSecret = s;
    }

    protected final void setOAuthAccessTokenURL(String s)
    {
        oAuthAccessTokenURL = s;
        fixRestBaseURL();
    }

    protected final void setOAuthAuthenticationURL(String s)
    {
        oAuthAuthenticationURL = s;
        fixRestBaseURL();
    }

    protected final void setOAuthAuthorizationURL(String s)
    {
        oAuthAuthorizationURL = s;
        fixRestBaseURL();
    }

    protected final void setOAuthConsumerKey(String s)
    {
        oAuthConsumerKey = s;
        fixRestBaseURL();
    }

    protected final void setOAuthConsumerSecret(String s)
    {
        oAuthConsumerSecret = s;
        fixRestBaseURL();
    }

    protected final void setOAuthRequestTokenURL(String s)
    {
        oAuthRequestTokenURL = s;
        fixRestBaseURL();
    }

    protected final void setPassword(String s)
    {
        password = s;
    }

    protected final void setPrettyDebugEnabled(boolean flag)
    {
        prettyDebug = flag;
    }

    protected final void setRestBaseURL(String s)
    {
        restBaseURL = s;
        fixRestBaseURL();
    }

    protected final void setSearchBaseURL(String s)
    {
        searchBaseURL = s;
    }

    protected final void setSiteStreamBaseURL(String s)
    {
        siteStreamBaseURL = s;
    }

    protected final void setStreamBaseURL(String s)
    {
        streamBaseURL = s;
    }

    protected final void setUploadBaseURL(String s)
    {
        uploadBaseURL = s;
        fixUploadBaseURL();
    }

    protected final void setUseSSL(boolean flag)
    {
        useSSL = flag;
        fixRestBaseURL();
    }

    protected final void setUser(String s)
    {
        user = s;
    }

    protected final void setUserAgent(String s)
    {
        userAgent = s;
        initRequestHeaders();
    }

    protected final void setUserStreamBaseURL(String s)
    {
        userStreamBaseURL = s;
    }

    protected final void setUserStreamRepliesAllEnabled(boolean flag)
    {
        userStreamRepliesAllEnabled = flag;
    }

    public String toString()
    {
        return "ConfigurationBase{debug=" + debug + ", userAgent='" + userAgent + '\'' + ", user='" + user + '\'' + ", password='" + password + '\'' + ", useSSL=" + useSSL + ", prettyDebug=" + prettyDebug + ", gzipEnabled=" + gzipEnabled + ", httpProxyHost='" + httpProxyHost + '\'' + ", httpProxyUser='" + httpProxyUser + '\'' + ", httpProxyPassword='" + httpProxyPassword + '\'' + ", httpProxyPort=" + httpProxyPort + ", httpConnectionTimeout=" + httpConnectionTimeout + ", httpReadTimeout=" + httpReadTimeout + ", httpStreamingReadTimeout=" + httpStreamingReadTimeout + ", httpRetryCount=" + httpRetryCount + ", httpRetryIntervalSeconds=" + httpRetryIntervalSeconds + ", maxTotalConnections=" + maxTotalConnections + ", defaultMaxPerRoute=" + defaultMaxPerRoute + ", oAuthConsumerKey='" + oAuthConsumerKey + '\'' + ", oAuthConsumerSecret='" + oAuthConsumerSecret + '\'' + ", oAuthAccessToken='" + oAuthAccessToken + '\'' + ", oAuthAccessTokenSecret='" + oAuthAccessTokenSecret + '\'' + ", oAuthRequestTokenURL='" + oAuthRequestTokenURL + '\'' + ", oAuthAuthorizationURL='" + oAuthAuthorizationURL + '\'' + ", oAuthAccessTokenURL='" + oAuthAccessTokenURL + '\'' + ", oAuthAuthenticationURL='" + oAuthAuthenticationURL + '\'' + ", restBaseURL='" + restBaseURL + '\'' + ", searchBaseURL='" + searchBaseURL + '\'' + ", streamBaseURL='" + streamBaseURL + '\'' + ", userStreamBaseURL='" + userStreamBaseURL + '\'' + ", siteStreamBaseURL='" + siteStreamBaseURL + '\'' + ", uploadBaseURL='" + uploadBaseURL + '\'' + ", dispatcherImpl='" + dispatcherImpl + '\'' + ", asyncNumThreads=" + asyncNumThreads + ", includeRTsEnabled=" + includeRTsEnabled + ", includeEntitiesEnabled=" + includeEntitiesEnabled + ", jsonStoreEnabled=" + jsonStoreEnabled + ", mbeanEnabled=" + mbeanEnabled + ", userStreamRepliesAllEnabled=" + userStreamRepliesAllEnabled + ", mediaProvider='" + mediaProvider + '\'' + ", mediaProviderAPIKey='" + mediaProviderAPIKey + '\'' + ", mediaProviderParameters=" + mediaProviderParameters + ", clientVersion='" + clientVersion + '\'' + ", clientURL='" + clientURL + '\'' + ", IS_DALVIK=" + IS_DALVIK + ", IS_GAE=" + IS_GAE + ", requestHeaders=" + requestHeaders + '}';
    }

    public static final String DALVIK = "twitter4j.dalvik";
    private static final String DEFAULT_OAUTH_ACCESS_TOKEN_URL = "http://api.twitter.com/oauth/access_token";
    private static final String DEFAULT_OAUTH_AUTHENTICATION_URL = "http://api.twitter.com/oauth/authenticate";
    private static final String DEFAULT_OAUTH_AUTHORIZATION_URL = "http://api.twitter.com/oauth/authorize";
    private static final String DEFAULT_OAUTH_REQUEST_TOKEN_URL = "http://api.twitter.com/oauth/request_token";
    private static final String DEFAULT_REST_BASE_URL = "http://api.twitter.com/1/";
    private static final String DEFAULT_SEARCH_BASE_URL = "http://search.twitter.com/";
    private static final String DEFAULT_SITE_STREAM_BASE_URL = "https://sitestream.twitter.com/2b/";
    private static final String DEFAULT_STREAM_BASE_URL = "https://stream.twitter.com/1/";
    private static final String DEFAULT_UPLOAD_BASE_URL = "http://upload.twitter.com/1/";
    private static final String DEFAULT_USER_STREAM_BASE_URL = "https://userstream.twitter.com/2/";
    public static final String GAE = "twitter4j.gae";
    static String dalvikDetected;
    static String gaeDetected;
    private static final List instances = new ArrayList();
    private static final long serialVersionUID = 0xa442cb880cac80f8L;
    private boolean IS_DALVIK;
    private boolean IS_GAE;
    private int asyncNumThreads;
    private String clientURL;
    private String clientVersion;
    private boolean debug;
    private int defaultMaxPerRoute;
    private String dispatcherImpl;
    private boolean gzipEnabled;
    private int httpConnectionTimeout;
    private String httpProxyHost;
    private String httpProxyPassword;
    private int httpProxyPort;
    private String httpProxyUser;
    private int httpReadTimeout;
    private int httpRetryCount;
    private int httpRetryIntervalSeconds;
    private int httpStreamingReadTimeout;
    private boolean includeEntitiesEnabled;
    private boolean includeRTsEnabled;
    private boolean jsonStoreEnabled;
    private int maxTotalConnections;
    private boolean mbeanEnabled;
    private String mediaProvider;
    private String mediaProviderAPIKey;
    private Properties mediaProviderParameters;
    private String oAuthAccessToken;
    private String oAuthAccessTokenSecret;
    private String oAuthAccessTokenURL;
    private String oAuthAuthenticationURL;
    private String oAuthAuthorizationURL;
    private String oAuthConsumerKey;
    private String oAuthConsumerSecret;
    private String oAuthRequestTokenURL;
    private String password;
    private boolean prettyDebug;
    Map requestHeaders;
    private String restBaseURL;
    private String searchBaseURL;
    private String siteStreamBaseURL;
    private String streamBaseURL;
    private String uploadBaseURL;
    private boolean useSSL;
    private String user;
    private String userAgent;
    private String userStreamBaseURL;
    private boolean userStreamRepliesAllEnabled;

    static 
    {
        try
        {
            Class.forName("dalvik.system.VMRuntime");
            dalvikDetected = "true";
        }
        catch(ClassNotFoundException classnotfoundexception)
        {
            dalvikDetected = "false";
        }
        try
        {
            Class.forName("com.google.appengine.api.urlfetch.URLFetchService");
            gaeDetected = "true";
        }
        catch(ClassNotFoundException classnotfoundexception1)
        {
            gaeDetected = "false";
        }
    }
}
