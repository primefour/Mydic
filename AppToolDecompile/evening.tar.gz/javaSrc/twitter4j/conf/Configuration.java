// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package twitter4j.conf;

import java.io.Serializable;
import java.util.Map;
import java.util.Properties;
import twitter4j.auth.AuthorizationConfiguration;
import twitter4j.internal.http.HttpClientConfiguration;
import twitter4j.internal.http.HttpClientWrapperConfiguration;

public interface Configuration
    extends HttpClientConfiguration, HttpClientWrapperConfiguration, AuthorizationConfiguration, Serializable
{

    public abstract int getAsyncNumThreads();

    public abstract String getClientURL();

    public abstract String getClientVersion();

    public abstract String getDispatcherImpl();

    public abstract int getHttpConnectionTimeout();

    public abstract int getHttpDefaultMaxPerRoute();

    public abstract int getHttpMaxTotalConnections();

    public abstract String getHttpProxyHost();

    public abstract String getHttpProxyPassword();

    public abstract int getHttpProxyPort();

    public abstract String getHttpProxyUser();

    public abstract int getHttpReadTimeout();

    public abstract int getHttpRetryCount();

    public abstract int getHttpRetryIntervalSeconds();

    public abstract int getHttpStreamingReadTimeout();

    public abstract String getMediaProvider();

    public abstract String getMediaProviderAPIKey();

    public abstract Properties getMediaProviderParameters();

    public abstract String getOAuthAccessToken();

    public abstract String getOAuthAccessTokenSecret();

    public abstract String getOAuthAccessTokenURL();

    public abstract String getOAuthAuthenticationURL();

    public abstract String getOAuthAuthorizationURL();

    public abstract String getOAuthConsumerKey();

    public abstract String getOAuthConsumerSecret();

    public abstract String getOAuthRequestTokenURL();

    public abstract String getPassword();

    public abstract Map getRequestHeaders();

    public abstract String getRestBaseURL();

    public abstract String getSearchBaseURL();

    public abstract String getSiteStreamBaseURL();

    public abstract String getStreamBaseURL();

    public abstract String getUploadBaseURL();

    public abstract String getUser();

    public abstract String getUserAgent();

    public abstract String getUserStreamBaseURL();

    public abstract boolean isDalvik();

    public abstract boolean isDebugEnabled();

    public abstract boolean isGAE();

    public abstract boolean isIncludeEntitiesEnabled();

    public abstract boolean isIncludeRTsEnabled();

    public abstract boolean isJSONStoreEnabled();

    public abstract boolean isMBeanEnabled();

    public abstract boolean isUserStreamRepliesAllEnabled();
}
