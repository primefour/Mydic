// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package android.support.v4.text;


public interface TextDirectionHeuristicCompat
{

    public abstract boolean isRtl(CharSequence charsequence, int i, int j);

    public abstract boolean isRtl(char ac[], int i, int j);
}
