// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package android.support.v4.app;

import android.app.Application;
import android.content.*;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import com.kogi.utils.FragmentCustomAnimation;
import com.kogi.webservices.ConnectivityReceiver;
import com.kogi.webservices.InternetChangedListener;
import java.io.Serializable;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package android.support.v4.app:
//            FragmentActivity, KogiApplication, FragmentManager, FragmentTransaction, 
//            Fragment

public abstract class KogiActivity extends FragmentActivity
{
    private class ActivityKiller3000Receiver extends BroadcastReceiver
    {

        public void onReceive(Context context, Intent intent)
        {
            if(intent.getAction().equals(TAG))
                finish();
        }

        final KogiActivity this$0;

        private ActivityKiller3000Receiver()
        {
            this$0 = KogiActivity.this;
            super();
        }

        ActivityKiller3000Receiver(ActivityKiller3000Receiver activitykiller3000receiver)
        {
            this();
        }
    }


    public KogiActivity()
    {
        goingBack = false;
        samePackage = false;
    }

    private boolean isGoingBack()
    {
        return goingBack;
    }

    private boolean isSamePackage()
    {
        return samePackage;
    }

    private void setGoingBack(boolean flag)
    {
        goingBack = flag;
    }

    private void setSamePackage(boolean flag)
    {
        samePackage = flag;
    }

    public boolean getBooleanParameter(Enum enum, boolean flag)
    {
        return ((KogiApplication)getApplicationContext()).getBooleanParameter(enum, flag);
    }

    public boolean getBooleanParameter(String s, boolean flag)
    {
        return ((KogiApplication)getApplicationContext()).getBooleanParameter(s, flag);
    }

    public Context getDialogContext()
    {
        if(getParent() != null)
            return getParent();
        else
            return this;
    }

    public float getFloatParameter(Enum enum, float f)
    {
        return ((KogiApplication)getApplicationContext()).getFloatParameter(enum, f);
    }

    public float getFloatParameter(String s, float f)
    {
        return ((KogiApplication)getApplicationContext()).getFloatParameter(s, f);
    }

    public int getIntegerParameter(Enum enum, int i)
    {
        return ((KogiApplication)getApplicationContext()).getIntegerParameter(enum, i);
    }

    public int getIntegerParameter(String s, int i)
    {
        return ((KogiApplication)getApplicationContext()).getIntegerParameter(s, i);
    }

    public InternetChangedListener getInternetChangedListener()
    {
        return internetChangedListener;
    }

    public JSONArray getJSONArrayParameter(Enum enum)
    {
        return ((KogiApplication)getApplicationContext()).getJSONArrayParameter(enum);
    }

    public JSONArray getJSONArrayParameter(String s)
    {
        return ((KogiApplication)getApplicationContext()).getJSONArrayParameter(s);
    }

    public JSONObject getJSONObjectParameter(Enum enum)
    {
        return ((KogiApplication)getApplicationContext()).getJSONObjectParameter(enum);
    }

    public JSONObject getJSONObjectParameter(String s)
    {
        return ((KogiApplication)getApplicationContext()).getJSONObjectParameter(s);
    }

    public long getLongParameter(Enum enum, long l)
    {
        return ((KogiApplication)getApplicationContext()).getLongParameter(enum, l);
    }

    public long getLongParameter(String s, long l)
    {
        return ((KogiApplication)getApplicationContext()).getLongParameter(s, l);
    }

    public Serializable getSerializableParameter(Enum enum)
    {
        return ((KogiApplication)getApplicationContext()).getSerializableParameter(enum);
    }

    public Serializable getSerializableParameter(String s)
    {
        return ((KogiApplication)getApplicationContext()).getSerializableParameter(s);
    }

    public String getStringParameter(Enum enum, String s)
    {
        return ((KogiApplication)getApplicationContext()).getStringParameter(enum, s);
    }

    public String getStringParameter(String s, String s1)
    {
        return ((KogiApplication)getApplicationContext()).getStringParameter(s, s1);
    }

    public ViewPager getmViewPager()
    {
        return mViewPager;
    }

    protected abstract void initData();

    protected abstract void initListeners();

    protected void initUI()
    {
    }

    protected abstract void initVars();

    protected abstract void initViews(Bundle bundle);

    protected void killActivity(String s)
    {
        Intent intent = new Intent();
        intent.setAction(s);
        sendBroadcast(intent);
    }

    protected void killAllActivities()
    {
        ((KogiApplication)getApplicationContext()).killAllExceptThis(TAG);
    }

    public void navigateClearingStackTo(Fragment fragment, int i)
    {
        FragmentManager fragmentmanager = getSupportFragmentManager();
        FragmentTransaction fragmenttransaction = fragmentmanager.beginTransaction();
        int j = 0;
        do
        {
            if(j >= fragmentmanager.getBackStackEntryCount())
            {
                fragmenttransaction.commit();
                navigateTo(fragment, i);
                return;
            }
            fragmentmanager.popBackStack();
            j++;
        } while(true);
    }

    public void navigateTo(Fragment fragment, int i)
    {
        FragmentTransaction fragmenttransaction = getSupportFragmentManager().beginTransaction();
        fragmenttransaction.replace(i, fragment);
        fragmenttransaction.addToBackStack(null);
        fragmenttransaction.commit();
    }

    public void navigateTo(Fragment fragment, int i, int j)
    {
        FragmentTransaction fragmenttransaction = getSupportFragmentManager().beginTransaction();
        fragmenttransaction.setTransition(j);
        fragmenttransaction.replace(i, fragment);
        fragmenttransaction.addToBackStack(null);
        fragmenttransaction.commit();
    }

    public void navigateTo(Fragment fragment, int i, FragmentCustomAnimation fragmentcustomanimation)
    {
        FragmentTransaction fragmenttransaction = getSupportFragmentManager().beginTransaction();
        fragmenttransaction.setCustomAnimations(fragmentcustomanimation.getEnter(), fragmentcustomanimation.getExit(), fragmentcustomanimation.getPopEnter(), fragmentcustomanimation.getPopExit());
        fragmenttransaction.replace(i, fragment);
        fragmenttransaction.addToBackStack(null);
        fragmenttransaction.commit();
    }

    public void onBackPressed()
    {
        setGoingBack(true);
        if(getSupportFragmentManager().getBackStackEntryCount() > 1)
        {
            super.onBackPressed();
            return;
        } else
        {
            finish();
            return;
        }
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        TAG = getClass().getSimpleName();
        ((KogiApplication)getApplicationContext()).registerActivity(TAG);
        saveInstanceTemp = bundle;
        activityKiller3000Receiver = new ActivityKiller3000Receiver(null);
        IntentFilter intentfilter = new IntentFilter(TAG);
        try
        {
            registerReceiver(activityKiller3000Receiver, intentfilter);
            return;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    protected void onDestroy()
    {
        unregisterReceiver(activityKiller3000Receiver);
        super.onDestroy();
    }

    protected void onPause()
    {
        super.onPause();
        try
        {
            unregisterReceiver(connectivityReceiver);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        if(!isGoingBack() && !isSamePackage())
            ((KogiApplication)getApplicationContext()).setComingFromBackGround();
        setGoingBack(false);
    }

    protected void onPostResume()
    {
        super.onPostResume();
        if(((KogiApplication)getApplicationContext()).shouldIRefresh(TAG))
            updateUI();
    }

    protected void onResume()
    {
        super.onResume();
        connectivityReceiver = new ConnectivityReceiver();
        IntentFilter intentfilter = new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE");
        try
        {
            registerReceiver(connectivityReceiver, intentfilter);
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
        setSamePackage(false);
        setGoingBack(false);
    }

    public void removeParameter(Enum enum)
    {
        ((KogiApplication)getApplicationContext()).removeParameter(enum);
    }

    public void removeParameter(String s)
    {
        ((KogiApplication)getApplicationContext()).removeParameter(s);
    }

    public void setContentView(int i)
    {
        super.setContentView(i);
        initVars();
        initViews(saveInstanceTemp);
        initListeners();
        initData();
        initUI();
        saveInstanceTemp = null;
    }

    public void setInternetChangedListener(InternetChangedListener internetchangedlistener)
    {
        internetChangedListener = internetchangedlistener;
    }

    public void setParameter(Enum enum, float f)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, f);
    }

    public void setParameter(Enum enum, int i)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, i);
    }

    public void setParameter(Enum enum, long l)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, l);
    }

    public void setParameter(Enum enum, Serializable serializable)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, serializable);
    }

    public void setParameter(Enum enum, String s)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, s);
    }

    public void setParameter(Enum enum, JSONArray jsonarray)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, jsonarray);
    }

    public void setParameter(Enum enum, JSONObject jsonobject)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, jsonobject);
    }

    public void setParameter(Enum enum, boolean flag)
    {
        ((KogiApplication)getApplicationContext()).setParameter(enum, flag);
    }

    public void setParameter(String s, float f)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, f);
    }

    public void setParameter(String s, int i)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, i);
    }

    public void setParameter(String s, long l)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, l);
    }

    public void setParameter(String s, Serializable serializable)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, serializable);
    }

    public void setParameter(String s, String s1)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, s1);
    }

    public void setParameter(String s, JSONArray jsonarray)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, jsonarray);
    }

    public void setParameter(String s, JSONObject jsonobject)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, jsonobject);
    }

    public void setParameter(String s, boolean flag)
    {
        ((KogiApplication)getApplicationContext()).setParameter(s, flag);
    }

    public void setmViewPager(ViewPager viewpager)
    {
        mViewPager = viewpager;
    }

    public void startActivity(Intent intent)
    {
        super.startActivity(intent);
        if(intent.getClass() != null)
        {
            if(intent.getComponent() != null)
            {
                if(getApplication().getPackageName().equals(intent.getComponent().getPackageName()))
                {
                    setSamePackage(true);
                    return;
                } else
                {
                    setSamePackage(false);
                    return;
                }
            } else
            {
                setSamePackage(false);
                return;
            }
        } else
        {
            setSamePackage(false);
            return;
        }
    }

    public void startActivityForResult(Intent intent, int i)
    {
        super.startActivityForResult(intent, i);
        if(intent.getClass() != null)
        {
            if(intent.getComponent() != null)
            {
                Log.d(TAG, intent.getComponent().getPackageName());
                Log.d(TAG, (new StringBuilder("Package Name: ")).append(getApplication().getPackageName()).toString());
                if(getApplication().getPackageName().equals(intent.getComponent().getPackageName()))
                {
                    setSamePackage(true);
                    return;
                } else
                {
                    setSamePackage(false);
                    return;
                }
            } else
            {
                Log.d(TAG, "content is not in this package");
                setSamePackage(false);
                return;
            }
        } else
        {
            Log.d(TAG, "class is NULL");
            setSamePackage(false);
            return;
        }
    }

    protected void updateUI()
    {
    }

    protected String TAG;
    private ActivityKiller3000Receiver activityKiller3000Receiver;
    private ConnectivityReceiver connectivityReceiver;
    private boolean goingBack;
    private InternetChangedListener internetChangedListener;
    protected ViewPager mViewPager;
    private boolean samePackage;
    private Bundle saveInstanceTemp;
}
