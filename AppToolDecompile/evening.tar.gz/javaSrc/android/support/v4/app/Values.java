// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package android.support.v4.app;


public class Values
{

    private Values()
    {
        throw new AssertionError();
    }

    public static final int CACHE_TIME_DEFAULT = 60000;
    public static final CharSequence KOGI_ASYNC_TASK_DEFAULT_CONTENT = "Loading Data...";
    public static final CharSequence KOGI_ASYNC_TASK_DEFAULT_TITLE = "Please Wait";
    public static final String MESSAGE_NO_INTERNET_CONECTION = "No network connection, please check your data configuration";

}
