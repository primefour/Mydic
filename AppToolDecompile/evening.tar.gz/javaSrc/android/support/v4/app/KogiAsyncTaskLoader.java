// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package android.support.v4.app;

import android.app.*;
import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.content.AsyncTaskLoader;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

// Referenced classes of package android.support.v4.app:
//            KogiActivity, KogiApplication, Values

public abstract class KogiAsyncTaskLoader extends AsyncTaskLoader
{

    public KogiAsyncTaskLoader(Enum enum, Activity activity)
    {
        super(activity);
        HIDE = true;
        hide = false;
        visibility = 8;
        command = enum;
        parentActivity = (KogiActivity)activity;
        context = ((KogiActivity)activity).getDialogContext();
        TAG = (new StringBuilder(String.valueOf(TAG))).append(((Activity)context).getLocalClassName()).toString();
        hide = true;
        initUI();
    }

    public KogiAsyncTaskLoader(Enum enum, Activity activity, View view)
    {
        super(activity);
        HIDE = true;
        hide = false;
        visibility = 8;
        Log.e(TAG, "WITH PROBRESS DIALOG");
        command = enum;
        parentActivity = (KogiActivity)activity;
        context = ((KogiActivity)activity).getDialogContext();
        TAG = (new StringBuilder(String.valueOf(TAG))).append(((Activity)context).getLocalClassName()).toString();
        progressViewReference = new WeakReference(view);
        hide = true;
        initUI();
    }

    public KogiAsyncTaskLoader(Enum enum, Activity activity, String s, String s1)
    {
        super(activity);
        HIDE = true;
        hide = false;
        visibility = 8;
        command = enum;
        parentActivity = (KogiActivity)activity;
        context = ((KogiActivity)activity).getDialogContext();
        TAG = ((Activity)context).getClass().getSimpleName();
        if(s != null)
            title = s;
        else
            title = "";
        if(s1 != null)
            body = s1;
        else
            body = "";
        initUI();
    }

    private void initUI()
    {
        if(!((KogiApplication)parentActivity.getApplication()).isConnectedToInternet())
            break MISSING_BLOCK_LABEL_106;
        if(title == null || body == null) goto _L2; else goto _L1
_L1:
        dialog = ProgressDialog.show(context, title, body);
_L4:
        return;
_L2:
        if(!hide)
        {
            dialog = ProgressDialog.show(context, Values.KOGI_ASYNC_TASK_DEFAULT_TITLE, Values.KOGI_ASYNC_TASK_DEFAULT_CONTENT);
            return;
        }
        Log.e(TAG, "PREGOFRESS VIEW VISIBLE");
        if(progressViewReference == null) goto _L4; else goto _L3
_L3:
        ((View)progressViewReference.get()).setVisibility(0);
        return;
        cancelLoad();
        if(noInternetMessage == null)
        {
            Toast.makeText(parentActivity, "Check your internet connection", 1).show();
            return;
        } else
        {
            Toast.makeText(parentActivity, noInternetMessage, 1).show();
            return;
        }
    }

    public volatile void deliverResult(Object obj)
    {
        deliverResult((JSONObject)obj);
    }

    public void deliverResult(JSONObject jsonobject)
    {
        super.deliverResult(jsonobject);
        try
        {
            if(progressViewReference != null)
                ((View)progressViewReference.get()).setVisibility(visibility);
            if(dialog != null && dialog.isShowing())
                dialog.dismiss();
            return;
        }
        catch(IllegalArgumentException illegalargumentexception)
        {
            Log.e(TAG, "You probably killed the parent activity before removing the dialog, try putting the super at the top of your postExecute code", illegalargumentexception);
        }
    }

    protected void onStartLoading()
    {
        super.onStartLoading();
        forceLoad();
    }

    public void setNoInternetMessage(String s)
    {
        noInternetMessage = s;
    }

    public void setProgressDialogShowOff(int i)
    {
        if(i == 4)
            visibility = 4;
    }

    protected void showDialog(String s, String s1)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setMessage(s1).setTitle(s).setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialoginterface, int i)
            {
                dialoginterface.cancel();
            }

            final KogiAsyncTaskLoader this$0;

            
            {
                this$0 = KogiAsyncTaskLoader.this;
                super();
            }
        });
        builder.create().show();
    }

    protected static String TAG;
    protected final boolean HIDE;
    private String body;
    protected Enum command;
    protected Context context;
    private ProgressDialog dialog;
    private boolean hide;
    private CharSequence noInternetMessage;
    protected KogiActivity parentActivity;
    private WeakReference progressViewReference;
    private String title;
    private int visibility;
}
