// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package android.support.v4.app;

import android.app.Application;
import android.content.*;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.http.AndroidHttpClient;
import android.os.AsyncTask;
import android.support.v4.util.LruCache;
import android.util.Log;
import android.widget.Toast;
import java.io.*;
import java.util.Enumeration;
import java.util.Hashtable;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnManagerParams;
import org.json.*;

public abstract class KogiApplication extends Application
{
    class DeleteSerializableAsyncTask extends AsyncTask
    {

        protected volatile transient Object doInBackground(Object aobj[])
        {
            return doInBackground((JSONObject[])aobj);
        }

        protected transient JSONObject doInBackground(JSONObject ajsonobject[])
        {
            try
            {
                (new File(getCacheDir(), ajsonobject[0].getString("name"))).delete();
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
            return null;
        }

        final KogiApplication this$0;

        DeleteSerializableAsyncTask()
        {
            this$0 = KogiApplication.this;
            super();
        }
    }

    class SaveSerializableAsyncTask extends AsyncTask
    {

        protected volatile transient Object doInBackground(Object aobj[])
        {
            return doInBackground((JSONObject[])aobj);
        }

        protected transient JSONObject doInBackground(JSONObject ajsonobject[])
        {
            ObjectOutputStream objectoutputstream = null;
            ObjectOutputStream objectoutputstream1 = new ObjectOutputStream(new FileOutputStream(new File(getCacheDir(), ajsonobject[0].getString("name"))));
            objectoutputstream1.writeObject(ajsonobject[0].get("serializable"));
            objectoutputstream1.flush();
            JSONException jsonexception;
            Exception exception;
            FileNotFoundException filenotfoundexception;
            IOException ioexception3;
            if(objectoutputstream1 != null)
                try
                {
                    objectoutputstream1.flush();
                    objectoutputstream1.close();
                }
                catch(IOException ioexception5)
                {
                    ioexception5.printStackTrace();
                }
            return null;
            jsonexception;
_L8:
            jsonexception.printStackTrace();
            if(objectoutputstream != null)
                try
                {
                    objectoutputstream.flush();
                    objectoutputstream.close();
                }
                catch(IOException ioexception1)
                {
                    ioexception1.printStackTrace();
                }
            break MISSING_BLOCK_LABEL_67;
            filenotfoundexception;
_L6:
            filenotfoundexception.printStackTrace();
            if(objectoutputstream != null)
                try
                {
                    objectoutputstream.flush();
                    objectoutputstream.close();
                }
                catch(IOException ioexception2)
                {
                    ioexception2.printStackTrace();
                }
            break MISSING_BLOCK_LABEL_67;
            ioexception3;
_L4:
            ioexception3.printStackTrace();
            if(objectoutputstream != null)
                try
                {
                    objectoutputstream.flush();
                    objectoutputstream.close();
                }
                catch(IOException ioexception4)
                {
                    ioexception4.printStackTrace();
                }
            break MISSING_BLOCK_LABEL_67;
            exception;
_L2:
            if(objectoutputstream != null)
                try
                {
                    objectoutputstream.flush();
                    objectoutputstream.close();
                }
                catch(IOException ioexception)
                {
                    ioexception.printStackTrace();
                }
            throw exception;
            exception;
            objectoutputstream = objectoutputstream1;
            if(true) goto _L2; else goto _L1
_L1:
            ioexception3;
            objectoutputstream = objectoutputstream1;
            if(true) goto _L4; else goto _L3
_L3:
            filenotfoundexception;
            objectoutputstream = objectoutputstream1;
            if(true) goto _L6; else goto _L5
_L5:
            jsonexception;
            objectoutputstream = objectoutputstream1;
            if(true) goto _L8; else goto _L7
_L7:
        }

        final KogiApplication this$0;

        SaveSerializableAsyncTask()
        {
            this$0 = KogiApplication.this;
            super();
        }
    }


    protected KogiApplication()
    {
        connectedToInternet = false;
        cacheSize = 0x100000;
        parametersBoolean = new Hashtable();
        parametersFloat = new Hashtable();
        parametersInteger = new Hashtable();
        parametersLong = new Hashtable();
        parametersString = new Hashtable();
        parametersJSONObject = new LruCache(cacheSize);
        parametersJSONArray = new LruCache(cacheSize);
        parametersSerializable = new Hashtable();
        registeredActivities = new Hashtable();
        cacheTimes = new Hashtable();
        TAG = getClass().getSimpleName();
        appClient = AndroidHttpClient.newInstance("Android Mobile");
        ConnManagerParams.setTimeout(appClient.getParams(), 30000L);
    }

    private void checkInternet()
    {
        ConnectivityManager connectivitymanager = (ConnectivityManager)getSystemService("connectivity");
        if(connectivitymanager.getActiveNetworkInfo() != null)
        {
            if(connectivitymanager.getActiveNetworkInfo().isConnected())
            {
                setConnectedToInternet(true);
                return;
            } else
            {
                setConnectedToInternet(false);
                return;
            }
        } else
        {
            setConnectedToInternet(false);
            return;
        }
    }

    public static AndroidHttpClient getAppClient()
    {
        return appClient;
    }

    public static void setAppClient(AndroidHttpClient androidhttpclient)
    {
        appClient = androidhttpclient;
    }

    protected void finalize()
        throws Throwable
    {
        super.finalize();
        try
        {
            appClient.getConnectionManager().shutdown();
            appClient.close();
            return;
        }
        catch(Exception exception)
        {
            exception.printStackTrace();
        }
    }

    public boolean getBooleanParameter(Enum enum, boolean flag)
    {
        return getBooleanParameter(enum.name(), flag);
    }

    public boolean getBooleanParameter(String s, boolean flag)
    {
        if(parametersBoolean.containsKey(s))
        {
            return ((Boolean)parametersBoolean.get(s)).booleanValue();
        } else
        {
            boolean flag1 = getSharedPreferences(TAG, 0).getBoolean(s, flag);
            parametersBoolean.put(s, Boolean.valueOf(flag1));
            return flag1;
        }
    }

    public int getCacheTime(int i)
    {
        if(cacheTimes.containsKey(Integer.valueOf(i)))
            return ((Integer)cacheTimes.get(Integer.valueOf(i))).intValue();
        else
            return 0;
    }

    public float getFloatParameter(Enum enum, float f)
    {
        return getFloatParameter(enum.name(), f);
    }

    public float getFloatParameter(String s, float f)
    {
        if(parametersFloat.containsKey(s))
        {
            return ((Float)parametersFloat.get(s)).floatValue();
        } else
        {
            float f1 = getSharedPreferences(TAG, 0).getFloat(s, f);
            parametersFloat.put(s, Float.valueOf(f1));
            return f1;
        }
    }

    public int getIntegerParameter(Enum enum, int i)
    {
        return getIntegerParameter(enum.name(), i);
    }

    public int getIntegerParameter(String s, int i)
    {
        if(parametersInteger.containsKey(s))
        {
            return ((Integer)parametersInteger.get(s)).intValue();
        } else
        {
            int j = getSharedPreferences(TAG, 0).getInt(s, i);
            parametersInteger.put(s, Integer.valueOf(j));
            return j;
        }
    }

    public JSONArray getJSONArrayParameter(Enum enum)
    {
        return getJSONArrayParameter(enum.name());
    }

    public JSONArray getJSONArrayParameter(String s)
    {
        if(parametersJSONArray.get(s) != null)
            return (JSONArray)parametersJSONArray.get(s);
        String s1 = getSharedPreferences(TAG, 0).getString(s, "");
        JSONArray jsonarray;
        try
        {
            jsonarray = new JSONArray(s1);
        }
        catch(Exception exception)
        {
            jsonarray = new JSONArray();
            Log.d("TAG", (new StringBuilder("Fail reading JSONArray Parameter ")).append(s).toString(), exception);
        }
        parametersJSONArray.put(s, jsonarray);
        return jsonarray;
    }

    public JSONObject getJSONObjectParameter(Enum enum)
    {
        return getJSONObjectParameter(enum.name());
    }

    public JSONObject getJSONObjectParameter(String s)
    {
        if(parametersJSONObject.get(s) != null)
            return (JSONObject)parametersJSONObject.get(s);
        String s1 = getSharedPreferences(TAG, 0).getString(s, "");
        JSONObject jsonobject;
        try
        {
            jsonobject = new JSONObject(s1);
        }
        catch(Exception exception)
        {
            Log.d("TAG", (new StringBuilder("Fail reading JSONObject Parameter ")).append(s).toString(), exception);
            jsonobject = new JSONObject();
        }
        parametersJSONObject.put(s, jsonobject);
        return jsonobject;
    }

    public long getLongParameter(Enum enum, long l)
    {
        return getLongParameter(enum.name(), l);
    }

    public long getLongParameter(String s, long l)
    {
        if(parametersLong.containsKey(s))
        {
            return ((Long)parametersLong.get(s)).longValue();
        } else
        {
            long l1 = getSharedPreferences(TAG, 0).getLong(s, l);
            parametersLong.put(s, Long.valueOf(l1));
            return l1;
        }
    }

    public Serializable getSerializableParameter(Enum enum)
    {
        return getSerializableParameter(enum.name());
    }

    public Serializable getSerializableParameter(String s)
    {
        if(parametersSerializable.containsKey(s))
            return (Serializable)parametersSerializable.get(s);
        Serializable serializable;
        ObjectInputStream objectinputstream = new ObjectInputStream(new FileInputStream(new File(getCacheDir(), s)));
        serializable = (Serializable)objectinputstream.readObject();
        objectinputstream.close();
        return serializable;
        FileNotFoundException filenotfoundexception;
        filenotfoundexception;
        filenotfoundexception.printStackTrace();
_L2:
        return null;
        StreamCorruptedException streamcorruptedexception;
        streamcorruptedexception;
        streamcorruptedexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        IOException ioexception;
        ioexception;
        ioexception.printStackTrace();
        continue; /* Loop/switch isn't completed */
        ClassNotFoundException classnotfoundexception;
        classnotfoundexception;
        classnotfoundexception.printStackTrace();
        if(true) goto _L2; else goto _L1
_L1:
    }

    public String getStringParameter(Enum enum, String s)
    {
        return getStringParameter(enum.name(), s);
    }

    public String getStringParameter(String s, String s1)
    {
        if(parametersString.containsKey(s))
        {
            return (String)parametersString.get(s);
        } else
        {
            String s2 = getSharedPreferences(TAG, 0).getString(s, s1);
            parametersString.put(s, s2);
            return s2;
        }
    }

    protected abstract void initParameters();

    public boolean isConnectedToInternet()
    {
        return connectedToInternet;
    }

    public void killAllExceptThis(String s)
    {
        Enumeration enumeration = registeredActivities.keys();
        do
        {
            if(!enumeration.hasMoreElements())
                return;
            try
            {
                String s1 = (String)enumeration.nextElement();
                if(!s1.equals(s))
                {
                    Intent intent = new Intent();
                    intent.setAction(s1);
                    sendBroadcast(intent);
                }
            }
            catch(Exception exception)
            {
                exception.printStackTrace();
            }
        } while(true);
    }

    public void onCreate()
    {
        super.onCreate();
        checkInternet();
        initParameters();
    }

    public void registerActivity(String s)
    {
        registeredActivities.put(s, Boolean.valueOf(false));
    }

    public void removeParameter(Enum enum)
    {
        removeParameter(enum.name());
    }

    public void removeParameter(String s)
    {
        if(parametersBoolean.containsKey(s))
        {
            parametersBoolean.remove(s);
            android.content.SharedPreferences.Editor editor6 = getSharedPreferences(TAG, 0).edit();
            editor6.remove(s);
            editor6.commit();
            return;
        }
        if(parametersFloat.containsKey(s))
        {
            parametersFloat.remove(s);
            android.content.SharedPreferences.Editor editor5 = getSharedPreferences(TAG, 0).edit();
            editor5.remove(s);
            editor5.commit();
            return;
        }
        if(parametersInteger.containsKey(s))
        {
            parametersInteger.remove(s);
            android.content.SharedPreferences.Editor editor4 = getSharedPreferences(TAG, 0).edit();
            editor4.remove(s);
            editor4.commit();
            return;
        }
        if(parametersSerializable.containsKey(s))
        {
            try
            {
                JSONObject jsonobject = (new JSONObject()).put("name", s);
                (new DeleteSerializableAsyncTask()).execute(new JSONObject[] {
                    jsonobject
                });
                return;
            }
            catch(JSONException jsonexception)
            {
                jsonexception.printStackTrace();
            }
            return;
        }
        if(parametersLong.containsKey(s))
        {
            parametersLong.remove(s);
            android.content.SharedPreferences.Editor editor3 = getSharedPreferences(TAG, 0).edit();
            editor3.remove(s);
            editor3.commit();
            return;
        }
        if(parametersString.containsKey(s))
        {
            parametersString.remove(s);
            android.content.SharedPreferences.Editor editor2 = getSharedPreferences(TAG, 0).edit();
            editor2.remove(s);
            editor2.commit();
            return;
        }
        try
        {
            parametersJSONArray.remove(s);
            android.content.SharedPreferences.Editor editor1 = getSharedPreferences(TAG, 0).edit();
            editor1.remove(s);
            editor1.commit();
        }
        catch(Exception exception) { }
        try
        {
            parametersJSONObject.remove(s);
            android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
            editor.remove(s);
            editor.commit();
            return;
        }
        catch(Exception exception1)
        {
            return;
        }
    }

    public void setCacheSize(int i)
    {
        cacheSize = i;
        parametersJSONObject = new LruCache(cacheSize);
        parametersJSONArray = new LruCache(cacheSize);
    }

    public void setCacheTime(int i, int j)
    {
        cacheTimes.put(Integer.valueOf(i), Integer.valueOf(j));
    }

    public void setComingFromBackGround()
    {
        Enumeration enumeration = registeredActivities.keys();
        do
        {
            if(!enumeration.hasMoreElements())
                return;
            String s = (String)enumeration.nextElement();
            registeredActivities.put(s, Boolean.valueOf(true));
        } while(true);
    }

    public void setConnectedToInternet(boolean flag)
    {
        connectedToInternet = flag;
    }

    public void setParameter(Enum enum, float f)
    {
        setParameter(enum.name(), f);
    }

    public void setParameter(Enum enum, int i)
    {
        setParameter(enum.name(), i);
    }

    public void setParameter(Enum enum, long l)
    {
        setParameter(enum.name(), l);
    }

    public void setParameter(Enum enum, Serializable serializable)
    {
        setParameter(enum.name(), serializable);
    }

    public void setParameter(Enum enum, String s)
    {
        setParameter(enum.name(), s);
    }

    public void setParameter(Enum enum, JSONArray jsonarray)
    {
        setParameter(enum.name(), jsonarray);
    }

    public void setParameter(Enum enum, JSONObject jsonobject)
    {
        setParameter(enum.name(), jsonobject);
    }

    public void setParameter(Enum enum, boolean flag)
    {
        setParameter(enum.name(), flag);
    }

    public void setParameter(String s, float f)
    {
        parametersFloat.put(s, Float.valueOf(f));
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putFloat(s, f);
        editor.commit();
    }

    public void setParameter(String s, int i)
    {
        parametersInteger.put(s, Integer.valueOf(i));
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putInt(s, i);
        editor.commit();
    }

    public void setParameter(String s, long l)
    {
        parametersLong.put(s, Long.valueOf(l));
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putLong(s, l);
        editor.commit();
    }

    public void setParameter(String s, Serializable serializable)
    {
        parametersSerializable.put(s, serializable);
        try
        {
            JSONObject jsonobject = (new JSONObject()).put("name", s).put("serializable", serializable);
            (new SaveSerializableAsyncTask()).execute(new JSONObject[] {
                jsonobject
            });
            return;
        }
        catch(JSONException jsonexception)
        {
            jsonexception.printStackTrace();
        }
    }

    public void setParameter(String s, String s1)
    {
        parametersString.put(s, s1);
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putString(s, s1);
        editor.commit();
    }

    public void setParameter(String s, JSONArray jsonarray)
    {
        parametersJSONArray.put(s, jsonarray);
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putString(s, jsonarray.toString());
        editor.commit();
    }

    public void setParameter(String s, JSONObject jsonobject)
    {
        parametersJSONObject.put(s, jsonobject);
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putString(s, jsonobject.toString());
        editor.commit();
    }

    public void setParameter(String s, boolean flag)
    {
        parametersBoolean.put(s, Boolean.valueOf(flag));
        android.content.SharedPreferences.Editor editor = getSharedPreferences(TAG, 0).edit();
        editor.putBoolean(s, flag);
        editor.commit();
    }

    public boolean shouldIRefresh(String s)
    {
        boolean flag = ((Boolean)registeredActivities.get(s)).booleanValue();
        registeredActivities.put(s, Boolean.valueOf(false));
        return flag;
    }

    public void showNoInternetMessage(Context context)
    {
        Toast.makeText(context, "No network connection, please check your data configuration", 1).show();
    }

    public static final String KILL_EM_ALL = "killEmAmBaby";
    protected static String TAG;
    protected static AndroidHttpClient appClient;
    private int cacheSize;
    private Hashtable cacheTimes;
    private boolean connectedToInternet;
    private Hashtable parametersBoolean;
    private Hashtable parametersFloat;
    private Hashtable parametersInteger;
    private LruCache parametersJSONArray;
    private LruCache parametersJSONObject;
    private Hashtable parametersLong;
    private Hashtable parametersSerializable;
    private Hashtable parametersString;
    private Hashtable registeredActivities;
}
