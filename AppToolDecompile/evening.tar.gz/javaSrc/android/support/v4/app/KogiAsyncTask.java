// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: packimports(3) 

package android.support.v4.app;

import android.app.*;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Toast;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

// Referenced classes of package android.support.v4.app:
//            KogiActivity, KogiApplication, Values

public abstract class KogiAsyncTask extends AsyncTask
{

    public KogiAsyncTask(Enum enum, KogiActivity kogiactivity)
    {
        HIDE = true;
        hide = false;
        visibility = 8;
        command = enum;
        parentActivity = kogiactivity;
        context = kogiactivity.getDialogContext();
        TAG = (new StringBuilder(String.valueOf(TAG))).append(((Activity)context).getLocalClassName()).toString();
        hide = true;
    }

    public KogiAsyncTask(Enum enum, KogiActivity kogiactivity, View view)
    {
        HIDE = true;
        hide = false;
        visibility = 8;
        command = enum;
        parentActivity = kogiactivity;
        context = kogiactivity.getDialogContext();
        TAG = (new StringBuilder(String.valueOf(TAG))).append(((Activity)context).getLocalClassName()).toString();
        progressViewReference = new WeakReference(view);
        hide = true;
    }

    public KogiAsyncTask(Enum enum, KogiActivity kogiactivity, String s, String s1)
    {
        HIDE = true;
        hide = false;
        visibility = 8;
        command = enum;
        parentActivity = kogiactivity;
        context = kogiactivity.getDialogContext();
        TAG = ((Activity)context).getClass().getSimpleName();
        if(s != null)
            title = s;
        else
            title = "";
        if(s1 != null)
        {
            body = s1;
            return;
        } else
        {
            body = "";
            return;
        }
    }

    protected volatile void onPostExecute(Object obj)
    {
        onPostExecute((JSONObject)obj);
    }

    protected void onPostExecute(JSONObject jsonobject)
    {
        super.onPostExecute(jsonobject);
        try
        {
            if(progressViewReference != null)
                ((View)progressViewReference.get()).setVisibility(visibility);
            if(dialog != null && dialog.isShowing())
                dialog.dismiss();
            return;
        }
        catch(IllegalArgumentException illegalargumentexception)
        {
            Log.e(TAG, "You probably killed the parent activity before removing the dialog, try putting the super at the top of your postExecute code", illegalargumentexception);
        }
    }

    protected void onPreExecute()
    {
        if(!((KogiApplication)parentActivity.getApplication()).isConnectedToInternet())
            break MISSING_BLOCK_LABEL_101;
        super.onPreExecute();
        if(title == null || body == null) goto _L2; else goto _L1
_L1:
        dialog = ProgressDialog.show(context, title, body);
_L4:
        return;
_L2:
        if(!hide)
        {
            dialog = ProgressDialog.show(context, Values.KOGI_ASYNC_TASK_DEFAULT_TITLE, Values.KOGI_ASYNC_TASK_DEFAULT_CONTENT);
            return;
        }
        if(progressViewReference == null) goto _L4; else goto _L3
_L3:
        ((View)progressViewReference.get()).setVisibility(0);
        return;
        cancel(true);
        if(noInternetMessage == null)
        {
            Toast.makeText(parentActivity, "Check your internet connection", 1).show();
            return;
        } else
        {
            Toast.makeText(parentActivity, noInternetMessage, 1).show();
            return;
        }
    }

    public void setNoInternetMessage(String s)
    {
        noInternetMessage = s;
    }

    public void setProgressDialogShowOff(int i)
    {
        if(i == 4)
            visibility = 4;
    }

    protected void showDialog(String s, String s1)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setMessage(s1).setTitle(s).setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialoginterface, int i)
            {
                dialoginterface.cancel();
            }

            final KogiAsyncTask this$0;

            
            {
                this$0 = KogiAsyncTask.this;
                super();
            }
        });
        builder.create().show();
    }

    protected static String TAG;
    protected final boolean HIDE;
    private String body;
    protected Enum command;
    protected Context context;
    private ProgressDialog dialog;
    private boolean hide;
    private CharSequence noInternetMessage;
    protected KogiActivity parentActivity;
    private WeakReference progressViewReference;
    private String title;
    private int visibility;
}
