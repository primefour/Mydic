<?php
  echo "Here is a very simple PHP statement.<br />";
?>

