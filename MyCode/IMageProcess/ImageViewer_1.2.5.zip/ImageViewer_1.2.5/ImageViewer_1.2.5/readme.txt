To ease debug of imaging omx component a viewer dedicated to imaging's format has been developped.

You can download it here:  https://codexstn.cro.st.com/file/showfiles.php?group_id=746

For support and enhancement request please send a mail to laurent.regnier@stericsson.com with "support ImageViewer" in title

Enjoy

Laurent Regnier

 

 

ImageViewer release 1.2.4.B (February 2011)

 

Introduction

This soft allows viewing, manipulating, saving images coded in various format supported by the camera team

It is based on the armivproc and uses QT as graphic interface

 

Main functionnalities

- Read various imaging formats (see list bellow) + jpeg and bmp format

- Write various imaging formats (see list bellow).

- Image rotation (90, 180, 270�)

- Image flipping (along X, Y, XY axis)

- Support downscale to any size

- Embedded face_detection (use the same algorythm as face_detection omx component)

- Support drop of many images

- Can step between images in an animated sequence

- Stores information for already opened images (size and format) for easy re-opening

- autodetect format within filename ( resolution eg: 640x480 or vga, format eg: 420mb)

 

 

Supported format:

Format                     Extension (default)  Description

YUV 420 macro block       , 420mb             , macroblock 3 planes Y,Cr,Cb (1:4:4) 

YUV 422 macro block       , 422mb             , macroblock 3 planes Y,Cr,Cb (1:2:2) 

RGB 565 16 bits           , Rgb565            , 1 plane RGB 

RGB 888 3B/p              , Rgb888            , 1 plane RGB 

yuv 888i                  , yuv888i           , 1 plane YUV (8:8:8) 

yuv 844i                  , yuv844i           , 1 plane YUV (8:4:4) 

YUV 420 blue first 1.5B/p , I420              , 3 planes Y,Cb,Cr (1:4:4) 

YUV 420 red first 1.5B/p  , YV12              , 3 planes Y,Cr,Cb (1:4:4) 

YUV422 planar blue first  , 422pb             , 3 planes, 2B/p, Y,Cb,Cr (1:2:2) 

YUV422 planar red first   , 422p              , 3 planes, 2B/p, Y,Cr,Cb (1:2:2) 

NV21 -> Y-V/U 1.5B/p      , NV21              , 2 planes Y, V/U (1:4:4) 

NV12 -> Y-U/V 1.5B/p      , NV12              , 2 planes Y, V/U (1:4:4) 

YUV422i Y Cb Y Cr         , YCbYCr            , 1 plane interleaved, 16 bits/p, Y0-Cb-Y1-Cr 

YUV422i Cr Y Cb Y         , CrYCbY            , 1 plane interleaved, 16 bits/p, Cr-Y0-Cb-Y1 

YUV422i Y Cr Y Cb         , YCrYCb            , 1 plane interleaved, 16 bits/p, Y0-Cr-Y1-Cb 

YUV422i Cb Y Cr Y         , CbYCrY            , 1 plane interleaved, 16 bits/p, Cb-Y0-Cr-Y1 

YUV planar blue first     , YUVpb             , 3 planes, 3B/p, Y,Cb,Cr 

YUV planar red first      , YUVp              , 3 planes, 3B/p, Y,Cr,Cb 

raw8 camera format        , (raw8) raw        , 1 planes, 1B/p, 

 

Native format (write not supported)

jpeg format               , jpg , to be filled 

BMP format                , bmp , header=54 bytes 

 

AutoDetected resolution:

The sofware recognizes resolutions like 640x480, 320_240. Central delimitor can be one of [_-xX ]. The resolution must be prefixed by one of [-_ ].

It also recognizes predefined resolution like vga, qcif ... prefixed by one of [-_ ].

 

List of recognized format:

"CGA"  , 320  , 200 
"QCIF" , 176  , 144 
"QVGA" , 320  , 240 
"VGA"  , 640  , 480 
"SVGA" , 800  , 600 
"XGA"  , 1024 , 768 
"XGA+" , 1152 , 864 
"XGA+2", 1280 , 600 
"HDTV" , 1280 , 720 
"WXGA" , 1280 , 768 
"WXGA" , 1280 , 800 
"WXGA2", 1280 , 854 
"SXGA" , 1280 , 960 
"UVGA" , 1280 , 960 
"SXGA" , 1280 , 1024 
"WXGA" , 1360 , 768 
"WSXGA", 1440 , 900 
"HD+"  , 1600 , 900 
"UXGA" , 1600 , 1200 
"WSXGA+" , 1680 , 1050 
"HDTV" , 1920 , 1080 
"WUXGA", 1920 , 1200 
"8M_basco" , 3288 , 2448
rotated format are also supported (eg: VGA 90�).

Format isn't case sensitive.

 

 

Opening a file:

Usually "open" is used for native formats (jpeg and bmp) and "open as" for imaging ones.

The software recognises .img .yuv .gam as extensions for image format. Obviously you can override them.

When you open an image for the first time, the filename is used to try to retreive resolution and format. If this information is not found, a dialog is displayed for allowing you to fill missing info. If all needed information are present, the dialog isn't opened exept if the 'CTRL' key is pressed.

When an image has been already opened, the software try first to retreive format's information in its database (64 entries), then if not found in the filename (like for first open). You can still press 'CTRL' key to force the format dialog to open

 

  

Dropping files:

Just select your files in the explorer and drop them in the ImageViewer. If more than one file is selected a dialog box is displayed between each image.

 

  

Displaying multi-images files:

When you are viewing a file that contains more than one image, the first one is displayed. You can navigate thrue other images by pressing key 'N' for next or 'P' for previous. You can also use menu. Image index is displayed in the status bar.

 

Status bar:

Relevant information are displayed in the status bar. Resolution, zoom factor, format description...

 

 

Face detection:

Face detection algorythm is embedded on the application. It's the same as used in face_detection omx component. When faces are found, a green rectangle is displayed an d the number of detected faces is displayed on the status bar. 

 

Rotation, Mirror, downscale, Zoom in out...:

See in menu for available command. You can also find associated shorcut when exist.

