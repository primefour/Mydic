/**
 * PigLatinTranslatorPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Sep 23, 2006 (12:31:18 GMT+00:00) WSDL2Java emitter.
 */

package com.httprecipes.www._1._11.soap;

public interface PigLatinTranslatorPortType extends java.rmi.Remote {
    public java.lang.String translate(java.lang.String inputString) throws java.rmi.RemoteException;
}
