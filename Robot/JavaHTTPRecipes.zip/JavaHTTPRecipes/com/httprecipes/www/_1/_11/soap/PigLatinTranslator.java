/**
 * PigLatinTranslator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Sep 23, 2006 (12:31:18 GMT+00:00) WSDL2Java emitter.
 */

package com.httprecipes.www._1._11.soap;

public interface PigLatinTranslator extends javax.xml.rpc.Service {
    public java.lang.String getPigLatinTranslatorPortAddress();

    public com.httprecipes.www._1._11.soap.PigLatinTranslatorPortType getPigLatinTranslatorPort() throws javax.xml.rpc.ServiceException;

    public com.httprecipes.www._1._11.soap.PigLatinTranslatorPortType getPigLatinTranslatorPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
