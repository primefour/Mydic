HTTP Programming Recipes for Java Bots
by Jeff Heaton
ISBN: 0-9773206-6-9
===============================================================================

This archive contains the source code for the above book.  For more information about
this book visit the following URL:

http://www.heatonresearch.com/articles/series/16/